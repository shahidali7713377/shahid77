// lib/main.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:workmanager/workmanager.dart';
import 'core/constants/app_constants.dart';
import 'core/theme/app_theme.dart';
import 'core/utils/notification_service.dart';
import 'data/repositories/prayer_repository.dart';
import 'data/repositories/sadqa_repository.dart';
import 'presentation/blocs/prayer/prayer_bloc.dart';
import 'presentation/blocs/qaza/qaza_bloc.dart';
import 'presentation/blocs/sadqa/sadqa_bloc.dart';
import 'presentation/blocs/tasbeeh/tasbeeh_bloc.dart';
import 'presentation/blocs/settings/settings_bloc.dart';
import 'presentation/screens/main_shell.dart';

@pragma('vm:entry-point')
void callbackDispatcher() {
  Workmanager().executeTask((task, _) async {
    await NotificationService.instance.initialize();
    if (task == 'reschedule') {
      await NotificationService.instance.scheduleAllPrayer();
      await NotificationService.instance.scheduleSadqaReminder();
    } else if (task == 'auto_miss') {
      final repo = PrayerRepository();
      await repo.autoMarkMissed(DateTime.now().subtract(const Duration(days: 1)));
    }
    return true;
  });
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(statusBarColor: Colors.transparent));

  await NotificationService.instance.initialize();
  await NotificationService.instance.requestPermission();

  await Workmanager().initialize(callbackDispatcher, isInDebugMode: false);
  await Workmanager().registerPeriodicTask('reschedule', 'reschedule', frequency: const Duration(hours: 24));
  await Workmanager().registerPeriodicTask('auto_miss', 'auto_miss', frequency: const Duration(hours: 24));

  await NotificationService.instance.scheduleAllPrayer();
  await NotificationService.instance.scheduleSadqaReminder();

  final prefs = await SharedPreferences.getInstance();
  final darkMode = prefs.getBool(AppConstants.keyDarkMode) ?? false;

  runApp(MyApp(initialDarkMode: darkMode));
}

class MyApp extends StatelessWidget {
  final bool initialDarkMode;
  const MyApp({super.key, this.initialDarkMode = false});

  @override
  Widget build(BuildContext context) {
    return MultiRepositoryProvider(
      providers: [
        RepositoryProvider(create: (_) => PrayerRepository()),
        RepositoryProvider(create: (_) => SadqaRepository()),
      ],
      child: MultiBlocProvider(
        providers: [
          BlocProvider(create: (ctx) => PrayerBloc(repo: ctx.read<PrayerRepository>())..add(const LoadToday())),
          BlocProvider(create: (ctx) => QazaBloc(repo: ctx.read<PrayerRepository>())..add(const LoadQaza())),
          BlocProvider(create: (ctx) => SadqaBloc(repo: ctx.read<SadqaRepository>())..add(const LoadSadqa())),
          BlocProvider(create: (_) => TasbeehBloc()..add(LoadTasbeeh())),
          BlocProvider(create: (_) => SettingsBloc()..add(LoadSettings())),
        ],
        child: BlocBuilder<SettingsBloc, SettingsState>(
          builder: (_, settings) => MaterialApp(
            title: AppConstants.appName,
            debugShowCheckedModeBanner: false,
            theme: AppTheme.light,
            darkTheme: AppTheme.dark,
            themeMode: settings.darkMode ? ThemeMode.dark : ThemeMode.light,
            home: const MainShell(),
          ),
        ),
      ),
    );
  }
}
