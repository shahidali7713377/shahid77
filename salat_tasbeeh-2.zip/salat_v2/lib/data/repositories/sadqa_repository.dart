// lib/data/repositories/sadqa_repository.dart
import '../database/database_helper.dart';
import '../models/sadqa_model.dart';
import '../../core/utils/date_utils.dart';

class SadqaRepository {
  final _db = DatabaseHelper.instance;

  Future<int> add({required DateTime date, required double amount, String? notes}) =>
      _db.insertSadqa(date: AppDateUtils.toDb(date), amount: amount, notes: notes);

  Future<int> update(SadqaModel s) =>
      _db.updateSadqa(id: s.id!, date: s.date, amount: s.amount, notes: s.notes);

  Future<int> delete(int id) => _db.deleteSadqa(id);

  Future<List<SadqaModel>> forDate(DateTime date) async =>
      (await _db.getSadqaDate(AppDateUtils.toDb(date))).map(SadqaModel.fromMap).toList();

  Future<List<SadqaModel>> forMonth(DateTime month) async =>
      (await _db.getSadqaMonth(AppDateUtils.toYM(month))).map(SadqaModel.fromMap).toList();

  Future<double> monthTotal(DateTime m) => _db.totalSadqa(ym: AppDateUtils.toYM(m));
  Future<double> allTimeTotal() => _db.totalSadqa();

  Future<double> todayTotal() async {
    final items = await forDate(DateTime.now());
    return items.fold(0.0, (s, e) => s + e.amount);
  }
}
