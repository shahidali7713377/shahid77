// lib/data/repositories/prayer_repository.dart
import '../database/database_helper.dart';
import '../models/prayer_model.dart';
import '../../core/constants/app_constants.dart';
import '../../core/utils/date_utils.dart';

class PrayerRepository {
  final _db = DatabaseHelper.instance;

  Future<void> initDay(DateTime date) => _db.initDayPrayers(AppDateUtils.toDb(date));

  Future<List<PrayerModel>> getPrayersForDate(DateTime date) async {
    final s = AppDateUtils.toDb(date);
    final maps = await _db.getPrayersForDate(s);
    final names = maps.map((m) => m['prayer_name'] as String).toSet();
    return AppConstants.prayerNames.map((n) {
      if (names.contains(n)) return PrayerModel.fromMap(maps.firstWhere((m) => m['prayer_name'] == n));
      return PrayerModel(date: s, prayerName: n);
    }).toList();
  }

  Future<void> markOffered(DateTime date, String name) async {
    await _db.upsertPrayer(
      date: AppDateUtils.toDb(date), prayerName: name,
      status: AppConstants.statusOffered, offeredTime: DateTime.now().toIso8601String(),
    );
  }

  Future<void> markMissed(DateTime date, String name) async {
    final s = AppDateUtils.toDb(date);
    final ex = await _db.getPrayer(s, name);
    if (ex != null && ex['status'] == AppConstants.statusOffered) return;
    await _db.upsertPrayer(
      date: s, prayerName: name, status: AppConstants.statusMissed,
      nafalCount: (ex?['nafal_count'] as int?) ?? 0,
    );
  }

  Future<void> updateNafal(DateTime date, String name, int count) =>
      _db.updateNafalCount(AppDateUtils.toDb(date), name, count);

  Future<void> autoMarkMissed(DateTime date) => _db.autoMarkMissed(AppDateUtils.toDb(date));

  // ── Qaza ──────────────────────────────────────────────────────────────────

  Future<QazaSummary> getQazaSummary() async {
    final remaining = await _db.remainingQazaCount();
    final offered   = await _db.offeredQazaCount();
    final grouped   = await _db.getQazaByDate();
    final typed = grouped.map((k, v) => MapEntry(k, v.map(PrayerModel.fromMap).toList()));
    return QazaSummary(totalRemaining: remaining, totalOffered: offered, byDate: typed);
  }

  Future<List<PrayerModel>> getRemainingQaza() async {
    return (await _db.getRemainingQaza()).map(PrayerModel.fromMap).toList();
  }

  Future<List<PrayerModel>> getOfferedQaza() async {
    return (await _db.getOfferedQaza()).map(PrayerModel.fromMap).toList();
  }

  Future<void> offerQaza(int id) => _db.offerQaza(id);
  Future<void> undoQaza(int id)  => _db.undoQaza(id);

  // ── Calendar / Analytics ──────────────────────────────────────────────────

  Future<Map<DateTime, DailyPrayerData>> getCalendarData(DateTime start, DateTime end) async {
    final maps = await _db.getPrayersRange(AppDateUtils.toDb(start), AppDateUtils.toDb(end));
    final Map<DateTime, DailyPrayerData> out = {};
    for (final m in maps) {
      final p = PrayerModel.fromMap(m);
      final d = AppDateUtils.fromDb(p.date);
      final key = DateTime(d.year, d.month, d.day);
      out.putIfAbsent(key, () => DailyPrayerData(date: p.date, prayers: {}));
      out[key]!.prayers[p.prayerName] = p;
    }
    return out;
  }

  Future<AnalyticsData> getAnalytics(DateTime start, DateTime end) async {
    final s = AppDateUtils.toDb(start);
    final e = AppDateUtils.toDb(end);
    final data = await _db.getAnalytics(s, e);
    final days = AppDateUtils.daysBetween(start, end) + 1;
    return AnalyticsData(
      startDate: start, endDate: end, totalDays: days,
      totalExpected: days * 5,
      totalOffered: data['total_offered'] ?? 0,
      totalMissed: data['total_missed'] ?? 0,
      missedPerPrayer: {for (final n in AppConstants.prayerNames) n: data['missed_${n.toLowerCase()}'] ?? 0},
    );
  }
}
