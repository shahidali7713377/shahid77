// lib/data/database/database_helper.dart
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../../core/constants/app_constants.dart';

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._();
  static Database? _db;
  DatabaseHelper._();

  Future<Database> get db async => _db ??= await _init();

  Future<Database> _init() async {
    final path = join(await getDatabasesPath(), AppConstants.dbName);
    return openDatabase(path, version: AppConstants.dbVersion, onCreate: _onCreate);
  }

  Future<void> _onCreate(Database db, int v) async {
    await db.execute('''
      CREATE TABLE prayers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        date TEXT NOT NULL,
        prayer_name TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'Pending',
        nafal_count INTEGER NOT NULL DEFAULT 0,
        offered_time TEXT,
        qaza_offered INTEGER NOT NULL DEFAULT 0,
        qaza_offered_time TEXT,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      )
    ''');
    await db.execute('''
      CREATE TABLE sadqa (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        date TEXT NOT NULL,
        amount REAL NOT NULL,
        notes TEXT,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      )
    ''');
    await db.execute('''
      CREATE TABLE tasbeeh_sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        date TEXT NOT NULL,
        count INTEGER NOT NULL DEFAULT 0
      )
    ''');
    await db.execute('CREATE INDEX idx_p_date ON prayers(date)');
    await db.execute('CREATE INDEX idx_p_name ON prayers(prayer_name)');
    await db.execute('CREATE UNIQUE INDEX idx_p_date_name ON prayers(date, prayer_name)');
    await db.execute('CREATE INDEX idx_p_qaza ON prayers(status, qaza_offered)');
    await db.execute('CREATE INDEX idx_s_date ON sadqa(date)');
  }

  // ── Prayers ───────────────────────────────────────────────────────────────

  Future<int> upsertPrayer({
    required String date, required String prayerName, required String status,
    int nafalCount = 0, String? offeredTime,
    int qazaOffered = 0, String? qazaOfferedTime,
  }) async {
    final d = await db;
    final existing = await d.query('prayers',
        where: 'date=? AND prayer_name=?', whereArgs: [date, prayerName]);
    if (existing.isEmpty) {
      return d.insert('prayers', {
        'date': date, 'prayer_name': prayerName, 'status': status,
        'nafal_count': nafalCount, 'offered_time': offeredTime,
        'qaza_offered': qazaOffered, 'qaza_offered_time': qazaOfferedTime,
      });
    } else {
      final id = existing.first['id'] as int;
      await d.update('prayers', {
        'status': status, 'nafal_count': nafalCount, 'offered_time': offeredTime,
        'qaza_offered': qazaOffered, 'qaza_offered_time': qazaOfferedTime,
      }, where: 'id=?', whereArgs: [id]);
      return id;
    }
  }

  Future<Map<String, dynamic>?> getPrayer(String date, String name) async {
    final d = await db;
    final r = await d.query('prayers',
        where: 'date=? AND prayer_name=?', whereArgs: [date, name]);
    return r.isNotEmpty ? r.first : null;
  }

  Future<List<Map<String, dynamic>>> getPrayersForDate(String date) async {
    final d = await db;
    return d.query('prayers', where: 'date=?', whereArgs: [date]);
  }

  Future<void> updateNafalCount(String date, String name, int count) async {
    final d = await db;
    final ex = await getPrayer(date, name);
    if (ex == null) {
      await d.insert('prayers', {
        'date': date, 'prayer_name': name,
        'status': AppConstants.statusPending, 'nafal_count': count, 'qaza_offered': 0,
      });
    } else {
      await d.update('prayers', {'nafal_count': count},
          where: 'date=? AND prayer_name=?', whereArgs: [date, name]);
    }
  }

  /// Marks all PENDING prayers for [date] as Missed.
  /// Pass [prayerTimeCutoff] to only miss prayers whose time has passed.
  /// When called at midnight (no cutoff) all remaining pending become missed.
  Future<void> autoMarkMissed(String date, {DateTime? prayerTimeCutoff}) async {
    final d = await db;
    for (final name in AppConstants.prayerNames) {
      final ex = await getPrayer(date, name);
      if (ex == null) {
        // Create a missed record for this prayer
        await d.insert('prayers', {
          'date': date, 'prayer_name': name,
          'status': AppConstants.statusMissed, 'nafal_count': 0, 'qaza_offered': 0,
        });
      } else if (ex['status'] == AppConstants.statusPending) {
        await d.update('prayers', {'status': AppConstants.statusMissed},
            where: 'date=? AND prayer_name=?', whereArgs: [date, name]);
      }
    }
  }

  Future<void> initDayPrayers(String date) async {
    for (final name in AppConstants.prayerNames) {
      final ex = await getPrayer(date, name);
      if (ex == null) {
        final d = await db;
        await d.insert('prayers', {
          'date': date, 'prayer_name': name,
          'status': AppConstants.statusPending, 'nafal_count': 0, 'qaza_offered': 0,
        });
      }
    }
  }

  // ── Qaza ──────────────────────────────────────────────────────────────────

  Future<List<Map<String, dynamic>>> getRemainingQaza() async {
    final d = await db;
    return d.rawQuery(
      "SELECT * FROM prayers WHERE status='Missed' AND qaza_offered=0 ORDER BY date ASC, prayer_name ASC",
    );
  }

  Future<Map<String, List<Map<String, dynamic>>>> getQazaByDate() async {
    final rows = await getRemainingQaza();
    final Map<String, List<Map<String, dynamic>>> out = {};
    for (final r in rows) {
      final date = r['date'] as String;
      out.putIfAbsent(date, () => []).add(r);
    }
    return out;
  }

  Future<int> remainingQazaCount() async {
    final d = await db;
    return Sqflite.firstIntValue(await d.rawQuery(
          "SELECT COUNT(*) FROM prayers WHERE status='Missed' AND qaza_offered=0")) ?? 0;
  }

  Future<int> offeredQazaCount() async {
    final d = await db;
    return Sqflite.firstIntValue(await d.rawQuery(
          "SELECT COUNT(*) FROM prayers WHERE status='Missed' AND qaza_offered=1")) ?? 0;
  }

  Future<void> offerQaza(int id) async {
    final d = await db;
    await d.update('prayers', {
      'qaza_offered': 1,
      'qaza_offered_time': DateTime.now().toIso8601String(),
    }, where: 'id=?', whereArgs: [id]);
  }

  Future<void> undoQaza(int id) async {
    final d = await db;
    await d.update('prayers',
        {'qaza_offered': 0, 'qaza_offered_time': null},
        where: 'id=?', whereArgs: [id]);
  }

  Future<List<Map<String, dynamic>>> getOfferedQaza() async {
    final d = await db;
    return d.rawQuery(
      "SELECT * FROM prayers WHERE status='Missed' AND qaza_offered=1 ORDER BY qaza_offered_time DESC",
    );
  }

  // ── Analytics ─────────────────────────────────────────────────────────────

  Future<List<Map<String, dynamic>>> getPrayersRange(String s, String e) async {
    final d = await db;
    return d.query('prayers',
        where: 'date BETWEEN ? AND ?', whereArgs: [s, e], orderBy: 'date ASC');
  }

  Future<Map<String, int>> getAnalytics(String s, String e) async {
    final d = await db;
    final offered = Sqflite.firstIntValue(await d.rawQuery(
          "SELECT COUNT(*) FROM prayers WHERE date BETWEEN ? AND ? AND status='Offered'",
          [s, e])) ?? 0;
    final missed = Sqflite.firstIntValue(await d.rawQuery(
          "SELECT COUNT(*) FROM prayers WHERE date BETWEEN ? AND ? AND status='Missed'",
          [s, e])) ?? 0;
    final out = <String, int>{'total_offered': offered, 'total_missed': missed};
    for (final n in AppConstants.prayerNames) {
      out['missed_${n.toLowerCase()}'] = Sqflite.firstIntValue(await d.rawQuery(
            "SELECT COUNT(*) FROM prayers WHERE date BETWEEN ? AND ? AND prayer_name=? AND status='Missed'",
            [s, e, n])) ?? 0;
    }
    return out;
  }

  // ── Sadqa ─────────────────────────────────────────────────────────────────

  Future<int> insertSadqa({required String date, required double amount, String? notes}) async {
    final d = await db;
    return d.insert('sadqa', {'date': date, 'amount': amount, 'notes': notes});
  }

  Future<int> updateSadqa({required int id, required String date, required double amount, String? notes}) async {
    final d = await db;
    return d.update('sadqa', {'date': date, 'amount': amount, 'notes': notes},
        where: 'id=?', whereArgs: [id]);
  }

  Future<int> deleteSadqa(int id) async {
    final d = await db;
    return d.delete('sadqa', where: 'id=?', whereArgs: [id]);
  }

  Future<List<Map<String, dynamic>>> getSadqaDate(String date) async {
    final d = await db;
    return d.query('sadqa', where: 'date=?', whereArgs: [date], orderBy: 'id DESC');
  }

  Future<List<Map<String, dynamic>>> getSadqaMonth(String ym) async {
    final d = await db;
    return d.query('sadqa', where: 'date LIKE ?', whereArgs: ['$ym%'], orderBy: 'date DESC');
  }

  Future<double> totalSadqa({String? ym}) async {
    final d = await db;
    final r = ym != null
        ? await d.rawQuery("SELECT SUM(amount) as t FROM sadqa WHERE date LIKE ?", ['$ym%'])
        : await d.rawQuery("SELECT SUM(amount) as t FROM sadqa");
    return (r.first['t'] as num?)?.toDouble() ?? 0;
  }

  // ── Tasbeeh ───────────────────────────────────────────────────────────────

  Future<void> saveTasbeeh(String date, int count) async {
    final d = await db;
    final ex = await d.query('tasbeeh_sessions', where: 'date=?', whereArgs: [date]);
    if (ex.isEmpty) {
      await d.insert('tasbeeh_sessions', {'date': date, 'count': count});
    } else {
      await d.update('tasbeeh_sessions', {'count': count}, where: 'date=?', whereArgs: [date]);
    }
  }

  Future<int> getTasbeeh(String date) async {
    final d = await db;
    final r = await d.query('tasbeeh_sessions', where: 'date=?', whereArgs: [date]);
    return r.isNotEmpty ? (r.first['count'] as int) : 0;
  }
}
