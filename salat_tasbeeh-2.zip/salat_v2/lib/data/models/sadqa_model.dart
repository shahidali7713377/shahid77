// lib/data/models/sadqa_model.dart
class SadqaModel {
  final int? id;
  final String date;
  final double amount;
  final String? notes;

  const SadqaModel({this.id, required this.date, required this.amount, this.notes});

  factory SadqaModel.fromMap(Map<String, dynamic> m) => SadqaModel(
    id: m['id'] as int?,
    date: m['date'] as String,
    amount: (m['amount'] as num).toDouble(),
    notes: m['notes'] as String?,
  );

  SadqaModel copyWith({int? id, String? date, double? amount, String? notes}) =>
      SadqaModel(
        id: id ?? this.id, date: date ?? this.date,
        amount: amount ?? this.amount, notes: notes ?? this.notes,
      );
}
