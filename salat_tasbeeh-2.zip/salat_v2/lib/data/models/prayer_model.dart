// lib/data/models/prayer_model.dart
import '../../core/constants/app_constants.dart';

class PrayerModel {
  final int? id;
  final String date;
  final String prayerName;
  final String status;
  final int nafalCount;
  final String? offeredTime;
  final bool qazaOffered;
  final String? qazaOfferedTime;

  const PrayerModel({
    this.id, required this.date, required this.prayerName,
    this.status = AppConstants.statusPending, this.nafalCount = 0,
    this.offeredTime, this.qazaOffered = false, this.qazaOfferedTime,
  });

  factory PrayerModel.fromMap(Map<String, dynamic> m) => PrayerModel(
    id: m['id'] as int?,
    date: m['date'] as String,
    prayerName: m['prayer_name'] as String,
    status: m['status'] as String? ?? AppConstants.statusPending,
    nafalCount: m['nafal_count'] as int? ?? 0,
    offeredTime: m['offered_time'] as String?,
    qazaOffered: (m['qaza_offered'] as int? ?? 0) == 1,
    qazaOfferedTime: m['qaza_offered_time'] as String?,
  );

  PrayerModel copyWith({
    int? id, String? date, String? prayerName, String? status,
    int? nafalCount, String? offeredTime, bool? qazaOffered, String? qazaOfferedTime,
  }) => PrayerModel(
    id: id ?? this.id, date: date ?? this.date, prayerName: prayerName ?? this.prayerName,
    status: status ?? this.status, nafalCount: nafalCount ?? this.nafalCount,
    offeredTime: offeredTime ?? this.offeredTime, qazaOffered: qazaOffered ?? this.qazaOffered,
    qazaOfferedTime: qazaOfferedTime ?? this.qazaOfferedTime,
  );

  bool get isOffered => status == AppConstants.statusOffered;
  bool get isMissed  => status == AppConstants.statusMissed;
  bool get isPending => status == AppConstants.statusPending;
  bool get isRemainingQaza => isMissed && !qazaOffered;
  bool get isCompletedQaza => isMissed && qazaOffered;
}

// Grouped summary used by QazaBloc
class QazaSummary {
  final int totalRemaining;
  final int totalOffered;
  final Map<String, List<PrayerModel>> byDate; // date-string → prayers

  const QazaSummary({
    required this.totalRemaining, required this.totalOffered, required this.byDate,
  });

  int get totalEver => totalRemaining + totalOffered;
  double get completionPct => totalEver > 0 ? totalOffered / totalEver : 0;
}

// For analytics screen
class AnalyticsData {
  final DateTime startDate, endDate;
  final int totalDays, totalExpected, totalOffered, totalMissed;
  final Map<String, int> missedPerPrayer;

  const AnalyticsData({
    required this.startDate, required this.endDate, required this.totalDays,
    required this.totalExpected, required this.totalOffered, required this.totalMissed,
    required this.missedPerPrayer,
  });

  double get consistencyPct => totalExpected > 0 ? totalOffered / totalExpected * 100 : 0;
}

// For calendar
class DailyPrayerData {
  final String date;
  final Map<String, PrayerModel> prayers;
  DailyPrayerData({required this.date, required this.prayers});
  int get offeredCount => prayers.values.where((p) => p.isOffered).length;
  int get missedCount  => prayers.values.where((p) => p.isMissed).length;
}
