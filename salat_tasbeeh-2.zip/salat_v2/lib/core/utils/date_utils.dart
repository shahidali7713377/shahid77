// lib/core/utils/date_utils.dart
import 'package:intl/intl.dart';

class AppDateUtils {
  static final _db = DateFormat('yyyy-MM-dd');
  static final _display = DateFormat('dd MMM yyyy');
  static final _month = DateFormat('MMMM yyyy');
  static final _time = DateFormat('hh:mm a');
  static final _ym = DateFormat('yyyy-MM');

  static String toDb(DateTime d) => _db.format(d);
  static String toDisplay(DateTime d) => _display.format(d);
  static String toMonth(DateTime d) => _month.format(d);
  static String toTime(DateTime d) => _time.format(d);
  static String toYM(DateTime d) => _ym.format(d);
  static DateTime fromDb(String s) => _db.parse(s);
  static String todayDb() => toDb(DateTime.now());
  static bool isToday(DateTime d) {
    final n = DateTime.now();
    return d.year == n.year && d.month == n.month && d.day == n.day;
  }
  static int daysBetween(DateTime a, DateTime b) {
    final an = DateTime(a.year, a.month, a.day, 12);
    final bn = DateTime(b.year, b.month, b.day, 12);
    return bn.difference(an).inDays;
  }
  static DateTime firstOfMonth(DateTime d) => DateTime(d.year, d.month, 1);
  static DateTime lastOfMonth(DateTime d) => DateTime(d.year, d.month + 1, 0);
}
