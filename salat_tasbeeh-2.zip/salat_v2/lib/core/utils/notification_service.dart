// lib/core/utils/notification_service.dart
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest.dart' as tz;
import 'package:shared_preferences/shared_preferences.dart';
import '../constants/app_constants.dart';
import 'prayer_calculator.dart';

class NotificationService {
  static final NotificationService instance = NotificationService._();
  final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  bool _initialized = false;
  NotificationService._();

  Future<void> initialize() async {
    if (_initialized) return;
    tz.initializeTimeZones();
    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosInit = DarwinInitializationSettings(
      requestAlertPermission: true, requestBadgePermission: true, requestSoundPermission: true,
    );
    await _plugin.initialize(
      const InitializationSettings(android: androidInit, iOS: iosInit),
      onDidReceiveNotificationResponse: (_) {},
    );
    // Create channels
    final android = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await android?.createNotificationChannel(const AndroidNotificationChannel(
      'prayer_channel', 'Prayer Notifications',
      description: 'Alerts before each prayer time',
      importance: Importance.high, playSound: true, enableVibration: true,
    ));
    await android?.createNotificationChannel(const AndroidNotificationChannel(
      'sadqa_channel', 'Sadqa Reminder',
      description: 'Daily reminder to give Sadqa',
      importance: Importance.defaultImportance, playSound: true,
    ));
    _initialized = true;
  }

  Future<void> requestPermission() async {
    final android = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    final ios = _plugin.resolvePlatformSpecificImplementation<IOSFlutterLocalNotificationsPlugin>();
    await android?.requestNotificationsPermission();
    await ios?.requestPermissions(alert: true, badge: true, sound: true);
  }

  // ── Prayer Notifications ──────────────────────────────────────────────────

  Future<void> scheduleAllPrayer() async {
    final prefs = await SharedPreferences.getInstance();
    final enabled = prefs.getBool(AppConstants.keyNotifEnabled) ?? true;
    if (!enabled) { await cancelAllPrayer(); return; }
    final offset = prefs.getInt(AppConstants.keyNotifOffset) ?? AppConstants.defaultNotifOffset;
    await cancelAllPrayer();
    final now = DateTime.now();
    final ids = {
      AppConstants.fajr: AppConstants.fajrNotifId, AppConstants.zuhr: AppConstants.zuhrNotifId,
      AppConstants.asr: AppConstants.asrNotifId, AppConstants.maghrib: AppConstants.maghribNotifId,
      AppConstants.isha: AppConstants.ishaNotifId,
    };
    for (int d = 0; d <= 1; d++) {
      final pt = await PrayerCalculatorService.getPrayerTimes(date: now.add(Duration(days: d)));
      if (pt == null) continue;
      for (final e in pt.toMap().entries) {
        final notifTime = e.value.subtract(Duration(minutes: offset));
        if (notifTime.isAfter(now)) {
          await _schedulePrayer(
            id: ids[e.key]! + d * 10,
            name: e.key, time: notifTime, offset: offset,
          );
        }
      }
    }
  }

  Future<void> _schedulePrayer({required int id, required String name, required DateTime time, required int offset}) async {
    await _plugin.zonedSchedule(
      id, '🕌 $name Prayer',
      '$name prayer in $offset minutes. Time to prepare!',
      tz.TZDateTime.from(time, tz.local),
      const NotificationDetails(
        android: AndroidNotificationDetails('prayer_channel', 'Prayer Notifications',
            importance: Importance.high, priority: Priority.high, icon: '@mipmap/ic_launcher'),
        iOS: DarwinNotificationDetails(presentAlert: true, presentBadge: true, presentSound: true),
      ),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
    );
  }

  Future<void> cancelAllPrayer() async {
    for (int i = 1; i <= 5; i++) { await _plugin.cancel(i); await _plugin.cancel(i + 10); }
  }

  // ── Sadqa Daily Reminder ──────────────────────────────────────────────────

  Future<void> scheduleSadqaReminder() async {
    final prefs = await SharedPreferences.getInstance();
    final enabled = prefs.getBool(AppConstants.keySadqaNotifEnabled) ?? false;
    await _plugin.cancel(AppConstants.sadqaNotifId);
    if (!enabled) return;

    final hour = prefs.getInt(AppConstants.keySadqaNotifHour) ?? AppConstants.defaultSadqaHour;
    final minute = prefs.getInt(AppConstants.keySadqaNotifMinute) ?? AppConstants.defaultSadqaMinute;
    final now = DateTime.now();
    var scheduled = DateTime(now.year, now.month, now.day, hour, minute);
    if (scheduled.isBefore(now)) scheduled = scheduled.add(const Duration(days: 1));

    await _plugin.zonedSchedule(
      AppConstants.sadqaNotifId,
      '🤲 Daily Sadqa Reminder',
      "Today's Sadqa is pending. Give charity and earn blessings!",
      tz.TZDateTime.from(scheduled, tz.local),
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'sadqa_channel', 'Sadqa Reminder',
          importance: Importance.defaultImportance, priority: Priority.defaultPriority,
          icon: '@mipmap/ic_launcher',
          styleInformation: BigTextStyleInformation(
            "Today's Sadqa is pending. Every act of charity counts. Give what you can! 🤲"),
        ),
        iOS: DarwinNotificationDetails(presentAlert: true, presentBadge: false, presentSound: true),
      ),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
      matchDateTimeComponents: DateTimeComponents.time, // repeats daily
    );
  }

  Future<void> cancelAll() async => await _plugin.cancelAll();
}
