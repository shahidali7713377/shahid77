// lib/core/utils/prayer_calculator.dart
import 'package:adhan/adhan.dart';
import 'package:geolocator/geolocator.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../constants/app_constants.dart';

class PrayerTimesResult {
  final DateTime fajr, zuhr, asr, maghrib, isha;
  const PrayerTimesResult({
    required this.fajr, required this.zuhr, required this.asr,
    required this.maghrib, required this.isha,
  });
  DateTime? byName(String n) {
    switch (n) {
      case AppConstants.fajr: return fajr;
      case AppConstants.zuhr: return zuhr;
      case AppConstants.asr: return asr;
      case AppConstants.maghrib: return maghrib;
      case AppConstants.isha: return isha;
      default: return null;
    }
  }
  Map<String, DateTime> toMap() => {
    AppConstants.fajr: fajr, AppConstants.zuhr: zuhr, AppConstants.asr: asr,
    AppConstants.maghrib: maghrib, AppConstants.isha: isha,
  };
}

class PrayerCalculatorService {
  static Future<Position?> getLocation() async {
    try {
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
        if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) return null;
      }
      if (perm == LocationPermission.deniedForever) return null;
      return await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.medium,
          timeLimit: const Duration(seconds: 10));
    } catch (_) { return null; }
  }

  static Future<PrayerTimesResult?> getPrayerTimes({double? lat, double? lng, DateTime? date}) async {
    double? la = lat, lo = lng;
    if (la == null || lo == null) {
      final p = await SharedPreferences.getInstance();
      la = p.getDouble(AppConstants.keyLat);
      lo = p.getDouble(AppConstants.keyLng);
    }
    if (la == null || lo == null) {
      final pos = await getLocation();
      if (pos != null) {
        la = pos.latitude; lo = pos.longitude;
        final p = await SharedPreferences.getInstance();
        await p.setDouble(AppConstants.keyLat, la);
        await p.setDouble(AppConstants.keyLng, lo);
      } else { la = 24.8607; lo = 67.0011; } // default Karachi
    }
    return _calc(la, lo, date ?? DateTime.now());
  }

  static PrayerTimesResult _calc(double lat, double lng, DateTime date) {
    final coords = Coordinates(lat, lng);
    final params = CalculationMethod.karachi.getParameters()..madhab = Madhab.hanafi;
    final dc = DateComponents(date.year, date.month, date.day);
    final pt = PrayerTimes(coords, dc, params);
    return PrayerTimesResult(
      fajr: pt.fajr, zuhr: pt.dhuhr, asr: pt.asr, maghrib: pt.maghrib, isha: pt.isha,
    );
  }

  static Future<void> saveLocation(double lat, double lng) async {
    final p = await SharedPreferences.getInstance();
    await p.setDouble(AppConstants.keyLat, lat);
    await p.setDouble(AppConstants.keyLng, lng);
  }
}
