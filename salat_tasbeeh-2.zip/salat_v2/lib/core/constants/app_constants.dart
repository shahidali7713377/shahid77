// lib/core/constants/app_constants.dart

class AppConstants {
  static const String appName = 'Salat & Tasbeeh';
  static const String dbName = 'salat_tasbeeh_v2.db';
  static const int dbVersion = 1;

  static const String fajr = 'Fajr';
  static const String zuhr = 'Zuhr';
  static const String asr = 'Asr';
  static const String maghrib = 'Maghrib';
  static const String isha = 'Isha';
  static const List<String> prayerNames = [fajr, zuhr, asr, maghrib, isha];

  static const String statusOffered = 'Offered';
  static const String statusMissed = 'Missed';
  static const String statusPending = 'Pending';

  // Notification IDs
  static const int fajrNotifId = 1;
  static const int zuhrNotifId = 2;
  static const int asrNotifId = 3;
  static const int maghribNotifId = 4;
  static const int ishaNotifId = 5;
  static const int sadqaNotifId = 20;

  // SharedPrefs keys
  static const String keyNotifEnabled = 'notifications_enabled';
  static const String keyNotifOffset = 'notification_offset_minutes';
  static const String keyLat = 'last_lat';
  static const String keyLng = 'last_lng';
  static const String keyTasbeehCount = 'tasbeeh_count';
  static const String keyDarkMode = 'dark_mode';
  static const String keySadqaNotifEnabled = 'sadqa_notif_enabled';
  static const String keySadqaNotifHour = 'sadqa_notif_hour';
  static const String keySadqaNotifMinute = 'sadqa_notif_minute';

  // Tracks the last date prayers were loaded — survives app restarts
  static const String keyLastLoadedDate = 'last_loaded_prayer_date';

  static const int defaultNotifOffset = 10;
  static const List<int> notifOffsets = [5, 10, 15, 20];
  static const int defaultSadqaHour = 20;
  static const int defaultSadqaMinute = 0;
}

// ── Rakat configuration ───────────────────────────────────────────────────────

enum RakatType { farz, sunnah, sunnahGM, nafal, witr }

class RakatInfo {
  final int count;
  final RakatType type;
  final String label;
  const RakatInfo({required this.count, required this.type, required this.label});
}

class PrayerRakats {
  static const Map<String, List<RakatInfo>> rakats = {
    AppConstants.fajr: [
      RakatInfo(count: 2, type: RakatType.sunnah, label: '2 Rakat Sunnah'),
      RakatInfo(count: 2, type: RakatType.farz, label: '2 Rakat Farz'),
    ],
    AppConstants.zuhr: [
      RakatInfo(count: 4, type: RakatType.sunnah, label: '4 Rakat Sunnah'),
      RakatInfo(count: 4, type: RakatType.farz, label: '4 Rakat Farz'),
      RakatInfo(count: 2, type: RakatType.sunnah, label: '2 Rakat Sunnah'),
      RakatInfo(count: 2, type: RakatType.nafal, label: '2 Rakat Nafal'),
    ],
    AppConstants.asr: [
      RakatInfo(count: 4, type: RakatType.sunnahGM, label: '4 Rakat Sunnah (Ghair Muakkadah)'),
      RakatInfo(count: 4, type: RakatType.farz, label: '4 Rakat Farz'),
    ],
    AppConstants.maghrib: [
      RakatInfo(count: 3, type: RakatType.farz, label: '3 Rakat Farz'),
      RakatInfo(count: 2, type: RakatType.sunnah, label: '2 Rakat Sunnah'),
      RakatInfo(count: 2, type: RakatType.nafal, label: '2 Rakat Nafal'),
    ],
    AppConstants.isha: [
      RakatInfo(count: 4, type: RakatType.sunnah, label: '4 Rakat Sunnah'),
      RakatInfo(count: 4, type: RakatType.farz, label: '4 Rakat Farz'),
      RakatInfo(count: 2, type: RakatType.sunnah, label: '2 Rakat Sunnah'),
      RakatInfo(count: 2, type: RakatType.nafal, label: '2 Rakat Nafal'),
      RakatInfo(count: 3, type: RakatType.witr, label: '3 Rakat Witr (Wajib)'),
    ],
  };
}
