// lib/presentation/screens/all_qaza_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/date_utils.dart';
import '../../data/models/prayer_model.dart';
import '../blocs/qaza/qaza_bloc.dart';

class AllQazaScreen extends StatefulWidget {
  const AllQazaScreen({super.key});
  @override State<AllQazaScreen> createState() => _AllQazaScreenState();
}

class _AllQazaScreenState extends State<AllQazaScreen> with SingleTickerProviderStateMixin {
  late TabController _tabs;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 2, vsync: this);
    context.read<QazaBloc>().add(const LoadQaza());
  }

  @override
  void dispose() { _tabs.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: BlocBuilder<QazaBloc, QazaState>(
          builder: (_, s) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('All Qaza Prayers'),
            Text('${s.remaining} remaining · ${s.offered} offered',
                style: const TextStyle(fontSize: 12, color: Colors.white70)),
          ]),
        ),
        bottom: TabBar(
          controller: _tabs,
          indicatorColor: AppColors.accent,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white54,
          tabs: const [
            Tab(icon: Icon(Icons.pending_actions), text: 'Remaining'),
            Tab(icon: Icon(Icons.verified_outlined), text: 'Offered'),
          ],
        ),
      ),
      body: BlocConsumer<QazaBloc, QazaState>(
        listener: (ctx, s) {
          if (s.snackMessage != null) {
            ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(
              content: Text(s.snackMessage!),
              backgroundColor: AppColors.offered,
              duration: const Duration(seconds: 2),
            ));
          }
        },
        builder: (ctx, s) {
          if (s.isLoading) {
            return const Center(child: CircularProgressIndicator(color: AppColors.primary));
          }
          return Column(children: [
            _progressBar(s),
            Expanded(child: TabBarView(controller: _tabs, children: [
              _remainingTab(ctx, s),
              _offeredTab(ctx, s),
            ])),
          ]);
        },
      ),
    );
  }

  Widget _progressBar(QazaState s) {
    final pct = s.total > 0 ? s.offered / s.total : 0.0;
    return Container(
      padding: const EdgeInsets.all(16),
      color: Theme.of(context).cardColor,
      child: Column(children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
          _statBox('Total', s.total, AppColors.primary, Icons.history_edu),
          _statBox('Remaining', s.remaining, AppColors.missed, Icons.pending_actions),
          _statBox('Offered', s.offered, Colors.teal, Icons.check_circle),
        ]),
        if (s.total > 0) ...[
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: ClipRRect(
              borderRadius: BorderRadius.circular(6),
              child: LinearProgressIndicator(
                value: pct,
                backgroundColor: AppColors.missed.withOpacity(0.15),
                valueColor: const AlwaysStoppedAnimation(Colors.teal),
                minHeight: 10,
              ),
            )),
            const SizedBox(width: 10),
            Text('${(pct * 100).toStringAsFixed(0)}%',
                style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.teal, fontSize: 15)),
          ]),
        ],
      ]),
    );
  }

  Widget _statBox(String label, int val, Color color, IconData icon) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
    decoration: BoxDecoration(
      color: color.withOpacity(0.08),
      borderRadius: BorderRadius.circular(12),
      border: Border.all(color: color.withOpacity(0.2)),
    ),
    child: Column(children: [
      Icon(icon, color: color, size: 20),
      const SizedBox(height: 4),
      Text('$val', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20, color: color)),
      Text(label, style: TextStyle(fontSize: 10, color: color.withOpacity(0.7))),
    ]),
  );

  Widget _remainingTab(BuildContext ctx, QazaState s) {
    final byDate = s.summary?.byDate ?? {};
    if (byDate.isEmpty) {
      return _empty('No remaining qaza!', 'Alhamdulillah - all offered.');
    }
    final dates = byDate.keys.toList()..sort();
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: dates.length,
      itemBuilder: (_, i) => _group(ctx, dates[i], byDate[dates[i]]!, isRemaining: true),
    );
  }

  Widget _offeredTab(BuildContext ctx, QazaState s) {
    if (s.offeredList.isEmpty) {
      return _empty('No qaza offered yet', 'Tap "Offer Qaza" to start tracking.');
    }
    final Map<String, List<PrayerModel>> grouped = {};
    for (final p in s.offeredList) {
      final key = p.qazaOfferedTime != null
          ? AppDateUtils.toDb(DateTime.parse(p.qazaOfferedTime!))
          : p.date;
      grouped.putIfAbsent(key, () => []).add(p);
    }
    final dates = grouped.keys.toList()..sort((a, b) => b.compareTo(a));
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: dates.length,
      itemBuilder: (_, i) => _group(ctx, dates[i], grouped[dates[i]]!, isRemaining: false),
    );
  }

  Widget _group(BuildContext ctx, String dateStr, List<PrayerModel> prayers, {required bool isRemaining}) {
    final color = isRemaining ? AppColors.missed : Colors.teal;
    DateTime date;
    try { date = AppDateUtils.fromDb(dateStr); } catch (_) { date = DateTime.now(); }

    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.25)),
        color: Theme.of(context).cardColor,
      ),
      child: Column(children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            color: color.withOpacity(0.07),
            borderRadius: const BorderRadius.vertical(top: Radius.circular(15)),
          ),
          child: Row(children: [
            Icon(isRemaining ? Icons.calendar_today : Icons.event_available, size: 14, color: color),
            const SizedBox(width: 8),
            Text(
              isRemaining
                  ? 'Missed on: ${AppDateUtils.toDisplay(date)}'
                  : 'Offered on: ${AppDateUtils.toDisplay(date)}',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: color),
            ),
            const Spacer(),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(10)),
              child: Text('${prayers.length} prayer${prayers.length > 1 ? "s" : ""}',
                  style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: color)),
            ),
          ]),
        ),
        ...prayers.map((p) => _row(ctx, p, isRemaining: isRemaining)),
      ]),
    );
  }

  Widget _row(BuildContext ctx, PrayerModel prayer, {required bool isRemaining}) {
    return Container(
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 10),
      decoration: BoxDecoration(border: Border(top: BorderSide(color: Colors.grey.withOpacity(0.1)))),
      child: Row(children: [
        Text(_emoji(prayer.prayerName), style: const TextStyle(fontSize: 24)),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(prayer.prayerName, style: TextStyle(
            fontWeight: FontWeight.bold, fontSize: 15,
            color: isRemaining ? AppColors.missed : Colors.teal,
          )),
          if (!isRemaining && prayer.qazaOfferedTime != null)
            Text('Offered at ${AppDateUtils.toTime(DateTime.parse(prayer.qazaOfferedTime!))}',
                style: const TextStyle(fontSize: 11, color: Colors.teal)),
          if (!isRemaining)
            Text('Originally missed: ${AppDateUtils.toDisplay(AppDateUtils.fromDb(prayer.date))}',
                style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
        ])),
        if (isRemaining)
          ElevatedButton(
            onPressed: () => _doOffer(ctx, prayer),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.missed, foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              minimumSize: const Size(95, 34),
              textStyle: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            ),
            child: const Text('Offer Qaza'),
          )
        else
          TextButton.icon(
            onPressed: () => _doUndo(ctx, prayer),
            icon: const Icon(Icons.undo, size: 16),
            label: const Text('Undo'),
            style: TextButton.styleFrom(foregroundColor: Colors.teal),
          ),
      ]),
    );
  }

  void _doOffer(BuildContext ctx, PrayerModel prayer) {
    showDialog(context: ctx, builder: (_) => AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      title: Row(children: [
        Text(_emoji(prayer.prayerName), style: const TextStyle(fontSize: 26)),
        const SizedBox(width: 8),
        Expanded(child: Text('Offer ${prayer.prayerName} Qaza')),
      ]),
      content: Text(
        'Confirm you offered the qaza for ${prayer.prayerName} that was missed on '
        '${AppDateUtils.toDisplay(AppDateUtils.fromDb(prayer.date))}.\n\n'
        'Remaining count will reduce by 1.',
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
        ElevatedButton(
          onPressed: () { Navigator.pop(ctx); ctx.read<QazaBloc>().add(OfferQaza(prayer)); },
          style: ElevatedButton.styleFrom(backgroundColor: AppColors.offered),
          child: const Text('Yes, Offered!'),
        ),
      ],
    ));
  }

  void _doUndo(BuildContext ctx, PrayerModel prayer) {
    showDialog(context: ctx, builder: (_) => AlertDialog(
      title: const Text('Undo Qaza Offer?'),
      content: const Text('This prayer will return to the remaining list.'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
        TextButton(
          onPressed: () { Navigator.pop(ctx); ctx.read<QazaBloc>().add(UndoQaza(prayer)); },
          child: const Text('Undo', style: TextStyle(color: AppColors.missed)),
        ),
      ],
    ));
  }

  Widget _empty(String title, String sub) => Center(
    child: Padding(padding: const EdgeInsets.all(32), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      const Text('📿', style: TextStyle(fontSize: 64)),
      const SizedBox(height: 16),
      Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
      const SizedBox(height: 8),
      Text(sub, style: const TextStyle(color: AppColors.textSecondary), textAlign: TextAlign.center),
    ])),
  );

  String _emoji(String n) {
    switch (n) {
      case AppConstants.fajr: return '🌅'; case AppConstants.zuhr: return '☀️';
      case AppConstants.asr: return '🌤'; case AppConstants.maghrib: return '🌆';
      case AppConstants.isha: return '🌙'; default: return '🕌';
    }
  }
}
