// lib/presentation/screens/sadqa_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/date_utils.dart';
import '../../data/models/sadqa_model.dart';
import '../blocs/sadqa/sadqa_bloc.dart';

class SadqaScreen extends StatefulWidget {
  const SadqaScreen({super.key});
  @override State<SadqaScreen> createState() => _SadqaScreenState();
}

class _SadqaScreenState extends State<SadqaScreen> {
  @override
  void initState() {
    super.initState();
    context.read<SadqaBloc>().add(const LoadSadqa());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Sadqa Tracker')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showAddEdit(context),
        backgroundColor: AppColors.accent,
        icon: const Icon(Icons.add, color: Colors.white),
        label: const Text('Add Sadqa', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
      ),
      body: BlocBuilder<SadqaBloc, SadqaState>(
        builder: (ctx, state) {
          if (state.isLoading) return const Center(child: CircularProgressIndicator(color: AppColors.accent));
          return ListView(children: [
            _header(ctx, state),
            _monthNav(ctx, state),
            if (state.entries.isEmpty)
              const Padding(
                padding: EdgeInsets.all(48),
                child: Center(child: Column(children: [
                  Text('🤲', style: TextStyle(fontSize: 56)),
                  SizedBox(height: 12),
                  Text('No sadqa recorded this month', style: TextStyle(fontSize: 15, color: AppColors.textSecondary)),
                ])),
              )
            else
              ...state.entries.map((s) => _tile(ctx, s)),
            const SizedBox(height: 100),
          ]);
        },
      ),
    );
  }

  Widget _header(BuildContext ctx, SadqaState state) => Container(
    margin: const EdgeInsets.all(16),
    padding: const EdgeInsets.all(20),
    decoration: BoxDecoration(
      gradient: const LinearGradient(colors: [Color(0xFF795548), Color(0xFF6D4C41)], begin: Alignment.topLeft, end: Alignment.bottomRight),
      borderRadius: BorderRadius.circular(20),
      boxShadow: [BoxShadow(color: const Color(0xFF795548).withOpacity(0.3), blurRadius: 12, offset: const Offset(0, 4))],
    ),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Row(children: [
        Text('🤲 ', style: TextStyle(fontSize: 22)),
        Text('Sadqa Tracker', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
      ]),
      const SizedBox(height: 14),
      Row(children: [
        Expanded(child: _stat2('Today', 'PKR ${state.todayTotal.toStringAsFixed(0)}')),
        const SizedBox(width: 8),
        Expanded(child: _stat2('This Month', 'PKR ${state.monthTotal.toStringAsFixed(0)}')),
        const SizedBox(width: 8),
        Expanded(child: _stat2('All Time', 'PKR ${state.allTimeTotal.toStringAsFixed(0)}')),
      ]),
    ]),
  );

  Widget _stat2(String label, String val) => Container(
    padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
    decoration: BoxDecoration(color: Colors.white.withOpacity(0.12), borderRadius: BorderRadius.circular(12)),
    child: Column(children: [
      Text(val, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13), textAlign: TextAlign.center, overflow: TextOverflow.ellipsis),
      const SizedBox(height: 2),
      Text(label, style: const TextStyle(color: Colors.white60, fontSize: 10)),
    ]),
  );

  Widget _monthNav(BuildContext ctx, SadqaState state) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
    child: Row(children: [
      IconButton(
        icon: const Icon(Icons.chevron_left),
        onPressed: () => ctx.read<SadqaBloc>().add(ChangeMonth(
            DateTime(state.currentMonth.year, state.currentMonth.month - 1))),
      ),
      Expanded(child: Text(AppDateUtils.toMonth(state.currentMonth),
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16), textAlign: TextAlign.center)),
      IconButton(
        icon: const Icon(Icons.chevron_right),
        onPressed: () => ctx.read<SadqaBloc>().add(ChangeMonth(
            DateTime(state.currentMonth.year, state.currentMonth.month + 1))),
      ),
    ]),
  );

  Widget _tile(BuildContext ctx, SadqaModel s) => Container(
    margin: const EdgeInsets.fromLTRB(16, 0, 16, 8),
    decoration: BoxDecoration(
      color: Theme.of(ctx).cardColor,
      borderRadius: BorderRadius.circular(12),
      border: Border.all(color: const Color(0xFF795548).withOpacity(0.15)),
    ),
    child: ListTile(
      leading: Container(width: 44, height: 44, decoration: BoxDecoration(color: const Color(0xFF795548).withOpacity(0.1), borderRadius: BorderRadius.circular(10)),
          child: const Center(child: Text('🤲', style: TextStyle(fontSize: 22)))),
      title: Text('PKR ${s.amount.toStringAsFixed(0)}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
      subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(AppDateUtils.toDisplay(AppDateUtils.fromDb(s.date)), style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
        if (s.notes != null && s.notes!.isNotEmpty) Text(s.notes!, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
      ]),
      trailing: Row(mainAxisSize: MainAxisSize.min, children: [
        IconButton(icon: const Icon(Icons.edit_outlined, color: AppColors.primary), onPressed: () => _showAddEdit(ctx, sadqa: s)),
        IconButton(icon: const Icon(Icons.delete_outline, color: AppColors.missed), onPressed: () => _confirmDelete(ctx, s)),
      ]),
    ),
  );

  void _showAddEdit(BuildContext ctx, {SadqaModel? sadqa}) {
    final amtCtrl = TextEditingController(text: sadqa?.amount.toStringAsFixed(0) ?? '');
    final notesCtrl = TextEditingController(text: sadqa?.notes ?? '');
    DateTime selectedDate = sadqa != null ? AppDateUtils.fromDb(sadqa.date) : DateTime.now();

    showModalBottomSheet(
      context: ctx, isScrollControlled: true, useSafeArea: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (bCtx) => StatefulBuilder(
        builder: (_, setS) => Padding(
          padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(bCtx).viewInsets.bottom + 20),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Center(child: Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.grey.shade300, borderRadius: BorderRadius.circular(2)))),
            const SizedBox(height: 16),
            Text(sadqa == null ? 'Add Sadqa' : 'Edit Sadqa', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            TextField(controller: amtCtrl, keyboardType: TextInputType.number,
                decoration: InputDecoration(labelText: 'Amount (PKR)', prefixText: 'PKR ', border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)))),
            const SizedBox(height: 12),
            TextField(controller: notesCtrl,
                decoration: InputDecoration(labelText: 'Notes (optional)', border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)))),
            const SizedBox(height: 12),
            GestureDetector(
              onTap: () async {
                final d = await showDatePicker(context: bCtx, initialDate: selectedDate, firstDate: DateTime(2020), lastDate: DateTime.now());
                if (d != null) setS(() => selectedDate = d);
              },
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                decoration: BoxDecoration(border: Border.all(color: Colors.grey), borderRadius: BorderRadius.circular(12)),
                child: Row(children: [
                  const Icon(Icons.calendar_today, size: 18, color: AppColors.primary),
                  const SizedBox(width: 8),
                  Text(AppDateUtils.toDisplay(selectedDate)),
                ]),
              ),
            ),
            const SizedBox(height: 20),
            SizedBox(width: double.infinity, child: ElevatedButton(
              onPressed: () {
                final amt = double.tryParse(amtCtrl.text.trim());
                if (amt == null || amt <= 0) return;
                if (sadqa == null) {
                  ctx.read<SadqaBloc>().add(AddSadqa(date: selectedDate, amount: amt, notes: notesCtrl.text.trim().isEmpty ? null : notesCtrl.text.trim()));
                } else {
                  ctx.read<SadqaBloc>().add(UpdateSadqa(sadqa.copyWith(date: AppDateUtils.toDb(selectedDate), amount: amt, notes: notesCtrl.text.trim().isEmpty ? null : notesCtrl.text.trim())));
                }
                Navigator.pop(bCtx);
              },
              style: ElevatedButton.styleFrom(backgroundColor: AppColors.accent, padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
              child: Text(sadqa == null ? 'Add Sadqa' : 'Save Changes', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            )),
          ]),
        ),
      ),
    );
  }

  void _confirmDelete(BuildContext ctx, SadqaModel s) {
    showDialog(context: ctx, builder: (_) => AlertDialog(
      title: const Text('Delete Sadqa?'),
      content: Text('Remove PKR ${s.amount.toStringAsFixed(0)} entry?'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
        TextButton(onPressed: () { Navigator.pop(ctx); ctx.read<SadqaBloc>().add(DeleteSadqa(s.id!)); }, child: const Text('Delete', style: TextStyle(color: AppColors.missed))),
      ],
    ));
  }
}
