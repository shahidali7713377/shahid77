// lib/presentation/screens/history_screen.dart
//
// History tab shows:
//  1. Qaza summary card (total remaining / offered) → taps to AllQazaScreen
//  2. Date-wise list of ONLY missed (qaza) prayers grouped by date
//  3. Each missed prayer tile has "Offer Qaza" button
//  4. Offering reduces the counter immediately
//
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/date_utils.dart';
import '../../data/models/prayer_model.dart';
import '../blocs/qaza/qaza_bloc.dart';
import 'all_qaza_screen.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});
  @override State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  @override
  void initState() {
    super.initState();
    context.read<QazaBloc>().add(const LoadQaza());
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<QazaBloc, QazaState>(
      listener: (ctx, state) {
        if (state.snackMessage != null) {
          ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(
            content: Text(state.snackMessage!),
            backgroundColor: AppColors.offered,
            duration: const Duration(seconds: 2),
          ));
        }
      },
      builder: (ctx, state) {
        if (state.isLoading) {
          return const Center(child: CircularProgressIndicator(color: AppColors.primary));
        }

        final byDate = state.summary?.byDate ?? {};
        final sortedDates = byDate.keys.toList()..sort();

        return RefreshIndicator(
          onRefresh: () async => ctx.read<QazaBloc>().add(const LoadQaza()),
          child: CustomScrollView(
            slivers: [
              // ── Top Summary Card ──────────────────────────────────────────
              SliverToBoxAdapter(child: _buildSummaryCard(ctx, state)),

              // ── Section title ─────────────────────────────────────────────
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
                  child: Row(children: [
                    const Icon(Icons.pending_actions, color: AppColors.missed, size: 18),
                    const SizedBox(width: 8),
                    Text(
                      'Remaining Qaza Prayers (${state.remaining})',
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: AppColors.missed),
                    ),
                  ]),
                ),
              ),

              // ── Date-wise qaza groups ─────────────────────────────────────
              if (sortedDates.isEmpty)
                SliverFillRemaining(
                  child: Center(
                    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      const Text('🌟', style: TextStyle(fontSize: 72)),
                      const SizedBox(height: 16),
                      const Text('No remaining Qaza prayers!',
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 8),
                      Text(
                        state.offered > 0
                            ? 'Alhamdulillah! You have offered ${state.offered} qaza prayers.'
                            : 'Keep up with your daily prayers.',
                        style: const TextStyle(color: AppColors.textSecondary),
                        textAlign: TextAlign.center,
                      ),
                    ]),
                  ),
                )
              else
                SliverList(
                  delegate: SliverChildBuilderDelegate(
                    (_, i) {
                      final date = sortedDates[i];
                      final prayers = byDate[date]!;
                      return _buildDateGroup(ctx, date, prayers);
                    },
                    childCount: sortedDates.length,
                  ),
                ),

              const SliverToBoxAdapter(child: SizedBox(height: 100)),
            ],
          ),
        );
      },
    );
  }

  // ── Summary Card ─────────────────────────────────────────────────────────

  Widget _buildSummaryCard(BuildContext ctx, QazaState state) {
    final remaining = state.remaining;
    final offered   = state.offered;
    final total     = state.total;
    final pct       = total > 0 ? offered / total : 0.0;

    return GestureDetector(
      onTap: () async {
        await Navigator.push(ctx, MaterialPageRoute(builder: (_) => const AllQazaScreen()));
        ctx.read<QazaBloc>().add(const LoadQaza());
      },
      child: Container(
        margin: const EdgeInsets.all(16),
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: remaining > 0
                ? [const Color(0xFFB71C1C), const Color(0xFFC62828)]
                : [AppColors.primary, AppColors.primaryLight],
            begin: Alignment.topLeft, end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [BoxShadow(
            color: (remaining > 0 ? AppColors.missed : AppColors.primary).withOpacity(0.4),
            blurRadius: 14, offset: const Offset(0, 4),
          )],
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          // Header row
          Row(children: [
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Row(children: [
                Text('📿 ', style: TextStyle(fontSize: 20)),
                Text('Qaza Prayer Tracker',
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 17)),
              ]),
              const SizedBox(height: 4),
              Text(
                remaining > 0
                    ? 'You have $remaining qaza prayer${remaining == 1 ? "" : "s"} to offer'
                    : 'All qaza prayers offered. Alhamdulillah! 🌟',
                style: const TextStyle(color: Colors.white70, fontSize: 12),
              ),
            ])),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(color: Colors.white.withOpacity(0.15), borderRadius: BorderRadius.circular(10)),
              child: const Row(mainAxisSize: MainAxisSize.min, children: [
                Text('View All', style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold)),
                SizedBox(width: 4),
                Icon(Icons.arrow_forward_ios, color: Colors.white60, size: 12),
              ]),
            ),
          ]),
          const SizedBox(height: 16),
          // Stats row
          Row(children: [
            Expanded(child: _cardStat('Remaining', remaining, Icons.pending_actions)),
            const SizedBox(width: 8),
            Expanded(child: _cardStat('Offered', offered, Icons.check_circle_outline)),
            const SizedBox(width: 8),
            Expanded(child: _cardStat('Total', total, Icons.history_edu)),
          ]),
          if (total > 0) ...[
            const SizedBox(height: 14),
            ClipRRect(
              borderRadius: BorderRadius.circular(5),
              child: LinearProgressIndicator(
                value: pct, backgroundColor: Colors.white24,
                valueColor: const AlwaysStoppedAnimation(Colors.white), minHeight: 8,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              '${(pct * 100).toStringAsFixed(0)}% qaza prayers offered',
              style: const TextStyle(color: Colors.white70, fontSize: 11),
            ),
          ],
        ]),
      ),
    );
  }

  Widget _cardStat(String label, int val, IconData icon) => Container(
    padding: const EdgeInsets.symmetric(vertical: 10),
    decoration: BoxDecoration(color: Colors.white.withOpacity(0.12), borderRadius: BorderRadius.circular(12)),
    child: Column(children: [
      Icon(icon, color: Colors.white70, size: 18),
      const SizedBox(height: 4),
      Text('$val', style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
      Text(label, style: const TextStyle(color: Colors.white60, fontSize: 10)),
    ]),
  );

  // ── Date group ────────────────────────────────────────────────────────────

  Widget _buildDateGroup(BuildContext ctx, String dateStr, List<PrayerModel> prayers) {
    final date = AppDateUtils.fromDb(dateStr);
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.missed.withOpacity(0.2)),
        color: Theme.of(context).cardColor,
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 6)],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        // Date header
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            color: AppColors.missed.withOpacity(0.07),
            borderRadius: const BorderRadius.vertical(top: Radius.circular(15)),
          ),
          child: Row(children: [
            const Icon(Icons.calendar_today, color: AppColors.missed, size: 15),
            const SizedBox(width: 8),
            Text(
              AppDateUtils.toDisplay(date),
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: AppColors.missed),
            ),
            const Spacer(),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
              decoration: BoxDecoration(color: AppColors.missed.withOpacity(0.12), borderRadius: BorderRadius.circular(12)),
              child: Text(
                '${prayers.length} qaza',
                style: const TextStyle(color: AppColors.missed, fontSize: 12, fontWeight: FontWeight.bold),
              ),
            ),
          ]),
        ),
        // Prayer rows
        ...prayers.map((p) => _buildPrayerRow(ctx, p)),
      ]),
    );
  }

  Widget _buildPrayerRow(BuildContext ctx, PrayerModel prayer) {
    return Container(
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 10),
      decoration: BoxDecoration(
        border: Border(top: BorderSide(color: AppColors.missed.withOpacity(0.1))),
      ),
      child: Row(children: [
        // Emoji
        Text(_emoji(prayer.prayerName), style: const TextStyle(fontSize: 24)),
        const SizedBox(width: 12),
        // Name + info
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(
            prayer.prayerName,
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: AppColors.missed),
          ),
          const Text('Qaza – not yet offered', style: TextStyle(fontSize: 11, color: AppColors.textSecondary)),
        ])),
        // Offer Qaza button
        ElevatedButton(
          onPressed: () => _confirmOffer(ctx, prayer),
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.missed,
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            minimumSize: const Size(100, 36),
            textStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            elevation: 0,
          ),
          child: const Text('Offer Qaza'),
        ),
      ]),
    );
  }

  void _confirmOffer(BuildContext ctx, PrayerModel prayer) {
    final date = AppDateUtils.fromDb(prayer.date);
    showDialog(
      context: ctx,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(children: [
          Text(_emoji(prayer.prayerName), style: const TextStyle(fontSize: 26)),
          const SizedBox(width: 10),
          Expanded(child: Text('Offer ${prayer.prayerName} Qaza')),
        ]),
        content: RichText(
          text: TextSpan(
            style: DefaultTextStyle.of(ctx).style,
            children: [
              const TextSpan(text: 'You are about to offer qaza for '),
              TextSpan(
                text: prayer.prayerName,
                style: const TextStyle(fontWeight: FontWeight.bold, color: AppColors.missed),
              ),
              const TextSpan(text: ' that was missed on '),
              TextSpan(
                text: AppDateUtils.toDisplay(date),
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              const TextSpan(text: '.\n\nThis will reduce your remaining qaza count by 1.'),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(ctx);
              ctx.read<QazaBloc>().add(OfferQaza(prayer));
            },
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.offered),
            child: const Text('Yes, I offered it!'),
          ),
        ],
      ),
    );
  }

  String _emoji(String name) {
    switch (name) {
      case AppConstants.fajr:    return '🌅';
      case AppConstants.zuhr:    return '☀️';
      case AppConstants.asr:     return '🌤';
      case AppConstants.maghrib: return '🌆';
      case AppConstants.isha:    return '🌙';
      default: return '🕌';
    }
  }
}
