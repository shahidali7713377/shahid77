// lib/presentation/screens/main_shell.dart
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../core/theme/app_theme.dart';
import '../blocs/prayer/prayer_bloc.dart';
import '../blocs/tasbeeh/tasbeeh_bloc.dart';
import 'home_screen.dart';
import 'history_screen.dart';
import 'analysis_screen.dart';
import 'sadqa_screen.dart';
import 'tasbeeh_screen.dart';
import 'settings_screen.dart';

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> with WidgetsBindingObserver {
  int _idx = 0;

  final _titles = ["Today's Prayers", 'Qaza History', 'Analysis', 'Sadqa', 'Tasbeeh'];
  final _screens = const [
    HomeScreen(),
    HistoryScreen(),
    AnalysisScreen(),
    SadqaScreen(),
    TasbeehScreen(),
  ];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    context.read<TasbeehBloc>().add(LoadTasbeeh());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  /// Every time the app comes back from background, check if the date changed.
  /// CheckDateChange compares SharedPrefs date to today — only reloads if needed.
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      context.read<PrayerBloc>().add(const CheckDateChange());
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _idx == 4
          ? null
          : AppBar(
              title: Text(_titles[_idx]),
              actions: [
                IconButton(
                  icon: const Icon(Icons.settings_outlined),
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const SettingsScreen()),
                  ),
                ),
              ],
            ),
      body: IndexedStack(index: _idx, children: _screens),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _idx,
        onDestinationSelected: (i) => setState(() => _idx = i),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.mosque_outlined),
            selectedIcon: Icon(Icons.mosque),
            label: 'Prayers',
          ),
          NavigationDestination(
            icon: Icon(Icons.history_outlined),
            selectedIcon: Icon(Icons.history),
            label: 'Qaza',
          ),
          NavigationDestination(
            icon: Icon(Icons.bar_chart_outlined),
            selectedIcon: Icon(Icons.bar_chart),
            label: 'Analysis',
          ),
          NavigationDestination(
            icon: Icon(Icons.volunteer_activism_outlined),
            selectedIcon: Icon(Icons.volunteer_activism),
            label: 'Sadqa',
          ),
          NavigationDestination(
            icon: Icon(Icons.radio_button_unchecked),
            selectedIcon: Icon(Icons.circle),
            label: 'Tasbeeh',
          ),
        ],
      ),
    );
  }
}
