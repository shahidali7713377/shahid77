// lib/presentation/screens/analysis_screen.dart
import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';
import '../../data/models/prayer_model.dart';
import '../../data/repositories/prayer_repository.dart';

class AnalysisScreen extends StatefulWidget {
  const AnalysisScreen({super.key});
  @override State<AnalysisScreen> createState() => _AnalysisScreenState();
}

class _AnalysisScreenState extends State<AnalysisScreen> {
  String _range = '1M';
  AnalyticsData? _data;
  bool _loading = false;
  final ranges = ['1W', '1M', '3M', '6M', '1Y'];

  @override void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() => _loading = true);
    final repo = PrayerRepository();
    final now = DateTime.now();
    DateTime start;
    switch (_range) {
      case '1W': start = now.subtract(const Duration(days: 7)); break;
      case '3M': start = DateTime(now.year, now.month - 3, now.day); break;
      case '6M': start = DateTime(now.year, now.month - 6, now.day); break;
      case '1Y': start = DateTime(now.year - 1, now.month, now.day); break;
      default:   start = DateTime(now.year, now.month - 1, now.day);
    }
    final data = await repo.getAnalytics(start, now);
    setState(() { _data = data; _loading = false; });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Prayer Analysis')),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: AppColors.primary))
          : _data == null ? const Center(child: Text('No data'))
          : ListView(padding: const EdgeInsets.all(16), children: [
              _rangeSelector(), const SizedBox(height: 16),
              _summaryCards(),  const SizedBox(height: 20),
              _barChart(),      const SizedBox(height: 20),
              _perPrayerList(), const SizedBox(height: 32),
            ]),
    );
  }

  Widget _rangeSelector() => Row(
    mainAxisAlignment: MainAxisAlignment.center,
    children: ranges.map((r) {
      final sel = _range == r;
      return GestureDetector(
        onTap: () { setState(() => _range = r); _load(); },
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 4),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
          decoration: BoxDecoration(
            color: sel ? AppColors.primary : AppColors.primary.withOpacity(0.08),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Text(r, style: TextStyle(color: sel ? Colors.white : AppColors.primary, fontWeight: FontWeight.bold, fontSize: 13)),
        ),
      );
    }).toList(),
  );

  Widget _summaryCards() {
    final d = _data!;
    return Row(children: [
      _sCard('${d.totalOffered}', 'Offered', AppColors.offered, Icons.check_circle),
      const SizedBox(width: 8),
      _sCard('${d.totalMissed}', 'Missed', AppColors.missed, Icons.cancel),
      const SizedBox(width: 8),
      _sCard('${d.consistencyPct.toStringAsFixed(0)}%', 'Consistency', AppColors.primary, Icons.show_chart),
    ]);
  }

  Widget _sCard(String val, String label, Color color, IconData icon) => Expanded(
    child: Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: color.withOpacity(0.08), borderRadius: BorderRadius.circular(14), border: Border.all(color: color.withOpacity(0.2))),
      child: Column(children: [
        Icon(icon, color: color, size: 22),
        const SizedBox(height: 6),
        Text(val, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: color)),
        Text(label, style: TextStyle(fontSize: 11, color: color.withOpacity(0.7))),
      ]),
    ),
  );

  Widget _barChart() {
    final d = _data!;
    final names = AppConstants.prayerNames;
    final vals = names.map((n) => (d.missedPerPrayer[n] ?? 0).toDouble()).toList();
    final maxY = vals.fold(0.0, (a, b) => a > b ? a : b);
    if (maxY == 0) return Card(child: Padding(padding: const EdgeInsets.all(24), child: Center(child: Text('No missed prayers in this period!', style: TextStyle(color: AppColors.offered, fontWeight: FontWeight.bold)))));
    return Card(child: Padding(
      padding: const EdgeInsets.all(20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Missed by Salah', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
        const SizedBox(height: 16),
        SizedBox(height: 200, child: BarChart(BarChartData(
          maxY: maxY + 2,
          barTouchData: BarTouchData(enabled: true),
          titlesData: FlTitlesData(
            bottomTitles: AxisTitles(sideTitles: SideTitles(showTitles: true, reservedSize: 28,
              getTitlesWidget: (v, _) => Text(['🌅','☀️','🌤','🌆','🌙'][v.toInt()], style: const TextStyle(fontSize: 18)))),
            leftTitles: AxisTitles(sideTitles: SideTitles(showTitles: true, reservedSize: 28)),
            topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          ),
          gridData: const FlGridData(show: false), borderData: FlBorderData(show: false),
          barGroups: List.generate(names.length, (i) => BarChartGroupData(x: i, barRods: [
            BarChartRodData(toY: vals[i], color: AppColors.missed, width: 30, borderRadius: BorderRadius.circular(6)),
          ])),
        ))),
      ]),
    ));
  }

  Widget _perPrayerList() => Card(child: Padding(
    padding: const EdgeInsets.all(16),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Per Prayer Breakdown', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
      const SizedBox(height: 12),
      ...AppConstants.prayerNames.map((n) {
        final missed = _data!.missedPerPrayer[n] ?? 0;
        final pct = _data!.totalDays > 0 ? missed / _data!.totalDays : 0.0;
        final emojis = {'Fajr':'🌅','Zuhr':'☀️','Asr':'🌤','Maghrib':'🌆','Isha':'🌙'};
        return Padding(padding: const EdgeInsets.only(bottom: 10), child: Row(children: [
          Text(emojis[n] ?? '🕌', style: const TextStyle(fontSize: 20)),
          const SizedBox(width: 10),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Text(n, style: const TextStyle(fontWeight: FontWeight.w600)),
              const Spacer(),
              Text('$missed missed', style: const TextStyle(color: AppColors.missed, fontSize: 12)),
            ]),
            const SizedBox(height: 4),
            ClipRRect(borderRadius: BorderRadius.circular(4), child: LinearProgressIndicator(
              value: pct.clamp(0.0, 1.0),
              backgroundColor: AppColors.missed.withOpacity(0.12),
              valueColor: AlwaysStoppedAnimation(missed > 0 ? AppColors.missed : AppColors.offered),
              minHeight: 6,
            )),
          ])),
        ]));
      }),
    ]),
  ));
}
