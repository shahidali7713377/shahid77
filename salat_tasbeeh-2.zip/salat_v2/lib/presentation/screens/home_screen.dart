// lib/presentation/screens/home_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/date_utils.dart';
import '../blocs/prayer/prayer_bloc.dart';
import '../widgets/prayer_card.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<PrayerBloc, PrayerState>(
      builder: (ctx, state) {
        if (state.isLoading) {
          return const Center(
            child: CircularProgressIndicator(color: AppColors.primary),
          );
        }

        if (state.error != null) {
          return Center(
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              const Icon(Icons.error_outline, color: AppColors.missed, size: 56),
              const SizedBox(height: 12),
              Text('Error: ${state.error}', textAlign: TextAlign.center),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: () => ctx.read<PrayerBloc>().add(const LoadToday()),
                child: const Text('Retry'),
              ),
            ]),
          );
        }

        return RefreshIndicator(
          onRefresh: () async => ctx.read<PrayerBloc>().add(const CheckDateChange()),
          child: CustomScrollView(slivers: [
            SliverToBoxAdapter(child: _buildHeader(state)),
            SliverList(
              delegate: SliverChildBuilderDelegate(
                (_, i) {
                  final name   = AppConstants.prayerNames[i];
                  final prayer = state.byName(name);
                  return PrayerCard(
                    prayerName:  name,
                    prayer:      prayer,
                    prayerTime:  state.times?.byName(name),
                    onOffered:   () => ctx.read<PrayerBloc>().add(MarkOffered(name)),
                    onMissed:    () => ctx.read<PrayerBloc>().add(MarkMissed(name)),
                    onIncrNafal: () => ctx.read<PrayerBloc>().add(IncrNafal(name)),
                    onDecrNafal: () => ctx.read<PrayerBloc>().add(DecrNafal(name)),
                  );
                },
                childCount: AppConstants.prayerNames.length,
              ),
            ),
            const SliverToBoxAdapter(child: SizedBox(height: 24)),
          ]),
        );
      },
    );
  }

  Widget _buildHeader(PrayerState state) {
    final offered = state.offeredCount;
    final missed  = state.missedCount;
    final pending = state.pendingCount;
    final total   = state.prayers.length;

    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [AppColors.primary, AppColors.primaryLight],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.withOpacity(0.3),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text(
                'بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيم',
                style: TextStyle(color: Colors.white70, fontSize: 13),
              ),
              const SizedBox(height: 4),
              Text(
                AppDateUtils.toDisplay(DateTime.now()),
                style: const TextStyle(
                  color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold,
                ),
              ),
            ]),
          ),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.15),
              borderRadius: BorderRadius.circular(14),
            ),
            child: const Text('🕌', style: TextStyle(fontSize: 28)),
          ),
        ]),
        const SizedBox(height: 16),
        Row(children: [
          Expanded(child: _stat('Offered', offered, Colors.greenAccent)),
          const SizedBox(width: 8),
          Expanded(child: _stat('Missed',  missed,  Colors.redAccent.shade100)),
          const SizedBox(width: 8),
          Expanded(child: _stat('Pending', pending, Colors.white60)),
        ]),
        const SizedBox(height: 12),
        ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: LinearProgressIndicator(
            value: total > 0 ? offered / total : 0,
            backgroundColor: Colors.white24,
            valueColor: const AlwaysStoppedAnimation(Colors.white),
            minHeight: 6,
          ),
        ),
        const SizedBox(height: 6),
        Text(
          offered > 0
              ? '$offered of $total prayers completed today'
              : 'No prayers recorded yet today',
          style: const TextStyle(color: Colors.white70, fontSize: 12),
        ),
      ]),
    );
  }

  Widget _stat(String label, int val, Color textColor) => Container(
    padding: const EdgeInsets.symmetric(vertical: 10),
    decoration: BoxDecoration(
      color: Colors.white.withOpacity(0.12),
      borderRadius: BorderRadius.circular(12),
    ),
    child: Column(children: [
      Text('$val',
          style: TextStyle(
              color: textColor, fontSize: 20, fontWeight: FontWeight.bold)),
      Text(label,
          style: const TextStyle(color: Colors.white70, fontSize: 11)),
    ]),
  );
}
