// lib/presentation/screens/settings_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/notification_service.dart';
import '../../core/utils/prayer_calculator.dart';
import '../blocs/settings/settings_bloc.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  @override
  void initState() { super.initState(); context.read<SettingsBloc>().add(LoadSettings()); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: BlocBuilder<SettingsBloc, SettingsState>(
        builder: (ctx, state) => ListView(padding: const EdgeInsets.all(16), children: [

          _section('Prayer Notifications'),
          _card([
            SwitchListTile(
              title: const Text('Prayer Reminders'),
              subtitle: const Text('Get notified before each prayer'),
              value: state.prayerNotif, activeColor: AppColors.primary,
              secondary: const Icon(Icons.notifications_outlined, color: AppColors.primary),
              onChanged: (v) => ctx.read<SettingsBloc>().add(TogglePrayerNotif(v)),
            ),
            if (state.prayerNotif) ...[
              const Divider(),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 14),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('Remind me before prayer:', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500)),
                  const SizedBox(height: 10),
                  Wrap(spacing: 8, children: AppConstants.notifOffsets.map((o) {
                    final sel = state.notifOffset == o;
                    return ChoiceChip(
                      label: Text('$o min'), selected: sel, selectedColor: AppColors.primary,
                      labelStyle: TextStyle(color: sel ? Colors.white : null, fontWeight: sel ? FontWeight.bold : null),
                      onSelected: (_) => ctx.read<SettingsBloc>().add(SetNotifOffset(o)),
                    );
                  }).toList()),
                ]),
              ),
            ],
          ]),

          const SizedBox(height: 16),

          _section('Sadqa Reminder'),
          _card([
            SwitchListTile(
              title: const Text('Daily Sadqa Reminder'),
              subtitle: Text(state.sadqaNotif ? 'Reminder at ${state.sadqaTimeDisplay}' : 'Get a daily prompt to give charity'),
              value: state.sadqaNotif, activeColor: AppColors.accent,
              secondary: const Text('🤲', style: TextStyle(fontSize: 24)),
              onChanged: (v) => ctx.read<SettingsBloc>().add(ToggleSadqaNotif(v)),
            ),
            if (state.sadqaNotif) ...[
              const Divider(),
              ListTile(
                leading: const Icon(Icons.schedule, color: AppColors.accent),
                title: const Text('Reminder Time'),
                subtitle: Text(state.sadqaTimeDisplay,
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: AppColors.accent)),
                trailing: TextButton.icon(
                  onPressed: () => _pickSadqaTime(ctx, state),
                  icon: const Icon(Icons.edit, size: 16),
                  label: const Text('Change'),
                  style: TextButton.styleFrom(foregroundColor: AppColors.accent),
                ),
              ),
              Container(
                margin: const EdgeInsets.fromLTRB(16, 0, 16, 14),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AppColors.accent.withOpacity(0.07),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: AppColors.accent.withOpacity(0.2)),
                ),
                child: const Row(children: [
                  Icon(Icons.info_outline, color: AppColors.accent, size: 16),
                  SizedBox(width: 8),
                  Expanded(child: Text(
                    'You will receive: "Today\'s Sadqa is pending. Give charity and earn blessings!"',
                    style: TextStyle(fontSize: 12, color: AppColors.textSecondary),
                  )),
                ]),
              ),
            ],
          ]),

          const SizedBox(height: 16),
          _section('Appearance'),
          _card([
            SwitchListTile(
              title: const Text('Dark Mode'),
              subtitle: const Text('Switch to dark theme'),
              value: state.darkMode, activeColor: AppColors.primary,
              secondary: const Icon(Icons.dark_mode_outlined, color: AppColors.primary),
              onChanged: (v) => ctx.read<SettingsBloc>().add(ToggleDarkMode(v)),
            ),
          ]),

          const SizedBox(height: 16),
          _section('Location & Prayer Times'),
          _card([
            ListTile(
              leading: const Icon(Icons.location_on_outlined, color: AppColors.primary),
              title: const Text('Update Location'),
              subtitle: const Text('Refresh GPS for accurate prayer times'),
              trailing: const Icon(Icons.arrow_forward_ios, size: 14),
              onTap: () async {
                final pos = await PrayerCalculatorService.getLocation();
                if (pos != null) {
                  await PrayerCalculatorService.saveLocation(pos.latitude, pos.longitude);
                  await NotificationService.instance.scheduleAllPrayer();
                  if (ctx.mounted) ScaffoldMessenger.of(ctx).showSnackBar(const SnackBar(
                    content: Text('Location updated!'), backgroundColor: AppColors.offered));
                }
              },
            ),
          ]),

          const SizedBox(height: 16),
          _section('About'),
          _card([
            const ListTile(
              leading: Icon(Icons.mosque_outlined, color: AppColors.primary),
              title: Text('Salat & Tasbeeh'),
              subtitle: Text('Version 2.0.0\nBuilt for Sunni Muslims', ),
              isThreeLine: true,
            ),
          ]),
          const SizedBox(height: 32),
        ]),
      ),
    );
  }

  Future<void> _pickSadqaTime(BuildContext ctx, SettingsState state) async {
    final picked = await showTimePicker(
      context: ctx,
      initialTime: TimeOfDay(hour: state.sadqaHour, minute: state.sadqaMinute),
      helpText: 'Set Sadqa Reminder Time',
      builder: (bCtx, child) => Theme(
        data: Theme.of(bCtx).copyWith(colorScheme: const ColorScheme.light(primary: AppColors.accent, onPrimary: Colors.white)),
        child: child!,
      ),
    );
    if (picked != null && ctx.mounted) {
      ctx.read<SettingsBloc>().add(SetSadqaTime(hour: picked.hour, minute: picked.minute));
      ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(
        content: Text('Sadqa reminder set for ${picked.format(ctx)}'),
        backgroundColor: AppColors.accent,
      ));
    }
  }

  Widget _section(String title) => Padding(
    padding: const EdgeInsets.only(left: 4, bottom: 8),
    child: Text(title, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: AppColors.primary, letterSpacing: 0.5)),
  );

  Widget _card(List<Widget> children) => Card(margin: EdgeInsets.zero, child: Column(children: children));
}
