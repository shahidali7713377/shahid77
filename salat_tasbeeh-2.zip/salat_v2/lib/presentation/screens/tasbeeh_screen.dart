// lib/presentation/screens/tasbeeh_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../core/theme/app_theme.dart';
import '../blocs/tasbeeh/tasbeeh_bloc.dart';

class TasbeehScreen extends StatelessWidget {
  const TasbeehScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Digital Tasbeeh'), actions: [
        BlocBuilder<TasbeehBloc, TasbeehState>(builder: (ctx, s) => PopupMenuButton<int>(
          icon: const Icon(Icons.tune, color: Colors.white),
          itemBuilder: (_) => [33, 99, 100, 1000].map((t) => PopupMenuItem(value: t, child: Text('Target: $t'))).toList(),
          onSelected: (t) => ctx.read<TasbeehBloc>().add(SetTarget(t)),
        )),
      ]),
      body: BlocBuilder<TasbeehBloc, TasbeehState>(
        builder: (ctx, state) {
          final pct = state.target > 0 ? (state.count % state.target) / state.target : 0.0;
          return Column(children: [
            if (state.targetReached) Container(
              width: double.infinity, padding: const EdgeInsets.symmetric(vertical: 12),
              color: AppColors.accent.withOpacity(0.15),
              child: const Text('🌟 SubhanAllah! Target reached!', textAlign: TextAlign.center,
                  style: TextStyle(color: AppColors.accent, fontWeight: FontWeight.bold, fontSize: 15)),
            ),
            Expanded(child: GestureDetector(
              onTap: () {
                HapticFeedback.lightImpact();
                ctx.read<TasbeehBloc>().add(IncrTasbeeh());
              },
              child: Container(
                color: Colors.transparent,
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Container(
                    width: 200, height: 200,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: RadialGradient(colors: [AppColors.primary.withOpacity(0.9), AppColors.primary]),
                      boxShadow: [BoxShadow(color: AppColors.primary.withOpacity(0.35), blurRadius: 30, spreadRadius: 5)],
                    ),
                    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Text('${state.count}', style: const TextStyle(color: Colors.white, fontSize: 52, fontWeight: FontWeight.bold)),
                      const Text('Tap anywhere', style: TextStyle(color: Colors.white60, fontSize: 13)),
                    ]),
                  ),
                  const SizedBox(height: 32),
                  Text('Target: ${state.target}', style: const TextStyle(fontSize: 15, color: AppColors.textSecondary)),
                  const SizedBox(height: 8),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 48),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(6),
                      child: LinearProgressIndicator(
                        value: pct, backgroundColor: AppColors.primary.withOpacity(0.12),
                        valueColor: const AlwaysStoppedAnimation(AppColors.primary), minHeight: 8,
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text('${state.count % (state.target > 0 ? state.target : 1)} / ${state.target}',
                      style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 24),
                  const Text('بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيم',
                      style: TextStyle(fontSize: 16, color: AppColors.primary, fontWeight: FontWeight.w500)),
                ]),
              ),
            )),
            SafeArea(child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
              child: SizedBox(width: double.infinity, child: OutlinedButton.icon(
                onPressed: () { HapticFeedback.heavyImpact(); ctx.read<TasbeehBloc>().add(ResetTasbeeh()); },
                icon: const Icon(Icons.refresh),
                label: const Text('Reset Count'),
                style: OutlinedButton.styleFrom(foregroundColor: AppColors.missed, side: const BorderSide(color: AppColors.missed),
                    padding: const EdgeInsets.symmetric(vertical: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
              )),
            )),
          ]);
        },
      ),
    );
  }
}
