// lib/presentation/blocs/settings/settings_bloc.dart
import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/utils/notification_service.dart';

abstract class SettingsEvent extends Equatable {
  const SettingsEvent();
  @override List<Object?> get props => [];
}
class LoadSettings extends SettingsEvent {}
class TogglePrayerNotif extends SettingsEvent {
  final bool v; const TogglePrayerNotif(this.v);
  @override List<Object?> get props => [v];
}
class SetNotifOffset extends SettingsEvent {
  final int min; const SetNotifOffset(this.min);
  @override List<Object?> get props => [min];
}
class ToggleDarkMode extends SettingsEvent {
  final bool v; const ToggleDarkMode(this.v);
  @override List<Object?> get props => [v];
}
class ToggleSadqaNotif extends SettingsEvent {
  final bool v; const ToggleSadqaNotif(this.v);
  @override List<Object?> get props => [v];
}
class SetSadqaTime extends SettingsEvent {
  final int hour, minute;
  const SetSadqaTime({required this.hour, required this.minute});
  @override List<Object?> get props => [hour, minute];
}

class SettingsState extends Equatable {
  final bool prayerNotif, darkMode, sadqaNotif;
  final int notifOffset, sadqaHour, sadqaMinute;

  const SettingsState({
    this.prayerNotif = true, this.darkMode = false, this.sadqaNotif = false,
    this.notifOffset = AppConstants.defaultNotifOffset,
    this.sadqaHour = AppConstants.defaultSadqaHour,
    this.sadqaMinute = AppConstants.defaultSadqaMinute,
  });

  String get sadqaTimeDisplay {
    final period = sadqaHour >= 12 ? 'PM' : 'AM';
    final h = sadqaHour == 0 ? 12 : (sadqaHour > 12 ? sadqaHour - 12 : sadqaHour);
    final m = sadqaMinute.toString().padLeft(2, '0');
    return '\$h:\$m \$period';
  }

  SettingsState cw({bool? prayerNotif, bool? darkMode, bool? sadqaNotif,
      int? notifOffset, int? sadqaHour, int? sadqaMinute}) =>
      SettingsState(
        prayerNotif: prayerNotif ?? this.prayerNotif,
        darkMode: darkMode ?? this.darkMode,
        sadqaNotif: sadqaNotif ?? this.sadqaNotif,
        notifOffset: notifOffset ?? this.notifOffset,
        sadqaHour: sadqaHour ?? this.sadqaHour,
        sadqaMinute: sadqaMinute ?? this.sadqaMinute,
      );

  @override List<Object?> get props => [prayerNotif, darkMode, sadqaNotif, notifOffset, sadqaHour, sadqaMinute];
}

class SettingsBloc extends Bloc<SettingsEvent, SettingsState> {
  SettingsBloc() : super(const SettingsState()) {
    on<LoadSettings>(_load);
    on<TogglePrayerNotif>(_togglePrayer);
    on<SetNotifOffset>(_setOffset);
    on<ToggleDarkMode>(_toggleDark);
    on<ToggleSadqaNotif>(_toggleSadqa);
    on<SetSadqaTime>(_setSadqaTime);
  }

  Future<void> _load(LoadSettings _, Emitter<SettingsState> emit) async {
    final p = await SharedPreferences.getInstance();
    emit(state.cw(
      prayerNotif: p.getBool(AppConstants.keyNotifEnabled) ?? true,
      notifOffset: p.getInt(AppConstants.keyNotifOffset) ?? AppConstants.defaultNotifOffset,
      darkMode: p.getBool(AppConstants.keyDarkMode) ?? false,
      sadqaNotif: p.getBool(AppConstants.keySadqaNotifEnabled) ?? false,
      sadqaHour: p.getInt(AppConstants.keySadqaNotifHour) ?? AppConstants.defaultSadqaHour,
      sadqaMinute: p.getInt(AppConstants.keySadqaNotifMinute) ?? AppConstants.defaultSadqaMinute,
    ));
  }

  Future<void> _togglePrayer(TogglePrayerNotif e, Emitter<SettingsState> emit) async {
    emit(state.cw(prayerNotif: e.v));
    final p = await SharedPreferences.getInstance();
    await p.setBool(AppConstants.keyNotifEnabled, e.v);
    if (e.v) await NotificationService.instance.scheduleAllPrayer();
    else await NotificationService.instance.cancelAllPrayer();
  }

  Future<void> _setOffset(SetNotifOffset e, Emitter<SettingsState> emit) async {
    emit(state.cw(notifOffset: e.min));
    final p = await SharedPreferences.getInstance();
    await p.setInt(AppConstants.keyNotifOffset, e.min);
    if (state.prayerNotif) await NotificationService.instance.scheduleAllPrayer();
  }

  Future<void> _toggleDark(ToggleDarkMode e, Emitter<SettingsState> emit) async {
    emit(state.cw(darkMode: e.v));
    final p = await SharedPreferences.getInstance();
    await p.setBool(AppConstants.keyDarkMode, e.v);
  }

  Future<void> _toggleSadqa(ToggleSadqaNotif e, Emitter<SettingsState> emit) async {
    emit(state.cw(sadqaNotif: e.v));
    final p = await SharedPreferences.getInstance();
    await p.setBool(AppConstants.keySadqaNotifEnabled, e.v);
    await NotificationService.instance.scheduleSadqaReminder();
  }

  Future<void> _setSadqaTime(SetSadqaTime e, Emitter<SettingsState> emit) async {
    emit(state.cw(sadqaHour: e.hour, sadqaMinute: e.minute));
    final p = await SharedPreferences.getInstance();
    await p.setInt(AppConstants.keySadqaNotifHour, e.hour);
    await p.setInt(AppConstants.keySadqaNotifMinute, e.minute);
    if (state.sadqaNotif) await NotificationService.instance.scheduleSadqaReminder();
  }
}
