// lib/presentation/blocs/tasbeeh/tasbeeh_bloc.dart
import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../../core/constants/app_constants.dart';

abstract class TasbeehEvent extends Equatable {
  const TasbeehEvent();
  @override List<Object?> get props => [];
}
class LoadTasbeeh extends TasbeehEvent {}
class IncrTasbeeh extends TasbeehEvent {}
class ResetTasbeeh extends TasbeehEvent {}
class SetTarget extends TasbeehEvent {
  final int t; const SetTarget(this.t);
  @override List<Object?> get props => [t];
}

class TasbeehState extends Equatable {
  final int count, target;
  final bool targetReached;
  const TasbeehState({this.count = 0, this.target = 33, this.targetReached = false});
  TasbeehState cw({int? count, int? target, bool? targetReached}) =>
      TasbeehState(count: count ?? this.count, target: target ?? this.target, targetReached: targetReached ?? this.targetReached);
  @override List<Object?> get props => [count, target, targetReached];
}

class TasbeehBloc extends Bloc<TasbeehEvent, TasbeehState> {
  TasbeehBloc() : super(const TasbeehState()) {
    on<LoadTasbeeh>(_load);
    on<IncrTasbeeh>(_incr);
    on<ResetTasbeeh>(_reset);
    on<SetTarget>(_setTarget);
  }
  Future<void> _load(LoadTasbeeh _, Emitter<TasbeehState> emit) async {
    final p = await SharedPreferences.getInstance();
    emit(state.cw(count: p.getInt(AppConstants.keyTasbeehCount) ?? 0));
  }
  Future<void> _incr(IncrTasbeeh _, Emitter<TasbeehState> emit) async {
    final c = state.count + 1;
    final reached = state.target > 0 && c % state.target == 0;
    final p = await SharedPreferences.getInstance();
    await p.setInt(AppConstants.keyTasbeehCount, c);
    emit(state.cw(count: c, targetReached: reached));
  }
  Future<void> _reset(ResetTasbeeh _, Emitter<TasbeehState> emit) async {
    final p = await SharedPreferences.getInstance();
    await p.setInt(AppConstants.keyTasbeehCount, 0);
    emit(state.cw(count: 0, targetReached: false));
  }
  Future<void> _setTarget(SetTarget e, Emitter<TasbeehState> emit) async {
    emit(state.cw(target: e.t));
  }
}
