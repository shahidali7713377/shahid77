// lib/presentation/blocs/qaza/qaza_bloc.dart
import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../data/models/prayer_model.dart';
import '../../../data/repositories/prayer_repository.dart';

// ── Events ────────────────────────────────────────────────────────────────────
abstract class QazaEvent extends Equatable {
  const QazaEvent();
  @override List<Object?> get props => [];
}
class LoadQaza extends QazaEvent { const LoadQaza(); }
class OfferQaza extends QazaEvent {
  final PrayerModel prayer;
  const OfferQaza(this.prayer);
  @override List<Object?> get props => [prayer.id];
}
class UndoQaza extends QazaEvent {
  final PrayerModel prayer;
  const UndoQaza(this.prayer);
  @override List<Object?> get props => [prayer.id];
}

// ── State ─────────────────────────────────────────────────────────────────────
class QazaState extends Equatable {
  final bool isLoading;
  final QazaSummary? summary;
  final List<PrayerModel> offeredList;
  final String? snackMessage;

  const QazaState({
    this.isLoading = true,
    this.summary,
    this.offeredList = const [],
    this.snackMessage,
  });

  int get remaining => summary?.totalRemaining ?? 0;
  int get offered   => summary?.totalOffered ?? 0;
  int get total     => summary?.totalEver ?? 0;

  QazaState copyWith({
    bool? isLoading, QazaSummary? summary,
    List<PrayerModel>? offeredList, String? snackMessage,
  }) => QazaState(
    isLoading: isLoading ?? this.isLoading,
    summary: summary ?? this.summary,
    offeredList: offeredList ?? this.offeredList,
    snackMessage: snackMessage,
  );

  @override List<Object?> get props => [isLoading, remaining, offered, offeredList.length, snackMessage];
}

// ── BLoC ──────────────────────────────────────────────────────────────────────
class QazaBloc extends Bloc<QazaEvent, QazaState> {
  final PrayerRepository _repo;

  QazaBloc({required PrayerRepository repo})
      : _repo = repo, super(const QazaState()) {
    on<LoadQaza>(_load);
    on<OfferQaza>(_offer);
    on<UndoQaza>(_undo);
  }

  Future<void> _load(LoadQaza _, Emitter<QazaState> emit) async {
    emit(state.copyWith(isLoading: true));
    final summary     = await _repo.getQazaSummary();
    final offeredList = await _repo.getOfferedQaza();
    emit(state.copyWith(isLoading: false, summary: summary, offeredList: offeredList));
  }

  Future<void> _offer(OfferQaza e, Emitter<QazaState> emit) async {
    await _repo.offerQaza(e.prayer.id!);
    final summary     = await _repo.getQazaSummary();
    final offeredList = await _repo.getOfferedQaza();
    emit(state.copyWith(
      summary: summary,
      offeredList: offeredList,
      snackMessage: '✅ ${e.prayer.prayerName} qaza offered! ${summary.totalRemaining} remaining.',
    ));
  }

  Future<void> _undo(UndoQaza e, Emitter<QazaState> emit) async {
    await _repo.undoQaza(e.prayer.id!);
    final summary     = await _repo.getQazaSummary();
    final offeredList = await _repo.getOfferedQaza();
    emit(state.copyWith(
      summary: summary,
      offeredList: offeredList,
      snackMessage: '↩️ Undo successful. ${summary.totalRemaining} remaining.',
    ));
  }
}
