// lib/presentation/blocs/prayer/prayer_bloc.dart
//
// ROOT-CAUSE FIX:
// The previous approach stored `loadedDate` only in BLoC memory. When the app
// is killed and relaunched the state is gone, so the date check never detected
// that the day had changed, and `initDay()` found existing records (from the
// previous day) so it skipped creation — meaning yesterday's "Offered/Missed"
// data was shown again today.
//
// Fix: We persist `lastLoadedDate` in SharedPreferences so it survives app
// restarts. On EVERY startup and resume we compare it to today's date. When
// they differ we:
//   1. Mark all un-actioned prayers from the previous date as Missed
//   2. Create fresh Pending records for today
//   3. Update the persisted date
//
import 'dart:async';
import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/utils/date_utils.dart';
import '../../../core/utils/prayer_calculator.dart';
import '../../../data/models/prayer_model.dart';
import '../../../data/repositories/prayer_repository.dart';

// ── Events ────────────────────────────────────────────────────────────────────
abstract class PrayerEvent extends Equatable {
  const PrayerEvent();
  @override List<Object?> get props => [];
}

/// Called at app start and on every resume — always checks if date changed.
class LoadToday extends PrayerEvent { const LoadToday(); }

/// Alias used by main_shell on app resume.
class CheckDateChange extends PrayerEvent { const CheckDateChange(); }

class MarkOffered extends PrayerEvent {
  final String name;
  const MarkOffered(this.name);
  @override List<Object?> get props => [name];
}

class MarkMissed extends PrayerEvent {
  final String name;
  const MarkMissed(this.name);
  @override List<Object?> get props => [name];
}

class IncrNafal extends PrayerEvent {
  final String name;
  const IncrNafal(this.name);
  @override List<Object?> get props => [name];
}

class DecrNafal extends PrayerEvent {
  final String name;
  const DecrNafal(this.name);
  @override List<Object?> get props => [name];
}

class RefreshPrayers extends PrayerEvent { const RefreshPrayers(); }
class _MidnightRollover extends PrayerEvent { const _MidnightRollover(); }

// ── State ─────────────────────────────────────────────────────────────────────
class PrayerState extends Equatable {
  final bool isLoading;
  final List<PrayerModel> prayers;
  final PrayerTimesResult? times;
  final String? error;

  const PrayerState({
    this.isLoading = false,
    this.prayers = const [],
    this.times,
    this.error,
  });

  PrayerModel? byName(String n) {
    try { return prayers.firstWhere((p) => p.prayerName == n); }
    catch (_) { return null; }
  }

  PrayerState copyWith({
    bool? isLoading,
    List<PrayerModel>? prayers,
    PrayerTimesResult? times,
    String? error,
  }) => PrayerState(
    isLoading: isLoading ?? this.isLoading,
    prayers:   prayers   ?? this.prayers,
    times:     times     ?? this.times,
    error:     error,
  );

  int get offeredCount => prayers.where((p) => p.isOffered).length;
  int get missedCount  => prayers.where((p) => p.isMissed).length;
  int get pendingCount => prayers.where((p) => p.isPending).length;

  @override
  List<Object?> get props => [isLoading, prayers, times, error];
}

// ── BLoC ──────────────────────────────────────────────────────────────────────
class PrayerBloc extends Bloc<PrayerEvent, PrayerState> {
  final PrayerRepository _repo;
  Timer? _midnightTimer;

  PrayerBloc({required PrayerRepository repo})
      : _repo = repo, super(const PrayerState()) {
    on<LoadToday>(_load);
    on<CheckDateChange>(_checkDate);
    on<MarkOffered>(_markOffered);
    on<MarkMissed>(_markMissed);
    on<IncrNafal>(_incrNafal);
    on<DecrNafal>(_decrNafal);
    on<RefreshPrayers>(_refresh);
    on<_MidnightRollover>(_midnight);
    _scheduleMidnight();
  }

  // ── SharedPrefs helpers ──────────────────────────────────────────────────

  Future<String> _getStoredDate() async {
    final p = await SharedPreferences.getInstance();
    return p.getString(AppConstants.keyLastLoadedDate) ?? '';
  }

  Future<void> _saveStoredDate(String date) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(AppConstants.keyLastLoadedDate, date);
  }

  // ── Core load — the single source of truth ───────────────────────────────

  Future<void> _load(LoadToday _, Emitter<PrayerState> emit) async {
    emit(state.copyWith(isLoading: true));
    try {
      final today    = DateTime.now();
      final todayStr = AppDateUtils.toDb(today);

      // Read the last date we successfully loaded from persistent storage
      final lastDate = await _getStoredDate();

      if (lastDate.isNotEmpty && lastDate != todayStr) {
        // A new calendar day has started since last launch.
        // Mark any prayers that were left as Pending on that previous date
        // as Missed (they were never offered).
        try {
          await _repo.autoMarkMissed(AppDateUtils.fromDb(lastDate));
        } catch (_) {
          // If the date string is malformed just continue — don't crash.
        }
      }

      // Create fresh Pending records for today if they don't already exist.
      // This is safe to call every time — it's idempotent.
      await _repo.initDay(today);

      // Load today's prayers and current prayer times
      final prayers = await _repo.getPrayersForDate(today);
      final times   = await PrayerCalculatorService.getPrayerTimes();

      // Persist today's date so next startup knows when we last ran
      await _saveStoredDate(todayStr);

      emit(state.copyWith(
        isLoading: false,
        prayers:   prayers,
        times:     times,
      ));
    } catch (e) {
      emit(state.copyWith(isLoading: false, error: e.toString()));
    }
  }

  // CheckDateChange simply delegates to LoadToday — the full load already
  // handles the date-change detection via SharedPreferences.
  Future<void> _checkDate(CheckDateChange _, Emitter<PrayerState> emit) async {
    final todayStr = AppDateUtils.toDb(DateTime.now());
    final lastDate = await _getStoredDate();
    // Only do a full reload if the date actually changed — saves a DB round-trip
    // when the user merely switches apps and comes back the same day.
    if (lastDate != todayStr) {
      add(const LoadToday());
    }
  }

  // ── Midnight rollover (app stays open overnight) ──────────────────────────

  Future<void> _midnight(_MidnightRollover _, Emitter<PrayerState> emit) async {
    // Mark whatever is still pending from "yesterday" as missed, then load
    // the new day fresh.
    final yesterday = DateTime.now().subtract(const Duration(days: 1));
    try { await _repo.autoMarkMissed(yesterday); } catch (_) {}
    add(const LoadToday());
  }

  void _scheduleMidnight() {
    _midnightTimer?.cancel();
    final now      = DateTime.now();
    final midnight = DateTime(now.year, now.month, now.day + 1);
    _midnightTimer = Timer(midnight.difference(now), () {
      add(const _MidnightRollover());
      _scheduleMidnight(); // reschedule for the following midnight
    });
  }

  // ── Mark Offered / Missed ────────────────────────────────────────────────

  Future<void> _markOffered(MarkOffered e, Emitter<PrayerState> emit) async {
    await _repo.markOffered(DateTime.now(), e.name);
    final prayers = await _repo.getPrayersForDate(DateTime.now());
    emit(state.copyWith(prayers: prayers));
  }

  Future<void> _markMissed(MarkMissed e, Emitter<PrayerState> emit) async {
    await _repo.markMissed(DateTime.now(), e.name);
    final prayers = await _repo.getPrayersForDate(DateTime.now());
    emit(state.copyWith(prayers: prayers));
  }

  // ── Nafal ────────────────────────────────────────────────────────────────

  Future<void> _incrNafal(IncrNafal e, Emitter<PrayerState> emit) async {
    final p = state.byName(e.name);
    if (p == null) return;
    final c = p.nafalCount + 1;
    await _repo.updateNafal(DateTime.now(), e.name, c);
    emit(state.copyWith(prayers: state.prayers
        .map((x) => x.prayerName == e.name ? x.copyWith(nafalCount: c) : x)
        .toList()));
  }

  Future<void> _decrNafal(DecrNafal e, Emitter<PrayerState> emit) async {
    final p = state.byName(e.name);
    if (p == null || p.nafalCount <= 0) return;
    final c = p.nafalCount - 1;
    await _repo.updateNafal(DateTime.now(), e.name, c);
    emit(state.copyWith(prayers: state.prayers
        .map((x) => x.prayerName == e.name ? x.copyWith(nafalCount: c) : x)
        .toList()));
  }

  // ── Refresh (periodic or pull-to-refresh) ────────────────────────────────

  Future<void> _refresh(RefreshPrayers _, Emitter<PrayerState> emit) async {
    // Same as CheckDateChange: only reload if date changed
    final todayStr = AppDateUtils.toDb(DateTime.now());
    final lastDate = await _getStoredDate();
    if (lastDate != todayStr) {
      add(const LoadToday());
      return;
    }
    final prayers = await _repo.getPrayersForDate(DateTime.now());
    emit(state.copyWith(prayers: prayers));
  }

  @override
  Future<void> close() {
    _midnightTimer?.cancel();
    return super.close();
  }
}
