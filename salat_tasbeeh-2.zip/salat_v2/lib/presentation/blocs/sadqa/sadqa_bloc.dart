// lib/presentation/blocs/sadqa/sadqa_bloc.dart
import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../data/models/sadqa_model.dart';
import '../../../data/repositories/sadqa_repository.dart';
import '../../../core/utils/date_utils.dart';

abstract class SadqaEvent extends Equatable {
  const SadqaEvent();
  @override List<Object?> get props => [];
}
class LoadSadqa extends SadqaEvent { const LoadSadqa(); }
class AddSadqa extends SadqaEvent {
  final DateTime date; final double amount; final String? notes;
  const AddSadqa({required this.date, required this.amount, this.notes});
  @override List<Object?> get props => [date, amount];
}
class UpdateSadqa extends SadqaEvent {
  final SadqaModel sadqa;
  const UpdateSadqa(this.sadqa);
  @override List<Object?> get props => [sadqa.id];
}
class DeleteSadqa extends SadqaEvent {
  final int id; const DeleteSadqa(this.id);
  @override List<Object?> get props => [id];
}
class ChangeMonth extends SadqaEvent {
  final DateTime month; const ChangeMonth(this.month);
  @override List<Object?> get props => [AppDateUtils.toYM(month)];
}

class SadqaState extends Equatable {
  final bool isLoading;
  final List<SadqaModel> entries;
  final double todayTotal, monthTotal, allTimeTotal;
  final DateTime currentMonth;

  const SadqaState({
    this.isLoading = false,
    this.entries = const [],
    this.todayTotal = 0,
    this.monthTotal = 0,
    this.allTimeTotal = 0,
    required this.currentMonth,
  });

  @override List<Object?> get props => [isLoading, entries, todayTotal, monthTotal, allTimeTotal, AppDateUtils.toYM(currentMonth)];
}

class SadqaBloc extends Bloc<SadqaEvent, SadqaState> {
  final SadqaRepository _repo;
  DateTime _month = DateTime.now();

  SadqaBloc({required SadqaRepository repo})
      : _repo = repo,
        super(SadqaState(currentMonth: DateTime.now())) {
    on<LoadSadqa>(_load);
    on<AddSadqa>(_add);
    on<UpdateSadqa>(_update);
    on<DeleteSadqa>(_delete);
    on<ChangeMonth>(_changeMonth);
  }

  Future<void> _load(LoadSadqa _, Emitter<SadqaState> emit) async {
    emit(SadqaState(isLoading: true, currentMonth: _month));
    await _refresh(emit);
  }

  Future<void> _add(AddSadqa e, Emitter<SadqaState> emit) async {
    await _repo.add(date: e.date, amount: e.amount, notes: e.notes);
    await _refresh(emit);
  }

  Future<void> _update(UpdateSadqa e, Emitter<SadqaState> emit) async {
    await _repo.update(e.sadqa);
    await _refresh(emit);
  }

  Future<void> _delete(DeleteSadqa e, Emitter<SadqaState> emit) async {
    await _repo.delete(e.id);
    await _refresh(emit);
  }

  Future<void> _changeMonth(ChangeMonth e, Emitter<SadqaState> emit) async {
    _month = e.month;
    await _refresh(emit);
  }

  Future<void> _refresh(Emitter<SadqaState> emit) async {
    final entries    = await _repo.forMonth(_month);
    final todayTotal = await _repo.todayTotal();
    final monthTotal = await _repo.monthTotal(_month);
    final allTime    = await _repo.allTimeTotal();
    emit(SadqaState(
      entries: entries,
      todayTotal: todayTotal,
      monthTotal: monthTotal,
      allTimeTotal: allTime,
      currentMonth: _month,
    ));
  }
}
