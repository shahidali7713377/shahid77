// lib/presentation/widgets/prayer_card.dart
//
// BUG FIX: Prayers that have not yet reached their scheduled start time are
// locked — their action buttons are disabled and replaced with a
// "Prayer time starts at HH:MM" label. The card re-checks every 30 seconds
// so it unlocks automatically when prayer time arrives.
//
import 'dart:async';
import 'package:flutter/material.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/date_utils.dart';
import '../../data/models/prayer_model.dart';

class PrayerCard extends StatefulWidget {
  final String prayerName;
  final PrayerModel? prayer;
  final DateTime? prayerTime;
  final VoidCallback onOffered, onMissed, onIncrNafal, onDecrNafal;

  const PrayerCard({
    super.key,
    required this.prayerName,
    required this.prayer,
    this.prayerTime,
    required this.onOffered,
    required this.onMissed,
    required this.onIncrNafal,
    required this.onDecrNafal,
  });

  @override
  State<PrayerCard> createState() => _PrayerCardState();
}

class _PrayerCardState extends State<PrayerCard> {
  Timer? _unlockTimer;

  @override
  void initState() {
    super.initState();
    // Re-evaluate lock state every 30 seconds so the card unlocks at
    // the exact moment prayer time arrives without waiting for a rebuild.
    _unlockTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _unlockTimer?.cancel();
    super.dispose();
  }

  static const Map<String, String> _emojis = {
    AppConstants.fajr:    '🌅',
    AppConstants.zuhr:    '☀️',
    AppConstants.asr:     '🌤',
    AppConstants.maghrib: '🌆',
    AppConstants.isha:    '🌙',
  };

  /// True when prayer time is in the future AND status is still Pending.
  /// Once a prayer is Offered or Missed it stays unlocked regardless of time.
  bool get _locked {
    final status = widget.prayer?.status ?? AppConstants.statusPending;
    if (status != AppConstants.statusPending) return false;
    if (widget.prayerTime == null) return false;
    return DateTime.now().isBefore(widget.prayerTime!);
  }

  int get _minsUntil =>
      widget.prayerTime?.difference(DateTime.now()).inMinutes ?? 0;

  @override
  Widget build(BuildContext context) {
    final status = widget.prayer?.status ?? AppConstants.statusPending;
    final nafal  = widget.prayer?.nafalCount ?? 0;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final locked = _locked;

    Color borderColor;
    if (status == AppConstants.statusOffered) {
      borderColor = AppColors.offered;
    } else if (status == AppConstants.statusMissed) {
      borderColor = AppColors.missed;
    } else if (locked) {
      borderColor = Colors.grey.withOpacity(0.3);
    } else {
      borderColor = Colors.transparent;
    }

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
            color: borderColor,
            width: borderColor == Colors.transparent ? 0 : 2),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.06),
              blurRadius: 8,
              offset: const Offset(0, 2))
        ],
      ),
      child: Card(
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          _header(status, isDark, locked),
          _rakatChips(locked),
          _nafalRow(nafal, status, locked),
          _buttons(status, locked),
        ]),
      ),
    );
  }

  // ── Header ───────────────────────────────────────────────────────────────

  Widget _header(String status, bool isDark, bool locked) {
    final Color sc;
    final IconData si;
    final String sl;
    final Color bg;

    if (locked) {
      sc = Colors.grey; si = Icons.lock_clock; sl = 'Not Yet';
      bg = Colors.grey.withOpacity(0.1);
    } else {
      switch (status) {
        case AppConstants.statusOffered:
          sc = AppColors.offered; si = Icons.check_circle;
          sl = 'Offered';  bg = AppColors.offeredLight;
          break;
        case AppConstants.statusMissed:
          sc = AppColors.missed;  si = Icons.cancel;
          sl = 'Missed';   bg = AppColors.missedLight;
          break;
        default:
          sc = AppColors.pending; si = Icons.radio_button_unchecked;
          sl = 'Pending';  bg = AppColors.pendingLight;
      }
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: (locked ? Colors.grey : AppColors.primary).withOpacity(0.05),
        borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
      ),
      child: Row(children: [
        // Emoji avatar
        Container(
          width: 44, height: 44,
          decoration: BoxDecoration(
            color: (locked ? Colors.grey : AppColors.primary).withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Center(
            child: Text(_emojis[widget.prayerName] ?? '🕌',
                style: const TextStyle(fontSize: 22)),
          ),
        ),
        const SizedBox(width: 12),
        // Name + time
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(
              widget.prayerName,
              style: TextStyle(
                fontSize: 18, fontWeight: FontWeight.bold,
                color: locked
                    ? Colors.grey
                    : (isDark ? AppColors.darkText : AppColors.textPrimary),
              ),
            ),
            if (widget.prayerTime != null)
              Row(children: [
                Icon(
                  locked ? Icons.access_time : Icons.access_time_filled,
                  size: 13,
                  color: locked ? Colors.grey : AppColors.primary,
                ),
                const SizedBox(width: 4),
                Text(
                  locked
                      ? 'Starts at ${AppDateUtils.toTime(widget.prayerTime!)}  (${_minsUntil}m away)'
                      : AppDateUtils.toTime(widget.prayerTime!),
                  style: TextStyle(
                    fontSize: 12,
                    color: locked ? Colors.grey : AppColors.primary,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ]),
          ]),
        ),
        // Status badge
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
          decoration: BoxDecoration(
              color: bg, borderRadius: BorderRadius.circular(20)),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(si, color: sc, size: 14),
            const SizedBox(width: 4),
            Text(sl,
                style: TextStyle(
                    color: sc, fontSize: 11, fontWeight: FontWeight.w600)),
          ]),
        ),
      ]),
    );
  }

  // ── Rakat chips ───────────────────────────────────────────────────────────

  Widget _rakatChips(bool locked) {
    final rakats = PrayerRakats.rakats[widget.prayerName] ?? [];
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
      child: Opacity(
        opacity: locked ? 0.4 : 1.0,
        child: Wrap(
          spacing: 6, runSpacing: 6,
          children: rakats.map((r) {
            Color c; Color bg;
            switch (r.type) {
              case RakatType.farz:
                c = AppColors.farzColor; bg = AppColors.farzColor.withOpacity(0.1); break;
              case RakatType.sunnah:
                c = AppColors.sunnahColor; bg = AppColors.sunnahColor.withOpacity(0.1); break;
              case RakatType.sunnahGM:
                c = AppColors.sunnahColor.withOpacity(0.8);
                bg = AppColors.sunnahColor.withOpacity(0.07); break;
              case RakatType.nafal:
                c = AppColors.nafalColor; bg = AppColors.nafalColor.withOpacity(0.1); break;
              case RakatType.witr:
                c = AppColors.witrColor; bg = AppColors.witrColor.withOpacity(0.1); break;
            }
            return Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: bg,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: c.withOpacity(0.3)),
              ),
              child: Text(r.label,
                  style: TextStyle(
                      color: c,
                      fontSize: 11,
                      fontWeight: FontWeight.w500)),
            );
          }).toList(),
        ),
      ),
    );
  }

  // ── Nafal counter ─────────────────────────────────────────────────────────

  Widget _nafalRow(int count, String status, bool locked) {
    final canEdit = !locked && status != AppConstants.statusMissed;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      child: Opacity(
        opacity: locked ? 0.4 : 1.0,
        child: Row(children: [
          const Icon(Icons.wb_sunny_outlined, color: AppColors.nafalColor, size: 16),
          const SizedBox(width: 6),
          const Text('Nafal:',
              style: TextStyle(fontSize: 13, color: AppColors.textSecondary)),
          const SizedBox(width: 8),
          _counterBtn(Icons.remove, canEdit ? widget.onDecrNafal : null),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Text('$count',
                style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: AppColors.nafalColor)),
          ),
          _counterBtn(Icons.add, canEdit ? widget.onIncrNafal : null),
        ]),
      ),
    );
  }

  Widget _counterBtn(IconData icon, VoidCallback? onTap) {
    final active = onTap != null;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 28, height: 28,
        decoration: BoxDecoration(
          color: active
              ? AppColors.nafalColor.withOpacity(0.1)
              : Colors.grey.withOpacity(0.1),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
              color: active
                  ? AppColors.nafalColor.withOpacity(0.3)
                  : Colors.transparent),
        ),
        child: Icon(icon,
            size: 16,
            color: active ? AppColors.nafalColor : Colors.grey),
      ),
    );
  }

  // ── Action buttons ────────────────────────────────────────────────────────

  Widget _buttons(String status, bool locked) {
    // Future prayer — show a lock banner instead of buttons
    if (locked) {
      return Padding(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 14),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: Colors.grey.withOpacity(0.07),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: Colors.grey.withOpacity(0.2)),
          ),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Icon(Icons.lock_clock, color: Colors.grey, size: 16),
            const SizedBox(width: 8),
            Text(
              'Prayer time starts at ${AppDateUtils.toTime(widget.prayerTime!)}',
              style: const TextStyle(color: Colors.grey, fontSize: 13),
            ),
          ]),
        ),
      );
    }

    final isOffered = status == AppConstants.statusOffered;
    final isMissed  = status == AppConstants.statusMissed;

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 14),
      child: Row(children: [
        Expanded(
          child: ElevatedButton.icon(
            onPressed: isOffered ? null : widget.onOffered,
            icon: Icon(
              isOffered ? Icons.check_circle : Icons.check_circle_outline,
              size: 18,
            ),
            label: Text(isOffered ? '✓ Offered' : 'Mark Offered'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.offered,
              foregroundColor: Colors.white,
              disabledBackgroundColor: AppColors.offeredLight,
              disabledForegroundColor: AppColors.offered,
              padding: const EdgeInsets.symmetric(vertical: 10),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
            ),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: OutlinedButton.icon(
            onPressed: (isOffered || isMissed) ? null : widget.onMissed,
            icon: Icon(isMissed ? Icons.cancel : Icons.cancel_outlined, size: 18),
            label: Text(isMissed ? '✗ Missed' : 'Mark Missed'),
            style: OutlinedButton.styleFrom(
              foregroundColor: isMissed ? AppColors.missed : AppColors.pending,
              side: BorderSide(
                  color: isMissed ? AppColors.missed : AppColors.divider),
              padding: const EdgeInsets.symmetric(vertical: 10),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
            ),
          ),
        ),
      ]),
    );
  }
}
