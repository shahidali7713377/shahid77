// lib/data/repositories/screenshot_repository.dart
import 'dart:io';
import 'dart:typed_data';
import 'package:crypto/crypto.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:logger/logger.dart';
import 'package:path_provider/path_provider.dart';
import 'package:photo_manager/photo_manager.dart';
import 'package:uuid/uuid.dart';

import '../../core/ai/classification_engine.dart';
import '../../core/constants/app_constants.dart';
import '../../core/services/ocr_service.dart';
import '../models/screenshot_model.dart';

class ScreenshotRepository {
  final Logger _logger = Logger();
  final ClassificationEngine _classifier = ClassificationEngine();
  final OcrService _ocrService = OcrService();
  final Uuid _uuid = const Uuid();

  Box<ScreenshotModel>? _screenshotsBox;

  Future<void> init() async {
    _screenshotsBox = await Hive.openBox<ScreenshotModel>(
      AppConstants.hiveBoxScreenshots,
    );
    _logger.i('ScreenshotRepository initialized with ${_screenshotsBox!.length} entries');
  }

  Box<ScreenshotModel> get _box {
    if (_screenshotsBox == null || !_screenshotsBox!.isOpen) {
      throw StateError('ScreenshotRepository not initialized. Call init() first.');
    }
    return _screenshotsBox!;
  }

  // ---------------------------------------------------------------------------
  // Read Operations
  // ---------------------------------------------------------------------------

  List<ScreenshotModel> getAll({String? category, String? sortBy}) {
    var items = _box.values.toList();

    if (category != null && category != 'All') {
      items = items.where((s) => s.category == category).toList();
    }

    // Sort
    switch (sortBy ?? 'newest') {
      case 'newest':
        items.sort((a, b) => b.createdAt.compareTo(a.createdAt));
        break;
      case 'oldest':
        items.sort((a, b) => a.createdAt.compareTo(b.createdAt));
        break;
      case 'confidence':
        items.sort((a, b) => b.classificationConfidence.compareTo(a.classificationConfidence));
        break;
    }

    return items;
  }

  List<ScreenshotModel> search(String query) {
    if (query.trim().isEmpty) return getAll();
    final q = query.toLowerCase();
    return _box.values.where((s) {
      return s.extractedText.toLowerCase().contains(q) ||
          s.category.toLowerCase().contains(q) ||
          s.tags.any((t) => t.toLowerCase().contains(q)) ||
          (s.userNote?.toLowerCase().contains(q) ?? false);
    }).toList();
  }

  Map<String, int> getCategoryCounts() {
    final counts = <String, int>{};
    for (final s in _box.values) {
      counts[s.category] = (counts[s.category] ?? 0) + 1;
    }
    return counts;
  }

  List<ScreenshotModel> getDuplicates() {
    return _box.values.where((s) => s.duplicateIds.isNotEmpty).toList();
  }

  List<ScreenshotModel> getFavorites() {
    return _box.values.where((s) => s.isFavorite).toList();
  }

  int get totalCount => _box.length;

  // ---------------------------------------------------------------------------
  // Gallery Scanning
  // ---------------------------------------------------------------------------

  Future<ScanResult> scanGallery({
    void Function(ScanProgress)? onProgress,
    bool rescanExisting = false,
  }) async {
    final permission = await PhotoManager.requestPermissionExtend();
    if (!permission.isAuth) {
      return ScanResult.failure('Gallery permission denied');
    }

    // Get screenshot albums
    final albums = await PhotoManager.getAssetPathList(
      type: RequestType.image,
      filterOption: FilterOptionGroup(
        orders: [OrderOption(type: OrderOptionType.createDate, asc: false)],
      ),
    );

    final screenshotAlbums = albums.where((album) {
      final name = album.name.toLowerCase();
      return AppConstants.screenshotPaths
          .any((p) => name.contains(p.toLowerCase().split('/').last));
    }).toList();

    if (screenshotAlbums.isEmpty) {
      // Fall back to all images
      screenshotAlbums.addAll(albums.take(1));
    }

    int total = 0;
    int processed = 0;
    int added = 0;
    int skipped = 0;

    final existingPaths = _box.values.map((s) => s.filePath).toSet();

    for (final album in screenshotAlbums) {
      final count = await album.assetCountAsync;
      total += count;

      const pageSize = AppConstants.pageSize;
      int page = 0;

      while (true) {
        final assets = await album.getAssetListPaged(
          page: page,
          size: pageSize,
        );
        if (assets.isEmpty) break;

        for (final asset in assets) {
          final file = await asset.originFile;
          if (file == null) continue;

          if (!rescanExisting && existingPaths.contains(file.path)) {
            skipped++;
            continue;
          }

          await _processAndStore(asset, file);
          added++;
          processed++;

          onProgress?.call(ScanProgress(
            total: total,
            processed: processed,
            current: file.path.split('/').last,
          ));
        }

        if (assets.length < pageSize) break;
        page++;
      }
    }

    return ScanResult.success(
      totalScanned: total,
      added: added,
      skipped: skipped,
    );
  }

  Future<void> importFromPicker(List<String> paths) async {
    for (final path in paths) {
      final file = File(path);
      if (!await file.exists()) continue;

      final stat = await file.stat();
      final model = ScreenshotModel(
        id: _uuid.v4(),
        filePath: path,
        category: 'Other',
        createdAt: stat.modified,
        isProcessed: false,
      );

      await _box.put(model.id, model);
      await _processScreenshot(model.id);
    }
  }

  // ---------------------------------------------------------------------------
  // Processing
  // ---------------------------------------------------------------------------

  Future<void> _processAndStore(AssetEntity asset, File file) async {
    final id = _uuid.v4();
    final thumbnailPath = await _generateThumbnail(file, id);
    final hash = await _computePerceptualHash(file);

    final model = ScreenshotModel(
      id: id,
      filePath: file.path,
      thumbnailPath: thumbnailPath,
      category: 'Other',
      createdAt: asset.createDateTime,
      perceptualHash: hash,
    );

    await _box.put(id, model);
    await _processScreenshot(id);
  }

  Future<void> _processScreenshot(String id) async {
    final model = _box.get(id);
    if (model == null) return;

    try {
      // OCR
      final ocrResult = await _ocrService.extractText(model.filePath);

      // Classification
      final classResult = _classifier.classify(ocrResult.text);

      // Tag extraction
      final tags = _classifier.extractTags(ocrResult.text, classResult.category);

      // Receipt data extraction
      Map<String, dynamic>? extractedData;
      if (classResult.category == 'Receipts') {
        final receiptData = _classifier.extractReceiptData(ocrResult.text);
        extractedData = receiptData?.toMap();
      }

      // Duplicate detection
      final duplicates = await _findDuplicates(model.id, model.perceptualHash);

      final updated = model.copyWith(
        extractedText: ocrResult.text,
        category: classResult.category,
        classificationConfidence: classResult.confidence,
        tags: tags,
        isProcessed: true,
        processedAt: DateTime.now(),
        extractedData: extractedData,
        duplicateIds: duplicates,
      );

      // Update in Hive using box.put (Hive objects are mutable but we want clean state)
      await _box.put(id, updated);
      _logger.d('Processed: ${classResult.category} (${(classResult.confidence * 100).toStringAsFixed(0)}%) - ${model.filePath.split('/').last}');
    } catch (e, stack) {
      _logger.e('Failed to process screenshot $id', error: e, stackTrace: stack);
    }
  }

  // ---------------------------------------------------------------------------
  // Thumbnail Generation
  // ---------------------------------------------------------------------------

  Future<String?> _generateThumbnail(File file, String id) async {
    try {
      final dir = await getApplicationDocumentsDirectory();
      final thumbDir = Directory('${dir.path}/thumbnails');
      await thumbDir.create(recursive: true);
      final thumbPath = '${thumbDir.path}/$id.jpg';

      final compressed = await FlutterImageCompress.compressAndGetFile(
        file.path,
        thumbPath,
        minWidth: AppConstants.thumbnailSize,
        minHeight: AppConstants.thumbnailSize,
        quality: AppConstants.thumbnailQuality,
      );

      return compressed?.path;
    } catch (e) {
      _logger.w('Thumbnail generation failed', error: e);
      return null;
    }
  }

  // ---------------------------------------------------------------------------
  // Perceptual Hashing for Duplicate Detection
  // ---------------------------------------------------------------------------

  Future<String?> _computePerceptualHash(File file) async {
    try {
      final bytes = await file.readAsBytes();
      final digest = md5.convert(bytes);
      return digest.toString();
    } catch (e) {
      return null;
    }
  }

  Future<List<String>> _findDuplicates(String currentId, String? hash) async {
    if (hash == null) return [];
    return _box.values
        .where((s) => s.id != currentId && s.perceptualHash == hash)
        .map((s) => s.id)
        .toList();
  }

  // ---------------------------------------------------------------------------
  // Write Operations
  // ---------------------------------------------------------------------------

  Future<void> updateCategory(String id, String newCategory) async {
    final model = _box.get(id);
    if (model == null) return;
    final updated = model.copyWith(category: newCategory);
    await _box.put(id, updated);
  }

  Future<void> updateNote(String id, String note) async {
    final model = _box.get(id);
    if (model == null) return;
    final updated = model.copyWith(userNote: note);
    await _box.put(id, updated);
  }

  Future<void> toggleFavorite(String id) async {
    final model = _box.get(id);
    if (model == null) return;
    final updated = model.copyWith(isFavorite: !model.isFavorite);
    await _box.put(id, updated);
  }

  Future<void> toggleLock(String id) async {
    final model = _box.get(id);
    if (model == null) return;
    final updated = model.copyWith(isLocked: !model.isLocked);
    await _box.put(id, updated);
  }

  Future<void> updateTags(String id, List<String> tags) async {
    final model = _box.get(id);
    if (model == null) return;
    final updated = model.copyWith(tags: tags);
    await _box.put(id, updated);
  }

  Future<void> delete(String id) async {
    final model = _box.get(id);
    if (model?.isLocked ?? false) {
      throw Exception('Cannot delete a locked screenshot');
    }
    await _box.delete(id);
  }

  Future<void> deleteMultiple(List<String> ids) async {
    for (final id in ids) {
      final model = _box.get(id);
      if (model?.isLocked ?? false) continue;
      await _box.delete(id);
    }
  }

  Future<void> reprocessScreenshot(String id) async {
    await _processScreenshot(id);
  }

  // ---------------------------------------------------------------------------
  // Custom Folder Scanning — public API
  // ---------------------------------------------------------------------------

  /// Returns all image albums available on the device, enriched with
  /// asset counts and lazy thumbnail loaders for the picker UI.
  Future<List<AlbumInfo>> getAvailableAlbums() async {
    final permission = await PhotoManager.requestPermissionExtend();
    if (!permission.isAuth) return [];

    final paths = await PhotoManager.getAssetPathList(
      type: RequestType.image,
      filterOption: FilterOptionGroup(
        orders: [OrderOption(type: OrderOptionType.createDate, asc: false)],
      ),
    );

    final albums = <AlbumInfo>[];
    for (final path in paths) {
      final count = await path.assetCountAsync;
      if (count == 0) continue;

      // Derive path components from album name (Android paths are flat names;
      // iOS paths may include slashes).
      final rawName = path.name;
      final parts = rawName.split(RegExp(r'[/\\]')).where((p) => p.isNotEmpty).toList();

      albums.add(AlbumInfo(
        id: path.id,
        name: rawName,
        assetCount: count,
        pathComponents: parts.isEmpty ? [rawName] : parts,
        thumbnailLoader: () async {
          try {
            final assets = await path.getAssetListRange(start: 0, end: 1);
            if (assets.isEmpty) return null;
            return await assets.first.thumbnailDataWithSize(
              const ThumbnailSize(120, 120),
              quality: 70,
            );
          } catch (_) {
            return null;
          }
        },
      ));
    }

    // Sort: screenshot folders first, then by asset count descending.
    albums.sort((a, b) {
      if (a.isScreenshotFolder && !b.isScreenshotFolder) return -1;
      if (!a.isScreenshotFolder && b.isScreenshotFolder) return 1;
      return b.assetCount.compareTo(a.assetCount);
    });

    return albums;
  }

  /// Scans only the albums whose IDs are in [albumIds].
  /// Calls [onProgress] for each processed asset.
  Future<ScanResult> scanCustomAlbums({
    required List<String> albumIds,
    void Function(ScanProgress)? onProgress,
    bool rescanExisting = false,
  }) async {
    final permission = await PhotoManager.requestPermissionExtend();
    if (!permission.isAuth) return ScanResult.failure('Gallery permission denied');

    final allPaths = await PhotoManager.getAssetPathList(type: RequestType.image);
    final targetPaths = allPaths.where((p) => albumIds.contains(p.id)).toList();

    if (targetPaths.isEmpty) {
      return ScanResult.failure('Selected folders not found on device');
    }

    final existingPaths = _box.values.map((s) => s.filePath).toSet();
    int total = 0;
    int processed = 0;
    int added = 0;
    int skipped = 0;

    // Pre-count so the progress bar is accurate.
    for (final path in targetPaths) {
      total += await path.assetCountAsync;
    }

    for (final path in targetPaths) {
      const pageSize = AppConstants.pageSize;
      int page = 0;

      while (true) {
        final assets = await path.getAssetListPaged(page: page, size: pageSize);
        if (assets.isEmpty) break;

        for (final asset in assets) {
          final file = await asset.originFile;
          if (file == null) { processed++; continue; }

          if (!rescanExisting && existingPaths.contains(file.path)) {
            skipped++;
            processed++;
          } else {
            await _processAndStore(asset, file);
            added++;
            processed++;
          }

          onProgress?.call(ScanProgress(
            total: total,
            processed: processed,
            current: file.path.split('/').last,
            folderLabel: path.name,
          ));
        }

        if (assets.length < pageSize) break;
        page++;
      }
    }

    return ScanResult.success(
      totalScanned: total,
      added: added,
      skipped: skipped,
    );
  }

  // ---------------------------------------------------------------------------
  // Analytics
  // ---------------------------------------------------------------------------

  Map<String, dynamic> getAnalytics() {
    final all = _box.values.toList();
    final byCategory = getCategoryCounts();

    // Monthly trend (last 6 months)
    final now = DateTime.now();
    final monthlyData = <String, int>{};
    for (int i = 5; i >= 0; i--) {
      final month = DateTime(now.year, now.month - i, 1);
      final key = '${month.year}-${month.month.toString().padLeft(2, '0')}';
      monthlyData[key] = 0;
    }
    for (final s in all) {
      final key = '${s.createdAt.year}-${s.createdAt.month.toString().padLeft(2, '0')}';
      if (monthlyData.containsKey(key)) {
        monthlyData[key] = (monthlyData[key] ?? 0) + 1;
      }
    }

    // Top tags
    final tagFreq = <String, int>{};
    for (final s in all) {
      for (final tag in s.tags) {
        tagFreq[tag] = (tagFreq[tag] ?? 0) + 1;
      }
    }
    final topTags = (tagFreq.entries.toList()
          ..sort((a, b) => b.value.compareTo(a.value)))
        .take(10)
        .map((e) => {'tag': e.key, 'count': e.value})
        .toList();

    // Receipt totals
    final receipts = all.where((s) => s.category == 'Receipts');
    final totalSpend = receipts
        .fold(0.0, (sum, s) => sum + (s.receiptAmount ?? 0));

    return {
      'total': all.length,
      'processed': all.where((s) => s.isProcessed).length,
      'byCategory': byCategory,
      'monthlyTrend': monthlyData,
      'topTags': topTags,
      'favorites': all.where((s) => s.isFavorite).length,
      'duplicates': all.where((s) => s.duplicateIds.isNotEmpty).length,
      'totalReceiptSpend': totalSpend,
    };
  }
}

// ---------------------------------------------------------------------------
// Value Objects
// ---------------------------------------------------------------------------

class ScanProgress {
  final int total;
  final int processed;
  final String current;
  /// Shown in the progress overlay when scanning specific folders.
  final String? folderLabel;

  const ScanProgress({
    required this.total,
    required this.processed,
    required this.current,
    this.folderLabel,
  });

  double get percentage => total > 0 ? processed / total : 0;
}

/// Lightweight representation of a device album for the folder picker.
class AlbumInfo {
  final String id;
  final String name;
  final int assetCount;
  /// Split path components for grouping (e.g. ['DCIM', 'Camera']).
  final List<String> pathComponents;
  /// Lazy loader for the cover thumbnail bytes.
  final Future<Uint8List?> Function()? thumbnailLoader;

  const AlbumInfo({
    required this.id,
    required this.name,
    required this.assetCount,
    required this.pathComponents,
    this.thumbnailLoader,
  });

  /// Top-level group label, e.g. "DCIM", "Pictures", "Downloads".
  String get groupName =>
      pathComponents.length > 1 ? pathComponents.first : 'Gallery';

  bool get isScreenshotFolder {
    final lower = name.toLowerCase();
    return lower.contains('screenshot') || lower.contains('screen shot');
  }
}

class ScanResult {
  final bool success;
  final String? error;
  final int totalScanned;
  final int added;
  final int skipped;

  const ScanResult._({
    required this.success,
    this.error,
    this.totalScanned = 0,
    this.added = 0,
    this.skipped = 0,
  });

  factory ScanResult.success({
    required int totalScanned,
    required int added,
    required int skipped,
  }) =>
      ScanResult._(
        success: true,
        totalScanned: totalScanned,
        added: added,
        skipped: skipped,
      );

  factory ScanResult.failure(String error) =>
      ScanResult._(success: false, error: error);
}
