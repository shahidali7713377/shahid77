// lib/data/models/screenshot_model.dart
import 'package:hive/hive.dart';
import 'package:equatable/equatable.dart';

part 'screenshot_model.g.dart';

@HiveType(typeId: 0)
class ScreenshotModel extends HiveObject with EquatableMixin {
  @HiveField(0)
  final String id;

  @HiveField(1)
  final String filePath;

  @HiveField(2)
  final String? thumbnailPath;

  @HiveField(3)
  String category;

  @HiveField(4)
  String extractedText;

  @HiveField(5)
  List<String> tags;

  @HiveField(6)
  final DateTime createdAt;

  @HiveField(7)
  DateTime? processedAt;

  @HiveField(8)
  bool isProcessed;

  @HiveField(9)
  bool isLocked;

  @HiveField(10)
  double classificationConfidence;

  @HiveField(11)
  String? perceptualHash;

  @HiveField(12)
  Map<String, dynamic>? extractedData;  // for receipts: amount, store, date

  @HiveField(13)
  String? userNote;

  @HiveField(14)
  bool isFavorite;

  @HiveField(15)
  List<String> duplicateIds;

  ScreenshotModel({
    required this.id,
    required this.filePath,
    this.thumbnailPath,
    required this.category,
    this.extractedText = '',
    List<String>? tags,
    required this.createdAt,
    this.processedAt,
    this.isProcessed = false,
    this.isLocked = false,
    this.classificationConfidence = 0.0,
    this.perceptualHash,
    this.extractedData,
    this.userNote,
    this.isFavorite = false,
    List<String>? duplicateIds,
  })  : tags = tags ?? [],
        duplicateIds = duplicateIds ?? [];

  ScreenshotModel copyWith({
    String? category,
    String? extractedText,
    List<String>? tags,
    DateTime? processedAt,
    bool? isProcessed,
    bool? isLocked,
    double? classificationConfidence,
    String? perceptualHash,
    Map<String, dynamic>? extractedData,
    String? userNote,
    bool? isFavorite,
    List<String>? duplicateIds,
    String? thumbnailPath,
  }) {
    return ScreenshotModel(
      id: id,
      filePath: filePath,
      thumbnailPath: thumbnailPath ?? this.thumbnailPath,
      category: category ?? this.category,
      extractedText: extractedText ?? this.extractedText,
      tags: tags ?? this.tags,
      createdAt: createdAt,
      processedAt: processedAt ?? this.processedAt,
      isProcessed: isProcessed ?? this.isProcessed,
      isLocked: isLocked ?? this.isLocked,
      classificationConfidence: classificationConfidence ?? this.classificationConfidence,
      perceptualHash: perceptualHash ?? this.perceptualHash,
      extractedData: extractedData ?? this.extractedData,
      userNote: userNote ?? this.userNote,
      isFavorite: isFavorite ?? this.isFavorite,
      duplicateIds: duplicateIds ?? this.duplicateIds,
    );
  }

  // Receipt helpers
  double? get receiptAmount => extractedData?['amount'] as double?;
  String? get receiptStore => extractedData?['store'] as String?;
  DateTime? get receiptDate {
    final dateStr = extractedData?['date'] as String?;
    return dateStr != null ? DateTime.tryParse(dateStr) : null;
  }

  @override
  List<Object?> get props => [id, filePath, category, extractedText, tags, createdAt];

  @override
  String toString() => 'ScreenshotModel(id: $id, category: $category, processed: $isProcessed)';
}

// Analytics model
@HiveType(typeId: 1)
class ScanSessionModel extends HiveObject {
  @HiveField(0)
  final String id;

  @HiveField(1)
  final DateTime startedAt;

  @HiveField(2)
  DateTime? completedAt;

  @HiveField(3)
  int totalScanned;

  @HiveField(4)
  int totalProcessed;

  @HiveField(5)
  Map<String, int> categoryBreakdown;

  ScanSessionModel({
    required this.id,
    required this.startedAt,
    this.completedAt,
    this.totalScanned = 0,
    this.totalProcessed = 0,
    Map<String, int>? categoryBreakdown,
  }) : categoryBreakdown = categoryBreakdown ?? {};
}

// App settings model
@HiveType(typeId: 2)
class AppSettingsModel extends HiveObject {
  @HiveField(0)
  bool biometricEnabled;

  @HiveField(1)
  bool autoScanEnabled;

  @HiveField(2)
  bool cloudBackupEnabled;

  @HiveField(3)
  int cleanupThresholdDays;

  @HiveField(4)
  bool duplicateDetectionEnabled;

  @HiveField(5)
  bool isProVersion;

  @HiveField(6)
  String defaultSortOrder;

  @HiveField(7)
  List<String> customCategories;

  AppSettingsModel({
    this.biometricEnabled = false,
    this.autoScanEnabled = true,
    this.cloudBackupEnabled = false,
    this.cleanupThresholdDays = 90,
    this.duplicateDetectionEnabled = true,
    this.isProVersion = false,
    this.defaultSortOrder = 'newest',
    List<String>? customCategories,
  }) : customCategories = customCategories ?? [];
}
