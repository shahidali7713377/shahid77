// lib/data/models/screenshot_model.g.dart
// GENERATED CODE - DO NOT MODIFY BY HAND
// Run: flutter packages pub run build_runner build --delete-conflicting-outputs

part of 'screenshot_model.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class ScreenshotModelAdapter extends TypeAdapter<ScreenshotModel> {
  @override
  final int typeId = 0;

  @override
  ScreenshotModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return ScreenshotModel(
      id: fields[0] as String,
      filePath: fields[1] as String,
      thumbnailPath: fields[2] as String?,
      category: fields[3] as String,
      extractedText: fields[4] as String,
      tags: (fields[5] as List).cast<String>(),
      createdAt: fields[6] as DateTime,
      processedAt: fields[7] as DateTime?,
      isProcessed: fields[8] as bool,
      isLocked: fields[9] as bool,
      classificationConfidence: fields[10] as double,
      perceptualHash: fields[11] as String?,
      extractedData: (fields[12] as Map?)?.cast<String, dynamic>(),
      userNote: fields[13] as String?,
      isFavorite: fields[14] as bool,
      duplicateIds: (fields[15] as List).cast<String>(),
    );
  }

  @override
  void write(BinaryWriter writer, ScreenshotModel obj) {
    writer
      ..writeByte(16)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.filePath)
      ..writeByte(2)
      ..write(obj.thumbnailPath)
      ..writeByte(3)
      ..write(obj.category)
      ..writeByte(4)
      ..write(obj.extractedText)
      ..writeByte(5)
      ..write(obj.tags)
      ..writeByte(6)
      ..write(obj.createdAt)
      ..writeByte(7)
      ..write(obj.processedAt)
      ..writeByte(8)
      ..write(obj.isProcessed)
      ..writeByte(9)
      ..write(obj.isLocked)
      ..writeByte(10)
      ..write(obj.classificationConfidence)
      ..writeByte(11)
      ..write(obj.perceptualHash)
      ..writeByte(12)
      ..write(obj.extractedData)
      ..writeByte(13)
      ..write(obj.userNote)
      ..writeByte(14)
      ..write(obj.isFavorite)
      ..writeByte(15)
      ..write(obj.duplicateIds);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is ScreenshotModelAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class ScanSessionModelAdapter extends TypeAdapter<ScanSessionModel> {
  @override
  final int typeId = 1;

  @override
  ScanSessionModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return ScanSessionModel(
      id: fields[0] as String,
      startedAt: fields[1] as DateTime,
      completedAt: fields[2] as DateTime?,
      totalScanned: fields[3] as int,
      totalProcessed: fields[4] as int,
      categoryBreakdown: (fields[5] as Map).cast<String, int>(),
    );
  }

  @override
  void write(BinaryWriter writer, ScanSessionModel obj) {
    writer
      ..writeByte(6)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.startedAt)
      ..writeByte(2)
      ..write(obj.completedAt)
      ..writeByte(3)
      ..write(obj.totalScanned)
      ..writeByte(4)
      ..write(obj.totalProcessed)
      ..writeByte(5)
      ..write(obj.categoryBreakdown);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is ScanSessionModelAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class AppSettingsModelAdapter extends TypeAdapter<AppSettingsModel> {
  @override
  final int typeId = 2;

  @override
  AppSettingsModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return AppSettingsModel(
      biometricEnabled: fields[0] as bool,
      autoScanEnabled: fields[1] as bool,
      cloudBackupEnabled: fields[2] as bool,
      cleanupThresholdDays: fields[3] as int,
      duplicateDetectionEnabled: fields[4] as bool,
      isProVersion: fields[5] as bool,
      defaultSortOrder: fields[6] as String,
      customCategories: (fields[7] as List).cast<String>(),
    );
  }

  @override
  void write(BinaryWriter writer, AppSettingsModel obj) {
    writer
      ..writeByte(8)
      ..writeByte(0)
      ..write(obj.biometricEnabled)
      ..writeByte(1)
      ..write(obj.autoScanEnabled)
      ..writeByte(2)
      ..write(obj.cloudBackupEnabled)
      ..writeByte(3)
      ..write(obj.cleanupThresholdDays)
      ..writeByte(4)
      ..write(obj.duplicateDetectionEnabled)
      ..writeByte(5)
      ..write(obj.isProVersion)
      ..writeByte(6)
      ..write(obj.defaultSortOrder)
      ..writeByte(7)
      ..write(obj.customCategories);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is AppSettingsModelAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
