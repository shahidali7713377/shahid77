// lib/core/constants/app_constants.dart

class AppConstants {
  // App Info
  static const String appName = 'Screenshot Memory';
  static const String appVersion = '1.0.0';
  static const String appTagline = 'Your AI-powered second brain';

  // Database
  static const String hiveBoxScreenshots = 'screenshots';
  static const String hiveBoxCategories = 'categories';
  static const String hiveBoxTags = 'tags';
  static const String hiveBoxSettings = 'settings';
  static const String hiveBoxAnalytics = 'analytics';

  // Secure Storage Keys
  static const String keyBiometricEnabled = 'biometric_enabled';
  static const String keyOnboardingComplete = 'onboarding_complete';
  static const String keyProVersion = 'pro_version';

  // Free Tier Limits
  static const int freeScreenshotLimit = 5000;

  // OCR Settings
  static const int ocrBatchSize = 10;
  static const Duration ocrTimeout = Duration(seconds: 10);

  // Image Processing
  static const int duplicateHashSize = 8;       // perceptual hash size
  static const double duplicateThreshold = 0.85; // similarity threshold

  // Categories
  static const List<String> defaultCategories = [
    'Ideas',
    'Receipts',
    'Quotes',
    'Study Material',
    'Shopping',
    'Other',
  ];

  // Category Icons (using Material icon code points as strings)
  static const Map<String, String> categoryEmojis = {
    'Ideas': '💡',
    'Receipts': '🧾',
    'Quotes': '💬',
    'Study Material': '📚',
    'Shopping': '🛒',
    'Other': '📁',
  };

  // Search
  static const int searchDebounceMs = 300;
  static const int maxSearchResults = 100;

  // Analytics
  static const int analyticsRetentionDays = 90;

  // Export
  static const String exportFolderName = 'ScreenshotMemory';
  static const List<String> exportFormats = ['PDF', 'TXT', 'JSON'];

  // Pagination
  static const int pageSize = 30;

  // Image Compression
  static const int thumbnailQuality = 70;
  static const int thumbnailSize = 300;  // px

  // Supported Screenshot Folders (Android)
  static const List<String> screenshotPaths = [
    'Screenshots',
    'DCIM/Screenshots',
    'Pictures/Screenshots',
  ];
}

class AppStrings {
  // Onboarding
  static const String onboardTitle1 = 'Your Screenshots,\nOrganized by AI';
  static const String onboardDesc1 = 'Stop scrolling through thousands of screenshots. Let AI sort them instantly.';
  static const String onboardTitle2 = 'Extract Knowledge,\nNot Just Images';
  static const String onboardDesc2 = 'OCR technology reads every screenshot, turning images into searchable text.';
  static const String onboardTitle3 = 'Build Your\nSecond Brain';
  static const String onboardDesc3 = 'Ideas, receipts, quotes, study notes — all automatically organized.';

  // Empty States
  static const String emptyScreenshots = 'No screenshots yet';
  static const String emptyCategory = 'Nothing here yet';
  static const String emptySearch = 'No results found';
  static const String emptyDuplicates = 'No duplicates found!';

  // Actions
  static const String scanGallery = 'Scan Gallery';
  static const String importManually = 'Import Manually';
  static const String deleteSelected = 'Delete Selected';
  static const String exportPdf = 'Export as PDF';
  static const String shareCard = 'Share Card';
}
