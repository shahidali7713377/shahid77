// lib/core/ai/classification_engine.dart
import 'dart:math';

/// AI-powered classification engine for screenshot content.
/// Uses a hybrid rule-based + ML approach.
/// Replace keyword rules with a TFLite model for production.
class ClassificationEngine {
  static final ClassificationEngine _instance = ClassificationEngine._internal();
  factory ClassificationEngine() => _instance;
  ClassificationEngine._internal();

  // ---------------------------------------------------------------------------
  // Rule-based keyword patterns per category
  // ---------------------------------------------------------------------------

  static const Map<String, List<String>> _categoryPatterns = {
    'Receipts': [
      'total', 'subtotal', 'tax', 'vat', 'gst', 'payment', 'paid', 'receipt',
      'invoice', 'order', 'transaction', 'amount due', 'balance', 'cash',
      'credit card', 'debit', 'visa', 'mastercard', 'refund', 'item(s)',
      'qty', 'quantity', 'price', '\$', '€', '£', '₹', '¥', 'store',
      'purchase', 'checkout', 'thank you for', 'order number', 'delivery fee',
      'shipping', 'walmart', 'amazon', 'target', 'costco', 'whole foods',
    ],
    'Quotes': [
      '"', '"', '"', '—', 'said', 'wrote', 'quote', 'by ', '- ',
      'inspiration', 'motivation', 'wisdom', 'life lesson', 'mindset',
      'believe', 'success', 'dream', 'achieve', 'persevere', 'courage',
      'strength', 'journey', 'purpose', 'passion', 'grateful', 'gratitude',
    ],
    'Study Material': [
      'chapter', 'definition', 'formula', 'equation', 'theorem', 'proof',
      'lecture', 'notes', 'study', 'exam', 'quiz', 'test', 'assignment',
      'homework', 'course', 'university', 'college', 'professor', 'textbook',
      'summary', 'key points', 'important:', 'note:', 'remember:', 'learn',
      'concept', 'topic', 'unit', 'module', 'curriculum', 'syllabus',
      'biology', 'chemistry', 'physics', 'mathematics', 'history', 'literature',
      'psychology', 'economics', 'algorithm', 'programming', 'data structure',
    ],
    'Shopping': [
      'add to cart', 'buy now', 'wishlist', 'wish list', 'shop', 'store',
      'product', 'model', 'color', 'size', 'sku', 'asin', 'rating',
      'reviews', 'stars', 'in stock', 'out of stock', 'sold by',
      'free shipping', 'prime', 'sale', 'off', 'discount', 'deal',
      'limited time', 'flash sale', 'coupon', 'promo', 'offer expires',
      'available in', 'ships to', 'estimate', 'compare', 'specifications',
    ],
    'Ideas': [
      'idea', 'concept', 'plan', 'strategy', 'brainstorm', 'note to self',
      'todo', 'to-do', 'to do', 'reminder', 'task', 'project', 'goal',
      'vision', 'mission', 'startup', 'business', 'app', 'feature',
      'design', 'prototype', 'mvp', 'launch', 'market', 'customer',
      'solution', 'problem', 'opportunity', 'insight', 'hypothesis',
      'research', 'experiment', 'test', 'validate', 'iterate',
    ],
  };

  // ---------------------------------------------------------------------------
  // Receipt-specific extraction patterns (regex-like via contains checks)
  // ---------------------------------------------------------------------------
  static final RegExp _amountPattern = RegExp(
    r'(?:total|amount|subtotal|due|paid)[:\s]*[\$€£₹¥]?\s*(\d+[\.,]\d{2})',
    caseSensitive: false,
  );
  static final RegExp _datePattern = RegExp(
    r'\b(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4}|\d{4}[\/\-]\d{2}[\/\-]\d{2})\b',
  );
  static final RegExp _storePattern = RegExp(
    r'^([A-Z][A-Za-z\s&\']+?)(?:\s+(?:store|location|branch))?\s*\n',
    multiLine: true,
  );

  // ---------------------------------------------------------------------------
  // Public API
  // ---------------------------------------------------------------------------

  /// Classify extracted text into a category with a confidence score.
  ClassificationResult classify(String text) {
    if (text.trim().isEmpty) {
      return ClassificationResult(
        category: 'Other',
        confidence: 1.0,
        scores: {},
      );
    }

    final lower = text.toLowerCase();
    final scores = <String, double>{};

    _categoryPatterns.forEach((category, keywords) {
      double score = 0;
      int matched = 0;
      for (final keyword in keywords) {
        if (lower.contains(keyword.toLowerCase())) {
          matched++;
          // Weight longer / more specific keywords higher
          score += 1 + (keyword.length / 20);
        }
      }
      // Normalize by keyword count to prevent large lists dominating
      final normalizedScore = matched > 0
          ? score / sqrt(keywords.length.toDouble())
          : 0.0;
      scores[category] = normalizedScore;
    });

    if (scores.values.every((s) => s == 0)) {
      return ClassificationResult(
        category: 'Other',
        confidence: 0.5,
        scores: scores,
      );
    }

    // Pick the highest-scoring category
    final best = scores.entries.reduce((a, b) => a.value > b.value ? a : b);
    final total = scores.values.fold(0.0, (a, b) => a + b);
    final confidence = total > 0 ? (best.value / total).clamp(0.0, 1.0) : 0.5;

    return ClassificationResult(
      category: best.key,
      confidence: confidence,
      scores: scores,
    );
  }

  /// Extract structured data from receipt text.
  ReceiptData? extractReceiptData(String text) {
    final amountMatch = _amountPattern.firstMatch(text);
    final dateMatches = _datePattern.allMatches(text);
    final storeMatch = _storePattern.firstMatch(text);

    double? amount;
    if (amountMatch != null) {
      final amtStr = amountMatch.group(1)?.replaceAll(',', '.') ?? '';
      amount = double.tryParse(amtStr);
    }

    DateTime? date;
    if (dateMatches.isNotEmpty) {
      final dateStr = dateMatches.first.group(0) ?? '';
      // Normalize separators and try parsing
      final normalized = dateStr.replaceAll(RegExp(r'[-]'), '/');
      final parts = normalized.split('/');
      if (parts.length == 3) {
        try {
          // Handle dd/mm/yyyy or yyyy/mm/dd
          if (parts[0].length == 4) {
            date = DateTime(int.parse(parts[0]), int.parse(parts[1]), int.parse(parts[2]));
          } else {
            final year = int.parse(parts[2]);
            date = DateTime(
              year < 100 ? 2000 + year : year,
              int.parse(parts[1]),
              int.parse(parts[0]),
            );
          }
        } catch (_) {}
      }
    }

    if (amount == null && date == null && storeMatch == null) return null;

    return ReceiptData(
      amount: amount,
      date: date,
      storeName: storeMatch?.group(1)?.trim(),
    );
  }

  /// Auto-generate tags from extracted text.
  List<String> extractTags(String text, String category) {
    if (text.trim().isEmpty) return [category.toLowerCase()];

    final tags = <String>{category.toLowerCase()};
    final words = text.toLowerCase().split(RegExp(r'\W+'));

    // Stopwords to ignore
    const stopWords = {
      'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for',
      'of', 'with', 'by', 'from', 'is', 'it', 'its', 'be', 'are', 'was',
      'as', 'this', 'that', 'not', 'you', 'we', 'he', 'she', 'they', 'my',
      'our', 'your', 'has', 'have', 'had', 'can', 'will', 'do', 'did', 'so',
    };

    // Frequency map
    final freq = <String, int>{};
    for (final word in words) {
      if (word.length > 3 && !stopWords.contains(word)) {
        freq[word] = (freq[word] ?? 0) + 1;
      }
    }

    // Top 8 most frequent words as tags
    final sorted = freq.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    tags.addAll(sorted.take(8).map((e) => e.key));

    return tags.toList();
  }
}

class ClassificationResult {
  final String category;
  final double confidence;
  final Map<String, double> scores;

  const ClassificationResult({
    required this.category,
    required this.confidence,
    required this.scores,
  });

  bool get isHighConfidence => confidence > 0.6;
  bool get isMediumConfidence => confidence > 0.35;

  @override
  String toString() => 'ClassificationResult($category @ ${(confidence * 100).toStringAsFixed(1)}%)';
}

class ReceiptData {
  final double? amount;
  final DateTime? date;
  final String? storeName;

  const ReceiptData({
    this.amount,
    this.date,
    this.storeName,
  });

  Map<String, dynamic> toMap() => {
    if (amount != null) 'amount': amount,
    if (date != null) 'date': date!.toIso8601String(),
    if (storeName != null) 'store': storeName,
  };
}
