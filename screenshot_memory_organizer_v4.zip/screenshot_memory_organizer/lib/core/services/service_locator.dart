// lib/core/services/service_locator.dart
import 'package:get_it/get_it.dart';
import 'package:hive_flutter/hive_flutter.dart';

import '../../data/models/screenshot_model.dart';
import '../../data/repositories/screenshot_repository.dart';
import '../../features/scan/presentation/bloc/scan_bloc.dart';
import '../../features/dashboard/presentation/bloc/dashboard_bloc.dart';
import '../../features/settings/presentation/bloc/settings_bloc.dart';
import '../ai/classification_engine.dart';
import '../services/ocr_service.dart';

final getIt = GetIt.instance;

Future<void> setupServiceLocator() async {
  // ── Hive Adapters ──────────────────────────────────────────────────────
  if (!Hive.isAdapterRegistered(0)) Hive.registerAdapter(ScreenshotModelAdapter());
  if (!Hive.isAdapterRegistered(1)) Hive.registerAdapter(ScanSessionModelAdapter());
  if (!Hive.isAdapterRegistered(2)) Hive.registerAdapter(AppSettingsModelAdapter());

  // ── Core Services ──────────────────────────────────────────────────────
  getIt.registerLazySingleton<ClassificationEngine>(() => ClassificationEngine());
  getIt.registerLazySingleton<OcrService>(() => OcrService());

  // ── Repositories ───────────────────────────────────────────────────────
  getIt.registerSingletonAsync<ScreenshotRepository>(() async {
    final repo = ScreenshotRepository();
    await repo.init();
    return repo;
  });
  await getIt.isReady<ScreenshotRepository>();

  // ── BLoCs ──────────────────────────────────────────────────────────────
  getIt.registerFactory<ScanBloc>(
    () => ScanBloc(getIt<ScreenshotRepository>()),
  );
  getIt.registerFactory<DashboardBloc>(
    () => DashboardBloc(getIt<ScreenshotRepository>()),
  );
  // SettingsBloc is a singleton: settings should be shared across the whole app.
  getIt.registerLazySingleton<SettingsBloc>(() => SettingsBloc());
}
