// lib/core/services/ocr_service.dart
import 'dart:io';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:logger/logger.dart';

class OcrService {
  static final OcrService _instance = OcrService._internal();
  factory OcrService() => _instance;
  OcrService._internal();

  final Logger _logger = Logger();

  // Use DEVANAGARI or CHINESE script recognizers for multi-language support.
  // Default to Latin for broad coverage.
  late final TextRecognizer _latinRecognizer =
      TextRecognizer(script: TextRecognitionScript.latin);
  late final TextRecognizer _chineseRecognizer =
      TextRecognizer(script: TextRecognitionScript.chinese);
  late final TextRecognizer _devanagariRecognizer =
      TextRecognizer(script: TextRecognitionScript.devanagari);

  bool _isDisposed = false;

  /// Extract text from an image file path.
  Future<OcrResult> extractText(String imagePath, {bool multiLanguage = false}) async {
    if (_isDisposed) return OcrResult.empty(imagePath);

    final file = File(imagePath);
    if (!await file.exists()) {
      _logger.w('OcrService: File not found: $imagePath');
      return OcrResult.empty(imagePath);
    }

    final inputImage = InputImage.fromFilePath(imagePath);
    final stopwatch = Stopwatch()..start();

    try {
      // Primary: Latin recognition
      final recognizedText = await _latinRecognizer.processImage(inputImage);
      String combinedText = recognizedText.text;

      if (multiLanguage && combinedText.trim().isEmpty) {
        // Fallback: try Chinese recognizer
        try {
          final chineseText = await _chineseRecognizer.processImage(inputImage);
          if (chineseText.text.isNotEmpty) {
            combinedText = chineseText.text;
          }
        } catch (_) {}
      }

      stopwatch.stop();
      _logger.d('OCR completed in ${stopwatch.elapsedMilliseconds}ms for $imagePath');

      return OcrResult(
        imagePath: imagePath,
        text: combinedText.trim(),
        blocks: recognizedText.blocks
            .map((b) => OcrBlock(
                  text: b.text,
                  confidence: _avgConfidence(b),
                  lines: b.lines.map((l) => l.text).toList(),
                ))
            .toList(),
        processingTimeMs: stopwatch.elapsedMilliseconds,
        success: true,
      );
    } catch (e, stack) {
      stopwatch.stop();
      _logger.e('OCR failed for $imagePath', error: e, stackTrace: stack);
      return OcrResult(
        imagePath: imagePath,
        text: '',
        blocks: [],
        processingTimeMs: stopwatch.elapsedMilliseconds,
        success: false,
        error: e.toString(),
      );
    }
  }

  /// Process multiple images concurrently (batch processing).
  Future<List<OcrResult>> extractTextBatch(
    List<String> imagePaths, {
    int concurrency = 3,
  }) async {
    final results = <OcrResult>[];
    final chunks = <List<String>>[];

    for (int i = 0; i < imagePaths.length; i += concurrency) {
      chunks.add(imagePaths.sublist(
        i,
        (i + concurrency).clamp(0, imagePaths.length),
      ));
    }

    for (final chunk in chunks) {
      final chunkResults = await Future.wait(
        chunk.map((path) => extractText(path)),
      );
      results.addAll(chunkResults);
    }

    return results;
  }

  double _avgConfidence(TextBlock block) {
    if (block.lines.isEmpty) return 0.0;
    // ML Kit doesn't expose confidence per block directly;
    // we use a heuristic based on text quality (length/character density).
    final text = block.text;
    if (text.isEmpty) return 0.0;
    final alphanumericRatio = text.replaceAll(RegExp(r'\W'), '').length / text.length;
    return alphanumericRatio.clamp(0.0, 1.0);
  }

  void dispose() {
    if (!_isDisposed) {
      _isDisposed = true;
      _latinRecognizer.close();
      _chineseRecognizer.close();
      _devanagariRecognizer.close();
    }
  }
}

class OcrResult {
  final String imagePath;
  final String text;
  final List<OcrBlock> blocks;
  final int processingTimeMs;
  final bool success;
  final String? error;

  const OcrResult({
    required this.imagePath,
    required this.text,
    required this.blocks,
    required this.processingTimeMs,
    required this.success,
    this.error,
  });

  factory OcrResult.empty(String imagePath) => OcrResult(
        imagePath: imagePath,
        text: '',
        blocks: [],
        processingTimeMs: 0,
        success: false,
      );

  bool get hasText => text.isNotEmpty;
  int get wordCount => text.split(RegExp(r'\s+')).where((w) => w.isNotEmpty).length;

  /// Returns the most relevant / structured text by filtering low-confidence blocks.
  String get cleanText {
    if (blocks.isEmpty) return text;
    return blocks
        .where((b) => b.confidence > 0.3)
        .map((b) => b.text)
        .join('\n');
  }
}

class OcrBlock {
  final String text;
  final double confidence;
  final List<String> lines;

  const OcrBlock({
    required this.text,
    required this.confidence,
    required this.lines,
  });
}
