// lib/features/dashboard/presentation/screens/dashboard_screen.dart
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../core/constants/app_constants.dart';
import '../../../../core/theme/app_theme.dart';
import '../bloc/dashboard_bloc.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  @override
  void initState() {
    super.initState();
    context.read<DashboardBloc>().add(DashboardLoadRequested());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: BlocBuilder<DashboardBloc, DashboardState>(
        builder: (context, state) {
          return CustomScrollView(
            slivers: [
              _buildAppBar(),
              if (state is DashboardLoaded) ...[
                SliverToBoxAdapter(child: _buildStatCards(state)),
                SliverToBoxAdapter(child: _buildCategoryChart(state)),
                SliverToBoxAdapter(child: _buildMonthlyTrend(state)),
                if (state.totalReceiptSpend > 0)
                  SliverToBoxAdapter(child: _buildReceiptSummary(state)),
                SliverToBoxAdapter(child: _buildTopTags(state)),
                const SliverToBoxAdapter(child: SizedBox(height: 80)),
              ] else if (state is DashboardLoading)
                SliverFillRemaining(
                  child: const Center(
                    child: CircularProgressIndicator(color: AppColors.primary),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildAppBar() {
    return SliverAppBar(
      floating: true,
      backgroundColor: AppColors.background,
      title: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Insights', style: AppTextStyles.headlineLarge),
          Text('Your screenshot intelligence', style: AppTextStyles.bodySmall),
        ],
      ),
    );
  }

  Widget _buildStatCards(DashboardLoaded state) {
    final stats = [
      (label: 'Total', value: '${state.total}', icon: Icons.photo_library, color: AppColors.primary),
      (label: 'Processed', value: '${state.processed}', icon: Icons.check_circle, color: AppColors.receipts),
      (label: 'Favorites', value: '${state.favorites}', icon: Icons.star, color: AppColors.ideas),
      (label: 'Duplicates', value: '${state.duplicates}', icon: Icons.copy, color: AppColors.error),
    ];

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
      child: GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          childAspectRatio: 1.6,
        ),
        itemCount: stats.length,
        itemBuilder: (context, i) {
          final stat = stats[i];
          return Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppColors.border),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Icon(stat.icon, color: stat.color, size: 22),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      stat.value,
                      style: AppTextStyles.headlineLarge.copyWith(color: stat.color),
                    ),
                    Text(stat.label, style: AppTextStyles.bodySmall),
                  ],
                ),
              ],
            ),
          ).animate(delay: (i * 80).ms).fadeIn().scale(begin: const Offset(0.9, 0.9));
        },
      ),
    );
  }

  Widget _buildCategoryChart(DashboardLoaded state) {
    if (state.byCategory.isEmpty) return const SizedBox.shrink();

    final data = state.byCategory.entries.toList();
    final total = data.fold(0, (sum, e) => sum + e.value);

    return _DashboardCard(
      title: 'By Category',
      icon: Icons.pie_chart,
      child: SizedBox(
        height: 200,
        child: Row(
          children: [
            Expanded(
              child: PieChart(
                PieChartData(
                  sections: data.asMap().entries.map((entry) {
                    final cat = entry.value.key;
                    final count = entry.value.value;
                    final color = AppColors.categoryColor(cat);
                    return PieChartSectionData(
                      value: count.toDouble(),
                      color: color,
                      radius: 60,
                      title: '',
                    );
                  }).toList(),
                  centerSpaceRadius: 40,
                  sectionsSpace: 2,
                ),
              ),
            ),
            const SizedBox(width: 16),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: data.map((entry) {
                final color = AppColors.categoryColor(entry.key);
                final pct = total > 0 ? (entry.value / total * 100).toStringAsFixed(0) : '0';
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  child: Row(
                    children: [
                      Container(
                        width: 10,
                        height: 10,
                        decoration: BoxDecoration(color: color, shape: BoxShape.circle),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        '${AppConstants.categoryEmojis[entry.key] ?? ''} ${entry.key}',
                        style: AppTextStyles.bodySmall,
                      ),
                      const SizedBox(width: 8),
                      Text('$pct%', style: AppTextStyles.labelMedium.copyWith(color: color)),
                    ],
                  ),
                );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMonthlyTrend(DashboardLoaded state) {
    final trend = state.monthlyTrend;
    if (trend.isEmpty) return const SizedBox.shrink();

    final entries = trend.entries.toList();
    final maxVal = entries.fold(0, (m, e) => e.value > m ? e.value : m);

    return _DashboardCard(
      title: 'Monthly Trend',
      icon: Icons.trending_up,
      child: SizedBox(
        height: 180,
        child: BarChart(
          BarChartData(
            maxY: (maxVal + 2).toDouble(),
            barGroups: entries.asMap().entries.map((entry) {
              return BarChartGroupData(
                x: entry.key,
                barRods: [
                  BarChartRodData(
                    toY: entry.value.value.toDouble(),
                    gradient: const LinearGradient(
                      colors: [AppColors.primaryDark, AppColors.primaryLight],
                      begin: Alignment.bottomCenter,
                      end: Alignment.topCenter,
                    ),
                    width: 20,
                    borderRadius: const BorderRadius.vertical(top: Radius.circular(6)),
                  ),
                ],
              );
            }).toList(),
            titlesData: FlTitlesData(
              bottomTitles: AxisTitles(
                sideTitles: SideTitles(
                  showTitles: true,
                  getTitlesWidget: (value, meta) {
                    final i = value.toInt();
                    if (i >= entries.length) return const SizedBox.shrink();
                    final key = entries[i].key;
                    final parts = key.split('-');
                    return Text(
                      _monthAbbr(int.tryParse(parts.length > 1 ? parts[1] : '1') ?? 1),
                      style: AppTextStyles.bodySmall,
                    );
                  },
                ),
              ),
              leftTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
              topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
              rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
            ),
            gridData: FlGridData(
              show: true,
              drawVerticalLine: false,
              getDrawingHorizontalLine: (_) => FlLine(
                color: AppColors.border,
                strokeWidth: 1,
              ),
            ),
            borderData: FlBorderData(show: false),
          ),
        ),
      ),
    );
  }

  Widget _buildReceiptSummary(DashboardLoaded state) {
    return _DashboardCard(
      title: 'Receipt Tracker',
      icon: Icons.receipt_long,
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Total Tracked Spend', style: AppTextStyles.bodyMedium),
                const SizedBox(height: 4),
                Text(
                  '\$${state.totalReceiptSpend.toStringAsFixed(2)}',
                  style: AppTextStyles.displayMedium.copyWith(color: AppColors.receipts),
                ),
                const SizedBox(height: 4),
                Text(
                  '${state.byCategory['Receipts'] ?? 0} receipts scanned',
                  style: AppTextStyles.bodySmall,
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: AppColors.receipts.withOpacity(0.15),
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.account_balance_wallet, color: AppColors.receipts, size: 32),
          ),
        ],
      ),
    );
  }

  Widget _buildTopTags(DashboardLoaded state) {
    if (state.topTags.isEmpty) return const SizedBox.shrink();

    return _DashboardCard(
      title: 'Top Keywords',
      icon: Icons.tag,
      child: Wrap(
        spacing: 8,
        runSpacing: 8,
        children: state.topTags.asMap().entries.map((entry) {
          final i = entry.key;
          final tag = entry.value;
          final opacity = 1.0 - (i / state.topTags.length * 0.4);
          return Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: AppColors.primary.withOpacity(opacity * 0.2),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: AppColors.primary.withOpacity(opacity * 0.4)),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('#${tag['tag']}', style: AppTextStyles.bodySmall.copyWith(color: AppColors.primaryLight)),
                const SizedBox(width: 6),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: AppColors.primary,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    '${tag['count']}',
                    style: AppTextStyles.bodySmall.copyWith(color: Colors.white, fontSize: 10),
                  ),
                ),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }

  String _monthAbbr(int month) {
    const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    if (month >= 1 && month <= 12) return months[month - 1];
    return '';
  }
}

class _DashboardCard extends StatelessWidget {
  final String title;
  final IconData icon;
  final Widget child;

  const _DashboardCard({
    required this.title,
    required this.icon,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: AppColors.primary, size: 18),
              const SizedBox(width: 8),
              Text(title, style: AppTextStyles.titleMedium.copyWith(color: AppColors.primary)),
            ],
          ),
          const SizedBox(height: 16),
          child,
        ],
      ),
    ).animate().fadeIn(duration: 400.ms).slideY(begin: 0.1);
  }
}
