// lib/features/dashboard/presentation/bloc/dashboard_bloc.dart
import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import '../../../../data/repositories/screenshot_repository.dart';

// EVENTS
abstract class DashboardEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class DashboardLoadRequested extends DashboardEvent {}

// STATES
abstract class DashboardState extends Equatable {
  @override
  List<Object?> get props => [];
}

class DashboardInitial extends DashboardState {}
class DashboardLoading extends DashboardState {}

class DashboardLoaded extends DashboardState {
  final Map<String, dynamic> analytics;
  const DashboardLoaded(this.analytics);
  @override
  List<Object?> get props => [analytics];

  int get total => analytics['total'] as int? ?? 0;
  int get processed => analytics['processed'] as int? ?? 0;
  Map<String, int> get byCategory => Map<String, int>.from(analytics['byCategory'] as Map? ?? {});
  Map<String, int> get monthlyTrend => Map<String, int>.from(analytics['monthlyTrend'] as Map? ?? {});
  List<Map<String, dynamic>> get topTags =>
      (analytics['topTags'] as List? ?? []).cast<Map<String, dynamic>>();
  int get favorites => analytics['favorites'] as int? ?? 0;
  int get duplicates => analytics['duplicates'] as int? ?? 0;
  double get totalReceiptSpend => (analytics['totalReceiptSpend'] as num?)?.toDouble() ?? 0.0;
}

class DashboardFailure extends DashboardState {
  final String error;
  const DashboardFailure(this.error);
}

// BLOC
class DashboardBloc extends Bloc<DashboardEvent, DashboardState> {
  final ScreenshotRepository _repository;

  DashboardBloc(this._repository) : super(DashboardInitial()) {
    on<DashboardLoadRequested>(_onLoad);
  }

  Future<void> _onLoad(
    DashboardLoadRequested event,
    Emitter<DashboardState> emit,
  ) async {
    emit(DashboardLoading());
    try {
      final analytics = _repository.getAnalytics();
      emit(DashboardLoaded(analytics));
    } catch (e) {
      emit(DashboardFailure(e.toString()));
    }
  }
}
