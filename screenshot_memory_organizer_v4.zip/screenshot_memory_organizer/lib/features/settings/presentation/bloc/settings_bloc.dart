// lib/features/settings/presentation/bloc/settings_bloc.dart
import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../../../../core/constants/app_constants.dart';
import '../../../../data/models/screenshot_model.dart';

// ─────────────────────────────────────────────────────────────
// EVENTS
// ─────────────────────────────────────────────────────────────
abstract class SettingsEvent extends Equatable {
  const SettingsEvent();
  @override List<Object?> get props => [];
}
class SettingsLoadRequested extends SettingsEvent {}
class SettingsAutoScanChanged extends SettingsEvent {
  final bool value; const SettingsAutoScanChanged(this.value);
  @override List<Object?> get props => [value];
}
class SettingsDuplicateDetectionChanged extends SettingsEvent {
  final bool value; const SettingsDuplicateDetectionChanged(this.value);
  @override List<Object?> get props => [value];
}
class SettingsBiometricChanged extends SettingsEvent {
  final bool value; const SettingsBiometricChanged(this.value);
  @override List<Object?> get props => [value];
}
class SettingsCloudBackupChanged extends SettingsEvent {
  final bool value; const SettingsCloudBackupChanged(this.value);
  @override List<Object?> get props => [value];
}
class SettingsCleanupDaysChanged extends SettingsEvent {
  final int days; const SettingsCleanupDaysChanged(this.days);
  @override List<Object?> get props => [days];
}
class SettingsClearAllDataRequested extends SettingsEvent {}

// ─────────────────────────────────────────────────────────────
// STATES
// ─────────────────────────────────────────────────────────────
abstract class SettingsState extends Equatable {
  const SettingsState();
  @override List<Object?> get props => [];
}
class SettingsInitial extends SettingsState {}
class SettingsLoading extends SettingsState {}
class SettingsLoaded extends SettingsState {
  final bool autoScan;
  final bool duplicateDetection;
  final bool biometric;
  final bool cloudBackup;
  final int cleanupDays;
  final bool isPro;
  const SettingsLoaded({
    required this.autoScan,
    required this.duplicateDetection,
    required this.biometric,
    required this.cloudBackup,
    required this.cleanupDays,
    required this.isPro,
  });
  SettingsLoaded copyWith({bool? autoScan, bool? duplicateDetection, bool? biometric,
      bool? cloudBackup, int? cleanupDays, bool? isPro}) =>
      SettingsLoaded(
        autoScan: autoScan ?? this.autoScan,
        duplicateDetection: duplicateDetection ?? this.duplicateDetection,
        biometric: biometric ?? this.biometric,
        cloudBackup: cloudBackup ?? this.cloudBackup,
        cleanupDays: cleanupDays ?? this.cleanupDays,
        isPro: isPro ?? this.isPro,
      );
  @override
  List<Object?> get props => [autoScan, duplicateDetection, biometric, cloudBackup, cleanupDays, isPro];
}
class SettingsDataCleared extends SettingsState {}

// ─────────────────────────────────────────────────────────────
// BLOC
// ─────────────────────────────────────────────────────────────
class SettingsBloc extends Bloc<SettingsEvent, SettingsState> {
  SettingsBloc() : super(SettingsInitial()) {
    on<SettingsLoadRequested>(_onLoad);
    on<SettingsAutoScanChanged>(_onAutoScan);
    on<SettingsDuplicateDetectionChanged>(_onDuplicate);
    on<SettingsBiometricChanged>(_onBiometric);
    on<SettingsCloudBackupChanged>(_onCloud);
    on<SettingsCleanupDaysChanged>(_onCleanup);
    on<SettingsClearAllDataRequested>(_onClear);
  }

  Future<Box<AppSettingsModel>> get _box async =>
      Hive.openBox<AppSettingsModel>(AppConstants.hiveBoxSettings);

  Future<AppSettingsModel> _read() async => (await _box).get('settings') ?? AppSettingsModel();

  Future<void> _write(AppSettingsModel m) async => (await _box).put('settings', m);

  SettingsLoaded _toState(AppSettingsModel m) => SettingsLoaded(
    autoScan: m.autoScanEnabled,
    duplicateDetection: m.duplicateDetectionEnabled,
    biometric: m.biometricEnabled,
    cloudBackup: m.cloudBackupEnabled,
    cleanupDays: m.cleanupThresholdDays,
    isPro: m.isProVersion,
  );

  Future<void> _onLoad(SettingsLoadRequested e, Emitter<SettingsState> emit) async {
    emit(SettingsLoading());
    emit(_toState(await _read()));
  }

  Future<void> _onAutoScan(SettingsAutoScanChanged e, Emitter<SettingsState> emit) async {
    final m = await _read();
    m.autoScanEnabled = e.value;
    await _write(m);
    if (state is SettingsLoaded) emit((state as SettingsLoaded).copyWith(autoScan: e.value));
  }

  Future<void> _onDuplicate(SettingsDuplicateDetectionChanged e, Emitter<SettingsState> emit) async {
    final m = await _read();
    m.duplicateDetectionEnabled = e.value;
    await _write(m);
    if (state is SettingsLoaded) emit((state as SettingsLoaded).copyWith(duplicateDetection: e.value));
  }

  Future<void> _onBiometric(SettingsBiometricChanged e, Emitter<SettingsState> emit) async {
    final m = await _read();
    m.biometricEnabled = e.value;
    await _write(m);
    if (state is SettingsLoaded) emit((state as SettingsLoaded).copyWith(biometric: e.value));
  }

  Future<void> _onCloud(SettingsCloudBackupChanged e, Emitter<SettingsState> emit) async {
    final m = await _read();
    m.cloudBackupEnabled = e.value;
    await _write(m);
    if (state is SettingsLoaded) emit((state as SettingsLoaded).copyWith(cloudBackup: e.value));
  }

  Future<void> _onCleanup(SettingsCleanupDaysChanged e, Emitter<SettingsState> emit) async {
    final m = await _read();
    m.cleanupThresholdDays = e.days;
    await _write(m);
    if (state is SettingsLoaded) emit((state as SettingsLoaded).copyWith(cleanupDays: e.days));
  }

  Future<void> _onClear(SettingsClearAllDataRequested e, Emitter<SettingsState> emit) async {
    await Hive.box<dynamic>(AppConstants.hiveBoxScreenshots).clear();
    emit(SettingsDataCleared());
    add(SettingsLoadRequested());
  }
}

/// Static helper so any widget can read the current biometric setting
/// without needing the bloc in scope.
Future<bool> isBiometricEnabled() async {
  final box = await Hive.openBox<AppSettingsModel>(AppConstants.hiveBoxSettings);
  return box.get('settings')?.biometricEnabled ?? false;
}
