// lib/features/settings/presentation/screens/settings_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:local_auth/local_auth.dart';

import '../../../../core/constants/app_constants.dart';
import '../../../../core/theme/app_theme.dart';
import '../bloc/settings_bloc.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final LocalAuthentication _localAuth = LocalAuthentication();

  @override
  void initState() {
    super.initState();
    context.read<SettingsBloc>().add(SettingsLoadRequested());
  }

  // ── Biometric: check device support before toggling ──────────────────────
  Future<void> _handleBiometricToggle(bool newValue, SettingsLoaded state) async {
    if (!newValue) {
      context.read<SettingsBloc>().add(SettingsBiometricChanged(false));
      return;
    }
    final canCheck = await _localAuth.canCheckBiometrics;
    final isSupported = await _localAuth.isDeviceSupported();
    if (!canCheck || !isSupported) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('⚠️ This device does not support biometric authentication.'),
          behavior: SnackBarBehavior.floating,
        ));
      }
      return;
    }
    // Authenticate once to confirm the user wants to enable it
    try {
      final authenticated = await _localAuth.authenticate(
        localizedReason: 'Confirm your identity to enable biometric lock',
        options: const AuthenticationOptions(biometricOnly: false),
      );
      if (authenticated && mounted) {
        context.read<SettingsBloc>().add(SettingsBiometricChanged(true));
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('🔒 Biometric lock enabled'),
          behavior: SnackBarBehavior.floating,
        ));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Biometric error: $e'),
          behavior: SnackBarBehavior.floating,
        ));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: BlocConsumer<SettingsBloc, SettingsState>(
        listenWhen: (_, s) => s is SettingsDataCleared,
        listener: (context, state) {
          if (state is SettingsDataCleared) {
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
              content: Text('🗑️ All data cleared'),
              behavior: SnackBarBehavior.floating,
            ));
          }
        },
        builder: (context, state) {
          if (state is SettingsLoading || state is SettingsInitial) {
            return const Center(child: CircularProgressIndicator(color: AppColors.primary));
          }
          if (state is! SettingsLoaded) {
            return const Center(child: Text('Could not load settings'));
          }
          return _buildContent(state);
        },
      ),
    );
  }

  Widget _buildContent(SettingsLoaded state) {
    return CustomScrollView(
      slivers: [
        _buildAppBar(),
        SliverToBoxAdapter(child: _buildProBanner(state)),
        SliverToBoxAdapter(child: _buildSection(
          title: 'Processing',
          icon: Icons.auto_awesome,
          items: [
            _SettingsTile(
              icon: Icons.photo_library,
              color: AppColors.primary,
              title: 'Auto Scan Gallery',
              subtitle: state.autoScan
                  ? 'Automatically detecting new screenshots'
                  : 'Manual scan only',
              trailing: Switch.adaptive(
                value: state.autoScan,
                onChanged: (v) =>
                    context.read<SettingsBloc>().add(SettingsAutoScanChanged(v)),
                activeColor: AppColors.primary,
              ),
            ),
            _SettingsTile(
              icon: Icons.copy_outlined,
              color: AppColors.ideas,
              title: 'Duplicate Detection',
              subtitle: state.duplicateDetection
                  ? 'Finding and flagging duplicates'
                  : 'Duplicate detection disabled',
              trailing: Switch.adaptive(
                value: state.duplicateDetection,
                onChanged: (v) =>
                    context.read<SettingsBloc>().add(SettingsDuplicateDetectionChanged(v)),
                activeColor: AppColors.primary,
              ),
            ),
            _SettingsTile(
              icon: Icons.delete_sweep,
              color: AppColors.error,
              title: 'Cleanup Threshold',
              subtitle: 'Suggest old screenshots after ${state.cleanupDays} days',
              onTap: () => _showCleanupDialog(state),
            ),
          ],
        )),
        SliverToBoxAdapter(child: _buildSection(
          title: 'Privacy & Security',
          icon: Icons.security,
          items: [
            _SettingsTile(
              icon: Icons.fingerprint,
              color: AppColors.receipts,
              title: 'Biometric Lock',
              subtitle: state.biometric
                  ? 'App locked — fingerprint/face required'
                  : 'Tap to require fingerprint/face ID on open',
              trailing: Switch.adaptive(
                value: state.biometric,
                onChanged: (v) => _handleBiometricToggle(v, state),
                activeColor: AppColors.primary,
              ),
            ),
            _SettingsTile(
              icon: Icons.cloud_sync,
              color: AppColors.study,
              title: 'Cloud Backup',
              subtitle: state.isPro
                  ? (state.cloudBackup ? 'Syncing to cloud' : 'Cloud backup disabled')
                  : 'Upgrade to Pro to unlock',
              badge: state.isPro ? null : 'PRO',
              trailing: state.isPro
                  ? Switch.adaptive(
                      value: state.cloudBackup,
                      onChanged: (v) =>
                          context.read<SettingsBloc>().add(SettingsCloudBackupChanged(v)),
                      activeColor: AppColors.primary,
                    )
                  : null,
              onTap: state.isPro ? null : _showProGate,
            ),
            const _SettingsTile(
              icon: Icons.storage,
              color: AppColors.textSecondary,
              title: 'On-Device Processing',
              subtitle: 'All AI runs locally — no data leaves your device',
              trailing: Icon(Icons.check_circle, color: AppColors.receipts, size: 20),
            ),
          ],
        )),
        SliverToBoxAdapter(child: _buildSection(
          title: 'Data',
          icon: Icons.folder_open,
          items: [
            _SettingsTile(
              icon: Icons.delete_forever,
              color: AppColors.error,
              title: 'Clear All Data',
              subtitle: 'Remove all processed data (keeps original files)',
              onTap: () => _showClearDataDialog(),
            ),
            _SettingsTile(
              icon: Icons.info_outline,
              color: AppColors.textSecondary,
              title: 'About',
              subtitle: '${AppConstants.appName} v${AppConstants.appVersion}',
            ),
          ],
        )),
        const SliverToBoxAdapter(child: SizedBox(height: 80)),
      ],
    );
  }

  Widget _buildAppBar() {
    return SliverAppBar(
      floating: true,
      backgroundColor: AppColors.background,
      title: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Settings', style: AppTextStyles.headlineLarge),
          Text('Customize your experience', style: AppTextStyles.bodySmall),
        ],
      ),
    );
  }

  Widget _buildProBanner(SettingsLoaded state) {
    if (state.isPro) return const SizedBox.shrink();
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 8, 16, 0),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF7C3AED), Color(0xFF4F46E5)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  const Icon(Icons.star, color: Colors.amber, size: 18),
                  const SizedBox(width: 8),
                  Text('Upgrade to Pro',
                      style: AppTextStyles.titleMedium.copyWith(color: Colors.white)),
                ]),
                const SizedBox(height: 4),
                Text('Unlimited screenshots • Semantic search • Cloud backup',
                    style: AppTextStyles.bodySmall.copyWith(color: Colors.white70)),
              ],
            ),
          ),
          ElevatedButton(
            onPressed: _showProGate,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.white,
              foregroundColor: AppColors.primary,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
            child: const Text('Try Free'),
          ),
        ],
      ),
    ).animate().fadeIn().slideY(begin: -0.1);
  }

  Widget _buildSection({
    required String title,
    required IconData icon,
    required List<Widget> items,
  }) {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 16, 16, 0),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: Row(children: [
              Icon(icon, size: 16, color: AppColors.primary),
              const SizedBox(width: 8),
              Text(title,
                  style: AppTextStyles.labelLarge.copyWith(color: AppColors.primary)),
            ]),
          ),
          const Divider(color: AppColors.border, height: 1),
          ...items,
        ],
      ),
    );
  }

  void _showCleanupDialog(SettingsLoaded state) {
    int tempDays = state.cleanupDays;
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.surface,
        title: const Text('Cleanup Threshold', style: AppTextStyles.titleLarge),
        content: StatefulBuilder(
          builder: (ctx, setD) => Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('Suggest deleting screenshots older than:',
                  style: AppTextStyles.bodyMedium),
              const SizedBox(height: 16),
              Slider(
                value: tempDays.toDouble(),
                min: 30, max: 365, divisions: 11,
                label: '$tempDays days',
                activeColor: AppColors.primary,
                onChanged: (v) => setD(() => tempDays = v.toInt()),
              ),
              Text('$tempDays days',
                  style: AppTextStyles.headlineMedium.copyWith(color: AppColors.primary)),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(ctx);
              context.read<SettingsBloc>().add(SettingsCleanupDaysChanged(tempDays));
            },
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.primary),
            child: const Text('Save', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  void _showProGate() {
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
      content: Text('⭐ Upgrade to Pro to unlock this feature!'),
      behavior: SnackBarBehavior.floating,
    ));
  }

  void _showClearDataDialog() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: AppColors.error.withOpacity(0.15),
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(Icons.delete_forever, color: AppColors.error),
          ),
          const SizedBox(width: 12),
          const Text('Clear All Data?', style: AppTextStyles.titleLarge),
        ]),
        content: const Text(
          'This will permanently delete all your organized screenshots and AI data. '
          'Your original photos will NOT be affected.',
          style: AppTextStyles.bodyMedium,
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(ctx);
              context.read<SettingsBloc>().add(SettingsClearAllDataRequested());
            },
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.error),
            child: const Text('Clear All', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────
// Settings tile widget
// ─────────────────────────────────────────────────────────────
class _SettingsTile extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String title;
  final String subtitle;
  final Widget? trailing;
  final VoidCallback? onTap;
  final String? badge;

  const _SettingsTile({
    required this.icon,
    required this.color,
    required this.title,
    required this.subtitle,
    this.trailing,
    this.onTap,
    this.badge,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: onTap,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      leading: Container(
        width: 40, height: 40,
        decoration: BoxDecoration(
          color: color.withOpacity(0.15),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Icon(icon, color: color, size: 20),
      ),
      title: Row(children: [
        Flexible(child: Text(title, style: AppTextStyles.titleMedium)),
        if (badge != null) ...[
          const SizedBox(width: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
            decoration: BoxDecoration(
              color: AppColors.ideas.withOpacity(0.2),
              borderRadius: BorderRadius.circular(4),
              border: Border.all(color: AppColors.ideas.withOpacity(0.4)),
            ),
            child: Text(badge!,
                style: AppTextStyles.bodySmall.copyWith(color: AppColors.ideas, fontSize: 10)),
          ),
        ],
      ]),
      subtitle: Text(subtitle, style: AppTextStyles.bodySmall),
      trailing: trailing ??
          (onTap != null
              ? const Icon(Icons.chevron_right, color: AppColors.textTertiary)
              : null),
    );
  }
}
