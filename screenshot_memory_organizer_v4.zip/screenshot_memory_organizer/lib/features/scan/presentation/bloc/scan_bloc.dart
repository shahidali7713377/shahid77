// lib/features/scan/presentation/bloc/scan_bloc.dart
import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:photo_manager/photo_manager.dart';
import '../../../../data/models/screenshot_model.dart';
import '../../../../data/repositories/screenshot_repository.dart';

// ---------------------------------------------------------------------------
// EVENTS
// ---------------------------------------------------------------------------
abstract class ScanEvent extends Equatable {
  const ScanEvent();
  @override
  List<Object?> get props => [];
}

class ScanGalleryRequested extends ScanEvent {
  final bool rescan;
  const ScanGalleryRequested({this.rescan = false});
  @override
  List<Object?> get props => [rescan];
}

class ScanProgressUpdated extends ScanEvent {
  final ScanProgress progress;
  const ScanProgressUpdated(this.progress);
  @override
  List<Object?> get props => [progress];
}

class LoadScreenshotsRequested extends ScanEvent {
  final String? category;
  final String? sortBy;
  const LoadScreenshotsRequested({this.category, this.sortBy});
}

class ScreenshotCategoryChanged extends ScanEvent {
  final String id;
  final String newCategory;
  const ScreenshotCategoryChanged(this.id, this.newCategory);
}

/// Delete a single screenshot (from the detail sheet).
class ScreenshotDeleted extends ScanEvent {
  final String id;
  final String? category;
  final String sortBy;
  const ScreenshotDeleted(this.id, {this.category, this.sortBy = 'newest'});
  @override
  List<Object?> get props => [id, category, sortBy];
}

/// Delete multiple screenshots (from multi-select mode).
class DeleteMultipleRequested extends ScanEvent {
  final List<String> ids;
  final String? category;
  final String sortBy;
  const DeleteMultipleRequested(this.ids, {this.category, this.sortBy = 'newest'});
  @override
  List<Object?> get props => [ids, category, sortBy];
}

class ScreenshotLockToggled extends ScanEvent {
  final String id;
  final String? category;
  final String sortBy;
  const ScreenshotLockToggled(this.id, {this.category, this.sortBy = 'newest'});
  @override List<Object?> get props => [id, category, sortBy];
}

class ScreenshotFavoriteToggled extends ScanEvent {
  final String id;
  const ScreenshotFavoriteToggled(this.id);
}

class ScreenshotNoteUpdated extends ScanEvent {
  final String id;
  final String note;
  const ScreenshotNoteUpdated(this.id, this.note);
}

/// Triggers loading the list of available device albums for the picker.
class LoadAlbumsRequested extends ScanEvent {}

/// Triggered when the user confirms their folder selection in the custom picker.
class ScanCustomFoldersRequested extends ScanEvent {
  final List<AlbumInfo> selectedAlbums;
  const ScanCustomFoldersRequested(this.selectedAlbums);
  @override
  List<Object?> get props => [selectedAlbums];
}

// ---------------------------------------------------------------------------
// STATES
// ---------------------------------------------------------------------------
abstract class ScanState extends Equatable {
  const ScanState();
  @override
  List<Object?> get props => [];
}

class ScanInitial extends ScanState {}

class ScanInProgress extends ScanState {
  final int total;
  final int processed;
  final String currentFile;
  final String? folderLabel;

  const ScanInProgress({
    required this.total,
    required this.processed,
    required this.currentFile,
    this.folderLabel,
  });

  double get progress => total > 0 ? processed / total : 0;

  @override
  List<Object?> get props => [total, processed, currentFile, folderLabel];
}

class ScanSuccess extends ScanState {
  final int added;
  final int total;
  final bool isCustomScan;
  final List<String> scannedFolderNames;

  const ScanSuccess({
    required this.added,
    required this.total,
    this.isCustomScan = false,
    this.scannedFolderNames = const [],
  });

  @override
  List<Object?> get props => [added, total, isCustomScan, scannedFolderNames];
}

class ScanFailure extends ScanState {
  final String error;
  const ScanFailure(this.error);
  @override
  List<Object?> get props => [error];
}

class AlbumsLoading extends ScanState {}

class AlbumsLoaded extends ScanState {
  final List<AlbumInfo> albums;
  const AlbumsLoaded(this.albums);
  @override
  List<Object?> get props => [albums];
}

class AlbumsLoadFailure extends ScanState {
  final String error;
  const AlbumsLoadFailure(this.error);
}

class ScreenshotsLoaded extends ScanState {
  final List<ScreenshotModel> screenshots;
  final String? category;
  final String sortBy;

  const ScreenshotsLoaded({
    required this.screenshots,
    this.category,
    this.sortBy = 'newest',
  });

  @override
  List<Object?> get props => [screenshots, category, sortBy];
}

class ScreenshotsLoadFailure extends ScanState {
  final String error;
  const ScreenshotsLoadFailure(this.error);
}

/// Emitted after a successful multi-delete so the gallery can clear selection.
class DeleteSuccess extends ScanState {
  final int deletedCount;
  const DeleteSuccess(this.deletedCount);
  @override
  List<Object?> get props => [deletedCount];
}

// ---------------------------------------------------------------------------
// BLOC
// ---------------------------------------------------------------------------
class ScanBloc extends Bloc<ScanEvent, ScanState> {
  final ScreenshotRepository _repository;

  ScanBloc(this._repository) : super(ScanInitial()) {
    on<ScanGalleryRequested>(_onScanGallery);
    on<ScanProgressUpdated>(_onProgressUpdated);
    on<LoadScreenshotsRequested>(_onLoadScreenshots);
    on<ScreenshotCategoryChanged>(_onCategoryChanged);
    on<ScreenshotDeleted>(_onDeleted);
    on<DeleteMultipleRequested>(_onDeleteMultiple);
    on<ScreenshotLockToggled>(_onLockToggled);
    on<ScreenshotFavoriteToggled>(_onFavoriteToggled);
    on<ScreenshotNoteUpdated>(_onNoteUpdated);
    on<LoadAlbumsRequested>(_onLoadAlbums);
    on<ScanCustomFoldersRequested>(_onScanCustomFolders);
  }

  Future<void> _onScanGallery(
    ScanGalleryRequested event,
    Emitter<ScanState> emit,
  ) async {
    emit(const ScanInProgress(total: 0, processed: 0, currentFile: 'Initializing...'));

    final result = await _repository.scanGallery(
      rescanExisting: event.rescan,
      onProgress: (progress) {
        if (!isClosed) add(ScanProgressUpdated(progress));
      },
    );

    if (result.success) {
      emit(ScanSuccess(added: result.added, total: result.totalScanned));
      add(const LoadScreenshotsRequested());
    } else {
      emit(ScanFailure(result.error ?? 'Unknown error during scan'));
    }
  }

  Future<void> _onProgressUpdated(
    ScanProgressUpdated event,
    Emitter<ScanState> emit,
  ) async {
    emit(ScanInProgress(
      total: event.progress.total,
      processed: event.progress.processed,
      currentFile: event.progress.current,
      folderLabel: event.progress.folderLabel,
    ));
  }

  Future<void> _onLoadScreenshots(
    LoadScreenshotsRequested event,
    Emitter<ScanState> emit,
  ) async {
    try {
      final screenshots = _repository.getAll(
        category: event.category,
        sortBy: event.sortBy,
      );
      emit(ScreenshotsLoaded(
        screenshots: screenshots,
        category: event.category,
        sortBy: event.sortBy ?? 'newest',
      ));
    } catch (e) {
      emit(ScreenshotsLoadFailure(e.toString()));
    }
  }

  Future<void> _onCategoryChanged(
    ScreenshotCategoryChanged event,
    Emitter<ScanState> emit,
  ) async {
    await _repository.updateCategory(event.id, event.newCategory);
    add(const LoadScreenshotsRequested());
  }

  Future<void> _onDeleted(
    ScreenshotDeleted event,
    Emitter<ScanState> emit,
  ) async {
    try {
      await _repository.delete(event.id);
    } catch (_) {
      // Locked screenshot — skip silently
    }
    // Always reload after any delete attempt, preserving current filters.
    final screenshots = _repository.getAll(
      category: event.category,
      sortBy: event.sortBy,
    );
    emit(ScreenshotsLoaded(
      screenshots: screenshots,
      category: event.category,
      sortBy: event.sortBy,
    ));
  }

  Future<void> _onDeleteMultiple(
    DeleteMultipleRequested event,
    Emitter<ScanState> emit,
  ) async {
    int deleted = 0;
    for (final id in event.ids) {
      try {
        await _repository.delete(id);
        deleted++;
      } catch (_) {
        // Locked — skip
      }
    }

    // Emit DeleteSuccess so the gallery clears selection mode, then reload.
    emit(DeleteSuccess(deleted));

    final screenshots = _repository.getAll(
      category: event.category,
      sortBy: event.sortBy,
    );
    emit(ScreenshotsLoaded(
      screenshots: screenshots,
      category: event.category,
      sortBy: event.sortBy,
    ));
  }


  Future<void> _onLockToggled(
    ScreenshotLockToggled event,
    Emitter<ScanState> emit,
  ) async {
    await _repository.toggleLock(event.id);
    final screenshots = _repository.getAll(
      category: event.category,
      sortBy: event.sortBy,
    );
    emit(ScreenshotsLoaded(
      screenshots: screenshots,
      category: event.category,
      sortBy: event.sortBy,
    ));
  }

  Future<void> _onFavoriteToggled(
    ScreenshotFavoriteToggled event,
    Emitter<ScanState> emit,
  ) async {
    await _repository.toggleFavorite(event.id);
    // Re-read the current filters from the last ScreenshotsLoaded state.
    String? cat;
    String sort = 'newest';
    if (state is ScreenshotsLoaded) {
      final s = state as ScreenshotsLoaded;
      cat = s.category;
      sort = s.sortBy;
    }
    final screenshots = _repository.getAll(category: cat, sortBy: sort);
    emit(ScreenshotsLoaded(screenshots: screenshots, category: cat, sortBy: sort));
  }

  Future<void> _onNoteUpdated(
    ScreenshotNoteUpdated event,
    Emitter<ScanState> emit,
  ) async {
    await _repository.updateNote(event.id, event.note);
  }

  Future<void> _onLoadAlbums(
    LoadAlbumsRequested event,
    Emitter<ScanState> emit,
  ) async {
    emit(AlbumsLoading());
    try {
      final albums = await _repository.getAvailableAlbums();
      emit(AlbumsLoaded(albums));
    } catch (e) {
      emit(AlbumsLoadFailure(e.toString()));
    }
  }

  Future<void> _onScanCustomFolders(
    ScanCustomFoldersRequested event,
    Emitter<ScanState> emit,
  ) async {
    if (event.selectedAlbums.isEmpty) return;

    final folderNames = event.selectedAlbums.map((a) => a.name).toList();
    emit(ScanInProgress(
      total: event.selectedAlbums.fold(0, (s, a) => s + a.assetCount),
      processed: 0,
      currentFile: 'Starting custom scan…',
      folderLabel: folderNames.join(', '),
    ));

    final result = await _repository.scanCustomAlbums(
      albumIds: event.selectedAlbums.map((a) => a.id).toList(),
      onProgress: (progress) {
        if (!isClosed) add(ScanProgressUpdated(progress));
      },
    );

    if (result.success) {
      emit(ScanSuccess(
        added: result.added,
        total: result.totalScanned,
        isCustomScan: true,
        scannedFolderNames: folderNames,
      ));
      add(const LoadScreenshotsRequested());
    } else {
      emit(ScanFailure(result.error ?? 'Custom scan failed'));
    }
  }
}
