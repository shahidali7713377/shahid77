// lib/features/scan/presentation/screens/gallery_screen.dart
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';

import '../../../../core/constants/app_constants.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../data/models/screenshot_model.dart';
import '../bloc/scan_bloc.dart';
import '../widgets/scan_progress_overlay.dart';
import '../widgets/screenshot_detail_sheet.dart';
import '../widgets/category_filter_bar.dart';
import '../widgets/custom_scan_picker_sheet.dart';

class GalleryScreen extends StatefulWidget {
  const GalleryScreen({super.key});

  @override
  State<GalleryScreen> createState() => _GalleryScreenState();
}

class _GalleryScreenState extends State<GalleryScreen> {
  String? _selectedCategory;
  String _sortBy = 'newest';

  // ---- Multi-select state (purely UI, not in BLoC) ----
  bool _isSelectionMode = false;
  final Set<String> _selectedIds = {};

  @override
  void initState() {
    super.initState();
    context.read<ScanBloc>().add(const LoadScreenshotsRequested());
  }

  // ---- Selection helpers ----

  void _enterSelectionMode(String firstId) {
    HapticFeedback.mediumImpact();
    setState(() {
      _isSelectionMode = true;
      _selectedIds.clear();
      _selectedIds.add(firstId);
    });
  }

  void _exitSelectionMode() {
    setState(() {
      _isSelectionMode = false;
      _selectedIds.clear();
    });
  }

  void _toggleSelection(String id) {
    setState(() {
      if (_selectedIds.contains(id)) {
        _selectedIds.remove(id);
        if (_selectedIds.isEmpty) _isSelectionMode = false;
      } else {
        _selectedIds.add(id);
      }
    });
  }

  void _selectAll(List<ScreenshotModel> screenshots) {
    setState(() {
      _selectedIds.addAll(screenshots.map((s) => s.id));
    });
  }

  void _deselectAll() {
    setState(() => _selectedIds.clear());
  }

  void _confirmDelete() {
    final count = _selectedIds.length;
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: AppColors.error.withOpacity(0.15),
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(Icons.delete_outline, color: AppColors.error, size: 22),
            ),
            const SizedBox(width: 12),
            Text(
              'Delete $count item${count != 1 ? 's' : ''}?',
              style: AppTextStyles.titleLarge,
            ),
          ],
        ),
        content: Text(
          'This will remove $count screenshot${count != 1 ? 's' : ''} from the app. Original files will not be deleted.',
          style: AppTextStyles.bodyMedium,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text('Cancel', style: TextStyle(color: AppColors.textSecondary)),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(ctx);
              _executeDelete();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.error,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
            child: Text('Delete $count'),
          ),
        ],
      ),
    );
  }

  void _executeDelete() {
    final ids = List<String>.from(_selectedIds);
    context.read<ScanBloc>().add(DeleteMultipleRequested(
      ids,
      category: _selectedCategory,
      sortBy: _sortBy,
    ));
    // Selection mode will be exited via the DeleteSuccess state listener
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      // Intercept back press to exit selection mode first
      canPop: !_isSelectionMode,
      onPopInvoked: (didPop) {
        if (!didPop && _isSelectionMode) _exitSelectionMode();
      },
      child: Scaffold(
        backgroundColor: AppColors.background,
        body: BlocConsumer<ScanBloc, ScanState>(
          listenWhen: (_, curr) =>
              curr is ScanSuccess ||
              curr is ScanFailure ||
              curr is DeleteSuccess,
          listener: (context, state) {
            if (state is DeleteSuccess) {
              _exitSelectionMode();
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('🗑️ ${state.deletedCount} screenshot${state.deletedCount != 1 ? 's' : ''} deleted'),
                  behavior: SnackBarBehavior.floating,
                  backgroundColor: AppColors.surfaceElevated,
                ),
              );
            } else if (state is ScanSuccess) {
              final msg = state.isCustomScan
                  ? '✅ Scanned ${state.scannedFolderNames.join(", ")} — ${state.added} new'
                  : '✅ ${state.added} screenshots added';
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(msg),
                  behavior: SnackBarBehavior.floating,
                  backgroundColor: AppColors.surfaceElevated,
                ),
              );
            } else if (state is ScanFailure) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('❌ ${state.error}'),
                  backgroundColor: AppColors.error.withOpacity(0.9),
                  behavior: SnackBarBehavior.floating,
                ),
              );
            }
          },
          builder: (context, state) {
            final screenshots = state is ScreenshotsLoaded ? state.screenshots : <ScreenshotModel>[];

            return Stack(
              children: [
                CustomScrollView(
                  slivers: [
                    _buildAppBar(state, screenshots),
                    if (state is ScanInProgress)
                      SliverToBoxAdapter(child: ScanProgressOverlay(state: state)),
                    if (!_isSelectionMode)
                      SliverToBoxAdapter(
                        child: CategoryFilterBar(
                          selected: _selectedCategory,
                          onSelected: (cat) {
                            setState(() => _selectedCategory = cat);
                            context.read<ScanBloc>().add(LoadScreenshotsRequested(
                                  category: cat,
                                  sortBy: _sortBy,
                                ));
                          },
                        ),
                      ),
                    if (state is ScreenshotsLoaded)
                      screenshots.isEmpty
                          ? SliverFillRemaining(child: _buildEmpty())
                          : SliverPadding(
                              // Extra bottom padding when action bar is visible
                              padding: EdgeInsets.fromLTRB(16, 16, 16, _isSelectionMode ? 96 : 80),
                              sliver: SliverMasonryGrid.count(
                                crossAxisCount: 2,
                                mainAxisSpacing: 12,
                                crossAxisSpacing: 12,
                                childCount: screenshots.length,
                                itemBuilder: (context, index) {
                                  final s = screenshots[index];
                                  final isSelected = _selectedIds.contains(s.id);
                                  return _ScreenshotCard(
                                    screenshot: s,
                                    isSelectionMode: _isSelectionMode,
                                    isSelected: isSelected,
                                    onTap: () {
                                      if (_isSelectionMode) {
                                        _toggleSelection(s.id);
                                      } else {
                                        _openDetail(s);
                                      }
                                    },
                                    onLongPress: () {
                                      if (!_isSelectionMode) {
                                        _enterSelectionMode(s.id);
                                      }
                                    },
                                  ).animate(delay: (index * 20).ms)
                                    .fadeIn(duration: 250.ms)
                                    .slideY(begin: 0.08, duration: 250.ms);
                                },
                              ),
                            )
                    else if (state is ScanInitial ||
                        state is ScanInProgress ||
                        state is AlbumsLoading ||
                        state is AlbumsLoaded ||
                        state is AlbumsLoadFailure)
                      SliverFillRemaining(child: _buildLoadingGrid())
                    else if (state is ScreenshotsLoadFailure)
                      SliverFillRemaining(child: _buildError(state.error)),
                  ],
                ),

                // ---- Floating multi-select action bar ----
                if (_isSelectionMode)
                  Positioned(
                    left: 0,
                    right: 0,
                    bottom: 0,
                    child: _SelectionActionBar(
                      selectedCount: _selectedIds.length,
                      totalCount: screenshots.length,
                      onSelectAll: () => _selectAll(screenshots),
                      onDeselectAll: _deselectAll,
                      onDelete: _selectedIds.isNotEmpty ? _confirmDelete : null,
                      onCancel: _exitSelectionMode,
                    ),
                  ),
              ],
            );
          },
        ),
        floatingActionButton: _isSelectionMode ? null : _buildFab(),
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // AppBar
  // ---------------------------------------------------------------------------

  Widget _buildAppBar(ScanState state, List<ScreenshotModel> screenshots) {
    if (_isSelectionMode) {
      return SliverAppBar(
        floating: true,
        snap: true,
        backgroundColor: AppColors.surface,
        leading: IconButton(
          icon: const Icon(Icons.close, color: AppColors.textPrimary),
          onPressed: _exitSelectionMode,
        ),
        title: Text(
          _selectedIds.isEmpty
              ? 'Select items'
              : '${_selectedIds.length} selected',
          style: AppTextStyles.titleLarge,
        ),
        actions: [
          if (_selectedIds.length == screenshots.length)
            TextButton(
              onPressed: _deselectAll,
              child: Text('Deselect All',
                  style: AppTextStyles.labelMedium.copyWith(color: AppColors.primary)),
            )
          else
            TextButton(
              onPressed: () => _selectAll(screenshots),
              child: Text('Select All',
                  style: AppTextStyles.labelMedium.copyWith(color: AppColors.primary)),
            ),
        ],
      );
    }

    return SliverAppBar(
      floating: true,
      snap: true,
      backgroundColor: AppColors.background,
      expandedHeight: 100,
      flexibleSpace: FlexibleSpaceBar(
        title: Column(
          mainAxisAlignment: MainAxisAlignment.end,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(AppConstants.appName, style: AppTextStyles.headlineMedium),
            if (state is ScreenshotsLoaded)
              Text('${state.screenshots.length} screenshots', style: AppTextStyles.bodySmall),
          ],
        ),
        titlePadding: const EdgeInsets.fromLTRB(20, 0, 0, 16),
      ),
      actions: [
        PopupMenuButton<String>(
          icon: const Icon(Icons.sort, color: AppColors.textSecondary),
          color: AppColors.surfaceVariant,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          onSelected: (value) {
            setState(() => _sortBy = value);
            context.read<ScanBloc>().add(LoadScreenshotsRequested(
                  category: _selectedCategory,
                  sortBy: value,
                ));
          },
          itemBuilder: (ctx) => [
            _menuItem('newest', 'Newest First', Icons.arrow_downward),
            _menuItem('oldest', 'Oldest First', Icons.arrow_upward),
            _menuItem('confidence', 'AI Confidence', Icons.psychology),
          ],
        ),
        const SizedBox(width: 8),
      ],
    );
  }

  PopupMenuItem<String> _menuItem(String value, String label, IconData icon) {
    final isSelected = _sortBy == value;
    return PopupMenuItem(
      value: value,
      child: Row(
        children: [
          Icon(icon, size: 18, color: isSelected ? AppColors.primary : AppColors.textSecondary),
          const SizedBox(width: 12),
          Text(label,
              style: AppTextStyles.bodyMedium.copyWith(
                  color: isSelected ? AppColors.primary : AppColors.textPrimary)),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // FAB & Scan Options
  // ---------------------------------------------------------------------------

  Widget _buildFab() {
    return FloatingActionButton.extended(
      onPressed: _showScanOptions,
      backgroundColor: AppColors.primary,
      icon: const Icon(Icons.camera_alt_outlined, color: Colors.white),
      label: Text('Scan', style: AppTextStyles.labelLarge.copyWith(color: Colors.white)),
    );
  }

  void _showScanOptions() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40, height: 4,
              decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(2)),
            ),
            const SizedBox(height: 24),
            Text('Import Screenshots', style: AppTextStyles.headlineMedium),
            const SizedBox(height: 8),
            Text('Choose how to import your screenshots', style: AppTextStyles.bodyMedium),
            const SizedBox(height: 24),
            _ScanOption(
              icon: Icons.photo_library, color: AppColors.primary,
              title: 'Scan Gallery', subtitle: 'Automatically find all screenshots',
              onTap: () { Navigator.pop(ctx); context.read<ScanBloc>().add(const ScanGalleryRequested()); },
            ),
            const SizedBox(height: 12),
            _ScanOption(
              icon: Icons.refresh, color: AppColors.ideas,
              title: 'Full Rescan', subtitle: 'Reprocess all existing screenshots',
              onTap: () { Navigator.pop(ctx); context.read<ScanBloc>().add(const ScanGalleryRequested(rescan: true)); },
            ),
            const SizedBox(height: 12),
            _ScanOption(
              icon: Icons.folder_special_rounded, color: AppColors.shopping,
              title: 'Custom Scan', subtitle: 'Pick specific folders or sub-folders',
              badge: 'NEW',
              onTap: () { Navigator.pop(ctx); _openCustomScanPicker(); },
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  void _openCustomScanPicker() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => BlocProvider.value(
        value: context.read<ScanBloc>(),
        child: const CustomScanPickerSheet(),
      ),
    );
  }

  void _openDetail(ScreenshotModel screenshot) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => BlocProvider.value(
        value: context.read<ScanBloc>(),
        child: ScreenshotDetailSheet(
          screenshot: screenshot,
          currentCategory: _selectedCategory,
          sortBy: _sortBy,
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Empty / Loading / Error
  // ---------------------------------------------------------------------------

  Widget _buildEmpty() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.photo_library_outlined, size: 64, color: AppColors.textTertiary),
          const SizedBox(height: 16),
          Text('No screenshots found', style: AppTextStyles.titleMedium),
          const SizedBox(height: 8),
          Text('Tap the Scan button to get started', style: AppTextStyles.bodyMedium),
        ],
      ),
    );
  }

  Widget _buildLoadingGrid() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: MasonryGridView.count(
        crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12,
        itemCount: 10,
        itemBuilder: (_, __) => _ShimmerCard(),
      ),
    );
  }

  Widget _buildError(String error) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.error_outline, size: 48, color: AppColors.error),
          const SizedBox(height: 16),
          Text('Something went wrong', style: AppTextStyles.titleMedium),
          const SizedBox(height: 8),
          Text(error, style: AppTextStyles.bodySmall, textAlign: TextAlign.center),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Multi-select floating action bar
// ---------------------------------------------------------------------------

class _SelectionActionBar extends StatelessWidget {
  final int selectedCount;
  final int totalCount;
  final VoidCallback onSelectAll;
  final VoidCallback onDeselectAll;
  final VoidCallback? onDelete;
  final VoidCallback onCancel;

  const _SelectionActionBar({
    required this.selectedCount,
    required this.totalCount,
    required this.onSelectAll,
    required this.onDeselectAll,
    required this.onDelete,
    required this.onCancel,
  });

  @override
  Widget build(BuildContext context) {
    final allSelected = selectedCount == totalCount && totalCount > 0;

    return Container(
      padding: EdgeInsets.fromLTRB(16, 12, 16, MediaQuery.of(context).padding.bottom + 12),
      decoration: BoxDecoration(
        color: AppColors.surface,
        border: const Border(top: BorderSide(color: AppColors.border)),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 20, offset: const Offset(0, -4)),
        ],
      ),
      child: Row(
        children: [
          // Select all / deselect all
          GestureDetector(
            onTap: allSelected ? onDeselectAll : onSelectAll,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: allSelected ? AppColors.primaryGlow : AppColors.surfaceVariant,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: allSelected ? AppColors.primary : AppColors.border,
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    allSelected ? Icons.deselect : Icons.select_all,
                    size: 16,
                    color: allSelected ? AppColors.primary : AppColors.textSecondary,
                  ),
                  const SizedBox(width: 6),
                  Text(
                    allSelected ? 'Deselect All' : 'Select All',
                    style: AppTextStyles.labelMedium.copyWith(
                      color: allSelected ? AppColors.primary : AppColors.textSecondary,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const Spacer(),
          // Counter badge
          if (selectedCount > 0)
            Container(
              margin: const EdgeInsets.only(right: 12),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: AppColors.surfaceVariant,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(
                '$selectedCount selected',
                style: AppTextStyles.labelMedium,
              ),
            ),
          // Delete button
          AnimatedOpacity(
            duration: const Duration(milliseconds: 200),
            opacity: selectedCount > 0 ? 1.0 : 0.35,
            child: ElevatedButton.icon(
              onPressed: onDelete,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.error,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                elevation: selectedCount > 0 ? 4 : 0,
                shadowColor: AppColors.error.withOpacity(0.4),
              ),
              icon: const Icon(Icons.delete_outline, size: 18),
              label: Text('Delete', style: AppTextStyles.labelLarge.copyWith(color: Colors.white)),
            ),
          ),
        ],
      ),
    ).animate().slideY(begin: 1, end: 0, duration: 250.ms, curve: Curves.easeOutCubic);
  }
}

// ---------------------------------------------------------------------------
// Screenshot Card — supports selection mode with animated checkbox overlay
// ---------------------------------------------------------------------------

class _ScreenshotCard extends StatelessWidget {
  final ScreenshotModel screenshot;
  final bool isSelectionMode;
  final bool isSelected;
  final VoidCallback onTap;
  final VoidCallback onLongPress;

  const _ScreenshotCard({
    required this.screenshot,
    required this.isSelectionMode,
    required this.isSelected,
    required this.onTap,
    required this.onLongPress,
  });

  @override
  Widget build(BuildContext context) {
    final catColor = AppColors.categoryColor(screenshot.category);

    return GestureDetector(
      onTap: onTap,
      onLongPress: onLongPress,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isSelected ? AppColors.error : AppColors.border,
            width: isSelected ? 2 : 1,
          ),
          boxShadow: isSelected
              ? [BoxShadow(color: AppColors.error.withOpacity(0.2), blurRadius: 12, spreadRadius: 1)]
              : [],
        ),
        clipBehavior: Clip.antiAlias,
        child: Stack(
          children: [
            // ---- Card content ----
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Image
                AspectRatio(
                  aspectRatio: 0.75,
                  child: AnimatedOpacity(
                    duration: const Duration(milliseconds: 180),
                    opacity: isSelectionMode && !isSelected ? 0.55 : 1.0,
                    child: _buildImage(),
                  ),
                ),
                // Info
                Padding(
                  padding: const EdgeInsets.all(10),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Flexible(
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                              decoration: BoxDecoration(
                                color: catColor.withOpacity(0.15),
                                borderRadius: BorderRadius.circular(6),
                                border: Border.all(color: catColor.withOpacity(0.3)),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(
                                    AppConstants.categoryEmojis[screenshot.category] ?? '📁',
                                    style: const TextStyle(fontSize: 10),
                                  ),
                                  const SizedBox(width: 4),
                                  Flexible(
                                    child: Text(
                                      screenshot.category,
                                      style: AppTextStyles.bodySmall.copyWith(
                                        color: catColor,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 10,
                                      ),
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          const Spacer(),
                          if (!isSelectionMode) ...[
                            if (screenshot.isFavorite)
                              const Icon(Icons.star, size: 12, color: AppColors.ideas),
                            if (screenshot.isLocked)
                              const Icon(Icons.lock, size: 12, color: AppColors.textTertiary),
                          ],
                        ],
                      ),
                      if (screenshot.extractedText.isNotEmpty) ...[
                        const SizedBox(height: 6),
                        Text(
                          screenshot.extractedText.length > 80
                              ? '${screenshot.extractedText.substring(0, 80)}…'
                              : screenshot.extractedText,
                          style: AppTextStyles.bodySmall.copyWith(color: AppColors.textTertiary, height: 1.4),
                          maxLines: 3,
                        ),
                      ],
                      if (screenshot.receiptAmount != null) ...[
                        const SizedBox(height: 6),
                        Text(
                          '\$${screenshot.receiptAmount!.toStringAsFixed(2)}',
                          style: AppTextStyles.labelLarge.copyWith(color: AppColors.receipts),
                        ),
                      ],
                    ],
                  ),
                ),
              ],
            ),

            // ---- Selection checkbox overlay (top-right corner) ----
            if (isSelectionMode)
              Positioned(
                top: 8,
                right: 8,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 180),
                  width: 26,
                  height: 26,
                  decoration: BoxDecoration(
                    color: isSelected ? AppColors.error : AppColors.surface.withOpacity(0.85),
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: isSelected ? AppColors.error : AppColors.border,
                      width: 2,
                    ),
                    boxShadow: [
                      BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 6),
                    ],
                  ),
                  child: isSelected
                      ? const Icon(Icons.check, size: 16, color: Colors.white)
                      : null,
                ).animate(target: isSelectionMode ? 1 : 0)
                  .scale(begin: const Offset(0, 0), end: const Offset(1, 1), duration: 200.ms),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildImage() {
    final path = screenshot.thumbnailPath ?? screenshot.filePath;
    try {
      return Image.file(File(path), fit: BoxFit.cover,
          errorBuilder: (_, __, ___) => _placeholder());
    } catch (_) {
      return _placeholder();
    }
  }

  Widget _placeholder() {
    return Container(
      color: AppColors.surfaceVariant,
      child: const Center(child: Icon(Icons.image_outlined, size: 32, color: AppColors.textTertiary)),
    );
  }
}

// ---------------------------------------------------------------------------
// Shimmer loading card
// ---------------------------------------------------------------------------

class _ShimmerCard extends StatefulWidget {
  @override
  State<_ShimmerCard> createState() => _ShimmerCardState();
}

class _ShimmerCardState extends State<_ShimmerCard> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(duration: const Duration(milliseconds: 1200), vsync: this)
      ..repeat(reverse: true);
    _animation = Tween(begin: 0.3, end: 0.7).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _animation,
      builder: (_, __) => Container(
        height: 220,
        decoration: BoxDecoration(
          color: AppColors.surface.withOpacity(_animation.value + 0.3),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.border),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Scan option tile
// ---------------------------------------------------------------------------

class _ScanOption extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  final String? badge;

  const _ScanOption({
    required this.icon,
    required this.color,
    required this.title,
    required this.subtitle,
    required this.onTap,
    this.badge,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppColors.surfaceVariant,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.border),
        ),
        child: Row(
          children: [
            Container(
              width: 48, height: 48,
              decoration: BoxDecoration(
                color: color.withOpacity(0.15),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: color.withOpacity(0.25)),
              ),
              child: Icon(icon, color: color, size: 24),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(title, style: AppTextStyles.titleMedium),
                      if (badge != null) ...[
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: color.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(5),
                            border: Border.all(color: color.withOpacity(0.4)),
                          ),
                          child: Text(badge!,
                              style: AppTextStyles.bodySmall.copyWith(
                                  color: color, fontSize: 9, fontWeight: FontWeight.w800, letterSpacing: 0.6)),
                        ),
                      ],
                    ],
                  ),
                  const SizedBox(height: 3),
                  Text(subtitle, style: AppTextStyles.bodySmall),
                ],
              ),
            ),
            const SizedBox(width: 8),
            Icon(Icons.chevron_right, color: AppColors.textTertiary, size: 20),
          ],
        ),
      ),
    );
  }
}
