// lib/features/scan/presentation/screens/home_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_animate/flutter_animate.dart';

import '../../../../core/theme/app_theme.dart';
import '../bloc/scan_bloc.dart';
import 'gallery_screen.dart';
import '../../../../../../features/dashboard/presentation/bloc/dashboard_bloc.dart';
import '../../../../../../features/dashboard/presentation/screens/dashboard_screen.dart';
import '../../../../../../features/search/presentation/screens/search_screen.dart';
import '../../../../../../features/settings/presentation/bloc/settings_bloc.dart';
import '../../../../../../features/settings/presentation/screens/settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;
  static const int _dashboardIndex = 2;

  final _screens = const [
    GalleryScreen(),
    SearchScreen(),
    DashboardScreen(),
    SettingsScreen(),
  ];

  final _navItems = const [
    (icon: Icons.photo_library_outlined, activeIcon: Icons.photo_library,  label: 'Gallery'),
    (icon: Icons.search_outlined,        activeIcon: Icons.search,          label: 'Search'),
    (icon: Icons.insights_outlined,      activeIcon: Icons.insights,        label: 'Insights'),
    (icon: Icons.settings_outlined,      activeIcon: Icons.settings,        label: 'Settings'),
  ];

  void _onTabTapped(int index) {
    setState(() => _currentIndex = index);
    // Auto-refresh Insights whenever it becomes active
    if (index == _dashboardIndex) {
      context.read<DashboardBloc>().add(DashboardLoadRequested());
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: IndexedStack(
        index: _currentIndex,
        children: _screens,
      ),
      bottomNavigationBar: _buildBottomNav(),
    );
  }

  Widget _buildBottomNav() {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surface,
        border: const Border(top: BorderSide(color: AppColors.border, width: 1)),
      ),
      child: SafeArea(
        child: SizedBox(
          height: 60,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: List.generate(_navItems.length, (i) {
              final item = _navItems[i];
              final isActive = _currentIndex == i;
              return GestureDetector(
                onTap: () => _onTabTapped(i),
                behavior: HitTestBehavior.opaque,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                  decoration: BoxDecoration(
                    color: isActive ? AppColors.primaryGlow : Colors.transparent,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        isActive ? item.activeIcon : item.icon,
                        color: isActive ? AppColors.primary : AppColors.textTertiary,
                        size: 22,
                      ),
                      const SizedBox(height: 2),
                      Text(item.label,
                          style: AppTextStyles.bodySmall.copyWith(
                            color: isActive ? AppColors.primary : AppColors.textTertiary,
                            fontSize: 10,
                            fontWeight: isActive ? FontWeight.w600 : FontWeight.w400,
                          )),
                    ],
                  ),
                ).animate(target: isActive ? 1 : 0).scale(
                  begin: const Offset(1, 1),
                  end: const Offset(1.05, 1.05),
                  duration: 200.ms,
                ),
              );
            }),
          ),
        ),
      ),
    );
  }
}
