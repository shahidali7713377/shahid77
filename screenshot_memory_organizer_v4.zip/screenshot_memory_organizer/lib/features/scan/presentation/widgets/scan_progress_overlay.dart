// lib/features/scan/presentation/widgets/scan_progress_overlay.dart
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../../../core/theme/app_theme.dart';
import '../bloc/scan_bloc.dart';

class ScanProgressOverlay extends StatelessWidget {
  final ScanInProgress state;
  const ScanProgressOverlay({super.key, required this.state});

  bool get _isCustomScan => state.folderLabel != null;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: _isCustomScan
              ? AppColors.shopping.withOpacity(0.4)
              : AppColors.primary.withOpacity(0.3),
        ),
        boxShadow: [
          BoxShadow(
            color: (_isCustomScan ? AppColors.shopping : AppColors.primary).withOpacity(0.1),
            blurRadius: 20,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              // Pulsing dot
              Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  color: _isCustomScan ? AppColors.shopping : AppColors.primary,
                  shape: BoxShape.circle,
                ),
              )
                  .animate(onPlay: (c) => c.repeat())
                  .scale(end: const Offset(1.5, 1.5), duration: 800.ms)
                  .then()
                  .scale(end: const Offset(1, 1), duration: 800.ms),
              const SizedBox(width: 10),

              // Title
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _isCustomScan ? 'Custom Folder Scan' : 'AI Processing Screenshots',
                      style: AppTextStyles.titleMedium.copyWith(
                        color: _isCustomScan ? AppColors.shopping : AppColors.primary,
                      ),
                    ),
                    if (_isCustomScan && state.folderLabel != null)
                      Text(
                        '📂 ${state.folderLabel}',
                        style: AppTextStyles.bodySmall.copyWith(
                          color: AppColors.shopping.withOpacity(0.8),
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                  ],
                ),
              ),
              const SizedBox(width: 8),

              // Counter
              Text(
                '${state.processed} / ${state.total}',
                style: AppTextStyles.labelMedium,
              ),
            ],
          ),
          const SizedBox(height: 12),

          // Progress bar
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: state.total > 0 ? state.progress : null,
              backgroundColor: AppColors.surfaceVariant,
              valueColor: AlwaysStoppedAnimation<Color>(
                _isCustomScan ? AppColors.shopping : AppColors.primary,
              ),
              minHeight: 6,
            ),
          ),
          const SizedBox(height: 8),

          // Current file
          Text(
            state.currentFile.isEmpty ? 'Scanning…' : '📷 ${state.currentFile}',
            style: AppTextStyles.bodySmall,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    ).animate().fadeIn(duration: 300.ms).slideY(begin: -0.1);
  }
}
