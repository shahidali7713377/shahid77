// lib/features/scan/presentation/widgets/custom_scan_picker_sheet.dart
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../core/theme/app_theme.dart';
import '../../../../data/repositories/screenshot_repository.dart';
import '../bloc/scan_bloc.dart';

/// A full-featured folder-picker bottom sheet for custom scan.
///
/// Flow:
///   1. Loads all device albums via [LoadAlbumsRequested].
///   2. Groups them by top-level folder (DCIM, Pictures, etc.).
///   3. User multi-selects individual albums.
///   4. Confirms → fires [ScanCustomFoldersRequested].
class CustomScanPickerSheet extends StatefulWidget {
  const CustomScanPickerSheet({super.key});

  @override
  State<CustomScanPickerSheet> createState() => _CustomScanPickerSheetState();
}

class _CustomScanPickerSheetState extends State<CustomScanPickerSheet> {
  final Set<String> _selectedIds = {};
  String _searchQuery = '';
  final TextEditingController _searchCtrl = TextEditingController();

  // Track which groups are collapsed; default all open.
  final Set<String> _collapsedGroups = {};

  @override
  void initState() {
    super.initState();
    context.read<ScanBloc>().add(LoadAlbumsRequested());
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  // ---- helpers ---------------------------------------------------------------

  int get _selectedCount => _selectedIds.length;

  void _toggleAlbum(AlbumInfo album) {
    setState(() {
      if (_selectedIds.contains(album.id)) {
        _selectedIds.remove(album.id);
      } else {
        _selectedIds.add(album.id);
      }
    });
  }

  void _toggleGroup(String group, List<AlbumInfo> albums) {
    final ids = albums.map((a) => a.id).toSet();
    final allSelected = ids.every(_selectedIds.contains);
    setState(() {
      if (allSelected) {
        _selectedIds.removeAll(ids);
      } else {
        _selectedIds.addAll(ids);
      }
    });
  }

  void _confirmScan(List<AlbumInfo> allAlbums) {
    final selected = allAlbums.where((a) => _selectedIds.contains(a.id)).toList();
    if (selected.isEmpty) return;
    Navigator.of(context).pop();
    context.read<ScanBloc>().add(ScanCustomFoldersRequested(selected));
  }

  Map<String, List<AlbumInfo>> _groupAlbums(List<AlbumInfo> albums) {
    final filtered = _searchQuery.isEmpty
        ? albums
        : albums
            .where((a) => a.name.toLowerCase().contains(_searchQuery.toLowerCase()))
            .toList();

    final map = <String, List<AlbumInfo>>{};
    for (final album in filtered) {
      map.putIfAbsent(album.groupName, () => []).add(album);
    }
    // Sort groups: "Screenshots" first, then alphabetical.
    final sorted = map.entries.toList()
      ..sort((a, b) {
        final aIsShot = a.key.toLowerCase().contains('screenshot');
        final bIsShot = b.key.toLowerCase().contains('screenshot');
        if (aIsShot && !bIsShot) return -1;
        if (!aIsShot && bIsShot) return 1;
        return a.key.compareTo(b.key);
      });
    return Map.fromEntries(sorted);
  }

  // ---- build -----------------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      initialChildSize: 0.92,
      minChildSize: 0.5,
      maxChildSize: 0.97,
      builder: (context, scrollController) {
        return Container(
          decoration: const BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          ),
          child: BlocBuilder<ScanBloc, ScanState>(
            buildWhen: (prev, curr) =>
                curr is AlbumsLoading ||
                curr is AlbumsLoaded ||
                curr is AlbumsLoadFailure,
            builder: (context, state) {
              return Column(
                children: [
                  _buildHandle(),
                  _buildHeader(),
                  _buildSearchBar(),
                  const Divider(color: AppColors.border, height: 1),
                  Expanded(
                    child: _buildBody(state, scrollController),
                  ),
                  if (state is AlbumsLoaded) _buildConfirmBar(state.albums),
                ],
              );
            },
          ),
        );
      },
    );
  }

  Widget _buildHandle() {
    return Center(
      child: Container(
        margin: const EdgeInsets.only(top: 12, bottom: 4),
        width: 40,
        height: 4,
        decoration: BoxDecoration(
          color: AppColors.border,
          borderRadius: BorderRadius.circular(2),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 12),
      child: Row(
        children: [
          // Icon badge
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF7C3AED), Color(0xFF4F46E5)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(Icons.folder_special_rounded, color: Colors.white, size: 22),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Custom Scan', style: AppTextStyles.headlineMedium),
                Text(
                  'Pick specific folders to scan',
                  style: AppTextStyles.bodySmall,
                ),
              ],
            ),
          ),
          // Close button
          GestureDetector(
            onTap: () => Navigator.of(context).pop(),
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: AppColors.surfaceVariant,
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(Icons.close, size: 18, color: AppColors.textSecondary),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      child: TextField(
        controller: _searchCtrl,
        onChanged: (v) => setState(() => _searchQuery = v),
        style: AppTextStyles.bodyMedium.copyWith(color: AppColors.textPrimary),
        decoration: InputDecoration(
          hintText: 'Search folders…',
          prefixIcon: const Icon(Icons.search, size: 20, color: AppColors.textTertiary),
          suffixIcon: _searchQuery.isNotEmpty
              ? GestureDetector(
                  onTap: () {
                    _searchCtrl.clear();
                    setState(() => _searchQuery = '');
                  },
                  child: const Icon(Icons.clear, size: 18, color: AppColors.textTertiary),
                )
              : null,
          filled: true,
          fillColor: AppColors.surfaceVariant,
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
        ),
      ),
    );
  }

  Widget _buildBody(ScanState state, ScrollController scrollController) {
    if (state is AlbumsLoading) return _buildLoading();
    if (state is AlbumsLoadFailure) return _buildError(state.error);
    if (state is AlbumsLoaded) return _buildAlbumList(state.albums, scrollController);
    // Re-render after initial load if bloc emitted another state.
    return _buildLoading();
  }

  Widget _buildLoading() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const CircularProgressIndicator(color: AppColors.primary, strokeWidth: 2),
        const SizedBox(height: 16),
        Text('Loading folders…', style: AppTextStyles.bodyMedium),
      ],
    );
  }

  Widget _buildError(String error) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.folder_off_outlined, size: 56, color: AppColors.textTertiary),
          const SizedBox(height: 16),
          Text('Could not load folders', style: AppTextStyles.titleMedium),
          const SizedBox(height: 8),
          Text(error, style: AppTextStyles.bodySmall, textAlign: TextAlign.center),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            onPressed: () => context.read<ScanBloc>().add(LoadAlbumsRequested()),
            icon: const Icon(Icons.refresh),
            label: const Text('Retry'),
          ),
        ],
      ),
    );
  }

  Widget _buildAlbumList(List<AlbumInfo> albums, ScrollController scrollController) {
    final grouped = _groupAlbums(albums);

    if (grouped.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.search_off, size: 56, color: AppColors.textTertiary),
            const SizedBox(height: 12),
            Text('No folders match "$_searchQuery"', style: AppTextStyles.bodyMedium),
          ],
        ),
      );
    }

    return ListView.builder(
      controller: scrollController,
      padding: const EdgeInsets.only(bottom: 8),
      itemCount: grouped.length,
      itemBuilder: (context, groupIndex) {
        final groupName = grouped.keys.elementAt(groupIndex);
        final groupAlbums = grouped[groupName]!;
        final isCollapsed = _collapsedGroups.contains(groupName);
        final allSelected = groupAlbums.every((a) => _selectedIds.contains(a.id));
        final someSelected = groupAlbums.any((a) => _selectedIds.contains(a.id));

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ---- Group header ----
            _GroupHeader(
              name: groupName,
              albumCount: groupAlbums.length,
              totalAssets: groupAlbums.fold(0, (s, a) => s + a.assetCount),
              isCollapsed: isCollapsed,
              allSelected: allSelected,
              someSelected: someSelected,
              onToggleCollapse: () => setState(() {
                if (isCollapsed) {
                  _collapsedGroups.remove(groupName);
                } else {
                  _collapsedGroups.add(groupName);
                }
              }),
              onSelectAll: () => _toggleGroup(groupName, groupAlbums),
            ),

            // ---- Album rows ----
            if (!isCollapsed)
              ...groupAlbums.asMap().entries.map((entry) {
                final i = entry.key;
                final album = entry.value;
                final isSelected = _selectedIds.contains(album.id);

                return _AlbumRow(
                  album: album,
                  isSelected: isSelected,
                  onTap: () => _toggleAlbum(album),
                )
                    .animate(delay: (i * 40).ms)
                    .fadeIn(duration: 200.ms)
                    .slideX(begin: 0.05, duration: 200.ms);
              }),

            const SizedBox(height: 4),
          ],
        );
      },
    );
  }

  Widget _buildConfirmBar(List<AlbumInfo> albums) {
    final totalSelected = albums
        .where((a) => _selectedIds.contains(a.id))
        .fold(0, (s, a) => s + a.assetCount);

    return Container(
      padding: EdgeInsets.fromLTRB(
        20,
        16,
        20,
        MediaQuery.of(context).padding.bottom + 16,
      ),
      decoration: BoxDecoration(
        color: AppColors.surface,
        border: const Border(top: BorderSide(color: AppColors.border)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 20,
            offset: const Offset(0, -4),
          ),
        ],
      ),
      child: Row(
        children: [
          // Selection summary
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  _selectedCount == 0
                      ? 'No folders selected'
                      : '$_selectedCount folder${_selectedCount != 1 ? 's' : ''} selected',
                  style: AppTextStyles.titleMedium.copyWith(
                    color: _selectedCount > 0 ? AppColors.textPrimary : AppColors.textTertiary,
                  ),
                ),
                if (totalSelected > 0)
                  Text(
                    '$totalSelected image${totalSelected != 1 ? 's' : ''} to scan',
                    style: AppTextStyles.bodySmall.copyWith(color: AppColors.primary),
                  ),
              ],
            ),
          ),
          const SizedBox(width: 16),
          // Scan button
          AnimatedOpacity(
            duration: const Duration(milliseconds: 200),
            opacity: _selectedCount > 0 ? 1.0 : 0.4,
            child: ElevatedButton.icon(
              onPressed: _selectedCount > 0 ? () => _confirmScan(albums) : null,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                elevation: _selectedCount > 0 ? 4 : 0,
                shadowColor: AppColors.primary.withOpacity(0.4),
              ),
              icon: const Icon(Icons.document_scanner_outlined, size: 18),
              label: Text(
                'Start Scan',
                style: AppTextStyles.labelLarge.copyWith(color: Colors.white),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Group header row
// ---------------------------------------------------------------------------

class _GroupHeader extends StatelessWidget {
  final String name;
  final int albumCount;
  final int totalAssets;
  final bool isCollapsed;
  final bool allSelected;
  final bool someSelected;
  final VoidCallback onToggleCollapse;
  final VoidCallback onSelectAll;

  const _GroupHeader({
    required this.name,
    required this.albumCount,
    required this.totalAssets,
    required this.isCollapsed,
    required this.allSelected,
    required this.someSelected,
    required this.onToggleCollapse,
    required this.onSelectAll,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onToggleCollapse,
      behavior: HitTestBehavior.opaque,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        color: AppColors.background,
        child: Row(
          children: [
            // Collapse arrow
            AnimatedRotation(
              turns: isCollapsed ? -0.25 : 0,
              duration: const Duration(milliseconds: 200),
              child: const Icon(Icons.keyboard_arrow_down,
                  size: 18, color: AppColors.textTertiary),
            ),
            const SizedBox(width: 8),
            // Folder icon
            const Icon(Icons.folder_outlined, size: 16, color: AppColors.textSecondary),
            const SizedBox(width: 8),
            // Name
            Expanded(
              child: Text(
                name,
                style: AppTextStyles.labelLarge.copyWith(
                  color: AppColors.textSecondary,
                  letterSpacing: 0.8,
                ),
              ),
            ),
            // Asset count badge
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                color: AppColors.surfaceVariant,
                borderRadius: BorderRadius.circular(6),
              ),
              child: Text(
                '$totalAssets',
                style: AppTextStyles.bodySmall,
              ),
            ),
            const SizedBox(width: 10),
            // Select-all checkbox
            GestureDetector(
              onTap: onSelectAll,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 150),
                width: 22,
                height: 22,
                decoration: BoxDecoration(
                  color: allSelected
                      ? AppColors.primary
                      : someSelected
                          ? AppColors.primary.withOpacity(0.3)
                          : Colors.transparent,
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(
                    color: allSelected || someSelected
                        ? AppColors.primary
                        : AppColors.border,
                    width: 1.5,
                  ),
                ),
                child: allSelected
                    ? const Icon(Icons.check, size: 14, color: Colors.white)
                    : someSelected
                        ? Container(
                            margin: const EdgeInsets.all(3),
                            decoration: BoxDecoration(
                              color: AppColors.primary,
                              borderRadius: BorderRadius.circular(2),
                            ),
                          )
                        : null,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Individual album row
// ---------------------------------------------------------------------------

class _AlbumRow extends StatelessWidget {
  final AlbumInfo album;
  final bool isSelected;
  final VoidCallback onTap;

  const _AlbumRow({
    required this.album,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 3),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: isSelected
              ? AppColors.primary.withOpacity(0.08)
              : AppColors.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: isSelected ? AppColors.primary.withOpacity(0.4) : AppColors.border,
            width: isSelected ? 1.5 : 1,
          ),
        ),
        child: Row(
          children: [
            // Thumbnail
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: SizedBox(
                width: 52,
                height: 52,
                child: _AlbumThumbnail(loader: album.thumbnailLoader),
              ),
            ),
            const SizedBox(width: 14),
            // Info
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      if (album.isScreenshotFolder) ...[
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                          margin: const EdgeInsets.only(right: 6),
                          decoration: BoxDecoration(
                            color: AppColors.primary.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Text(
                            'SCREENSHOTS',
                            style: AppTextStyles.bodySmall.copyWith(
                              color: AppColors.primary,
                              fontSize: 9,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 0.8,
                            ),
                          ),
                        ),
                      ],
                      Flexible(
                        child: Text(
                          album.name,
                          style: AppTextStyles.titleMedium,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 3),
                  Text(
                    '${album.assetCount} image${album.assetCount != 1 ? 's' : ''}',
                    style: AppTextStyles.bodySmall,
                  ),
                ],
              ),
            ),
            const SizedBox(width: 12),
            // Checkbox
            AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              width: 24,
              height: 24,
              decoration: BoxDecoration(
                color: isSelected ? AppColors.primary : Colors.transparent,
                borderRadius: BorderRadius.circular(7),
                border: Border.all(
                  color: isSelected ? AppColors.primary : AppColors.border,
                  width: 2,
                ),
                boxShadow: isSelected
                    ? [BoxShadow(color: AppColors.primary.withOpacity(0.35), blurRadius: 8)]
                    : [],
              ),
              child: isSelected
                  ? const Icon(Icons.check, size: 15, color: Colors.white)
                  : null,
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Lazy-loading thumbnail widget
// ---------------------------------------------------------------------------

class _AlbumThumbnail extends StatefulWidget {
  final Future<Uint8List?> Function()? loader;

  const _AlbumThumbnail({this.loader});

  @override
  State<_AlbumThumbnail> createState() => _AlbumThumbnailState();
}

class _AlbumThumbnailState extends State<_AlbumThumbnail> {
  Uint8List? _bytes;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    if (widget.loader == null) {
      if (mounted) setState(() => _loading = false);
      return;
    }
    try {
      final bytes = await widget.loader!();
      if (mounted) setState(() { _bytes = bytes; _loading = false; });
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return Container(
        color: AppColors.surfaceVariant,
        child: const Center(
          child: SizedBox(
            width: 16,
            height: 16,
            child: CircularProgressIndicator(
              strokeWidth: 1.5,
              color: AppColors.textTertiary,
            ),
          ),
        ),
      );
    }
    if (_bytes != null) {
      return Image.memory(_bytes!, fit: BoxFit.cover);
    }
    return Container(
      color: AppColors.surfaceVariant,
      child: const Icon(Icons.folder, size: 26, color: AppColors.textTertiary),
    );
  }
}
