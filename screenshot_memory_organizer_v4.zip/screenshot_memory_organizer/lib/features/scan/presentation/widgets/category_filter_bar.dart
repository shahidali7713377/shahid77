// lib/features/scan/presentation/widgets/category_filter_bar.dart
import 'package:flutter/material.dart';
import '../../../../core/constants/app_constants.dart';
import '../../../../core/theme/app_theme.dart';

class CategoryFilterBar extends StatelessWidget {
  final String? selected;
  final void Function(String?) onSelected;

  const CategoryFilterBar({
    super.key,
    required this.selected,
    required this.onSelected,
  });

  @override
  Widget build(BuildContext context) {
    final categories = ['All', ...AppConstants.defaultCategories.where((c) => c != 'Other')];

    return SizedBox(
      height: 48,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        scrollDirection: Axis.horizontal,
        itemCount: categories.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, i) {
          final cat = categories[i];
          final isSelected = cat == 'All' ? selected == null : selected == cat;
          final catColor = cat == 'All' ? AppColors.primary : AppColors.categoryColor(cat);

          return GestureDetector(
            onTap: () => onSelected(cat == 'All' ? null : cat),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                color: isSelected ? catColor.withOpacity(0.2) : AppColors.surface,
                borderRadius: BorderRadius.circular(24),
                border: Border.all(
                  color: isSelected ? catColor : AppColors.border,
                  width: isSelected ? 1.5 : 1,
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (cat != 'All')
                    Padding(
                      padding: const EdgeInsets.only(right: 6),
                      child: Text(
                        AppConstants.categoryEmojis[cat] ?? '📁',
                        style: const TextStyle(fontSize: 14),
                      ),
                    ),
                  Text(
                    cat,
                    style: AppTextStyles.labelMedium.copyWith(
                      color: isSelected ? catColor : AppColors.textSecondary,
                      fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
