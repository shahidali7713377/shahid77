// lib/features/scan/presentation/widgets/screenshot_detail_sheet.dart
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:intl/intl.dart';

import '../../../../core/constants/app_constants.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../data/models/screenshot_model.dart';
import '../bloc/scan_bloc.dart';

class ScreenshotDetailSheet extends StatefulWidget {
  final ScreenshotModel screenshot;
  final String? currentCategory;
  final String sortBy;
  const ScreenshotDetailSheet({
    super.key,
    required this.screenshot,
    this.currentCategory,
    this.sortBy = 'newest',
  });

  @override
  State<ScreenshotDetailSheet> createState() => _ScreenshotDetailSheetState();
}

class _ScreenshotDetailSheetState extends State<ScreenshotDetailSheet> {
  late ScreenshotModel _screenshot;
  final TextEditingController _noteController = TextEditingController();
  bool _editingNote = false;

  @override
  void initState() {
    super.initState();
    _screenshot = widget.screenshot;
    _noteController.text = _screenshot.userNote ?? '';
  }

  @override
  void dispose() {
    _noteController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final catColor = AppColors.categoryColor(_screenshot.category);
    return BlocListener<ScanBloc, ScanState>(
      // Reflect live updates (e.g. favorite, lock) back into local state so
      // the sheet buttons re-render without needing to close and reopen.
      listenWhen: (_, s) => s is ScreenshotsLoaded,
      listener: (context, state) {
        if (state is ScreenshotsLoaded) {
          final fresh = state.screenshots.where((s) => s.id == _screenshot.id);
          if (fresh.isNotEmpty) {
            setState(() => _screenshot = fresh.first);
          }
        }
      },
      child: DraggableScrollableSheet(
        initialChildSize: 0.92,
        minChildSize: 0.5,
        maxChildSize: 0.97,
        builder: (context, scrollController) {
          return Container(
            decoration: const BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
            ),
            child: CustomScrollView(
              controller: scrollController,
              slivers: [
                SliverToBoxAdapter(child: _buildHandle()),
                SliverToBoxAdapter(child: _buildImage()),
                SliverToBoxAdapter(child: _buildHeader(catColor)),
                if (_screenshot.extractedText.isNotEmpty)
                  SliverToBoxAdapter(child: _buildSection(
                    icon: Icons.text_fields,
                    title: 'Extracted Text',
                    child: Text(_screenshot.extractedText, style: AppTextStyles.mono),
                  )),
                if (_screenshot.category == 'Receipts' && _screenshot.extractedData != null)
                  SliverToBoxAdapter(child: _buildReceiptData()),
                if (_screenshot.tags.isNotEmpty)
                  SliverToBoxAdapter(child: _buildTags()),
                SliverToBoxAdapter(child: _buildNote()),
                SliverToBoxAdapter(child: _buildActions()),
                const SliverToBoxAdapter(child: SizedBox(height: 40)),
              ],
            ),
          );
        },
      ),
    );
  }

  // ── Handle ──────────────────────────────────────────────────────────────
  Widget _buildHandle() {
    return Center(
      child: Container(
        margin: const EdgeInsets.only(top: 12, bottom: 8),
        width: 40, height: 4,
        decoration: BoxDecoration(
          color: AppColors.border,
          borderRadius: BorderRadius.circular(2),
        ),
      ),
    );
  }

  // ── Image (tap to full-screen) ───────────────────────────────────────────
  Widget _buildImage() {
    return GestureDetector(
      onTap: _openFullScreen,
      child: Stack(
        children: [
          Container(
            height: 280,
            margin: const EdgeInsets.symmetric(horizontal: 16),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppColors.border),
            ),
            clipBehavior: Clip.antiAlias,
            child: Image.file(
              File(_screenshot.thumbnailPath ?? _screenshot.filePath),
              fit: BoxFit.cover,
              width: double.infinity,
              errorBuilder: (_, __, ___) => Container(
                color: AppColors.surfaceVariant,
                child: const Center(
                  child: Icon(Icons.broken_image_outlined, size: 48, color: AppColors.textTertiary),
                ),
              ),
            ),
          ),
          // "Tap to enlarge" hint badge
          Positioned(
            bottom: 12, right: 24,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.55),
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.zoom_out_map, size: 13, color: Colors.white),
                  SizedBox(width: 4),
                  Text('Tap to enlarge', style: TextStyle(color: Colors.white, fontSize: 11)),
                ],
              ),
            ).animate().fadeIn(delay: 400.ms).slideY(begin: 0.3),
          ),
        ],
      ),
    );
  }

  void _openFullScreen() {
    Navigator.of(context).push(PageRouteBuilder(
      opaque: false,
      barrierColor: Colors.transparent,
      pageBuilder: (_, __, ___) => _FullScreenImageViewer(
        filePath: _screenshot.filePath,
        thumbnailPath: _screenshot.thumbnailPath,
        heroTag: 'screenshot_${_screenshot.id}',
      ),
      transitionsBuilder: (_, anim, __, child) =>
          FadeTransition(opacity: anim, child: child),
    ));
  }

  // ── Header ───────────────────────────────────────────────────────────────
  Widget _buildHeader(Color catColor) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              GestureDetector(
                onTap: _changeCategoryDialog,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    color: catColor.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: catColor.withOpacity(0.4)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(AppConstants.categoryEmojis[_screenshot.category] ?? '📁',
                          style: const TextStyle(fontSize: 16)),
                      const SizedBox(width: 8),
                      Text(_screenshot.category,
                          style: AppTextStyles.titleMedium.copyWith(color: catColor)),
                      const SizedBox(width: 4),
                      Icon(Icons.keyboard_arrow_down, size: 16, color: catColor),
                    ],
                  ),
                ),
              ),
              const Spacer(),
              if (_screenshot.isProcessed)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: AppColors.surfaceVariant,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.psychology, size: 14, color: AppColors.textSecondary),
                      const SizedBox(width: 4),
                      Text(
                        '${(_screenshot.classificationConfidence * 100).toStringAsFixed(0)}%',
                        style: AppTextStyles.labelMedium,
                      ),
                    ],
                  ),
                ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            DateFormat('MMM dd, yyyy • HH:mm').format(_screenshot.createdAt),
            style: AppTextStyles.bodySmall,
          ),
        ],
      ),
    );
  }

  // ── Generic section card ─────────────────────────────────────────────────
  Widget _buildSection({required IconData icon, required String title, required Widget child}) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surfaceVariant,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Icon(icon, size: 16, color: AppColors.primary),
            const SizedBox(width: 8),
            Text(title, style: AppTextStyles.labelLarge.copyWith(color: AppColors.primary)),
          ]),
          const SizedBox(height: 12),
          const Divider(color: AppColors.border, height: 1),
          const SizedBox(height: 12),
          child,
        ],
      ),
    );
  }

  // ── Receipt data ─────────────────────────────────────────────────────────
  Widget _buildReceiptData() {
    final amount = _screenshot.receiptAmount;
    final store  = _screenshot.receiptStore;
    final date   = _screenshot.receiptDate;
    return _buildSection(
      icon: Icons.receipt_long,
      title: 'Receipt Details',
      child: Column(
        children: [
          if (amount != null)
            _receiptRow('💰', 'Total', '\$${amount.toStringAsFixed(2)}', AppColors.receipts),
          if (store != null)
            _receiptRow('🏪', 'Store', store, AppColors.textPrimary),
          if (date != null)
            _receiptRow('📅', 'Date', DateFormat('MMM dd, yyyy').format(date), AppColors.textPrimary),
        ],
      ),
    );
  }

  Widget _receiptRow(String emoji, String label, String value, Color color) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(children: [
        Text(emoji, style: const TextStyle(fontSize: 18)),
        const SizedBox(width: 12),
        Text(label, style: AppTextStyles.bodyMedium),
        const Spacer(),
        Text(value, style: AppTextStyles.titleMedium.copyWith(color: color)),
      ]),
    );
  }

  // ── Tags ─────────────────────────────────────────────────────────────────
  Widget _buildTags() {
    return _buildSection(
      icon: Icons.tag,
      title: 'Tags',
      child: Wrap(
        spacing: 8, runSpacing: 8,
        children: _screenshot.tags.map((tag) => Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(6),
            border: Border.all(color: AppColors.border),
          ),
          child: Text('#$tag', style: AppTextStyles.bodySmall.copyWith(color: AppColors.primary)),
        )).toList(),
      ),
    );
  }

  // ── Note ─────────────────────────────────────────────────────────────────
  Widget _buildNote() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surfaceVariant,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            const Icon(Icons.edit_note, size: 16, color: AppColors.ideas),
            const SizedBox(width: 8),
            Text('Note', style: AppTextStyles.labelLarge.copyWith(color: AppColors.ideas)),
            const Spacer(),
            GestureDetector(
              onTap: () {
                if (_editingNote) {
                  context.read<ScanBloc>().add(
                    ScreenshotNoteUpdated(_screenshot.id, _noteController.text),
                  );
                }
                setState(() => _editingNote = !_editingNote);
              },
              child: Text(
                _editingNote ? 'Save' : 'Edit',
                style: AppTextStyles.labelMedium.copyWith(color: AppColors.primary),
              ),
            ),
          ]),
          const SizedBox(height: 12),
          if (_editingNote)
            TextField(
              controller: _noteController,
              maxLines: 3,
              style: AppTextStyles.bodyMedium,
              decoration: const InputDecoration(
                hintText: 'Add a note...',
                border: OutlineInputBorder(),
              ),
            )
          else
            Text(
              _noteController.text.isEmpty ? 'Tap Edit to add a note...' : _noteController.text,
              style: AppTextStyles.bodyMedium.copyWith(
                color: _noteController.text.isEmpty ? AppColors.textTertiary : AppColors.textPrimary,
              ),
            ),
        ],
      ),
    );
  }

  // ── Actions (Favorite | Lock | Delete) ───────────────────────────────────
  Widget _buildActions() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          // ── Favorite ──
          Expanded(
            child: _ActionButton(
              icon: _screenshot.isFavorite ? Icons.star : Icons.star_border,
              color: _screenshot.isFavorite ? AppColors.ideas : AppColors.textSecondary,
              label: _screenshot.isFavorite ? 'Unfavorite' : 'Favorite',
              onTap: () {
                context.read<ScanBloc>().add(ScreenshotFavoriteToggled(_screenshot.id));
                // Update local state immediately for instant feedback
                setState(() => _screenshot = _screenshot.copyWith(isFavorite: !_screenshot.isFavorite));
              },
            ),
          ),
          const SizedBox(width: 10),
          // ── Lock / Unlock ──
          Expanded(
            child: _ActionButton(
              icon: _screenshot.isLocked ? Icons.lock : Icons.lock_open,
              color: _screenshot.isLocked ? AppColors.primary : AppColors.textSecondary,
              label: _screenshot.isLocked ? 'Unlock' : 'Lock',
              onTap: () {
                context.read<ScanBloc>().add(ScreenshotLockToggled(
                  _screenshot.id,
                  category: widget.currentCategory,
                  sortBy: widget.sortBy,
                ));
                // Optimistic local update so the icon flips immediately
                setState(() => _screenshot = _screenshot.copyWith(isLocked: !_screenshot.isLocked));
              },
            ),
          ),
          const SizedBox(width: 10),
          // ── Delete ──
          Expanded(
            child: _ActionButton(
              icon: Icons.delete_outline,
              color: AppColors.error,
              label: 'Delete',
              onTap: _screenshot.isLocked
                  ? () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                        content: Text('🔒 Unlock the screenshot before deleting'),
                        behavior: SnackBarBehavior.floating,
                      ))
                  // Show confirm dialog WITHOUT closing the sheet first —
                  // dialog closes sheet itself after confirmation.
                  : _showDeleteConfirm,
            ),
          ),
        ],
      ),
    );
  }

  // ── Category picker ───────────────────────────────────────────────────────
  void _changeCategoryDialog() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.surface,
        title: const Text('Change Category', style: AppTextStyles.titleLarge),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: AppConstants.defaultCategories.map((cat) {
            final catColor = AppColors.categoryColor(cat);
            final isSelected = cat == _screenshot.category;
            return ListTile(
              leading: Text(AppConstants.categoryEmojis[cat] ?? '📁',
                  style: const TextStyle(fontSize: 22)),
              title: Text(cat, style: AppTextStyles.titleMedium),
              trailing: isSelected ? Icon(Icons.check, color: catColor) : null,
              selected: isSelected,
              selectedTileColor: catColor.withOpacity(0.1),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              onTap: () {
                Navigator.pop(ctx);
                context.read<ScanBloc>().add(ScreenshotCategoryChanged(_screenshot.id, cat));
                setState(() => _screenshot = _screenshot.copyWith(category: cat));
              },
            );
          }).toList(),
        ),
      ),
    );
  }

  // ── Delete confirmation ───────────────────────────────────────────────────
  // IMPORTANT: Show dialog FIRST. Only pop the sheet inside the confirm
  // callback so the BLoC context is still valid when the event is dispatched.
  void _showDeleteConfirm() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: AppColors.error.withOpacity(0.15),
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(Icons.delete_outline, color: AppColors.error),
          ),
          const SizedBox(width: 12),
          const Text('Delete Screenshot?', style: AppTextStyles.titleLarge),
        ]),
        content: const Text(
          'This will remove the screenshot from the app.\nThe original file will NOT be deleted.',
          style: AppTextStyles.bodyMedium,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              // 1. Close dialog
              Navigator.pop(ctx);
              // 2. Close detail sheet
              Navigator.pop(context);
              // 3. Dispatch delete — context is still valid because we just
              //    called Navigator.pop with the dialog's ctx, not context.
              context.read<ScanBloc>().add(ScreenshotDeleted(
                _screenshot.id,
                category: widget.currentCategory,
                sortBy: widget.sortBy,
              ));
            },
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.error),
            child: const Text('Delete', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────
// Action button widget
// ─────────────────────────────────────────────────────────────
class _ActionButton extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String label;
  final VoidCallback onTap;

  const _ActionButton({
    required this.icon,
    required this.color,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 22, color: color),
            const SizedBox(height: 4),
            Text(label, style: AppTextStyles.labelMedium.copyWith(color: color, fontSize: 11)),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────
// Full-screen image viewer with pinch-to-zoom + swipe-to-close
// ─────────────────────────────────────────────────────────────
class _FullScreenImageViewer extends StatefulWidget {
  final String filePath;
  final String? thumbnailPath;
  final String heroTag;

  const _FullScreenImageViewer({
    required this.filePath,
    this.thumbnailPath,
    required this.heroTag,
  });

  @override
  State<_FullScreenImageViewer> createState() => _FullScreenImageViewerState();
}

class _FullScreenImageViewerState extends State<_FullScreenImageViewer>
    with SingleTickerProviderStateMixin {
  late TransformationController _transformCtrl;
  late AnimationController _animCtrl;
  Animation<Matrix4>? _animation;
  bool _showControls = true;

  @override
  void initState() {
    super.initState();
    _transformCtrl = TransformationController();
    _animCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 250));
    _animCtrl.addListener(() {
      if (_animation != null) _transformCtrl.value = _animation!.value;
    });
    // Auto-hide controls after 2s
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) setState(() => _showControls = false);
    });
  }

  @override
  void dispose() {
    _transformCtrl.dispose();
    _animCtrl.dispose();
    super.dispose();
  }

  void _resetZoom() {
    _animation = Matrix4Tween(
      begin: _transformCtrl.value,
      end: Matrix4.identity(),
    ).animate(CurvedAnimation(parent: _animCtrl, curve: Curves.easeOut));
    _animCtrl.forward(from: 0);
  }

  void _toggleControls() => setState(() => _showControls = !_showControls);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      extendBodyBehindAppBar: true,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(kToolbarHeight),
        child: AnimatedOpacity(
          opacity: _showControls ? 1.0 : 0.0,
          duration: const Duration(milliseconds: 250),
          child: AppBar(
            backgroundColor: Colors.black54,
            elevation: 0,
            leading: IconButton(
              icon: const Icon(Icons.arrow_back_ios_new, color: Colors.white),
              onPressed: () => Navigator.pop(context),
            ),
            actions: [
              IconButton(
                icon: const Icon(Icons.zoom_out_map, color: Colors.white),
                tooltip: 'Reset zoom',
                onPressed: _resetZoom,
              ),
              const SizedBox(width: 8),
            ],
          ),
        ),
      ),
      body: GestureDetector(
        onTap: _toggleControls,
        onDoubleTap: _resetZoom,
        child: Center(
          child: InteractiveViewer(
            transformationController: _transformCtrl,
            minScale: 0.5,
            maxScale: 6.0,
            clipBehavior: Clip.none,
            child: _buildFullImage(),
          ),
        ),
      ),
    ).animate().fadeIn(duration: 200.ms);
  }

  Widget _buildFullImage() {
    // Try full-resolution first; fall back to thumbnail
    final file = File(widget.filePath);
    return Image.file(
      file,
      fit: BoxFit.contain,
      errorBuilder: (_, __, ___) {
        if (widget.thumbnailPath != null) {
          return Image.file(File(widget.thumbnailPath!), fit: BoxFit.contain);
        }
        return const Icon(Icons.broken_image_outlined, size: 80, color: Colors.white38);
      },
    );
  }
}
