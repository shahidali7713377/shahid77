// lib/features/search/presentation/screens/search_screen.dart
import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_animate/flutter_animate.dart';

import '../../../../core/constants/app_constants.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../data/models/screenshot_model.dart';
import '../../../../data/repositories/screenshot_repository.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final TextEditingController _controller = TextEditingController();
  Timer? _debounce;
  List<ScreenshotModel> _results = [];
  bool _isSearching = false;
  String _query = '';

  @override
  void dispose() {
    _debounce?.cancel();
    _controller.dispose();
    super.dispose();
  }

  void _onQueryChanged(String query) {
    _debounce?.cancel();
    setState(() => _query = query);

    if (query.isEmpty) {
      setState(() { _results = []; _isSearching = false; });
      return;
    }

    setState(() => _isSearching = true);
    _debounce = Timer(
      const Duration(milliseconds: AppConstants.searchDebounceMs),
      () {
        final repo = context.read<ScreenshotRepository>();
        final results = repo.search(query);
        if (mounted) {
          setState(() {
            _results = results.take(AppConstants.maxSearchResults).toList();
            _isSearching = false;
          });
        }
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            _buildSearchBar(),
            Expanded(child: _buildContent()),
          ],
        ),
      ),
    );
  }

  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Search', style: AppTextStyles.headlineLarge),
          const SizedBox(height: 4),
          Text('Search by text, category, or tags', style: AppTextStyles.bodyMedium),
          const SizedBox(height: 16),
          Container(
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppColors.border),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.2),
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: TextField(
              controller: _controller,
              onChanged: _onQueryChanged,
              style: AppTextStyles.bodyLarge,
              autofocus: false,
              decoration: InputDecoration(
                hintText: 'e.g. "business ideas", "Amazon receipt"...',
                hintStyle: AppTextStyles.bodyMedium,
                prefixIcon: const Icon(Icons.search, color: AppColors.textTertiary),
                suffixIcon: _query.isNotEmpty
                    ? GestureDetector(
                        onTap: () {
                          _controller.clear();
                          _onQueryChanged('');
                        },
                        child: const Icon(Icons.clear, color: AppColors.textTertiary),
                      )
                    : null,
                border: InputBorder.none,
                enabledBorder: InputBorder.none,
                focusedBorder: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildContent() {
    if (_query.isEmpty) {
      return _buildSuggestionsView();
    }
    if (_isSearching) {
      return const Center(child: CircularProgressIndicator(color: AppColors.primary));
    }
    if (_results.isEmpty) {
      return _buildEmpty();
    }
    return _buildResultsList();
  }

  Widget _buildSuggestionsView() {
    final suggestions = [
      ('💡', 'business ideas'),
      ('🧾', 'Amazon receipt'),
      ('💬', 'quotes about success'),
      ('📚', 'study notes'),
      ('🛒', 'product price'),
    ];

    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Try searching for...', style: AppTextStyles.labelLarge),
          const SizedBox(height: 12),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: suggestions.asMap().entries.map((entry) {
              final i = entry.key;
              final s = entry.value;
              return GestureDetector(
                onTap: () {
                  _controller.text = s.$2;
                  _onQueryChanged(s.$2);
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(s.$1, style: const TextStyle(fontSize: 16)),
                      const SizedBox(width: 8),
                      Text(s.$2, style: AppTextStyles.bodyMedium),
                    ],
                  ),
                ).animate(delay: (i * 60).ms).fadeIn().slideX(begin: -0.1),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildResultsList() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Text(
            '${_results.length} result${_results.length != 1 ? 's' : ''} for "$_query"',
            style: AppTextStyles.bodyMedium,
          ),
        ),
        Expanded(
          child: ListView.separated(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: _results.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, index) {
              final item = _results[index];
              return _SearchResultCard(item: item, query: _query)
                  .animate(delay: (index * 30).ms)
                  .fadeIn(duration: 200.ms)
                  .slideY(begin: 0.1);
            },
          ),
        ),
      ],
    );
  }

  Widget _buildEmpty() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.search_off, size: 64, color: AppColors.textTertiary),
          const SizedBox(height: 16),
          Text('No results found', style: AppTextStyles.titleMedium),
          const SizedBox(height: 8),
          Text('Try different keywords', style: AppTextStyles.bodyMedium),
        ],
      ),
    );
  }
}

class _SearchResultCard extends StatelessWidget {
  final ScreenshotModel item;
  final String query;

  const _SearchResultCard({required this.item, required this.query});

  @override
  Widget build(BuildContext context) {
    final catColor = AppColors.categoryColor(item.category);

    return Container(
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          // Thumbnail
          ClipRRect(
            borderRadius: const BorderRadius.horizontal(left: Radius.circular(16)),
            child: SizedBox(
              width: 80,
              height: 80,
              child: Image.file(
                File(item.thumbnailPath ?? item.filePath),
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(
                  color: AppColors.surfaceVariant,
                  child: Center(
                    child: Text(
                      AppConstants.categoryEmojis[item.category] ?? '📁',
                      style: const TextStyle(fontSize: 28),
                    ),
                  ),
                ),
              ),
            ),
          ),

          // Content
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: catColor.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          '${AppConstants.categoryEmojis[item.category] ?? ''} ${item.category}',
                          style: AppTextStyles.bodySmall.copyWith(color: catColor, fontWeight: FontWeight.w600),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  if (item.extractedText.isNotEmpty)
                    _highlightedText(
                      item.extractedText.length > 100
                          ? '${item.extractedText.substring(0, 100)}…'
                          : item.extractedText,
                    ),
                  if (item.tags.isNotEmpty) ...[
                    const SizedBox(height: 6),
                    Text(
                      item.tags.take(4).map((t) => '#$t').join(' '),
                      style: AppTextStyles.bodySmall.copyWith(color: AppColors.primary),
                    ),
                  ],
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _highlightedText(String text) {
    final q = query.toLowerCase();
    final lower = text.toLowerCase();
    final idx = lower.indexOf(q);

    if (idx == -1) {
      return Text(text, style: AppTextStyles.bodySmall, maxLines: 2);
    }

    return RichText(
      maxLines: 2,
      overflow: TextOverflow.ellipsis,
      text: TextSpan(
        style: AppTextStyles.bodySmall,
        children: [
          TextSpan(text: text.substring(0, idx)),
          TextSpan(
            text: text.substring(idx, idx + q.length),
            style: AppTextStyles.bodySmall.copyWith(
              color: AppColors.primary,
              fontWeight: FontWeight.w700,
              backgroundColor: AppColors.primaryGlow,
            ),
          ),
          TextSpan(text: text.substring(idx + q.length)),
        ],
      ),
    );
  }
}
