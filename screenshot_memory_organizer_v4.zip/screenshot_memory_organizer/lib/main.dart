// lib/main.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:local_auth/local_auth.dart';

import 'core/services/service_locator.dart';
import 'core/theme/app_theme.dart';
import 'data/repositories/screenshot_repository.dart';
import 'features/dashboard/presentation/bloc/dashboard_bloc.dart';
import 'features/scan/presentation/bloc/scan_bloc.dart';
import 'features/scan/presentation/screens/home_screen.dart';
import 'features/settings/presentation/bloc/settings_bloc.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: AppColors.surface,
    systemNavigationBarIconBrightness: Brightness.light,
  ));
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  await Hive.initFlutter();
  await setupServiceLocator();

  runApp(const ScreenshotMemoryApp());
}

class ScreenshotMemoryApp extends StatelessWidget {
  const ScreenshotMemoryApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiRepositoryProvider(
      providers: [
        RepositoryProvider<ScreenshotRepository>.value(
          value: getIt<ScreenshotRepository>(),
        ),
      ],
      child: MultiBlocProvider(
        providers: [
          BlocProvider<ScanBloc>(create: (_) => getIt<ScanBloc>()),
          BlocProvider<DashboardBloc>(create: (_) => getIt<DashboardBloc>()),
          // SettingsBloc singleton — accessible everywhere in the tree
          BlocProvider<SettingsBloc>(create: (_) => getIt<SettingsBloc>()),
        ],
        child: MaterialApp(
          title: 'Screenshot Memory',
          debugShowCheckedModeBanner: false,
          theme: AppTheme.dark,
          home: const AppStartupWrapper(),
        ),
      ),
    );
  }
}

/// Handles splash → biometric gate → home screen.
class AppStartupWrapper extends StatefulWidget {
  const AppStartupWrapper({super.key});
  @override
  State<AppStartupWrapper> createState() => _AppStartupWrapperState();
}

class _AppStartupWrapperState extends State<AppStartupWrapper>
    with SingleTickerProviderStateMixin {
  late AnimationController _animController;
  late Animation<double> _fadeAnim;

  // Startup phases
  bool _splashDone = false;        // minimum splash duration elapsed
  bool _biometricChecked = false;  // biometric result known
  bool _authenticated = false;     // true = show home; false = show lock screen

  final LocalAuthentication _localAuth = LocalAuthentication();

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(vsync: this, duration: const Duration(milliseconds: 1500));
    _fadeAnim = CurvedAnimation(parent: _animController, curve: Curves.easeIn);
    _animController.forward();
    _init();
  }

  Future<void> _init() async {
    // Minimum 2s splash, then check biometric
    await Future.delayed(const Duration(seconds: 2));
    await _checkBiometric();
  }

  Future<void> _checkBiometric() async {
    final enabled = await isBiometricEnabled();
    if (!enabled) {
      if (mounted) setState(() { _splashDone = true; _biometricChecked = true; _authenticated = true; });
      return;
    }
    // Device must support it
    final supported = await _localAuth.isDeviceSupported();
    if (!supported) {
      if (mounted) setState(() { _splashDone = true; _biometricChecked = true; _authenticated = true; });
      return;
    }
    if (mounted) setState(() => _splashDone = true);
    await _authenticate();
  }

  Future<void> _authenticate() async {
    try {
      final result = await _localAuth.authenticate(
        localizedReason: 'Authenticate to open Screenshot Memory',
        options: const AuthenticationOptions(
          biometricOnly: false,
          stickyAuth: true,
        ),
      );
      if (mounted) setState(() { _biometricChecked = true; _authenticated = result; });
    } catch (e) {
      // On error fall through to lock screen so user can retry
      if (mounted) setState(() { _biometricChecked = true; _authenticated = false; });
    }
  }

  @override
  void dispose() {
    _animController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Still showing splash
    if (!_splashDone) return _buildSplash();

    // Biometric pending or failed
    if (!_biometricChecked || !_authenticated) {
      return _buildLockScreen();
    }

    return const HomeScreen();
  }

  // ── Splash ────────────────────────────────────────────────────────────
  Widget _buildSplash() {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: Center(
        child: FadeTransition(
          opacity: _fadeAnim,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 100, height: 100,
                decoration: BoxDecoration(
                  gradient: AppColors.primaryGradient,
                  borderRadius: BorderRadius.circular(28),
                  boxShadow: [
                    BoxShadow(
                      color: AppColors.primary.withOpacity(0.4),
                      blurRadius: 30, spreadRadius: 5,
                    ),
                  ],
                ),
                child: const Icon(Icons.screenshot_monitor, size: 50, color: Colors.white),
              ),
              const SizedBox(height: 28),
              Text('Screenshot Memory', style: AppTextStyles.headlineLarge),
              const SizedBox(height: 8),
              Text('Your AI-powered second brain', style: AppTextStyles.bodyMedium),
              const SizedBox(height: 60),
              SizedBox(
                width: 40, height: 40,
                child: CircularProgressIndicator(
                  color: AppColors.primary.withOpacity(0.6), strokeWidth: 2,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── Lock Screen ───────────────────────────────────────────────────────
  Widget _buildLockScreen() {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 90, height: 90,
              decoration: BoxDecoration(
                color: AppColors.primary.withOpacity(0.15),
                shape: BoxShape.circle,
                border: Border.all(color: AppColors.primary.withOpacity(0.4), width: 2),
              ),
              child: const Icon(Icons.fingerprint, size: 46, color: AppColors.primary),
            ).animate().scale(duration: 600.ms, curve: Curves.elasticOut),
            const SizedBox(height: 28),
            Text('Screenshot Memory', style: AppTextStyles.headlineLarge),
            const SizedBox(height: 8),
            Text('Authentication required to continue',
                style: AppTextStyles.bodyMedium, textAlign: TextAlign.center),
            const SizedBox(height: 48),
            ElevatedButton.icon(
              onPressed: _authenticate,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              ),
              icon: const Icon(Icons.lock_open_outlined),
              label: const Text('Authenticate'),
            ).animate().fadeIn(delay: 400.ms).slideY(begin: 0.2),
          ],
        ),
      ),
    );
  }
}
