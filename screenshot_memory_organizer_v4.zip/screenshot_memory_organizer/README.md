# 📱 Screenshot Memory Organizer

> Your AI-powered second brain — transforms messy screenshot galleries into structured, searchable knowledge assets.

![Flutter](https://img.shields.io/badge/Flutter-3.10%2B-blue?logo=flutter)
![Dart](https://img.shields.io/badge/Dart-3.0%2B-blue?logo=dart)
![Architecture](https://img.shields.io/badge/Architecture-Clean%20%2B%20BLoC-purple)
![AI](https://img.shields.io/badge/AI-ML%20Kit%20%2B%20On--Device-green)
![License](https://img.shields.io/badge/License-MIT-yellow)

---

## ✨ Features

| Feature | Free | Pro |
|---------|------|-----|
| Auto gallery scan | ✅ | ✅ |
| AI classification (5 categories) | ✅ | ✅ |
| OCR text extraction | ✅ | ✅ |
| Smart search | ✅ | ✅ |
| 5,000 screenshot limit | ✅ | ∞ |
| Analytics dashboard | ✅ | ✅ |
| Custom categories | — | ✅ |
| Semantic AI search | — | ✅ |
| Cloud backup | — | ✅ |
| Advanced analytics | — | ✅ |

---

## 🏗️ Architecture

```
lib/
├── core/
│   ├── ai/                    # ClassificationEngine (rule-based + TFLite ready)
│   ├── services/              # OcrService, ServiceLocator
│   ├── constants/             # AppConstants, AppStrings
│   └── theme/                 # AppTheme, AppColors, AppTextStyles
├── features/
│   ├── scan/                  # Gallery scanning, BLoC, screens, widgets
│   ├── categories/            # Category management
│   ├── search/                # Full-text + semantic search
│   ├── dashboard/             # Analytics & insights
│   └── settings/              # App settings, privacy controls
├── data/
│   ├── models/                # Hive models (ScreenshotModel, etc.)
│   ├── repositories/          # ScreenshotRepository (all data ops)
│   └── datasources/           # Local & remote datasources
└── main.dart                  # App entry point
```

**Design Patterns:**
- **Clean Architecture** — strict separation of concerns across data / domain / presentation layers
- **BLoC** — predictable, testable state management
- **Repository Pattern** — single source of truth for all data
- **Service Locator** (GetIt) — dependency injection without build_runner boilerplate

---

## 🤖 AI Stack

### Classification Engine (`core/ai/classification_engine.dart`)
- **Hybrid approach**: rule-based keyword matching + TFLite model (plug-in ready)
- Classifies into: `Ideas`, `Receipts`, `Quotes`, `Study Material`, `Shopping`, `Other`
- Returns confidence score (0–100%) per classification
- Auto-generates relevant tags from extracted text

### OCR Service (`core/services/ocr_service.dart`)
- Uses **Google ML Kit Text Recognition**
- Multi-language support (Latin, Chinese, Devanagari)
- Batch processing with configurable concurrency
- Processes < 2 seconds per image (on mid-range devices)

### Receipt Data Extraction
Automatically extracts:
- **Total amount** (regex-based from common invoice patterns)
- **Date** (multiple date formats supported)
- **Store name** (heuristic line detection)

### Duplicate Detection
- MD5 perceptual hashing of original files
- O(n) comparison via hash lookup
- Configurable similarity threshold

---

## 🚀 Getting Started

### Prerequisites
```bash
flutter --version   # >= 3.10.0
dart --version      # >= 3.0.0
```

### Installation

```bash
# 1. Clone
git clone https://github.com/yourorg/screenshot-memory-organizer.git
cd screenshot-memory-organizer

# 2. Install dependencies
flutter pub get

# 3. Generate Hive adapters
flutter packages pub run build_runner build --delete-conflicting-outputs

# 4. Run
flutter run
```

### Android Setup

Add to `android/app/build.gradle`:
```groovy
android {
    compileSdkVersion 34
    defaultConfig {
        minSdkVersion 21
        targetSdkVersion 34
    }
}
```

The `AndroidManifest.xml` is already configured with all required permissions.

### iOS Setup

Minimum deployment target: **iOS 13.0**

The `Info.plist` is pre-configured with:
- `NSPhotoLibraryUsageDescription`
- `NSFaceIDUsageDescription`
- Background processing modes

---

## 📦 Key Dependencies

| Package | Purpose |
|---------|---------|
| `flutter_bloc` | State management |
| `get_it` | Dependency injection |
| `hive_flutter` | Local encrypted database |
| `google_mlkit_text_recognition` | On-device OCR |
| `photo_manager` | Gallery access & scanning |
| `flutter_image_compress` | Thumbnail generation |
| `fl_chart` | Analytics charts |
| `flutter_animate` | UI animations |
| `flutter_staggered_grid_view` | Masonry grid layout |
| `flutter_secure_storage` | Encrypted key storage |
| `local_auth` | Biometric authentication |
| `pdf` | PDF export |
| `share_plus` | Native sharing |

---

## 🎨 Design System

**Theme:** Dark-first, premium aesthetic

```dart
// Color palette
AppColors.background      // #0A0A0F - deep space
AppColors.surface         // #13131A - card surface
AppColors.primary         // #7C3AED - electric violet
AppColors.ideas           // #F59E0B - amber
AppColors.receipts        // #10B981 - emerald
AppColors.quotes          // #EC4899 - pink
AppColors.study           // #3B82F6 - blue
AppColors.shopping        // #F97316 - orange
```

**Typography:** Syne (display) + JetBrainsMono (code/extracted text)

---

## 🔐 Privacy by Design

- **100% on-device processing** — no screenshot ever leaves the device without explicit user consent
- **Hive database** — local, fast, encrypted
- **Biometric lock** — optional app-level protection
- **Permission transparency** — only requests gallery permission, clearly explained

---

## 📊 Performance

| Metric | Target | Notes |
|--------|--------|-------|
| OCR per image | < 2s | ML Kit on-device |
| Gallery scan (1k images) | ~3 min | Background, non-blocking |
| App cold start | < 2s | Lazy initialization |
| Max screenshots | 10,000+ | Hive lazy loading |
| UI frame rate | 60fps | Shimmer loading, lazy grids |

---

## 🛣️ Roadmap

- [ ] TFLite model integration (replace rule-based classifier)
- [ ] Semantic search with on-device embeddings
- [ ] AI auto-summary of screenshot clusters
- [ ] Voice query ("What did I save about marketing?")
- [ ] Chrome extension sync
- [ ] Smart reminders from screenshots
- [ ] iCloud / Google Drive backup
- [ ] Widget for quick capture

---

## 🧪 Testing

```bash
# Unit tests
flutter test

# Integration tests
flutter test integration_test/

# With coverage
flutter test --coverage
```

Key test areas:
- `ClassificationEngine` — keyword matching accuracy
- `OcrService` — mock ML Kit responses
- `ScreenshotRepository` — CRUD operations with in-memory Hive
- `ScanBloc` — state transitions

---

## 📄 License

MIT License — see [LICENSE](LICENSE)

---

## 🙏 Acknowledgments

- [Google ML Kit](https://developers.google.com/ml-kit) for on-device text recognition
- [Hive](https://docs.hivedb.dev/) for blazing-fast local storage
- [Flutter BLoC](https://bloclibrary.dev/) for clean state management
- [FL Chart](https://github.com/imaNNeoFighT/fl_chart) for beautiful analytics charts
