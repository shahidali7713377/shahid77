# 🔄 Reverse To-Do List AI

> **Track What You Actually Do — Not What You Planned To Do.**

A production-ready Flutter productivity application that flips the traditional to-do paradigm: instead of planning future tasks, you **log real completed actions** and let AI analyze your actual behavioral patterns.

---

## 📐 Architecture Overview

```
lib/
├── main.dart                          # App entry point
├── app.dart                           # Root widget + navigation shell
│
├── core/
│   ├── constants/
│   │   └── app_constants.dart         # Enums, spacing, radius constants
│   └── theme/
│       └── app_theme.dart             # Dark/Light ThemeData, AppColors
│
├── data/
│   ├── models/
│   │   ├── activity_entry.dart        # Hive model: ActivityEntry + Goal
│   │   └── activity_entry.g.dart      # Generated adapter placeholder
│   └── local/
│       └── hive_service.dart          # Database CRUD + analytics helpers
│
├── services/
│   └── ai_service.dart                # AI categorization, weekly insights, energy
│
└── presentation/
    ├── providers/
    │   └── app_providers.dart         # All Riverpod StateNotifier providers
    ├── screens/
    │   ├── home_screen.dart           # Today's activity feed + quick stats
    │   ├── log_activity_screen.dart   # Log activity bottom sheet
    │   ├── dashboard_screen.dart      # Analytics: charts, heatmaps, burnout
    │   ├── insights_screen.dart       # AI weekly report + energy insights
    │   ├── goals_screen.dart          # Goal management + progress tracking
    │   ├── settings_screen.dart       # Theme, AI config, privacy
    │   └── onboarding_screen.dart     # First-run experience
    └── widgets/
        └── shared_widgets.dart        # GlassCard, CategoryChip, BurnoutMeter, etc.
```

---

## 🚀 Getting Started

### Prerequisites

- Flutter SDK ≥ 3.2.0
- Dart SDK ≥ 3.2.0
- iOS 13+ / Android API 21+

### Installation

```bash
# Clone the repository
git clone <repo-url>
cd reverse_todo_ai

# Install dependencies
flutter pub get

# Run code generation (for Hive adapters in production)
flutter pub run build_runner build --delete-conflicting-outputs

# Run the app
flutter run
```

### AI Integration (Optional)

The app works fully offline with rule-based AI by default. To unlock advanced AI:

1. Open Settings → AI Engine
2. Select your provider (Anthropic or OpenAI)
3. Enter your API key

| Provider  | Model Used          | Recommended For        |
|-----------|---------------------|------------------------|
| Anthropic | claude-haiku-4-5    | Best categorization quality |
| OpenAI    | gpt-4o-mini         | Cost-effective insights |

---

## ✨ Features

### 🔄 Reverse Logging System
- **Under 5 seconds** to log any activity
- Smart time-of-day suggestions (e.g., "Morning routine", "Deep work session")
- Flexible duration picker with quick presets (15m, 30m, 1h, 90m, 2h)
- Energy level tracking (Low / Medium / High)
- Optional mood tagging (Focused, Creative, Stressed, etc.)
- Manual category override (when you know better than AI)
- Goal tagging to link activities to intentions

### 🤖 AI Auto-Categorization Engine
**Without API key:** Smart rule-based keyword matching across 150+ patterns  
**With API key:** Claude/GPT categorization with contextual understanding

Categories:
- 🧠 Deep Work · 📋 Shallow Work · 📚 Learning
- 👥 Social · 🎮 Entertainment · 💪 Health
- 📁 Admin · 🎨 Creative · 🌿 Personal

### 📊 Analytics Dashboard
- **Weekly time distribution** pie chart (fl_chart)
- **Activity heatmap** — minutes logged per day
- **Energy pattern graph** — average energy by hour of day
- **Burnout Risk Meter** — algorithmic score from 5 behavioral signals
- **Deep Work Focus Score** — deep work as % of total time

### 🤖 AI Insights Engine
- Weekly behavioral summary
- Top single insight highlighted
- Behavioral patterns detected
- Actionable, encouraging recommendations
- Focus score + goal alignment percentage
- Energy insights: peak window, energy boosters, stress triggers, streaks

### 🔥 Burnout Risk Prediction
Algorithmic scoring using:
- Total weekly hours (>40h = risk signal)
- Deep work ratio (>70% = overload signal)
- Low energy activity ratio
- Missing recovery activities (health/personal)
- Stressed mood frequency

Risk levels: **Low 🟢** / **Moderate 🟡** / **High 🔴**

### 🎯 Goals System
- Define goals with target focus areas (categories)
- Weekly hour targets
- Real-time progress bar updated from actual logged time
- Toggle goals active/inactive
- Color-coded for visual clarity

---

## 🎨 Design System

### Color Palette (Dark Mode)
```
Background:    #0A0A0F   (near-black)
Surface:       #13131A   (elevated surface)
Cards:         #1C1C27   (card background)
Border:        #2A2A3D   (subtle borders)
Primary:       #7C6AF7   (violet — brand color)
Secondary:     #06D6A0   (emerald — success/positive)
Accent:        #FF6B6B   (coral — warning/risk)
Warning:       #FFBE0B   (amber — moderate)
```

### Typography
- **Display/Headlines:** DM Serif Display (editorial, warm)
- **UI Text:** Space Grotesk (geometric, modern)
- **Body:** Inter (readable, neutral)

### Component Library (`shared_widgets.dart`)
| Component | Description |
|-----------|-------------|
| `GlassCard` | Bordered container with surface color |
| `CategoryChip` | Animated pill with category emoji + color |
| `EnergySelector` | Three-button energy level picker |
| `BurnoutMeter` | Animated progress bar with risk label |
| `ActivityTile` | List item with category, duration, mood |
| `StatCard` | Metric display card with accent |
| `EmptyState` | Centered emoji + message + action |
| `LoadingCard` | Shimmer placeholder |
| `SectionHeader` | Title + subtitle + trailing action |

---

## 🔧 State Management (Riverpod)

| Provider | Type | Description |
|----------|------|-------------|
| `themeProvider` | `StateNotifier<bool>` | Dark/light mode toggle |
| `activitiesProvider` | `StateNotifier<List<ActivityEntry>>` | All activity CRUD |
| `todayActivitiesProvider` | `Provider` | Filtered to today |
| `weekActivitiesProvider` | `Provider` | Filtered to this week |
| `goalsProvider` | `StateNotifier<List<Goal>>` | Goal management |
| `activeGoalsProvider` | `Provider` | Active goals filter |
| `categoryDistributionProvider` | `Provider` | Weekly minutes by category |
| `burnoutRiskProvider` | `Provider` | Current burnout risk enum |
| `burnoutScoreProvider` | `Provider` | Raw burnout score (0–1) |
| `hourlyEnergyProvider` | `Provider` | Avg energy by hour map |
| `weeklyInsightProvider` | `FutureProvider` | AI weekly analysis |
| `energyInsightsProvider` | `Provider` | Rule-based energy insights |
| `settingsProvider` | `StateNotifier<Map>` | App config |
| `bottomNavIndexProvider` | `StateProvider<int>` | Navigation tab |

---

## 💾 Data Models

### `ActivityEntry` (Hive typeId: 0)
```dart
id                  String        // UUID
description         String        // User's text description
startTime           DateTime      // When activity started
durationMinutes     int           // How long it lasted
categoryName        String        // ActivityCategory enum name
energyLevelName     String        // EnergyLevel enum name
moodTagName         String?       // Optional MoodTag enum name
goalId              String?       // Optional linked goal
createdAt           DateTime      // Log timestamp
aiInsight           String?       // Optional AI-generated note
isManualCategory    bool          // Whether user overrode AI
```

### `Goal` (Hive typeId: 1)
```dart
id                  String        // UUID
title               String        // Goal title
description         String        // Description
targetCategories    List<String>  // ActivityCategory names
weeklyTargetMinutes int           // Target hours × 60
createdAt           DateTime
isActive            bool
color               String?       // Hex color code
```

---

## 🔒 Privacy Model

- **All data stored locally** using Hive (on-device SQLite-like storage)
- **Zero telemetry** — no analytics, no crash reporting, no user tracking
- **API keys stored locally** in Hive settings box (not transmitted anywhere except to your chosen AI provider)
- **Clear data** option in Settings permanently deletes all Hive boxes
- AI API calls are **direct device-to-provider** with no proxy

---

## 🧪 Extending the App

### Adding a New Category
```dart
// In app_constants.dart
enum ActivityCategory {
  // ... existing
  mindfulness('Mindfulness', '🧘', '#A78BFA'), // add here
}

// Update AI service rules in ai_service.dart → _ruleCategorize()
ActivityCategory.mindfulness: ['meditat', 'breathe', 'mindful', 'yoga'],
```

### Adding a New Chart to Dashboard
```dart
// In dashboard_screen.dart, add to SliverChildListDelegate:
GlassCard(
  child: MyCustomChart(data: myData),
),
```

### Custom AI Provider
```dart
// In ai_service.dart → _callAI()
} else if (_provider == 'gemini') {
  // Add Gemini API call
}
```

---

## 🏗 Production Checklist

- [ ] Run `flutter pub run build_runner build` to generate Hive adapters
- [ ] Add `assets/animations/` directory with Lottie files (optional)
- [ ] Configure `android/app/src/main/AndroidManifest.xml` permissions
- [ ] Configure `ios/Runner/Info.plist` for microphone (voice input future feature)
- [ ] Enable ProGuard rules for Hive in Android release builds
- [ ] Set up crash reporting (Sentry/Firebase Crashlytics)
- [ ] Add app icons via `flutter_launcher_icons` package
- [ ] Enable notification scheduling via `flutter_local_notifications`

---

## 📦 Key Dependencies

| Package | Version | Purpose |
|---------|---------|---------|
| `flutter_riverpod` | ^2.4.9 | State management |
| `hive_flutter` | ^1.1.0 | Local NoSQL database |
| `fl_chart` | ^0.66.2 | Charts (pie, line, bar) |
| `flutter_animate` | ^4.5.0 | Fluid animations |
| `google_fonts` | ^6.1.0 | DM Serif, Space Grotesk, Inter |
| `http` | ^1.2.0 | AI API calls |
| `uuid` | ^4.3.3 | Unique activity IDs |
| `intl` | ^0.19.0 | Date formatting |
| `go_router` | ^12.1.3 | Navigation (future deep links) |

---

## 🤝 Contributing

This project follows Clean Architecture principles:

1. **Data Layer** (`data/`) — Models and local persistence only
2. **Service Layer** (`services/`) — Business logic, AI, analytics
3. **Presentation Layer** (`presentation/`) — UI, state, providers

Keep concerns separated, write descriptive commit messages, and test AI categorization changes against diverse activity descriptions.

---

*Built with Flutter · Powered by Riverpod · AI by Anthropic/OpenAI*
