// lib/core/constants/app_constants.dart

const String kAppName = 'Reverse To-Do AI';
const String kHiveActivityBox = 'activities';
const String kHiveGoalBox = 'goals';
const String kHiveSettingsBox = 'settings';
const String kOpenAIBaseUrl = 'https://api.openai.com/v1/chat/completions';
const String kAnthropicBaseUrl = 'https://api.anthropic.com/v1/messages';

// Activity Categories
enum ActivityCategory {
  deepWork('Deep Work', '🧠', '#6366F1'),
  shallowWork('Shallow Work', '📋', '#8B5CF6'),
  learning('Learning', '📚', '#06B6D4'),
  social('Social', '👥', '#10B981'),
  entertainment('Entertainment', '🎮', '#F59E0B'),
  health('Health', '💪', '#EF4444'),
  admin('Admin', '📁', '#64748B'),
  creative('Creative', '🎨', '#EC4899'),
  personal('Personal', '🌿', '#84CC16');

  const ActivityCategory(this.label, this.emoji, this.hexColor);
  final String label;
  final String emoji;
  final String hexColor;
}

// Energy Levels
enum EnergyLevel {
  low('Low', 1, '😴'),
  medium('Medium', 2, '😊'),
  high('High', 3, '⚡');

  const EnergyLevel(this.label, this.value, this.emoji);
  final String label;
  final int value;
  final String emoji;
}

// Mood Tags
enum MoodTag {
  focused('Focused', '🎯'),
  creative('Creative', '✨'),
  stressed('Stressed', '😤'),
  calm('Calm', '😌'),
  motivated('Motivated', '🚀'),
  tired('Tired', '😪'),
  anxious('Anxious', '😰'),
  happy('Happy', '😄');

  const MoodTag(this.label, this.emoji);
  final String label;
  final String emoji;
}

// Burnout Risk
enum BurnoutRisk {
  low('Low', 0.0, '#10B981'),
  moderate('Moderate', 0.5, '#F59E0B'),
  high('High', 1.0, '#EF4444');

  const BurnoutRisk(this.label, this.value, this.hexColor);
  final String label;
  final double value;
  final String hexColor;
}

class AppSpacing {
  static const double xs = 4.0;
  static const double sm = 8.0;
  static const double md = 16.0;
  static const double lg = 24.0;
  static const double xl = 32.0;
  static const double xxl = 48.0;
}

class AppRadius {
  static const double sm = 8.0;
  static const double md = 12.0;
  static const double lg = 16.0;
  static const double xl = 24.0;
  static const double full = 100.0;
}
