// lib/services/ai_service.dart
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../core/constants/app_constants.dart';
import '../data/local/hive_service.dart';
import '../data/models/activity_entry.dart';

class AIService {
  static final AIService _instance = AIService._internal();
  factory AIService() => _instance;
  AIService._internal();

  String? get _apiKey => HiveService.aiApiKey;
  String get _provider => HiveService.aiProvider;

  // ─── Auto-Categorization ────────────────────────────────────────────────────

  /// Uses rule-based categorization when no API key, AI when available.
  Future<ActivityCategory> categorizeActivity(String description) async {
    if (_apiKey != null && _apiKey!.isNotEmpty) {
      return _aiCategorize(description);
    }
    return _ruleCategorize(description);
  }

  ActivityCategory _ruleCategorize(String description) {
    final lower = description.toLowerCase();

    final Map<ActivityCategory, List<String>> rules = {
      ActivityCategory.deepWork: [
        'code', 'coding', 'programming', 'develop', 'debug', 'architect',
        'write', 'writing', 'draft', 'essay', 'research', 'analyze', 'design',
        'strategy', 'plan', 'focus', 'concentration', 'problem'
      ],
      ActivityCategory.learning: [
        'read', 'reading', 'book', 'course', 'learn', 'study', 'lecture',
        'tutorial', 'workshop', 'podcast', 'documentation', 'watch', 'video'
      ],
      ActivityCategory.social: [
        'meeting', 'call', 'talk', 'chat', 'lunch', 'coffee', 'team',
        'colleague', 'friend', 'family', 'dinner', 'party', 'event'
      ],
      ActivityCategory.health: [
        'gym', 'workout', 'run', 'walk', 'exercise', 'yoga', 'meditat',
        'sleep', 'nap', 'cook', 'meal', 'eat', 'doctor', 'therapy'
      ],
      ActivityCategory.entertainment: [
        'game', 'netflix', 'movie', 'music', 'play', 'fun', 'relax',
        'scroll', 'social media', 'youtube', 'tv', 'series', 'browse'
      ],
      ActivityCategory.admin: [
        'email', 'slack', 'admin', 'schedule', 'calendar', 'invoice',
        'billing', 'report', 'spreadsheet', 'meeting notes', 'organize'
      ],
      ActivityCategory.creative: [
        'design', 'art', 'sketch', 'paint', 'music', 'compose', 'create',
        'brainstorm', 'ideate', 'prototype', 'ui', 'ux', 'creative'
      ],
      ActivityCategory.personal: [
        'personal', 'journal', 'reflect', 'plan', 'goal', 'grocery',
        'errands', 'chores', 'home', 'clean', 'organize personal'
      ],
    };

    int bestScore = 0;
    ActivityCategory bestCategory = ActivityCategory.shallowWork;

    for (final entry in rules.entries) {
      final score = entry.value.where((kw) => lower.contains(kw)).length;
      if (score > bestScore) {
        bestScore = score;
        bestCategory = entry.key;
      }
    }

    return bestCategory;
  }

  Future<ActivityCategory> _aiCategorize(String description) async {
    try {
      final categories = ActivityCategory.values.map((c) => c.label).join(', ');
      final prompt = '''Categorize this activity into exactly one category.

Activity: "$description"

Available categories: $categories

Respond with ONLY the category name (e.g., "Deep Work"), nothing else.''';

      final response = await _callAI(prompt, maxTokens: 20);
      if (response == null) return _ruleCategorize(description);

      final cleaned = response.trim();
      return ActivityCategory.values.firstWhere(
        (c) => c.label.toLowerCase() == cleaned.toLowerCase(),
        orElse: () => _ruleCategorize(description),
      );
    } catch (_) {
      return _ruleCategorize(description);
    }
  }

  // ─── Weekly Insights ────────────────────────────────────────────────────────

  Future<WeeklyInsight> generateWeeklyInsight(List<ActivityEntry> activities) async {
    if (_apiKey != null && _apiKey!.isNotEmpty) {
      return _aiWeeklyInsight(activities);
    }
    return _ruleWeeklyInsight(activities);
  }

  WeeklyInsight _ruleWeeklyInsight(List<ActivityEntry> activities) {
    if (activities.isEmpty) {
      return WeeklyInsight(
        summary: 'No activities logged this week yet.',
        topInsight: 'Start logging to unlock personalized insights.',
        behavioralPatterns: [],
        recommendations: ['Log your first activity to get started!'],
        focusScore: 0.0,
        goalAlignmentPercent: 0.0,
      );
    }

    final totalMinutes = activities.fold(0, (sum, a) => sum + a.durationMinutes);
    final deepWorkMinutes = activities
        .where((a) => a.category == ActivityCategory.deepWork)
        .fold(0, (sum, a) => sum + a.durationMinutes);
    final deepWorkPercent = totalMinutes > 0 ? (deepWorkMinutes / totalMinutes * 100).round() : 0;

    // Energy analysis
    final avgEnergy = activities.isEmpty
        ? 0.0
        : activities.map((a) => a.energyLevel.value).reduce((a, b) => a + b) /
            activities.length;

    // Best hour
    final hourEnergy = HiveService.getAverageEnergyByHour();
    String bestWindow = '9:00–11:00 AM'; // default
    if (hourEnergy.isNotEmpty) {
      final bestHour = hourEnergy.entries.reduce((a, b) => a.value > b.value ? a : b).key;
      bestWindow = '${_formatHour(bestHour)}–${_formatHour(bestHour + 2)}';
    }

    // Category distribution
    final categoryMap = <ActivityCategory, int>{};
    for (final a in activities) {
      categoryMap[a.category] = (categoryMap[a.category] ?? 0) + a.durationMinutes;
    }
    final topCategories = categoryMap.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    final patterns = <String>[];
    if (topCategories.isNotEmpty) {
      patterns.add(
          '${topCategories.first.key.emoji} Most of your time was on **${topCategories.first.key.label}**');
    }
    if (avgEnergy < 2.0) {
      patterns.add('😴 Your average energy was low — consider scheduling recovery time');
    }
    if (deepWorkPercent > 50) {
      patterns.add('🧠 High deep work ratio — excellent focus discipline!');
    }

    final recommendations = <String>[];
    if (!activities.any((a) => a.category == ActivityCategory.health)) {
      recommendations.add('💪 No health activities logged — add exercise or movement');
    }
    if (deepWorkPercent < 20) {
      recommendations.add('🎯 Try dedicating morning hours to deep work');
    }
    recommendations.add('📊 Your peak focus window appears to be $bestWindow');

    final focusScore = (deepWorkPercent / 100.0 * 0.6 + (avgEnergy - 1) / 2 * 0.4).clamp(0.0, 1.0);

    return WeeklyInsight(
      summary:
          'You logged ${_formatDuration(totalMinutes)} across ${activities.length} activities. '
          'Deep work made up $deepWorkPercent% of your time.',
      topInsight: 'Your peak productivity window is $bestWindow',
      behavioralPatterns: patterns,
      recommendations: recommendations,
      focusScore: focusScore,
      goalAlignmentPercent: deepWorkPercent / 100.0,
    );
  }

  Future<WeeklyInsight> _aiWeeklyInsight(List<ActivityEntry> activities) async {
    try {
      final activitySummary = activities.take(50).map((a) {
        return '- ${a.description} (${a.category.label}, ${a.durationMinutes}min, energy: ${a.energyLevel.label})';
      }).join('\n');

      final prompt = '''Analyze this week's activity log and provide insights.

Activities:
$activitySummary

Respond with a JSON object with these exact keys:
{
  "summary": "2-3 sentence overview of the week",
  "topInsight": "The single most important insight",
  "behavioralPatterns": ["pattern1", "pattern2", "pattern3"],
  "recommendations": ["rec1", "rec2", "rec3"],
  "focusScore": 0.75,
  "goalAlignmentPercent": 0.60
}

Be encouraging, specific, and non-judgmental. Focus on behavioral truth.''';

      final response = await _callAI(prompt, maxTokens: 500);
      if (response == null) return _ruleWeeklyInsight(activities);

      final json = jsonDecode(response);
      return WeeklyInsight(
        summary: json['summary'] ?? '',
        topInsight: json['topInsight'] ?? '',
        behavioralPatterns: List<String>.from(json['behavioralPatterns'] ?? []),
        recommendations: List<String>.from(json['recommendations'] ?? []),
        focusScore: (json['focusScore'] as num?)?.toDouble() ?? 0.0,
        goalAlignmentPercent:
            (json['goalAlignmentPercent'] as num?)?.toDouble() ?? 0.0,
      );
    } catch (_) {
      return _ruleWeeklyInsight(activities);
    }
  }

  // ─── Energy Insights ────────────────────────────────────────────────────────

  List<EnergyInsight> generateEnergyInsights(List<ActivityEntry> activities) {
    final insights = <EnergyInsight>[];

    if (activities.length < 5) {
      insights.add(EnergyInsight(
        title: 'Gathering data...',
        description: 'Log more activities to unlock energy insights.',
        icon: '📊',
      ));
      return insights;
    }

    // Best time of day
    final hourEnergy = <int, List<int>>{};
    for (final a in activities) {
      hourEnergy[a.hour] = [...(hourEnergy[a.hour] ?? []), a.energyLevel.value];
    }

    if (hourEnergy.length >= 3) {
      final avgByHour = hourEnergy.map((h, e) =>
          MapEntry(h, e.reduce((a, b) => a + b) / e.length));
      final bestHour = avgByHour.entries.reduce((a, b) => a.value > b.value ? a : b);
      insights.add(EnergyInsight(
        title: 'Peak Focus Window',
        description:
            'Your energy peaks around ${_formatHour(bestHour.key)}. Schedule deep work here.',
        icon: '⚡',
      ));
    }

    // Category-energy correlation
    final catEnergy = <ActivityCategory, List<int>>{};
    for (final a in activities) {
      catEnergy[a.category] = [...(catEnergy[a.category] ?? []), a.energyLevel.value];
    }

    final highEnergyCategory = catEnergy.entries
        .where((e) => e.value.length >= 2)
        .map((e) => MapEntry(e.key, e.value.reduce((a, b) => a + b) / e.value.length))
        .fold<MapEntry<ActivityCategory, double>?>(null, (best, entry) {
      if (best == null || entry.value > best.value) return entry;
      return best;
    });

    if (highEnergyCategory != null) {
      insights.add(EnergyInsight(
        title: 'Energy Booster',
        description:
            '${highEnergyCategory.key.emoji} ${highEnergyCategory.key.label} activities give you the highest energy.',
        icon: '🚀',
      ));
    }

    // Stress detection
    final stressedActivities = activities.where((a) => a.moodTagName == MoodTag.stressed.name);
    if (stressedActivities.length >= 3) {
      final mostStressedCat = _mostFrequentCategory(stressedActivities.toList());
      if (mostStressedCat != null) {
        insights.add(EnergyInsight(
          title: 'Stress Trigger Detected',
          description:
              '${mostStressedCat.emoji} ${mostStressedCat.label} tasks correlate with stress. Consider batching or delegating.',
          icon: '⚠️',
        ));
      }
    }

    // Productivity streak
    final deepWorkDays = _consecutiveDeepWorkDays(activities);
    if (deepWorkDays >= 3) {
      insights.add(EnergyInsight(
        title: 'Focus Streak!',
        description: 'You\'ve maintained deep work for $deepWorkDays consecutive days. 🔥',
        icon: '🎯',
      ));
    }

    return insights;
  }

  // ─── Private Helpers ────────────────────────────────────────────────────────

  Future<String?> _callAI(String prompt, {int maxTokens = 300}) async {
    if (_apiKey == null || _apiKey!.isEmpty) return null;

    try {
      if (_provider == 'anthropic') {
        final response = await http.post(
          Uri.parse(kAnthropicBaseUrl),
          headers: {
            'x-api-key': _apiKey!,
            'anthropic-version': '2023-06-01',
            'content-type': 'application/json',
          },
          body: jsonEncode({
            'model': 'claude-haiku-4-5-20251001',
            'max_tokens': maxTokens,
            'messages': [
              {'role': 'user', 'content': prompt}
            ],
          }),
        );
        if (response.statusCode == 200) {
          final json = jsonDecode(response.body);
          return json['content'][0]['text'];
        }
      } else if (_provider == 'openai') {
        final response = await http.post(
          Uri.parse(kOpenAIBaseUrl),
          headers: {
            'Authorization': 'Bearer $_apiKey',
            'Content-Type': 'application/json',
          },
          body: jsonEncode({
            'model': 'gpt-4o-mini',
            'max_tokens': maxTokens,
            'messages': [
              {'role': 'user', 'content': prompt}
            ],
          }),
        );
        if (response.statusCode == 200) {
          final json = jsonDecode(response.body);
          return json['choices'][0]['message']['content'];
        }
      }
    } catch (_) {}
    return null;
  }

  ActivityCategory? _mostFrequentCategory(List<ActivityEntry> activities) {
    if (activities.isEmpty) return null;
    final freq = <ActivityCategory, int>{};
    for (final a in activities) {
      freq[a.category] = (freq[a.category] ?? 0) + 1;
    }
    return freq.entries.reduce((a, b) => a.value > b.value ? a : b).key;
  }

  int _consecutiveDeepWorkDays(List<ActivityEntry> activities) {
    final now = DateTime.now();
    int streak = 0;
    for (int i = 0; i < 14; i++) {
      final day = now.subtract(Duration(days: i));
      final dayStart = DateTime(day.year, day.month, day.day);
      final dayEnd = dayStart.add(const Duration(days: 1));
      final hasDeepWork = activities.any((a) =>
          a.startTime.isAfter(dayStart) &&
          a.startTime.isBefore(dayEnd) &&
          a.category == ActivityCategory.deepWork);
      if (hasDeepWork) {
        streak++;
      } else if (i > 0) {
        break;
      }
    }
    return streak;
  }

  String _formatHour(int hour) {
    final h = hour % 12 == 0 ? 12 : hour % 12;
    final ampm = hour < 12 ? 'AM' : 'PM';
    return '$h:00 $ampm';
  }

  String _formatDuration(int minutes) {
    final hours = minutes ~/ 60;
    final mins = minutes % 60;
    if (hours == 0) return '${mins}m';
    if (mins == 0) return '${hours}h';
    return '${hours}h ${mins}m';
  }
}

// ─── Data Classes ───────────────────────────────────────────────────────────

class WeeklyInsight {
  final String summary;
  final String topInsight;
  final List<String> behavioralPatterns;
  final List<String> recommendations;
  final double focusScore; // 0-1
  final double goalAlignmentPercent; // 0-1

  const WeeklyInsight({
    required this.summary,
    required this.topInsight,
    required this.behavioralPatterns,
    required this.recommendations,
    required this.focusScore,
    required this.goalAlignmentPercent,
  });
}

class EnergyInsight {
  final String title;
  final String description;
  final String icon;

  const EnergyInsight({
    required this.title,
    required this.description,
    required this.icon,
  });
}
