// lib/data/local/hive_service.dart
import 'package:hive_flutter/hive_flutter.dart';
import '../models/activity_entry.dart';
import '../../core/constants/app_constants.dart';

class HiveService {
  static late Box<ActivityEntry> _activityBox;
  static late Box<Goal> _goalBox;
  static late Box<dynamic> _settingsBox;

  static Future<void> initialize() async {
    await Hive.initFlutter();

    // Register adapters
    if (!Hive.isAdapterRegistered(0)) {
      Hive.registerAdapter(ActivityEntryAdapter());
    }
    if (!Hive.isAdapterRegistered(1)) {
      Hive.registerAdapter(GoalAdapter());
    }

    // Open boxes
    _activityBox = await Hive.openBox<ActivityEntry>(kHiveActivityBox);
    _goalBox = await Hive.openBox<Goal>(kHiveGoalBox);
    _settingsBox = await Hive.openBox<dynamic>(kHiveSettingsBox);
  }

  static Box<ActivityEntry> get activityBox => _activityBox;
  static Box<Goal> get goalBox => _goalBox;
  static Box<dynamic> get settingsBox => _settingsBox;

  // Activities
  static Future<void> saveActivity(ActivityEntry entry) async {
    await _activityBox.put(entry.id, entry);
  }

  static Future<void> deleteActivity(String id) async {
    await _activityBox.delete(id);
  }

  static List<ActivityEntry> getAllActivities() {
    return _activityBox.values.toList()
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
  }

  static List<ActivityEntry> getActivitiesForDateRange(DateTime start, DateTime end) {
    return _activityBox.values
        .where((a) => a.startTime.isAfter(start) && a.startTime.isBefore(end))
        .toList()
      ..sort((a, b) => b.startTime.compareTo(a.startTime));
  }

  static List<ActivityEntry> getTodayActivities() {
    final now = DateTime.now();
    final startOfDay = DateTime(now.year, now.month, now.day);
    final endOfDay = startOfDay.add(const Duration(days: 1));
    return getActivitiesForDateRange(startOfDay, endOfDay);
  }

  static List<ActivityEntry> getThisWeekActivities() {
    final now = DateTime.now();
    final startOfWeek = now.subtract(Duration(days: now.weekday - 1));
    final start = DateTime(startOfWeek.year, startOfWeek.month, startOfWeek.day);
    final end = start.add(const Duration(days: 7));
    return getActivitiesForDateRange(start, end);
  }

  // Goals
  static Future<void> saveGoal(Goal goal) async {
    await _goalBox.put(goal.id, goal);
  }

  static Future<void> deleteGoal(String id) async {
    await _goalBox.delete(id);
  }

  static List<Goal> getAllGoals() {
    return _goalBox.values.toList();
  }

  static List<Goal> getActiveGoals() {
    return _goalBox.values.where((g) => g.isActive).toList();
  }

  // Settings
  static Future<void> setSetting(String key, dynamic value) async {
    await _settingsBox.put(key, value);
  }

  static dynamic getSetting(String key, {dynamic defaultValue}) {
    return _settingsBox.get(key, defaultValue: defaultValue);
  }

  static bool get isDarkMode => getSetting('darkMode', defaultValue: true);
  static bool get hasCompletedOnboarding =>
      getSetting('onboardingComplete', defaultValue: false);
  static String? get aiApiKey => getSetting('aiApiKey');
  static String get aiProvider => getSetting('aiProvider', defaultValue: 'anthropic');

  // Analytics helpers
  static Map<ActivityCategory, int> getCategoryMinutesThisWeek() {
    final activities = getThisWeekActivities();
    final Map<ActivityCategory, int> result = {};
    for (final activity in activities) {
      result[activity.category] =
          (result[activity.category] ?? 0) + activity.durationMinutes;
    }
    return result;
  }

  static Map<int, double> getAverageEnergyByHour() {
    final activities = getAllActivities();
    final Map<int, List<int>> hourEnergy = {};
    for (final activity in activities) {
      final hour = activity.hour;
      hourEnergy[hour] = [...(hourEnergy[hour] ?? []), activity.energyLevel.value];
    }
    return hourEnergy.map((hour, levels) =>
        MapEntry(hour, levels.reduce((a, b) => a + b) / levels.length));
  }

  static double getBurnoutRiskScore() {
    final weekActivities = getThisWeekActivities();
    if (weekActivities.isEmpty) return 0.0;

    // Factors:
    // 1. High intensity days (>8 hours deep work)
    // 2. Consecutive work days without recovery
    // 3. Low energy activities ratio
    // 4. Missing health/personal activities

    double score = 0.0;

    // Total hours this week
    final totalMinutes = weekActivities.fold(0, (sum, a) => sum + a.durationMinutes);
    final totalHours = totalMinutes / 60;
    if (totalHours > 50) score += 0.3;
    else if (totalHours > 40) score += 0.15;

    // Deep work ratio
    final deepWorkMinutes = weekActivities
        .where((a) => a.category == ActivityCategory.deepWork)
        .fold(0, (sum, a) => sum + a.durationMinutes);
    final deepWorkRatio = deepWorkMinutes / totalMinutes;
    if (deepWorkRatio > 0.7) score += 0.2;

    // Low energy ratio
    final lowEnergyActivities = weekActivities.where((a) => a.energyLevel == EnergyLevel.low);
    final lowEnergyRatio = lowEnergyActivities.length / weekActivities.length;
    if (lowEnergyRatio > 0.5) score += 0.25;

    // Missing recovery (health/personal)
    final hasRecovery = weekActivities.any((a) =>
        a.category == ActivityCategory.health || a.category == ActivityCategory.personal);
    if (!hasRecovery) score += 0.25;

    // Stressed mood ratio
    final stressedCount = weekActivities.where((a) => a.moodTagName == MoodTag.stressed.name).length;
    final stressedRatio = stressedCount / weekActivities.length;
    score += stressedRatio * 0.2;

    return score.clamp(0.0, 1.0);
  }

  static BurnoutRisk getBurnoutRisk() {
    final score = getBurnoutRiskScore();
    if (score < 0.33) return BurnoutRisk.low;
    if (score < 0.66) return BurnoutRisk.moderate;
    return BurnoutRisk.high;
  }
}
