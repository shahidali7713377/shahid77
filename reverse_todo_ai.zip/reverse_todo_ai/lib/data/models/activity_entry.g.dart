// lib/data/models/activity_entry.g.dart
// This file is auto-generated. In production, run: flutter pub run build_runner build
// For this implementation, adapters are manually defined in activity_entry.dart
