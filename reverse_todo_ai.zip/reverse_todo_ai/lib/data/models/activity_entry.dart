// lib/data/models/activity_entry.dart
import 'package:hive/hive.dart';
import '../../core/constants/app_constants.dart';

part 'activity_entry.g.dart';

@HiveType(typeId: 0)
class ActivityEntry extends HiveObject {
  @HiveField(0)
  late String id;

  @HiveField(1)
  late String description;

  @HiveField(2)
  late DateTime startTime;

  @HiveField(3)
  late int durationMinutes;

  @HiveField(4)
  late String categoryName; // ActivityCategory.name

  @HiveField(5)
  late String energyLevelName; // EnergyLevel.name

  @HiveField(6)
  String? moodTagName; // MoodTag.name

  @HiveField(7)
  String? goalId;

  @HiveField(8)
  late DateTime createdAt;

  @HiveField(9)
  String? aiInsight;

  @HiveField(10)
  bool isManualCategory = false;

  ActivityCategory get category =>
      ActivityCategory.values.firstWhere((e) => e.name == categoryName,
          orElse: () => ActivityCategory.shallowWork);

  EnergyLevel get energyLevel =>
      EnergyLevel.values.firstWhere((e) => e.name == energyLevelName,
          orElse: () => EnergyLevel.medium);

  MoodTag? get moodTag => moodTagName != null
      ? MoodTag.values.firstWhere((e) => e.name == moodTagName, orElse: () => MoodTag.calm)
      : null;

  DateTime get endTime => startTime.add(Duration(minutes: durationMinutes));

  int get hour => startTime.hour;

  bool get isDeepWork => category == ActivityCategory.deepWork;
  bool get isHighEnergy => energyLevel == EnergyLevel.high;

  ActivityEntry({
    required this.id,
    required this.description,
    required this.startTime,
    required this.durationMinutes,
    required this.categoryName,
    required this.energyLevelName,
    this.moodTagName,
    this.goalId,
    required this.createdAt,
    this.aiInsight,
    this.isManualCategory = false,
  });

  ActivityEntry copyWith({
    String? id,
    String? description,
    DateTime? startTime,
    int? durationMinutes,
    String? categoryName,
    String? energyLevelName,
    String? moodTagName,
    String? goalId,
    DateTime? createdAt,
    String? aiInsight,
    bool? isManualCategory,
  }) {
    return ActivityEntry(
      id: id ?? this.id,
      description: description ?? this.description,
      startTime: startTime ?? this.startTime,
      durationMinutes: durationMinutes ?? this.durationMinutes,
      categoryName: categoryName ?? this.categoryName,
      energyLevelName: energyLevelName ?? this.energyLevelName,
      moodTagName: moodTagName ?? this.moodTagName,
      goalId: goalId ?? this.goalId,
      createdAt: createdAt ?? this.createdAt,
      aiInsight: aiInsight ?? this.aiInsight,
      isManualCategory: isManualCategory ?? this.isManualCategory,
    );
  }

  Map<String, dynamic> toMap() => {
        'id': id,
        'description': description,
        'startTime': startTime.toIso8601String(),
        'durationMinutes': durationMinutes,
        'categoryName': categoryName,
        'energyLevelName': energyLevelName,
        'moodTagName': moodTagName,
        'goalId': goalId,
        'createdAt': createdAt.toIso8601String(),
        'aiInsight': aiInsight,
        'isManualCategory': isManualCategory,
      };
}

@HiveType(typeId: 1)
class Goal extends HiveObject {
  @HiveField(0)
  late String id;

  @HiveField(1)
  late String title;

  @HiveField(2)
  late String description;

  @HiveField(3)
  late List<String> targetCategories; // ActivityCategory names

  @HiveField(4)
  late int weeklyTargetMinutes;

  @HiveField(5)
  late DateTime createdAt;

  @HiveField(6)
  late bool isActive;

  @HiveField(7)
  String? color;

  List<ActivityCategory> get categories => targetCategories
      .map((n) => ActivityCategory.values.firstWhere((e) => e.name == n,
          orElse: () => ActivityCategory.deepWork))
      .toList();

  Goal({
    required this.id,
    required this.title,
    required this.description,
    required this.targetCategories,
    required this.weeklyTargetMinutes,
    required this.createdAt,
    required this.isActive,
    this.color,
  });
}

// Manual Hive Adapters (since we can't run build_runner)
class ActivityEntryAdapter extends TypeAdapter<ActivityEntry> {
  @override
  final int typeId = 0;

  @override
  ActivityEntry read(BinaryReader reader) {
    return ActivityEntry(
      id: reader.read(),
      description: reader.read(),
      startTime: DateTime.parse(reader.read()),
      durationMinutes: reader.read(),
      categoryName: reader.read(),
      energyLevelName: reader.read(),
      moodTagName: reader.read(),
      goalId: reader.read(),
      createdAt: DateTime.parse(reader.read()),
      aiInsight: reader.read(),
      isManualCategory: reader.read(),
    );
  }

  @override
  void write(BinaryWriter writer, ActivityEntry obj) {
    writer.write(obj.id);
    writer.write(obj.description);
    writer.write(obj.startTime.toIso8601String());
    writer.write(obj.durationMinutes);
    writer.write(obj.categoryName);
    writer.write(obj.energyLevelName);
    writer.write(obj.moodTagName);
    writer.write(obj.goalId);
    writer.write(obj.createdAt.toIso8601String());
    writer.write(obj.aiInsight);
    writer.write(obj.isManualCategory);
  }
}

class GoalAdapter extends TypeAdapter<Goal> {
  @override
  final int typeId = 1;

  @override
  Goal read(BinaryReader reader) {
    return Goal(
      id: reader.read(),
      title: reader.read(),
      description: reader.read(),
      targetCategories: List<String>.from(reader.read()),
      weeklyTargetMinutes: reader.read(),
      createdAt: DateTime.parse(reader.read()),
      isActive: reader.read(),
      color: reader.read(),
    );
  }

  @override
  void write(BinaryWriter writer, Goal obj) {
    writer.write(obj.id);
    writer.write(obj.title);
    writer.write(obj.description);
    writer.write(obj.targetCategories);
    writer.write(obj.weeklyTargetMinutes);
    writer.write(obj.createdAt.toIso8601String());
    writer.write(obj.isActive);
    writer.write(obj.color);
  }
}
