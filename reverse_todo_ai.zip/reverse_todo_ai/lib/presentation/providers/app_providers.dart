// lib/presentation/providers/app_providers.dart
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uuid/uuid.dart';
import '../../core/constants/app_constants.dart';
import '../../data/local/hive_service.dart';
import '../../data/models/activity_entry.dart';
import '../../services/ai_service.dart';

const _uuid = Uuid();

// ─── Theme Provider ──────────────────────────────────────────────────────────

class ThemeNotifier extends StateNotifier<bool> {
  ThemeNotifier() : super(HiveService.isDarkMode);

  void toggle() {
    state = !state;
    HiveService.setSetting('darkMode', state);
  }
}

final themeProvider = StateNotifierProvider<ThemeNotifier, bool>((ref) {
  return ThemeNotifier();
});

// ─── Activities Provider ─────────────────────────────────────────────────────

class ActivitiesNotifier extends StateNotifier<List<ActivityEntry>> {
  ActivitiesNotifier() : super(HiveService.getAllActivities());

  Future<void> addActivity({
    required String description,
    required DateTime startTime,
    required int durationMinutes,
    required EnergyLevel energyLevel,
    MoodTag? moodTag,
    String? goalId,
    ActivityCategory? manualCategory,
  }) async {
    final aiService = AIService();
    final category = manualCategory ??
        await aiService.categorizeActivity(description);

    final entry = ActivityEntry(
      id: _uuid.v4(),
      description: description,
      startTime: startTime,
      durationMinutes: durationMinutes,
      categoryName: category.name,
      energyLevelName: energyLevel.name,
      moodTagName: moodTag?.name,
      goalId: goalId,
      createdAt: DateTime.now(),
      isManualCategory: manualCategory != null,
    );

    await HiveService.saveActivity(entry);
    state = HiveService.getAllActivities();
  }

  Future<void> deleteActivity(String id) async {
    await HiveService.deleteActivity(id);
    state = HiveService.getAllActivities();
  }

  Future<void> updateActivity(ActivityEntry entry) async {
    await HiveService.saveActivity(entry);
    state = HiveService.getAllActivities();
  }

  void refresh() {
    state = HiveService.getAllActivities();
  }

  List<ActivityEntry> get todayActivities => HiveService.getTodayActivities();
  List<ActivityEntry> get weekActivities => HiveService.getThisWeekActivities();
}

final activitiesProvider =
    StateNotifierProvider<ActivitiesNotifier, List<ActivityEntry>>((ref) {
  return ActivitiesNotifier();
});

final todayActivitiesProvider = Provider<List<ActivityEntry>>((ref) {
  ref.watch(activitiesProvider);
  return HiveService.getTodayActivities();
});

final weekActivitiesProvider = Provider<List<ActivityEntry>>((ref) {
  ref.watch(activitiesProvider);
  return HiveService.getThisWeekActivities();
});

// ─── Goals Provider ──────────────────────────────────────────────────────────

class GoalsNotifier extends StateNotifier<List<Goal>> {
  GoalsNotifier() : super(HiveService.getAllGoals());

  Future<void> addGoal({
    required String title,
    required String description,
    required List<ActivityCategory> targetCategories,
    required int weeklyTargetMinutes,
    String? color,
  }) async {
    final goal = Goal(
      id: _uuid.v4(),
      title: title,
      description: description,
      targetCategories: targetCategories.map((c) => c.name).toList(),
      weeklyTargetMinutes: weeklyTargetMinutes,
      createdAt: DateTime.now(),
      isActive: true,
      color: color,
    );
    await HiveService.saveGoal(goal);
    state = HiveService.getAllGoals();
  }

  Future<void> deleteGoal(String id) async {
    await HiveService.deleteGoal(id);
    state = HiveService.getAllGoals();
  }

  Future<void> toggleGoal(Goal goal) async {
    final updated = Goal(
      id: goal.id,
      title: goal.title,
      description: goal.description,
      targetCategories: goal.targetCategories,
      weeklyTargetMinutes: goal.weeklyTargetMinutes,
      createdAt: goal.createdAt,
      isActive: !goal.isActive,
      color: goal.color,
    );
    await HiveService.saveGoal(updated);
    state = HiveService.getAllGoals();
  }
}

final goalsProvider = StateNotifierProvider<GoalsNotifier, List<Goal>>((ref) {
  return GoalsNotifier();
});

final activeGoalsProvider = Provider<List<Goal>>((ref) {
  final goals = ref.watch(goalsProvider);
  return goals.where((g) => g.isActive).toList();
});

// ─── Analytics Providers ─────────────────────────────────────────────────────

final categoryDistributionProvider =
    Provider<Map<ActivityCategory, int>>((ref) {
  ref.watch(activitiesProvider);
  return HiveService.getCategoryMinutesThisWeek();
});

final burnoutRiskProvider = Provider<BurnoutRisk>((ref) {
  ref.watch(activitiesProvider);
  return HiveService.getBurnoutRisk();
});

final burnoutScoreProvider = Provider<double>((ref) {
  ref.watch(activitiesProvider);
  return HiveService.getBurnoutRiskScore();
});

final hourlyEnergyProvider = Provider<Map<int, double>>((ref) {
  ref.watch(activitiesProvider);
  return HiveService.getAverageEnergyByHour();
});

// ─── AI Insight Providers ────────────────────────────────────────────────────

final weeklyInsightProvider = FutureProvider<WeeklyInsight>((ref) async {
  final weekActivities = ref.watch(weekActivitiesProvider);
  return AIService().generateWeeklyInsight(weekActivities);
});

final energyInsightsProvider = Provider<List<EnergyInsight>>((ref) {
  final activities = ref.watch(activitiesProvider);
  return AIService().generateEnergyInsights(activities);
});

// ─── Settings Provider ───────────────────────────────────────────────────────

class SettingsNotifier extends StateNotifier<Map<String, dynamic>> {
  SettingsNotifier()
      : super({
          'aiApiKey': HiveService.aiApiKey ?? '',
          'aiProvider': HiveService.aiProvider,
          'enableNotifications':
              HiveService.getSetting('enableNotifications', defaultValue: true),
          'onboardingComplete': HiveService.hasCompletedOnboarding,
        });

  Future<void> updateApiKey(String key) async {
    await HiveService.setSetting('aiApiKey', key);
    state = {...state, 'aiApiKey': key};
  }

  Future<void> updateProvider(String provider) async {
    await HiveService.setSetting('aiProvider', provider);
    state = {...state, 'aiProvider': provider};
  }

  Future<void> completeOnboarding() async {
    await HiveService.setSetting('onboardingComplete', true);
    state = {...state, 'onboardingComplete': true};
  }
}

final settingsProvider =
    StateNotifierProvider<SettingsNotifier, Map<String, dynamic>>((ref) {
  return SettingsNotifier();
});

// ─── Bottom Nav Provider ─────────────────────────────────────────────────────

final bottomNavIndexProvider = StateProvider<int>((ref) => 0);
