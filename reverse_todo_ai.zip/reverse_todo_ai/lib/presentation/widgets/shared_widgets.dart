// lib/presentation/widgets/shared_widgets.dart
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';

// ─── Glass Card ─────────────────────────────────────────────────────────────

class GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry? padding;
  final Color? color;
  final double? borderRadius;
  final VoidCallback? onTap;

  const GlassCard({
    super.key,
    required this.child,
    this.padding,
    this.color,
    this.borderRadius,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: padding ?? const EdgeInsets.all(AppSpacing.md),
        decoration: BoxDecoration(
          color: color ?? (isDark ? AppColors.darkCard : AppColors.lightSurface),
          borderRadius: BorderRadius.circular(borderRadius ?? AppRadius.lg),
          border: Border.all(
            color: isDark ? AppColors.darkBorder : AppColors.lightBorder,
            width: 1,
          ),
        ),
        child: child,
      ),
    );
  }
}

// ─── Category Chip ───────────────────────────────────────────────────────────

class CategoryChip extends StatelessWidget {
  final ActivityCategory category;
  final bool isSelected;
  final VoidCallback? onTap;
  final bool compact;

  const CategoryChip({
    super.key,
    required this.category,
    this.isSelected = false,
    this.onTap,
    this.compact = false,
  });

  @override
  Widget build(BuildContext context) {
    final color = _hexToColor(category.hexColor);
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: EdgeInsets.symmetric(
          horizontal: compact ? 10 : 14,
          vertical: compact ? 6 : 8,
        ),
        decoration: BoxDecoration(
          color: isSelected ? color.withOpacity(0.2) : color.withOpacity(0.08),
          borderRadius: BorderRadius.circular(AppRadius.full),
          border: Border.all(
            color: isSelected ? color : color.withOpacity(0.3),
            width: isSelected ? 1.5 : 1,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              category.emoji,
              style: TextStyle(fontSize: compact ? 12 : 14),
            ),
            const SizedBox(width: 4),
            Text(
              category.label,
              style: TextStyle(
                color: isSelected ? color : color.withOpacity(0.8),
                fontSize: compact ? 11 : 13,
                fontWeight: isSelected ? FontWeight.w600 : FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Color _hexToColor(String hex) {
    return Color(int.parse(hex.replaceFirst('#', '0xFF')));
  }
}

// ─── Energy Selector ─────────────────────────────────────────────────────────

class EnergySelector extends StatelessWidget {
  final EnergyLevel selected;
  final ValueChanged<EnergyLevel> onChanged;

  const EnergySelector({
    super.key,
    required this.selected,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: EnergyLevel.values.map((level) {
        final isSelected = level == selected;
        return Expanded(
          child: GestureDetector(
            onTap: () => onChanged(level),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              margin: const EdgeInsets.symmetric(horizontal: 4),
              padding: const EdgeInsets.symmetric(vertical: 10),
              decoration: BoxDecoration(
                color: isSelected
                    ? _energyColor(level).withOpacity(0.2)
                    : Colors.transparent,
                borderRadius: BorderRadius.circular(AppRadius.md),
                border: Border.all(
                  color: isSelected
                      ? _energyColor(level)
                      : AppColors.darkBorder,
                  width: isSelected ? 1.5 : 1,
                ),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(level.emoji, style: const TextStyle(fontSize: 20)),
                  const SizedBox(height: 4),
                  Text(
                    level.label,
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
                      color: isSelected ? _energyColor(level) : AppColors.textSecondary,
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      }).toList(),
    );
  }

  Color _energyColor(EnergyLevel level) {
    switch (level) {
      case EnergyLevel.low:
        return AppColors.accent;
      case EnergyLevel.medium:
        return AppColors.warning;
      case EnergyLevel.high:
        return AppColors.secondary;
    }
  }
}

// ─── Burnout Meter ───────────────────────────────────────────────────────────

class BurnoutMeter extends StatelessWidget {
  final double score; // 0-1
  final BurnoutRisk risk;

  const BurnoutMeter({super.key, required this.score, required this.risk});

  @override
  Widget build(BuildContext context) {
    final color = _riskColor(risk);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(
              'Burnout Risk',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            const Spacer(),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: color.withOpacity(0.15),
                borderRadius: BorderRadius.circular(AppRadius.full),
                border: Border.all(color: color.withOpacity(0.4)),
              ),
              child: Text(
                risk.label,
                style: TextStyle(
                  color: color,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        ClipRRect(
          borderRadius: BorderRadius.circular(AppRadius.full),
          child: LinearProgressIndicator(
            value: score,
            backgroundColor: color.withOpacity(0.1),
            valueColor: AlwaysStoppedAnimation<Color>(color),
            minHeight: 8,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          _riskMessage(risk),
          style: Theme.of(context).textTheme.bodySmall?.copyWith(color: color),
        ),
      ],
    );
  }

  Color _riskColor(BurnoutRisk risk) {
    switch (risk) {
      case BurnoutRisk.low:
        return AppColors.secondary;
      case BurnoutRisk.moderate:
        return AppColors.warning;
      case BurnoutRisk.high:
        return AppColors.accent;
    }
  }

  String _riskMessage(BurnoutRisk risk) {
    switch (risk) {
      case BurnoutRisk.low:
        return '✨ You\'re in a good rhythm. Keep balancing deep work with recovery.';
      case BurnoutRisk.moderate:
        return '⚠️ Watch your energy. Consider adding recovery activities.';
      case BurnoutRisk.high:
        return '🚨 High burnout signal. Rest and recovery are essential now.';
    }
  }
}

// ─── Section Header ──────────────────────────────────────────────────────────

class SectionHeader extends StatelessWidget {
  final String title;
  final String? subtitle;
  final Widget? trailing;

  const SectionHeader({
    super.key,
    required this.title,
    this.subtitle,
    this.trailing,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: Theme.of(context).textTheme.headlineSmall),
              if (subtitle != null) ...[
                const SizedBox(height: 2),
                Text(subtitle!, style: Theme.of(context).textTheme.bodySmall),
              ],
            ],
          ),
        ),
        if (trailing != null) trailing!,
      ],
    );
  }
}

// ─── Empty State ─────────────────────────────────────────────────────────────

class EmptyState extends StatelessWidget {
  final String emoji;
  final String title;
  final String message;
  final Widget? action;

  const EmptyState({
    super.key,
    required this.emoji,
    required this.title,
    required this.message,
    this.action,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.xl),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(emoji, style: const TextStyle(fontSize: 48))
                .animate()
                .scale(duration: 300.ms, curve: Curves.elasticOut),
            const SizedBox(height: AppSpacing.md),
            Text(
              title,
              style: Theme.of(context).textTheme.headlineSmall,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: AppSpacing.sm),
            Text(
              message,
              style: Theme.of(context).textTheme.bodyMedium,
              textAlign: TextAlign.center,
            ),
            if (action != null) ...[
              const SizedBox(height: AppSpacing.lg),
              action!,
            ],
          ],
        ),
      ),
    );
  }
}

// ─── Stat Card ───────────────────────────────────────────────────────────────

class StatCard extends StatelessWidget {
  final String label;
  final String value;
  final String? subtitle;
  final Color? accentColor;
  final String? emoji;

  const StatCard({
    super.key,
    required this.label,
    required this.value,
    this.subtitle,
    this.accentColor,
    this.emoji,
  });

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (emoji != null)
            Text(emoji!, style: const TextStyle(fontSize: 20)),
          if (emoji != null) const SizedBox(height: 8),
          Text(
            value,
            style: Theme.of(context).textTheme.displaySmall?.copyWith(
                  color: accentColor ?? AppColors.primary,
                  fontWeight: FontWeight.w700,
                ),
          ),
          const SizedBox(height: 4),
          Text(label, style: Theme.of(context).textTheme.titleSmall),
          if (subtitle != null)
            Text(
              subtitle!,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: accentColor?.withOpacity(0.7),
                  ),
            ),
        ],
      ),
    );
  }
}

// ─── Loading Shimmer ─────────────────────────────────────────────────────────

class LoadingCard extends StatelessWidget {
  final double height;

  const LoadingCard({super.key, this.height = 100});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      height: height,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(AppRadius.lg),
        gradient: LinearGradient(
          colors: isDark
              ? [AppColors.darkCard, AppColors.darkBorder, AppColors.darkCard]
              : [AppColors.lightCard, AppColors.lightBorder, AppColors.lightCard],
          stops: const [0.0, 0.5, 1.0],
        ),
      ),
    ).animate(onPlay: (c) => c.repeat()).shimmer(
          duration: 1500.ms,
          color: isDark
              ? AppColors.darkBorder.withOpacity(0.5)
              : AppColors.lightBorder,
        );
  }
}

// ─── Activity List Tile ──────────────────────────────────────────────────────

class ActivityTile extends StatelessWidget {
  final dynamic activity; // ActivityEntry
  final VoidCallback? onDelete;
  final int index;

  const ActivityTile({
    super.key,
    required this.activity,
    this.onDelete,
    this.index = 0,
  });

  @override
  Widget build(BuildContext context) {
    final categoryColor = Color(
        int.parse(activity.category.hexColor.replaceFirst('#', '0xFF')));
    final timeStr = _formatTime(activity.startTime);
    final durationStr = _formatDuration(activity.durationMinutes);

    return GlassCard(
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: categoryColor.withOpacity(0.15),
              borderRadius: BorderRadius.circular(AppRadius.md),
            ),
            child: Center(
              child: Text(
                activity.category.emoji,
                style: const TextStyle(fontSize: 20),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  activity.description,
                  style: Theme.of(context).textTheme.titleMedium,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Text(
                      '${activity.category.label} · $durationStr · $timeStr',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                    if (activity.moodTag != null) ...[
                      const SizedBox(width: 6),
                      Text(activity.moodTag!.emoji),
                    ],
                  ],
                ),
              ],
            ),
          ),
          Column(
            children: [
              Text(
                activity.energyLevel.emoji,
                style: const TextStyle(fontSize: 18),
              ),
              if (onDelete != null)
                GestureDetector(
                  onTap: onDelete,
                  child: const Padding(
                    padding: EdgeInsets.only(top: 4),
                    child: Icon(Icons.close, size: 16, color: AppColors.textMuted),
                  ),
                ),
            ],
          ),
        ],
      ),
    )
        .animate(delay: (index * 50).ms)
        .fadeIn(duration: 300.ms)
        .slideY(begin: 0.2, end: 0, duration: 300.ms);
  }

  String _formatTime(DateTime time) {
    final h = time.hour % 12 == 0 ? 12 : time.hour % 12;
    final m = time.minute.toString().padLeft(2, '0');
    final ampm = time.hour < 12 ? 'AM' : 'PM';
    return '$h:$m $ampm';
  }

  String _formatDuration(int minutes) {
    final h = minutes ~/ 60;
    final m = minutes % 60;
    if (h == 0) return '${m}m';
    if (m == 0) return '${h}h';
    return '${h}h ${m}m';
  }
}
