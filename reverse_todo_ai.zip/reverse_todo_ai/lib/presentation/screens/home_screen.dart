// lib/presentation/screens/home_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:intl/intl.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';
import '../providers/app_providers.dart';
import '../widgets/shared_widgets.dart';
import 'log_activity_screen.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final todayActivities = ref.watch(todayActivitiesProvider);
    final burnoutRisk = ref.watch(burnoutRiskProvider);
    final burnoutScore = ref.watch(burnoutScoreProvider);
    final isDark = Theme.of(context).brightness == Brightness.dark;

    final totalMinutes = todayActivities.fold(0, (sum, a) => sum + a.durationMinutes);
    final now = DateTime.now();
    final greeting = _greeting(now.hour);

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          // ─── App Bar ─────────────────────────────────────────────────────
          SliverAppBar(
            expandedHeight: 180,
            floating: false,
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      AppColors.primary.withOpacity(0.15),
                      AppColors.secondary.withOpacity(0.05),
                    ],
                  ),
                ),
                child: SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.all(AppSpacing.md),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Text(
                          greeting,
                          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                color: AppColors.primary,
                                fontWeight: FontWeight.w500,
                              ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'What did you\nactually do today?',
                          style: Theme.of(context)
                              .textTheme
                              .displaySmall
                              ?.copyWith(height: 1.2),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          DateFormat('EEEE, MMMM d').format(now),
                          style: Theme.of(context).textTheme.bodySmall,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),

          SliverPadding(
            padding: const EdgeInsets.all(AppSpacing.md),
            sliver: SliverList(
              delegate: SliverChildListDelegate([
                // ─── Quick Stats ─────────────────────────────────────────
                Row(
                  children: [
                    Expanded(
                      child: StatCard(
                        label: 'Logged today',
                        value: _formatDuration(totalMinutes),
                        emoji: '⏱️',
                        accentColor: AppColors.primary,
                      ).animate().fadeIn(delay: 100.ms),
                    ),
                    const SizedBox(width: AppSpacing.sm),
                    Expanded(
                      child: StatCard(
                        label: 'Activities',
                        value: '${todayActivities.length}',
                        emoji: '✅',
                        accentColor: AppColors.secondary,
                      ).animate().fadeIn(delay: 150.ms),
                    ),
                  ],
                ),
                const SizedBox(height: AppSpacing.md),

                // ─── Burnout Card ─────────────────────────────────────────
                GlassCard(
                  child: BurnoutMeter(
                    score: burnoutScore,
                    risk: burnoutRisk,
                  ),
                ).animate().fadeIn(delay: 200.ms),

                const SizedBox(height: AppSpacing.lg),

                // ─── Today's Log ──────────────────────────────────────────
                SectionHeader(
                  title: "Today's Reality Log",
                  subtitle: '${todayActivities.length} activities logged',
                  trailing: TextButton.icon(
                    onPressed: () => _openLogSheet(context, ref),
                    icon: const Icon(Icons.add, size: 16),
                    label: const Text('Log'),
                  ),
                ).animate().fadeIn(delay: 250.ms),
                const SizedBox(height: AppSpacing.md),

                if (todayActivities.isEmpty)
                  EmptyState(
                    emoji: '📝',
                    title: 'Nothing logged yet',
                    message:
                        'Start tracking what you actually did today. No pressure, no planning.',
                    action: ElevatedButton.icon(
                      onPressed: () => _openLogSheet(context, ref),
                      icon: const Icon(Icons.add),
                      label: const Text('Log your first activity'),
                    ),
                  ).animate().fadeIn(delay: 300.ms)
                else
                  ...todayActivities.asMap().entries.map((entry) {
                    final index = entry.key;
                    final activity = entry.value;
                    return Padding(
                      padding: const EdgeInsets.only(bottom: AppSpacing.sm),
                      child: ActivityTile(
                        activity: activity,
                        index: index,
                        onDelete: () =>
                            ref.read(activitiesProvider.notifier).deleteActivity(activity.id),
                      ),
                    );
                  }),

                const SizedBox(height: 80), // Bottom padding for FAB
              ]),
            ),
          ),
        ],
      ),

      // ─── Floating Action Button ──────────────────────────────────────────
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openLogSheet(context, ref),
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add),
        label: const Text(
          'Log Activity',
          style: TextStyle(fontWeight: FontWeight.w600),
        ),
      ).animate().scale(delay: 400.ms, curve: Curves.elasticOut),
    );
  }

  String _greeting(int hour) {
    if (hour < 12) return '🌅 Good morning';
    if (hour < 17) return '☀️ Good afternoon';
    if (hour < 21) return '🌆 Good evening';
    return '🌙 Good night';
  }

  String _formatDuration(int minutes) {
    final h = minutes ~/ 60;
    final m = minutes % 60;
    if (h == 0) return '${m}m';
    if (m == 0) return '${h}h';
    return '${h}h ${m}m';
  }

  void _openLogSheet(BuildContext context, WidgetRef ref) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => const LogActivitySheet(),
    );
  }
}
