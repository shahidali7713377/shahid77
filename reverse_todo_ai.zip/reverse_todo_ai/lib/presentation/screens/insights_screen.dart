// lib/presentation/screens/insights_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';
import '../providers/app_providers.dart';
import '../widgets/shared_widgets.dart';

class InsightsScreen extends ConsumerWidget {
  const InsightsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final weeklyInsight = ref.watch(weeklyInsightProvider);
    final energyInsights = ref.watch(energyInsightsProvider);
    final weekActivities = ref.watch(weekActivitiesProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('AI Insights'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded),
            onPressed: () => ref.invalidate(weeklyInsightProvider),
          ),
        ],
      ),
      body: weekActivities.isEmpty
          ? const EmptyState(
              emoji: '🤖',
              title: 'Insights await your data',
              message:
                  'Log at least a few activities to unlock AI-powered behavioral insights.',
            )
          : SingleChildScrollView(
              padding: const EdgeInsets.all(AppSpacing.md),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // ─── Weekly AI Report ────────────────────────────────
                  const SectionHeader(
                    title: 'Weekly Reality Report',
                    subtitle: 'AI analysis of your actual behavior',
                  ),
                  const SizedBox(height: AppSpacing.md),

                  weeklyInsight.when(
                    loading: () => Column(
                      children: [
                        const LoadingCard(height: 120),
                        const SizedBox(height: 8),
                        const LoadingCard(height: 80),
                        const SizedBox(height: 8),
                        const LoadingCard(height: 100),
                      ],
                    ),
                    error: (e, _) => GlassCard(
                      child: Text('Could not load insights: $e'),
                    ),
                    data: (insight) => Column(
                      children: [
                        // Summary
                        GlassCard(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 10, vertical: 4),
                                    decoration: BoxDecoration(
                                      color: AppColors.primary.withOpacity(0.1),
                                      borderRadius:
                                          BorderRadius.circular(AppRadius.full),
                                    ),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        const Text('🤖',
                                            style: TextStyle(fontSize: 12)),
                                        const SizedBox(width: 4),
                                        Text(
                                          'AI Summary',
                                          style: TextStyle(
                                            color: AppColors.primary,
                                            fontSize: 11,
                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 12),
                              Text(
                                insight.summary,
                                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                      height: 1.6,
                                    ),
                              ),
                            ],
                          ),
                        ).animate().fadeIn(delay: 100.ms),

                        const SizedBox(height: AppSpacing.sm),

                        // Top Insight
                        GlassCard(
                          color: AppColors.primary.withOpacity(0.08),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('⚡', style: TextStyle(fontSize: 24)),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Top Insight',
                                      style: Theme.of(context)
                                          .textTheme
                                          .labelSmall
                                          ?.copyWith(color: AppColors.primary),
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      insight.topInsight,
                                      style: Theme.of(context)
                                          .textTheme
                                          .titleMedium
                                          ?.copyWith(
                                              color: AppColors.primary,
                                              height: 1.4),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ).animate().fadeIn(delay: 150.ms),

                        const SizedBox(height: AppSpacing.sm),

                        // Scores
                        Row(
                          children: [
                            Expanded(
                              child: GlassCard(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text('Focus Score',
                                        style:
                                            Theme.of(context).textTheme.bodySmall),
                                    const SizedBox(height: 6),
                                    _ScoreIndicator(
                                      score: insight.focusScore,
                                      color: AppColors.deepWork,
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      '${(insight.focusScore * 100).round()}%',
                                      style: Theme.of(context)
                                          .textTheme
                                          .headlineSmall
                                          ?.copyWith(color: AppColors.deepWork),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: GlassCard(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text('Goal Alignment',
                                        style:
                                            Theme.of(context).textTheme.bodySmall),
                                    const SizedBox(height: 6),
                                    _ScoreIndicator(
                                      score: insight.goalAlignmentPercent,
                                      color: AppColors.secondary,
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      '${(insight.goalAlignmentPercent * 100).round()}%',
                                      style: Theme.of(context)
                                          .textTheme
                                          .headlineSmall
                                          ?.copyWith(color: AppColors.secondary),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ).animate().fadeIn(delay: 200.ms),

                        const SizedBox(height: AppSpacing.sm),

                        // Behavioral Patterns
                        if (insight.behavioralPatterns.isNotEmpty)
                          GlassCard(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Behavioral Patterns Detected',
                                  style: Theme.of(context).textTheme.titleMedium,
                                ),
                                const SizedBox(height: 12),
                                ...insight.behavioralPatterns
                                    .asMap()
                                    .entries
                                    .map((e) {
                                  return Padding(
                                    padding: const EdgeInsets.only(bottom: 8),
                                    child: Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          width: 6,
                                          height: 6,
                                          margin: const EdgeInsets.only(
                                              top: 6, right: 10),
                                          decoration: BoxDecoration(
                                            color: AppColors.primary,
                                            shape: BoxShape.circle,
                                          ),
                                        ),
                                        Expanded(
                                          child: Text(
                                            e.value,
                                            style: Theme.of(context)
                                                .textTheme
                                                .bodyMedium,
                                          ),
                                        ),
                                      ],
                                    ),
                                  );
                                }),
                              ],
                            ),
                          ).animate().fadeIn(delay: 250.ms),

                        const SizedBox(height: AppSpacing.sm),

                        // Recommendations
                        if (insight.recommendations.isNotEmpty)
                          GlassCard(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  '💡 Recommendations',
                                  style: Theme.of(context).textTheme.titleMedium,
                                ),
                                const SizedBox(height: 12),
                                ...insight.recommendations.asMap().entries.map((e) {
                                  return Padding(
                                    padding: const EdgeInsets.only(bottom: 10),
                                    child: Container(
                                      padding: const EdgeInsets.all(12),
                                      decoration: BoxDecoration(
                                        color: AppColors.secondary.withOpacity(0.06),
                                        borderRadius:
                                            BorderRadius.circular(AppRadius.md),
                                        border: Border.all(
                                            color:
                                                AppColors.secondary.withOpacity(0.2)),
                                      ),
                                      child: Text(
                                        e.value,
                                        style: Theme.of(context)
                                            .textTheme
                                            .bodyMedium
                                            ?.copyWith(height: 1.5),
                                      ),
                                    ),
                                  );
                                }),
                              ],
                            ),
                          ).animate().fadeIn(delay: 300.ms),
                      ],
                    ),
                  ),

                  const SizedBox(height: AppSpacing.lg),

                  // ─── Energy Insights ─────────────────────────────────
                  const SectionHeader(
                    title: 'Energy Insights',
                    subtitle: 'Patterns from your behavioral data',
                  ),
                  const SizedBox(height: AppSpacing.md),

                  ...energyInsights.asMap().entries.map((entry) {
                    final i = entry.key;
                    final insight = entry.value;
                    return Padding(
                      padding: const EdgeInsets.only(bottom: AppSpacing.sm),
                      child: _EnergyInsightCard(insight: insight)
                          .animate(delay: (350 + i * 50).ms)
                          .fadeIn()
                          .slideX(begin: 0.1),
                    );
                  }),

                  const SizedBox(height: 80),
                ],
              ),
            ),
    );
  }
}

class _ScoreIndicator extends StatelessWidget {
  final double score;
  final Color color;

  const _ScoreIndicator({required this.score, required this.color});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(AppRadius.full),
      child: LinearProgressIndicator(
        value: score,
        backgroundColor: color.withOpacity(0.1),
        valueColor: AlwaysStoppedAnimation<Color>(color),
        minHeight: 6,
      ),
    );
  }
}

class _EnergyInsightCard extends StatelessWidget {
  final dynamic insight;

  const _EnergyInsightCard({required this.insight});

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: AppColors.primary.withOpacity(0.1),
              borderRadius: BorderRadius.circular(AppRadius.md),
            ),
            child: Center(
              child: Text(insight.icon, style: const TextStyle(fontSize: 22)),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  insight.title,
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                const SizedBox(height: 4),
                Text(
                  insight.description,
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        height: 1.5,
                      ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
