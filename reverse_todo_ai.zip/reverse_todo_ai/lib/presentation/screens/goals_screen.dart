// lib/presentation/screens/goals_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';
import '../providers/app_providers.dart';
import '../widgets/shared_widgets.dart';

class GoalsScreen extends ConsumerWidget {
  const GoalsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final goals = ref.watch(goalsProvider);
    final weekActivities = ref.watch(weekActivitiesProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Goals')),
      body: goals.isEmpty
          ? EmptyState(
              emoji: '🎯',
              title: 'Define your priorities',
              message:
                  'Set goals to track how your actual behavior aligns with what matters most to you.',
              action: ElevatedButton.icon(
                onPressed: () => _showAddGoalSheet(context, ref),
                icon: const Icon(Icons.add),
                label: const Text('Add First Goal'),
              ),
            )
          : SingleChildScrollView(
              padding: const EdgeInsets.all(AppSpacing.md),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Header note
                  GlassCard(
                    color: AppColors.primary.withOpacity(0.05),
                    child: Row(
                      children: [
                        const Text('💡', style: TextStyle(fontSize: 20)),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            'Goals are measured by what you actually do, not what you plan.',
                            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                  color: AppColors.primary,
                                ),
                          ),
                        ),
                      ],
                    ),
                  ).animate().fadeIn(),
                  const SizedBox(height: AppSpacing.lg),

                  ...goals.asMap().entries.map((entry) {
                    final i = entry.key;
                    final goal = entry.value;

                    // Calculate progress
                    final relevantActivities = weekActivities
                        .where((a) => goal.targetCategories.contains(a.categoryName));
                    final loggedMinutes = relevantActivities.fold(
                        0, (sum, a) => sum + a.durationMinutes);
                    final progress = goal.weeklyTargetMinutes > 0
                        ? (loggedMinutes / goal.weeklyTargetMinutes).clamp(0.0, 1.0)
                        : 0.0;

                    return Padding(
                      padding: const EdgeInsets.only(bottom: AppSpacing.sm),
                      child: _GoalCard(
                        goal: goal,
                        loggedMinutes: loggedMinutes,
                        progress: progress,
                        onToggle: () =>
                            ref.read(goalsProvider.notifier).toggleGoal(goal),
                        onDelete: () =>
                            ref.read(goalsProvider.notifier).deleteGoal(goal.id),
                      )
                          .animate(delay: (i * 80).ms)
                          .fadeIn()
                          .slideY(begin: 0.2),
                    );
                  }),
                  const SizedBox(height: 80),
                ],
              ),
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showAddGoalSheet(context, ref),
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
        child: const Icon(Icons.add),
      ).animate().scale(delay: 300.ms, curve: Curves.elasticOut),
    );
  }

  void _showAddGoalSheet(BuildContext context, WidgetRef ref) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _AddGoalSheet(),
    );
  }
}

class _GoalCard extends StatelessWidget {
  final dynamic goal;
  final int loggedMinutes;
  final double progress;
  final VoidCallback onToggle;
  final VoidCallback onDelete;

  const _GoalCard({
    required this.goal,
    required this.loggedMinutes,
    required this.progress,
    required this.onToggle,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    final color = goal.color != null
        ? Color(int.parse(goal.color!.replaceFirst('#', '0xFF')))
        : AppColors.primary;
    final isActive = goal.isActive;

    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  goal.title,
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        color: isActive ? null : AppColors.textMuted,
                      ),
                ),
              ),
              Switch(
                value: isActive,
                onChanged: (_) => onToggle(),
                activeColor: AppColors.primary,
              ),
              IconButton(
                onPressed: onDelete,
                icon: const Icon(Icons.delete_outline, size: 18),
                color: AppColors.textMuted,
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(),
              ),
            ],
          ),
          if (goal.description.isNotEmpty) ...[
            const SizedBox(height: 4),
            Text(
              goal.description,
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ],
          const SizedBox(height: 12),

          // Categories
          Wrap(
            spacing: 4,
            runSpacing: 4,
            children: goal.categories.map<Widget>((cat) {
              return CategoryChip(category: cat, compact: true);
            }).toList(),
          ),

          const SizedBox(height: 12),

          // Progress
          Row(
            children: [
              Text(
                '${_fmt(loggedMinutes)} / ${_fmt(goal.weeklyTargetMinutes)}',
                style: Theme.of(context).textTheme.bodySmall,
              ),
              const Spacer(),
              Text(
                '${(progress * 100).round()}%',
                style: TextStyle(
                  color: _progressColor(progress),
                  fontWeight: FontWeight.w700,
                  fontSize: 13,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          ClipRRect(
            borderRadius: BorderRadius.circular(AppRadius.full),
            child: LinearProgressIndicator(
              value: progress,
              backgroundColor: color.withOpacity(0.1),
              valueColor: AlwaysStoppedAnimation<Color>(_progressColor(progress)),
              minHeight: 8,
            ),
          ),
        ],
      ),
    );
  }

  Color _progressColor(double progress) {
    if (progress >= 1.0) return AppColors.secondary;
    if (progress >= 0.5) return AppColors.warning;
    return AppColors.accent;
  }

  String _fmt(int minutes) {
    final h = minutes ~/ 60;
    final m = minutes % 60;
    if (h == 0) return '${m}m';
    if (m == 0) return '${h}h';
    return '${h}h ${m}m';
  }
}

class _AddGoalSheet extends ConsumerStatefulWidget {
  @override
  ConsumerState<_AddGoalSheet> createState() => _AddGoalSheetState();
}

class _AddGoalSheetState extends ConsumerState<_AddGoalSheet> {
  final _titleController = TextEditingController();
  final _descController = TextEditingController();
  final Set<ActivityCategory> _selectedCategories = {};
  int _weeklyTargetHours = 10;
  String _selectedColor = '#7C6AF7';

  final _colors = [
    '#7C6AF7', '#06D6A0', '#FF6B6B', '#FFB703', '#48CAE4', '#EC4899',
  ];

  @override
  void dispose() {
    _titleController.dispose();
    _descController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final mediaQuery = MediaQuery.of(context);

    return Container(
      margin: EdgeInsets.only(top: mediaQuery.size.height * 0.15),
      decoration: BoxDecoration(
        color: isDark ? AppColors.darkSurface : AppColors.lightSurface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
        border: Border.all(
          color: isDark ? AppColors.darkBorder : AppColors.lightBorder,
        ),
      ),
      child: Padding(
        padding: EdgeInsets.only(
          left: 20,
          right: 20,
          top: 16,
          bottom: mediaQuery.viewInsets.bottom + 20,
        ),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: isDark ? AppColors.darkBorder : AppColors.lightBorder,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Text('New Goal', style: Theme.of(context).textTheme.headlineMedium),
              const SizedBox(height: 20),

              TextField(
                controller: _titleController,
                decoration: const InputDecoration(labelText: 'Goal Title'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _descController,
                decoration: const InputDecoration(labelText: 'Description (optional)'),
              ),
              const SizedBox(height: 20),

              Text('Focus Areas', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 8),
              Wrap(
                spacing: 6,
                runSpacing: 6,
                children: ActivityCategory.values.map((cat) {
                  return CategoryChip(
                    category: cat,
                    isSelected: _selectedCategories.contains(cat),
                    onTap: () => setState(() {
                      if (_selectedCategories.contains(cat)) {
                        _selectedCategories.remove(cat);
                      } else {
                        _selectedCategories.add(cat);
                      }
                    }),
                    compact: true,
                  );
                }).toList(),
              ),

              const SizedBox(height: 20),

              Row(
                children: [
                  Text('Weekly Target', style: Theme.of(context).textTheme.titleMedium),
                  const Spacer(),
                  Text(
                    '$_weeklyTargetHours hours',
                    style: TextStyle(
                      color: AppColors.primary,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
              Slider(
                value: _weeklyTargetHours.toDouble(),
                min: 1,
                max: 40,
                divisions: 39,
                activeColor: AppColors.primary,
                inactiveColor: AppColors.primary.withOpacity(0.1),
                onChanged: (v) => setState(() => _weeklyTargetHours = v.round()),
              ),

              const SizedBox(height: 8),
              Text('Color', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 8),
              Row(
                children: _colors.map((c) {
                  final selected = c == _selectedColor;
                  final color = Color(int.parse(c.replaceFirst('#', '0xFF')));
                  return GestureDetector(
                    onTap: () => setState(() => _selectedColor = c),
                    child: Container(
                      width: 32,
                      height: 32,
                      margin: const EdgeInsets.only(right: 8),
                      decoration: BoxDecoration(
                        color: color,
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: selected ? Colors.white : Colors.transparent,
                          width: 2,
                        ),
                      ),
                      child: selected
                          ? const Icon(Icons.check, color: Colors.white, size: 16)
                          : null,
                    ),
                  );
                }).toList(),
              ),

              const SizedBox(height: 24),

              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _save,
                  child: const Text('Create Goal'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _save() {
    if (_titleController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please add a title for your goal.')),
      );
      return;
    }
    if (_selectedCategories.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select at least one focus area.')),
      );
      return;
    }

    ref.read(goalsProvider.notifier).addGoal(
          title: _titleController.text.trim(),
          description: _descController.text.trim(),
          targetCategories: _selectedCategories.toList(),
          weeklyTargetMinutes: _weeklyTargetHours * 60,
          color: _selectedColor,
        );

    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('🎯 Goal created!'),
        backgroundColor: AppColors.secondary,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppRadius.md)),
      ),
    );
  }
}
