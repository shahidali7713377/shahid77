// lib/presentation/screens/onboarding_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';
import '../providers/app_providers.dart';

class OnboardingScreen extends ConsumerStatefulWidget {
  const OnboardingScreen({super.key});

  @override
  ConsumerState<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends ConsumerState<OnboardingScreen> {
  final _pageController = PageController();
  int _currentPage = 0;

  final _pages = const [
    _OnboardingPage(
      emoji: '🔄',
      title: 'Flip the Script',
      body:
          'Traditional to-do apps set you up to fail by tracking what you plan to do.\n\nReverse To-Do AI tracks what you actually did — no guilt, no pressure.',
      accentColor: AppColors.primary,
    ),
    _OnboardingPage(
      emoji: '🧠',
      title: 'AI Understands You',
      body:
          'Simply describe what you did. Our AI automatically categorizes it, detects behavioral patterns, and surfaces insights you\'d never see yourself.',
      accentColor: AppColors.secondary,
    ),
    _OnboardingPage(
      emoji: '⚡',
      title: 'Energy Over Hours',
      body:
          'We don\'t just count hours — we track energy levels, detect burnout before it hits, and find your natural peak performance windows.',
      accentColor: AppColors.info,
    ),
    _OnboardingPage(
      emoji: '🎯',
      title: 'Reality-Aligned Goals',
      body:
          'Set intentions, not rigid schedules. Watch how your real behavior aligns with what matters most — and get honest, encouraging feedback.',
      accentColor: AppColors.warning,
    ),
  ];

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isLast = _currentPage == _pages.length - 1;

    return Scaffold(
      body: Stack(
        children: [
          // Background gradient
          Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: Alignment.topRight,
                radius: 1.5,
                colors: [
                  _pages[_currentPage].accentColor.withOpacity(0.08),
                  Colors.transparent,
                ],
              ),
            ),
          ),

          Column(
            children: [
              const SizedBox(height: 60),

              // Page indicators
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: _pages.asMap().entries.map((e) {
                  return AnimatedContainer(
                    duration: const Duration(milliseconds: 300),
                    margin: const EdgeInsets.symmetric(horizontal: 4),
                    width: e.key == _currentPage ? 24 : 8,
                    height: 8,
                    decoration: BoxDecoration(
                      color: e.key == _currentPage
                          ? _pages[_currentPage].accentColor
                          : _pages[_currentPage].accentColor.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(4),
                    ),
                  );
                }).toList(),
              ),

              // Pages
              Expanded(
                child: PageView(
                  controller: _pageController,
                  onPageChanged: (i) => setState(() => _currentPage = i),
                  children: _pages,
                ),
              ),

              // Navigation
              Padding(
                padding: const EdgeInsets.fromLTRB(24, 0, 24, 48),
                child: Column(
                  children: [
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: () {
                          if (isLast) {
                            ref
                                .read(settingsProvider.notifier)
                                .completeOnboarding();
                          } else {
                            _pageController.nextPage(
                              duration: const Duration(milliseconds: 400),
                              curve: Curves.easeInOut,
                            );
                          }
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: _pages[_currentPage].accentColor,
                        ),
                        child: Text(isLast ? 'Start Tracking Reality' : 'Next'),
                      ),
                    ),
                    if (!isLast) ...[
                      const SizedBox(height: 12),
                      TextButton(
                        onPressed: () =>
                            ref.read(settingsProvider.notifier).completeOnboarding(),
                        child: Text(
                          'Skip',
                          style: TextStyle(color: AppColors.textSecondary),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _OnboardingPage extends StatelessWidget {
  final String emoji;
  final String title;
  final String body;
  final Color accentColor;

  const _OnboardingPage({
    required this.emoji,
    required this.title,
    required this.body,
    required this.accentColor,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 24),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(emoji, style: const TextStyle(fontSize: 72))
              .animate()
              .scale(duration: 500.ms, curve: Curves.elasticOut)
              .fadeIn(),

          const SizedBox(height: 32),

          Text(
            title,
            style: Theme.of(context).textTheme.displaySmall,
            textAlign: TextAlign.center,
          ).animate().fadeIn(delay: 100.ms).slideY(begin: 0.3),

          const SizedBox(height: 20),

          Text(
            body,
            style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                  color: AppColors.textSecondary,
                  height: 1.7,
                ),
            textAlign: TextAlign.center,
          ).animate().fadeIn(delay: 200.ms).slideY(begin: 0.2),
        ],
      ),
    );
  }
}
