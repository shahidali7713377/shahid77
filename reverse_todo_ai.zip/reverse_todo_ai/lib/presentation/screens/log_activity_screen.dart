// lib/presentation/screens/log_activity_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';
import '../providers/app_providers.dart';
import '../widgets/shared_widgets.dart';

class LogActivitySheet extends ConsumerStatefulWidget {
  const LogActivitySheet({super.key});

  @override
  ConsumerState<LogActivitySheet> createState() => _LogActivitySheetState();
}

class _LogActivitySheetState extends ConsumerState<LogActivitySheet> {
  final _controller = TextEditingController();
  final _focusNode = FocusNode();

  EnergyLevel _selectedEnergy = EnergyLevel.medium;
  MoodTag? _selectedMood;
  ActivityCategory? _manualCategory;
  String? _selectedGoalId;
  int _durationMinutes = 30;
  DateTime _startTime = DateTime.now();
  bool _isLogging = false;

  // Smart suggestions based on time of day
  List<String> get _suggestions {
    final hour = _startTime.hour;
    if (hour < 9) {
      return ['Morning routine', 'Meditation', 'Workout', 'Reading'];
    } else if (hour < 12) {
      return ['Deep work session', 'Code review', 'Writing', 'Planning'];
    } else if (hour < 14) {
      return ['Lunch break', 'Team meeting', 'Email catchup', 'Short walk'];
    } else if (hour < 17) {
      return ['Focused work', 'Client call', 'Learning', 'Project work'];
    } else if (hour < 20) {
      return ['Exercise', 'Cooking dinner', 'Family time', 'Reading'];
    }
    return ['Evening wind-down', 'Journaling', 'Light reading', 'Relaxation'];
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _focusNode.requestFocus();
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final goals = ref.watch(activeGoalsProvider);
    final mediaQuery = MediaQuery.of(context);

    return Container(
      margin: EdgeInsets.only(top: mediaQuery.size.height * 0.1),
      decoration: BoxDecoration(
        color: isDark ? AppColors.darkSurface : AppColors.lightSurface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
        border: Border.all(
          color: isDark ? AppColors.darkBorder : AppColors.lightBorder,
          width: 1,
        ),
      ),
      child: Padding(
        padding: EdgeInsets.only(bottom: mediaQuery.viewInsets.bottom),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(AppSpacing.md),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              // ─── Handle ─────────────────────────────────────────────────
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: isDark ? AppColors.darkBorder : AppColors.lightBorder,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: AppSpacing.md),

              Text(
                'What did you just do?',
                style: Theme.of(context).textTheme.headlineMedium,
              ).animate().fadeIn().slideY(begin: -0.2),

              const SizedBox(height: 4),
              Text(
                'Log your actual reality — no plans, just what happened.',
                style: Theme.of(context).textTheme.bodySmall,
              ).animate().fadeIn(delay: 50.ms),

              const SizedBox(height: AppSpacing.md),

              // ─── Text Input ──────────────────────────────────────────────
              TextField(
                controller: _controller,
                focusNode: _focusNode,
                maxLines: 3,
                minLines: 2,
                decoration: InputDecoration(
                  hintText: 'e.g., "Worked on the API authentication flow for 45 minutes"',
                  counterText: '',
                ),
                maxLength: 200,
              ).animate().fadeIn(delay: 100.ms),

              // ─── Quick Suggestions ───────────────────────────────────────
              const SizedBox(height: AppSpacing.sm),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: _suggestions.map((s) {
                    return Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: GestureDetector(
                        onTap: () => setState(() => _controller.text = s),
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: AppColors.primary.withOpacity(0.08),
                            borderRadius: BorderRadius.circular(AppRadius.full),
                            border: Border.all(
                                color: AppColors.primary.withOpacity(0.2)),
                          ),
                          child: Text(
                            s,
                            style: TextStyle(
                              fontSize: 12,
                              color: AppColors.primary,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ).animate().fadeIn(delay: 150.ms),

              const SizedBox(height: AppSpacing.lg),

              // ─── Duration Picker ─────────────────────────────────────────
              Row(
                children: [
                  Text('Duration', style: Theme.of(context).textTheme.titleMedium),
                  const Spacer(),
                  Text(
                    _formatDuration(_durationMinutes),
                    style: Theme.of(context)
                        .textTheme
                        .titleMedium
                        ?.copyWith(color: AppColors.primary),
                  ),
                ],
              ).animate().fadeIn(delay: 200.ms),

              Slider(
                value: _durationMinutes.toDouble(),
                min: 5,
                max: 480,
                divisions: 95,
                activeColor: AppColors.primary,
                inactiveColor: AppColors.primary.withOpacity(0.1),
                onChanged: (v) => setState(() => _durationMinutes = v.round()),
              ).animate().fadeIn(delay: 220.ms),

              // Quick duration buttons
              Row(
                children: [15, 30, 60, 90, 120].map((mins) {
                  final selected = _durationMinutes == mins;
                  return Padding(
                    padding: const EdgeInsets.only(right: 6),
                    child: GestureDetector(
                      onTap: () => setState(() => _durationMinutes = mins),
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: selected
                              ? AppColors.primary.withOpacity(0.15)
                              : Colors.transparent,
                          borderRadius: BorderRadius.circular(AppRadius.full),
                          border: Border.all(
                            color: selected
                                ? AppColors.primary
                                : AppColors.darkBorder,
                          ),
                        ),
                        child: Text(
                          '${mins}m',
                          style: TextStyle(
                            fontSize: 12,
                            color: selected ? AppColors.primary : AppColors.textSecondary,
                            fontWeight: selected ? FontWeight.w600 : FontWeight.w400,
                          ),
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ).animate().fadeIn(delay: 250.ms),

              const SizedBox(height: AppSpacing.lg),

              // ─── Energy Level ────────────────────────────────────────────
              Text('Energy Level', style: Theme.of(context).textTheme.titleMedium)
                  .animate()
                  .fadeIn(delay: 300.ms),
              const SizedBox(height: AppSpacing.sm),
              EnergySelector(
                selected: _selectedEnergy,
                onChanged: (e) => setState(() => _selectedEnergy = e),
              ).animate().fadeIn(delay: 320.ms),

              const SizedBox(height: AppSpacing.lg),

              // ─── Mood (Optional) ─────────────────────────────────────────
              Text('Mood (optional)', style: Theme.of(context).textTheme.titleMedium)
                  .animate()
                  .fadeIn(delay: 350.ms),
              const SizedBox(height: AppSpacing.sm),
              Wrap(
                spacing: 6,
                runSpacing: 6,
                children: MoodTag.values.map((mood) {
                  final selected = _selectedMood == mood;
                  return GestureDetector(
                    onTap: () => setState(() {
                      _selectedMood = selected ? null : mood;
                    }),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(
                        color: selected
                            ? AppColors.primary.withOpacity(0.15)
                            : Colors.transparent,
                        borderRadius: BorderRadius.circular(AppRadius.full),
                        border: Border.all(
                          color: selected ? AppColors.primary : AppColors.darkBorder,
                          width: selected ? 1.5 : 1,
                        ),
                      ),
                      child: Text(
                        '${mood.emoji} ${mood.label}',
                        style: TextStyle(
                          fontSize: 12,
                          color: selected
                              ? AppColors.primary
                              : AppColors.textSecondary,
                          fontWeight: selected ? FontWeight.w600 : FontWeight.w400,
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ).animate().fadeIn(delay: 380.ms),

              const SizedBox(height: AppSpacing.lg),

              // ─── Manual Category (Optional) ──────────────────────────────
              ExpansionTile(
                tilePadding: EdgeInsets.zero,
                title: Text(
                  'Override AI Category',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                subtitle: Text(
                  _manualCategory?.label ?? 'Auto-detect',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: AppColors.primary,
                      ),
                ),
                children: [
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: ActivityCategory.values.map((cat) {
                      return CategoryChip(
                        category: cat,
                        isSelected: _manualCategory == cat,
                        onTap: () => setState(() {
                          _manualCategory = _manualCategory == cat ? null : cat;
                        }),
                        compact: true,
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: AppSpacing.sm),
                ],
              ).animate().fadeIn(delay: 400.ms),

              // ─── Goal Tag (Optional) ─────────────────────────────────────
              if (goals.isNotEmpty) ...[
                const SizedBox(height: AppSpacing.sm),
                DropdownButtonFormField<String?>(
                  value: _selectedGoalId,
                  decoration: const InputDecoration(
                    labelText: 'Tag a Goal (optional)',
                    prefixIcon: Icon(Icons.flag_outlined, color: AppColors.textMuted),
                  ),
                  items: [
                    const DropdownMenuItem(
                      value: null,
                      child: Text('No goal'),
                    ),
                    ...goals.map((g) => DropdownMenuItem(
                          value: g.id,
                          child: Text(g.title),
                        )),
                  ],
                  onChanged: (v) => setState(() => _selectedGoalId = v),
                ).animate().fadeIn(delay: 420.ms),
              ],

              const SizedBox(height: AppSpacing.xl),

              // ─── Submit Button ────────────────────────────────────────────
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _isLogging ? null : _submit,
                  child: _isLogging
                      ? const SizedBox(
                          height: 20,
                          width: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        )
                      : const Text('Log Activity ✓'),
                ),
              ).animate().fadeIn(delay: 450.ms).slideY(begin: 0.3),

              const SizedBox(height: AppSpacing.md),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _submit() async {
    final description = _controller.text.trim();
    if (description.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please describe what you did.')),
      );
      return;
    }

    setState(() => _isLogging = true);

    try {
      await ref.read(activitiesProvider.notifier).addActivity(
            description: description,
            startTime: _startTime.subtract(Duration(minutes: _durationMinutes)),
            durationMinutes: _durationMinutes,
            energyLevel: _selectedEnergy,
            moodTag: _selectedMood,
            goalId: _selectedGoalId,
            manualCategory: _manualCategory,
          );

      if (mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('✅ Activity logged!'),
            backgroundColor: AppColors.secondary,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(AppRadius.md)),
          ),
        );
      }
    } catch (e) {
      setState(() => _isLogging = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e')),
        );
      }
    }
  }

  String _formatDuration(int minutes) {
    final h = minutes ~/ 60;
    final m = minutes % 60;
    if (h == 0) return '${m}m';
    if (m == 0) return '${h}h';
    return '${h}h ${m}m';
  }
}
