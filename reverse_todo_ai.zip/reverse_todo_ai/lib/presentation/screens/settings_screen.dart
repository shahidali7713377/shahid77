// lib/presentation/screens/settings_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';
import '../../data/local/hive_service.dart';
import '../providers/app_providers.dart';
import '../widgets/shared_widgets.dart';

class SettingsScreen extends ConsumerStatefulWidget {
  const SettingsScreen({super.key});

  @override
  ConsumerState<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends ConsumerState<SettingsScreen> {
  final _apiKeyController = TextEditingController();
  bool _showApiKey = false;

  @override
  void initState() {
    super.initState();
    _apiKeyController.text = HiveService.aiApiKey ?? '';
  }

  @override
  void dispose() {
    _apiKeyController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = ref.watch(themeProvider);
    final settings = ref.watch(settingsProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(AppSpacing.md),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ─── Appearance ──────────────────────────────────────────────
            _SettingsSection(
              title: 'Appearance',
              children: [
                _SettingsTile(
                  title: 'Dark Mode',
                  subtitle: 'Easier on the eyes during long sessions',
                  leading: const Text('🌙', style: TextStyle(fontSize: 20)),
                  trailing: Switch(
                    value: isDark,
                    onChanged: (_) => ref.read(themeProvider.notifier).toggle(),
                    activeColor: AppColors.primary,
                  ),
                ),
              ],
            ),

            const SizedBox(height: AppSpacing.md),

            // ─── AI Configuration ────────────────────────────────────────
            _SettingsSection(
              title: 'AI Engine',
              children: [
                Padding(
                  padding: const EdgeInsets.all(AppSpacing.md),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'AI Provider',
                        style: Theme.of(context).textTheme.titleSmall,
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          _ProviderButton(
                            label: 'Anthropic',
                            emoji: '🤖',
                            selected: settings['aiProvider'] == 'anthropic',
                            onTap: () => ref
                                .read(settingsProvider.notifier)
                                .updateProvider('anthropic'),
                          ),
                          const SizedBox(width: 8),
                          _ProviderButton(
                            label: 'OpenAI',
                            emoji: '🧠',
                            selected: settings['aiProvider'] == 'openai',
                            onTap: () => ref
                                .read(settingsProvider.notifier)
                                .updateProvider('openai'),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      Text(
                        'API Key (Optional)',
                        style: Theme.of(context).textTheme.titleSmall,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Without an API key, the app uses smart rule-based AI for categorization and insights.',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                      const SizedBox(height: 8),
                      TextField(
                        controller: _apiKeyController,
                        obscureText: !_showApiKey,
                        decoration: InputDecoration(
                          hintText: 'sk-... or sk-ant-...',
                          suffixIcon: IconButton(
                            icon: Icon(
                              _showApiKey ? Icons.visibility_off : Icons.visibility,
                              color: AppColors.textMuted,
                            ),
                            onPressed: () =>
                                setState(() => _showApiKey = !_showApiKey),
                          ),
                        ),
                      ),
                      const SizedBox(height: 8),
                      SizedBox(
                        width: double.infinity,
                        child: OutlinedButton(
                          onPressed: () {
                            ref
                                .read(settingsProvider.notifier)
                                .updateApiKey(_apiKeyController.text.trim());
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: const Text('✅ API key saved'),
                                backgroundColor: AppColors.secondary,
                                behavior: SnackBarBehavior.floating,
                              ),
                            );
                          },
                          child: const Text('Save API Key'),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),

            const SizedBox(height: AppSpacing.md),

            // ─── Privacy & Data ──────────────────────────────────────────
            _SettingsSection(
              title: 'Privacy & Data',
              children: [
                _SettingsTile(
                  title: 'Data Storage',
                  subtitle: 'All data stored locally on your device',
                  leading: const Text('🔒', style: TextStyle(fontSize: 20)),
                  trailing: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: AppColors.secondary.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(AppRadius.full),
                    ),
                    child: Text(
                      'Local',
                      style: TextStyle(
                        color: AppColors.secondary,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
                _SettingsTile(
                  title: 'No Third-Party Tracking',
                  subtitle: 'Your behavioral data is yours alone',
                  leading: const Text('🛡️', style: TextStyle(fontSize: 20)),
                  trailing: const Icon(Icons.check_circle,
                      color: AppColors.secondary, size: 20),
                ),
                _SettingsTile(
                  title: 'Clear All Data',
                  subtitle: 'Delete all logged activities permanently',
                  leading: const Text('🗑️', style: TextStyle(fontSize: 20)),
                  trailing: TextButton(
                    onPressed: () => _confirmClearData(context, ref),
                    child: Text(
                      'Clear',
                      style: TextStyle(color: AppColors.accent),
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: AppSpacing.md),

            // ─── About ───────────────────────────────────────────────────
            _SettingsSection(
              title: 'About',
              children: [
                _SettingsTile(
                  title: 'Reverse To-Do AI',
                  subtitle: 'Version 1.0.0 — Track what you actually do',
                  leading: const Text('📱', style: TextStyle(fontSize: 20)),
                ),
                _SettingsTile(
                  title: 'Philosophy',
                  subtitle: 'Productivity should be measured by reality, not intention.',
                  leading: const Text('💭', style: TextStyle(fontSize: 20)),
                ),
              ],
            ),

            const SizedBox(height: 80),
          ],
        ),
      ),
    );
  }

  void _confirmClearData(BuildContext context, WidgetRef ref) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Clear All Data'),
        content: const Text(
            'This will permanently delete all logged activities and goals. This cannot be undone.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () async {
              await HiveService.activityBox.clear();
              await HiveService.goalBox.clear();
              ref.read(activitiesProvider.notifier).refresh();
              if (ctx.mounted) Navigator.pop(ctx);
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('All data cleared.')),
                );
              }
            },
            child: Text('Clear', style: TextStyle(color: AppColors.accent)),
          ),
        ],
      ),
    );
  }
}

class _SettingsSection extends StatelessWidget {
  final String title;
  final List<Widget> children;

  const _SettingsSection({required this.title, required this.children});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 8),
          child: Text(
            title.toUpperCase(),
            style: Theme.of(context).textTheme.labelSmall?.copyWith(
                  letterSpacing: 1.2,
                ),
          ),
        ),
        GlassCard(
          padding: EdgeInsets.zero,
          child: Column(
            children: children.indexed.map((entry) {
              final i = entry.$1;
              final child = entry.$2;
              return Column(
                children: [
                  child,
                  if (i < children.length - 1)
                    Divider(
                      height: 1,
                      color: Theme.of(context).dividerColor,
                    ),
                ],
              );
            }).toList(),
          ),
        ),
      ],
    );
  }
}

class _SettingsTile extends StatelessWidget {
  final String title;
  final String? subtitle;
  final Widget? leading;
  final Widget? trailing;
  final VoidCallback? onTap;

  const _SettingsTile({
    required this.title,
    this.subtitle,
    this.leading,
    this.trailing,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(title, style: Theme.of(context).textTheme.titleMedium),
      subtitle: subtitle != null
          ? Text(subtitle!, style: Theme.of(context).textTheme.bodySmall)
          : null,
      leading: leading,
      trailing: trailing,
      onTap: onTap,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
    );
  }
}

class _ProviderButton extends StatelessWidget {
  final String label;
  final String emoji;
  final bool selected;
  final VoidCallback onTap;

  const _ProviderButton({
    required this.label,
    required this.emoji,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          color: selected ? AppColors.primary.withOpacity(0.15) : Colors.transparent,
          borderRadius: BorderRadius.circular(AppRadius.md),
          border: Border.all(
            color: selected ? AppColors.primary : AppColors.darkBorder,
            width: selected ? 1.5 : 1,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(emoji, style: const TextStyle(fontSize: 16)),
            const SizedBox(width: 6),
            Text(
              label,
              style: TextStyle(
                color: selected ? AppColors.primary : AppColors.textSecondary,
                fontWeight: selected ? FontWeight.w600 : FontWeight.w400,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
