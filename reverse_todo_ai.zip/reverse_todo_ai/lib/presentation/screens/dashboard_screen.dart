// lib/presentation/screens/dashboard_screen.dart
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';
import '../providers/app_providers.dart';
import '../widgets/shared_widgets.dart';

class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final weekActivities = ref.watch(weekActivitiesProvider);
    final categoryDist = ref.watch(categoryDistributionProvider);
    final burnoutScore = ref.watch(burnoutScoreProvider);
    final burnoutRisk = ref.watch(burnoutRiskProvider);
    final hourlyEnergy = ref.watch(hourlyEnergyProvider);

    final totalMinutes = weekActivities.fold(0, (sum, a) => sum + a.durationMinutes);
    final deepWorkMinutes = weekActivities
        .where((a) => a.category == ActivityCategory.deepWork)
        .fold(0, (sum, a) => sum + a.durationMinutes);
    final deepWorkPct = totalMinutes > 0
        ? (deepWorkMinutes / totalMinutes * 100).round()
        : 0;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Analytics'),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 16),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            decoration: BoxDecoration(
              color: AppColors.primary.withOpacity(0.1),
              borderRadius: BorderRadius.circular(AppRadius.full),
            ),
            child: Text(
              'This Week',
              style: TextStyle(
                color: AppColors.primary,
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
      body: weekActivities.isEmpty
          ? const EmptyState(
              emoji: '📊',
              title: 'No data yet',
              message: 'Log activities to unlock analytics and behavioral insights.',
            )
          : SingleChildScrollView(
              padding: const EdgeInsets.all(AppSpacing.md),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // ─── Top Stats ────────────────────────────────────────
                  _TopStats(
                    totalMinutes: totalMinutes,
                    activitiesCount: weekActivities.length,
                    deepWorkPct: deepWorkPct,
                  ).animate().fadeIn(delay: 100.ms),

                  const SizedBox(height: AppSpacing.lg),

                  // ─── Burnout Meter ────────────────────────────────────
                  const SectionHeader(title: 'Burnout Risk Meter'),
                  const SizedBox(height: AppSpacing.sm),
                  GlassCard(
                    child: BurnoutMeter(
                      score: burnoutScore,
                      risk: burnoutRisk,
                    ),
                  ).animate().fadeIn(delay: 150.ms),

                  const SizedBox(height: AppSpacing.lg),

                  // ─── Category Distribution ────────────────────────────
                  const SectionHeader(
                    title: 'Time Distribution',
                    subtitle: 'How you actually spent your week',
                  ),
                  const SizedBox(height: AppSpacing.sm),
                  GlassCard(
                    child: _CategoryPieChart(categoryDist: categoryDist),
                  ).animate().fadeIn(delay: 200.ms),

                  const SizedBox(height: AppSpacing.lg),

                  // ─── Energy by Hour ───────────────────────────────────
                  const SectionHeader(
                    title: 'Energy Patterns',
                    subtitle: 'Average energy level by hour of day',
                  ),
                  const SizedBox(height: AppSpacing.sm),
                  GlassCard(
                    child: _EnergyHeatmap(hourlyEnergy: hourlyEnergy),
                  ).animate().fadeIn(delay: 250.ms),

                  const SizedBox(height: AppSpacing.lg),

                  // ─── Weekly Heatmap ───────────────────────────────────
                  const SectionHeader(
                    title: 'Activity Heatmap',
                    subtitle: 'Minutes logged per day this week',
                  ),
                  const SizedBox(height: AppSpacing.sm),
                  GlassCard(
                    child: _WeeklyHeatmap(activities: weekActivities),
                  ).animate().fadeIn(delay: 300.ms),

                  const SizedBox(height: AppSpacing.lg),

                  // ─── Goal Alignment Bar ───────────────────────────────
                  const SectionHeader(
                    title: 'Focus Score',
                    subtitle: 'Deep work as % of total time',
                  ),
                  const SizedBox(height: AppSpacing.sm),
                  GlassCard(
                    child: _FocusScoreBar(deepWorkPct: deepWorkPct),
                  ).animate().fadeIn(delay: 350.ms),

                  const SizedBox(height: 80),
                ],
              ),
            ),
    );
  }
}

// ─── Component: Top Stats ────────────────────────────────────────────────────

class _TopStats extends StatelessWidget {
  final int totalMinutes;
  final int activitiesCount;
  final int deepWorkPct;

  const _TopStats({
    required this.totalMinutes,
    required this.activitiesCount,
    required this.deepWorkPct,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: StatCard(
            label: 'Total Time',
            value: _fmt(totalMinutes),
            emoji: '⏱️',
            accentColor: AppColors.primary,
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: StatCard(
            label: 'Activities',
            value: '$activitiesCount',
            emoji: '📋',
            accentColor: AppColors.secondary,
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: StatCard(
            label: 'Deep Work',
            value: '$deepWorkPct%',
            emoji: '🧠',
            accentColor: AppColors.deepWork,
          ),
        ),
      ],
    );
  }

  String _fmt(int mins) {
    final h = mins ~/ 60;
    final m = mins % 60;
    if (h == 0) return '${m}m';
    if (m == 0) return '${h}h';
    return '${h}h';
  }
}

// ─── Component: Category Pie Chart ──────────────────────────────────────────

class _CategoryPieChart extends StatefulWidget {
  final Map<ActivityCategory, int> categoryDist;

  const _CategoryPieChart({required this.categoryDist});

  @override
  State<_CategoryPieChart> createState() => _CategoryPieChartState();
}

class _CategoryPieChartState extends State<_CategoryPieChart> {
  int? _touchedIndex;

  @override
  Widget build(BuildContext context) {
    if (widget.categoryDist.isEmpty) {
      return const Padding(
        padding: EdgeInsets.all(20),
        child: Text('No data to display'),
      );
    }

    final total = widget.categoryDist.values.fold(0, (a, b) => a + b);
    final sections = widget.categoryDist.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    return Column(
      children: [
        SizedBox(
          height: 200,
          child: PieChart(
            PieChartData(
              pieTouchData: PieTouchData(
                touchCallback: (event, response) {
                  setState(() {
                    if (!event.isInterestedForInteractions ||
                        response == null ||
                        response.touchedSection == null) {
                      _touchedIndex = -1;
                    } else {
                      _touchedIndex =
                          response.touchedSection!.touchedSectionIndex;
                    }
                  });
                },
              ),
              borderData: FlBorderData(show: false),
              sectionsSpace: 2,
              centerSpaceRadius: 50,
              sections: sections.asMap().entries.map((entry) {
                final i = entry.key;
                final cat = entry.key;
                final mins = entry.value.value;
                final catObj = entry.value.key;
                final pct = mins / total * 100;
                final isTouched = i == _touchedIndex;
                final color = Color(
                    int.parse(catObj.hexColor.replaceFirst('#', '0xFF')));
                return PieChartSectionData(
                  color: color,
                  value: mins.toDouble(),
                  title: isTouched ? '${pct.round()}%' : '',
                  radius: isTouched ? 60 : 50,
                  titleStyle: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                  ),
                  badgeWidget: isTouched ? null : Text(catObj.emoji),
                  badgePositionPercentageOffset: 1.2,
                );
              }).toList(),
            ),
          ),
        ),
        const SizedBox(height: AppSpacing.md),
        Wrap(
          spacing: 8,
          runSpacing: 4,
          children: sections.take(6).map((entry) {
            final cat = entry.key;
            final mins = entry.value;
            final pct = (mins / total * 100).round();
            final color =
                Color(int.parse(cat.hexColor.replaceFirst('#', '0xFF')));
            return Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 10,
                  height: 10,
                  decoration: BoxDecoration(color: color, shape: BoxShape.circle),
                ),
                const SizedBox(width: 4),
                Text(
                  '${cat.emoji} ${cat.label} ($pct%)',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ],
            );
          }).toList(),
        ),
      ],
    );
  }
}

// ─── Component: Energy Heatmap ───────────────────────────────────────────────

class _EnergyHeatmap extends StatelessWidget {
  final Map<int, double> hourlyEnergy;

  const _EnergyHeatmap({required this.hourlyEnergy});

  @override
  Widget build(BuildContext context) {
    if (hourlyEnergy.isEmpty) {
      return const Padding(
        padding: EdgeInsets.all(20),
        child: Text('No energy data yet'),
      );
    }

    final hours = List.generate(24, (i) => i);
    final maxEnergy = 3.0;

    return SizedBox(
      height: 160,
      child: LineChart(
        LineChartData(
          gridData: FlGridData(
            show: true,
            getDrawingHorizontalLine: (v) =>
                FlLine(color: AppColors.darkBorder.withOpacity(0.3), strokeWidth: 1),
            getDrawingVerticalLine: (v) =>
                FlLine(color: AppColors.darkBorder.withOpacity(0.1), strokeWidth: 1),
          ),
          titlesData: FlTitlesData(
            leftTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 28,
                getTitlesWidget: (v, meta) {
                  final labels = {1.0: 'Low', 2.0: 'Med', 3.0: 'Hi'};
                  return Text(
                    labels[v] ?? '',
                    style: const TextStyle(
                        fontSize: 9, color: AppColors.textSecondary),
                  );
                },
                interval: 1,
              ),
            ),
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 22,
                interval: 6,
                getTitlesWidget: (v, meta) {
                  final h = v.toInt();
                  if (h % 6 != 0) return const SizedBox.shrink();
                  final label = h == 0
                      ? '12AM'
                      : h == 12
                          ? '12PM'
                          : h < 12
                              ? '${h}AM'
                              : '${h - 12}PM';
                  return Text(
                    label,
                    style: const TextStyle(
                        fontSize: 9, color: AppColors.textSecondary),
                  );
                },
              ),
            ),
            rightTitles:
                const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            topTitles:
                const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          ),
          borderData: FlBorderData(show: false),
          minX: 0,
          maxX: 23,
          minY: 0,
          maxY: maxEnergy,
          lineBarsData: [
            LineChartBarData(
              spots: List.generate(24, (h) {
                final energy = hourlyEnergy[h];
                return FlSpot(h.toDouble(), energy ?? 0);
              }),
              isCurved: true,
              color: AppColors.primary,
              barWidth: 2.5,
              isStrokeCapRound: true,
              dotData: const FlDotData(show: false),
              belowBarData: BarAreaData(
                show: true,
                color: AppColors.primary.withOpacity(0.1),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Component: Weekly Heatmap ────────────────────────────────────────────────

class _WeeklyHeatmap extends StatelessWidget {
  final List<dynamic> activities;

  const _WeeklyHeatmap({required this.activities});

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final days = List.generate(7, (i) {
      final day = now.subtract(Duration(days: 6 - i));
      return DateTime(day.year, day.month, day.day);
    });

    final dayMinutes = <DateTime, int>{};
    for (final day in days) {
      dayMinutes[day] = 0;
    }

    for (final activity in activities) {
      final actDay = DateTime(
        activity.startTime.year,
        activity.startTime.month,
        activity.startTime.day,
      );
      if (dayMinutes.containsKey(actDay)) {
        dayMinutes[actDay] = dayMinutes[actDay]! + activity.durationMinutes;
      }
    }

    final maxMins =
        dayMinutes.values.isEmpty ? 1 : dayMinutes.values.reduce((a, b) => a > b ? a : b);
    final dayNames = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

    return Row(
      children: days.asMap().entries.map((entry) {
        final day = entry.value;
        final mins = dayMinutes[day] ?? 0;
        final ratio = maxMins > 0 ? mins / maxMins : 0.0;
        final dayOfWeek = day.weekday - 1; // 0=Mon

        return Expanded(
          child: Column(
            children: [
              Text(
                dayNames[dayOfWeek],
                style: const TextStyle(fontSize: 10, color: AppColors.textMuted),
              ),
              const SizedBox(height: 6),
              Container(
                height: 60,
                margin: const EdgeInsets.symmetric(horizontal: 2),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(6),
                  color: AppColors.primary.withOpacity(0.05),
                ),
                child: Align(
                  alignment: Alignment.bottomCenter,
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 500),
                    curve: Curves.easeOut,
                    height: 60 * ratio.toDouble(),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(6),
                      gradient: LinearGradient(
                        begin: Alignment.bottomCenter,
                        end: Alignment.topCenter,
                        colors: [
                          AppColors.primary,
                          AppColors.primaryLight,
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 4),
              Text(
                mins > 0 ? '${(mins / 60).toStringAsFixed(1)}h' : '-',
                style: const TextStyle(fontSize: 9, color: AppColors.textMuted),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }
}

// ─── Component: Focus Score Bar ───────────────────────────────────────────────

class _FocusScoreBar extends StatelessWidget {
  final int deepWorkPct;

  const _FocusScoreBar({required this.deepWorkPct});

  @override
  Widget build(BuildContext context) {
    Color barColor;
    String label;
    if (deepWorkPct >= 40) {
      barColor = AppColors.secondary;
      label = '🏆 Excellent focus discipline';
    } else if (deepWorkPct >= 20) {
      barColor = AppColors.warning;
      label = '📈 Good — aim for 40%+ deep work';
    } else {
      barColor = AppColors.accent;
      label = '💡 Try blocking morning hours for deep work';
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(
              'Deep Work Ratio',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            const Spacer(),
            Text(
              '$deepWorkPct%',
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                    color: barColor,
                    fontWeight: FontWeight.w700,
                  ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        ClipRRect(
          borderRadius: BorderRadius.circular(AppRadius.full),
          child: LinearProgressIndicator(
            value: deepWorkPct / 100,
            backgroundColor: barColor.withOpacity(0.1),
            valueColor: AlwaysStoppedAnimation<Color>(barColor),
            minHeight: 12,
          ),
        ),
        const SizedBox(height: 8),
        Text(label, style: Theme.of(context).textTheme.bodySmall),
      ],
    );
  }
}
