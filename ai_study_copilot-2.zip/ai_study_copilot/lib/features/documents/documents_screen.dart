import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../core/constants/app_colors.dart';
import '../../core/models/models.dart';
import '../../core/services/app_provider.dart';
import '../../widgets/common_widgets.dart';
import '../summaries/summary_screen.dart';
import '../exam/exam_screen.dart';
import '../chat/chat_screen.dart';
import '../flashcards/flashcard_generator_screen.dart';

class DocumentsScreen extends StatefulWidget {
  const DocumentsScreen({super.key});

  @override
  State<DocumentsScreen> createState() => _DocumentsScreenState();
}

class _DocumentsScreenState extends State<DocumentsScreen> {
  final _textCtrl = TextEditingController();
  final _titleCtrl = TextEditingController();

  Future<void> _showAddOptions() async {
    final provider = context.read<AppProvider>();

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        decoration: const BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(width: 40, height: 4, decoration: BoxDecoration(color: AppColors.surfaceAlt, borderRadius: BorderRadius.circular(2))),
            const SizedBox(height: 24),
            const Text('Add Study Material', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, fontFamily: 'Poppins')),
            const SizedBox(height: 20),
            _addOption(Icons.upload_file_rounded, 'Upload PDF / DOC', AppColors.primary, () async {
              Navigator.pop(ctx);
              await provider.uploadDocument(context);
            }),
            _addOption(Icons.camera_alt_rounded, 'Scan Image (OCR)', AppColors.secondary, () async {
              Navigator.pop(ctx);
              await provider.scanImage();
            }),
            _addOption(Icons.edit_note_rounded, 'Type / Paste Text', AppColors.warning, () {
              Navigator.pop(ctx);
              _showTextInputDialog();
            }),
          ],
        ),
      ),
    );
  }

  Widget _addOption(IconData icon, String label, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: color.withOpacity(0.08),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: color.withOpacity(0.2)),
        ),
        child: Row(
          children: [
            Icon(icon, color: color, size: 24),
            const SizedBox(width: 14),
            Text(label, style: TextStyle(fontSize: 15, fontWeight: FontWeight.w500, color: color, fontFamily: 'Poppins')),
            const Spacer(),
            Icon(Icons.chevron_right_rounded, color: color),
          ],
        ),
      ),
    );
  }

  void _showTextInputDialog() {
    _titleCtrl.clear();
    _textCtrl.clear();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Add Text Material', style: TextStyle(fontFamily: 'Poppins', fontWeight: FontWeight.w700)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            AppTextField(label: 'Title', controller: _titleCtrl),
            const SizedBox(height: 12),
            AppTextField(label: 'Content', controller: _textCtrl, maxLines: 8, hint: 'Paste your notes or text here...'),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () async {
              if (_titleCtrl.text.isNotEmpty && _textCtrl.text.isNotEmpty) {
                await context.read<AppProvider>().createTextDocument(title: _titleCtrl.text, content: _textCtrl.text);
                if (mounted) Navigator.pop(ctx);
              }
            },
            child: const Text('Add'),
          ),
        ],
      ),
    );
  }

  void _showDocumentActions(DocumentModel doc) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        decoration: const BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(width: 40, height: 4, decoration: BoxDecoration(color: AppColors.surfaceAlt, borderRadius: BorderRadius.circular(2))),
            const SizedBox(height: 16),
            Text(doc.title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, fontFamily: 'Poppins'), maxLines: 2),
            const SizedBox(height: 20),
            _actionTile(Icons.auto_awesome_rounded, 'Generate Summary', AppColors.primary, () {
              Navigator.pop(ctx);
              Navigator.push(context, MaterialPageRoute(builder: (_) => SummaryScreen(document: doc)));
            }),
            _actionTile(Icons.style_rounded, 'Create Flashcards', AppColors.secondary, () {
              Navigator.pop(ctx);
              Navigator.push(context, MaterialPageRoute(builder: (_) => FlashcardGeneratorScreen(document: doc)));
            }),
            _actionTile(Icons.quiz_rounded, 'Exam Questions', AppColors.warning, () {
              Navigator.pop(ctx);
              Navigator.push(context, MaterialPageRoute(builder: (_) => ExamScreen(document: doc)));
            }),
            _actionTile(Icons.chat_bubble_rounded, 'Ask AI Tutor', AppColors.accent, () {
              Navigator.pop(ctx);
              Navigator.push(context, MaterialPageRoute(builder: (_) => ChatScreen(document: doc)));
            }),
            const Divider(height: 24),
            _actionTile(Icons.delete_rounded, 'Delete', AppColors.hard, () async {
              Navigator.pop(ctx);
              final confirm = await showDialog<bool>(
                context: context,
                builder: (ctx) => AlertDialog(
                  title: const Text('Delete Document?'),
                  content: const Text('This will also delete all summaries, flashcards, and exam questions for this document.'),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(backgroundColor: AppColors.hard),
                      onPressed: () => Navigator.pop(ctx, true),
                      child: const Text('Delete'),
                    ),
                  ],
                ),
              );
              if (confirm == true && mounted) {
                await context.read<AppProvider>().deleteDocument(doc.id);
              }
            }),
          ],
        ),
      ),
    );
  }

  Widget _actionTile(IconData icon, String label, Color color, VoidCallback onTap) {
    return ListTile(
      leading: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(10)),
        child: Icon(icon, color: color, size: 20),
      ),
      title: Text(label, style: TextStyle(fontSize: 15, fontWeight: FontWeight.w500, color: color, fontFamily: 'Poppins')),
      onTap: onTap,
    );
  }

  @override
  Widget build(BuildContext context) {
    final docs = context.watch<AppProvider>().documents;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Study Materials'),
        actions: [
          IconButton(
            icon: Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(color: AppColors.primaryLight, borderRadius: BorderRadius.circular(10)),
              child: const Icon(Icons.add_rounded, color: AppColors.primary, size: 22),
            ),
            onPressed: _showAddOptions,
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: docs.isEmpty
          ? EmptyState(
              icon: Icons.upload_file_rounded,
              title: 'No study materials yet',
              subtitle: 'Upload PDFs, scan images, or type your notes to get started',
              buttonText: 'Add Material',
              onButton: _showAddOptions,
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: docs.length,
              itemBuilder: (context, index) {
                final doc = docs[index];
                return _buildDocumentCard(doc);
              },
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showAddOptions,
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add_rounded),
        label: const Text('Add Material', style: TextStyle(fontFamily: 'Poppins', fontWeight: FontWeight.w600)),
      ),
    );
  }

  Widget _buildDocumentCard(DocumentModel doc) {
    final iconMap = {'pdf': Icons.picture_as_pdf_rounded, 'image': Icons.image_rounded, 'text': Icons.edit_note_rounded, 'doc': Icons.description_rounded, 'docx': Icons.description_rounded};
    final colorMap = {'pdf': AppColors.hard, 'image': AppColors.secondary, 'text': AppColors.primary, 'doc': AppColors.warning, 'docx': AppColors.warning};
    final color = colorMap[doc.fileType] ?? AppColors.primary;

    return GestureDetector(
      onTap: () => _showDocumentActions(doc),
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.surfaceAlt),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8, offset: const Offset(0, 2))],
        ),
        child: Row(
          children: [
            Container(
              width: 52,
              height: 52,
              decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(14)),
              child: Icon(iconMap[doc.fileType] ?? Icons.description_rounded, color: color, size: 26),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(doc.title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: AppColors.textPrimary, fontFamily: 'Poppins'), maxLines: 1, overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 4),
                  Text(doc.contentPreview, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary, fontFamily: 'Poppins'), maxLines: 1, overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                        decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(6)),
                        child: Text(doc.fileType.toUpperCase(), style: TextStyle(fontSize: 10, fontWeight: FontWeight.w600, color: color, fontFamily: 'Poppins')),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        DateFormat('MMM d, yyyy').format(doc.createdAt),
                        style: const TextStyle(fontSize: 11, color: AppColors.textHint, fontFamily: 'Poppins'),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const Icon(Icons.more_vert_rounded, color: AppColors.textHint),
          ],
        ),
      ),
    );
  }
}
