import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';
import '../../core/constants/app_colors.dart';
import '../../core/models/models.dart';
import '../../core/services/ai_service.dart';
import '../../core/services/app_provider.dart';
import '../../core/database/database_helper.dart';
import '../../widgets/common_widgets.dart';

class ExamScreen extends StatefulWidget {
  final DocumentModel document;
  const ExamScreen({super.key, required this.document});

  @override
  State<ExamScreen> createState() => _ExamScreenState();
}

class _ExamScreenState extends State<ExamScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  String _questionType = 'mixed';
  int _questionCount = 10;
  bool _isGenerating = false;
  List<ExamQuestionModel> _questions = [];
  Map<String, String> _userAnswers = {};
  Map<String, Map<String, dynamic>> _evaluations = {};
  bool _submitted = false;

  final List<Map<String, dynamic>> _questionTypes = [
    {'key': 'mcq', 'label': 'MCQ', 'icon': Icons.radio_button_checked_rounded},
    {'key': 'short_answer', 'label': 'Short Answer', 'icon': Icons.short_text_rounded},
    {'key': 'long_form', 'label': 'Essay', 'icon': Icons.article_rounded},
    {'key': 'mixed', 'label': 'Mixed', 'icon': Icons.shuffle_rounded},
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _loadExistingQuestions();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _loadExistingQuestions() async {
    final maps = await DatabaseHelper.instance.getExamQuestions(widget.document.id);
    setState(() => _questions = maps.map(ExamQuestionModel.fromMap).toList());
  }

  Future<void> _generateQuestions() async {
    final user = context.read<AppProvider>().user!;
    setState(() { _isGenerating = true; });

    try {
      final data = await AIService.instance.generateExamQuestions(
        content: widget.document.content,
        documentTitle: widget.document.title,
        questionType: _questionType,
        count: _questionCount,
      );

      final questions = data.map((q) {
        final options = q['options'];
        return ExamQuestionModel(
          id: const Uuid().v4(),
          documentId: widget.document.id,
          userId: user.id,
          questionText: q['question_text'] as String,
          questionType: q['question_type'] as String,
          options: options != null ? List<String>.from(options) : null,
          correctAnswer: q['correct_answer'] as String,
          modelAnswer: q['model_answer'] as String?,
          difficulty: q['difficulty'] as String? ?? 'medium',
          topic: q['topic'] as String?,
          createdAt: DateTime.now(),
        );
      }).toList();

      await DatabaseHelper.instance.insertExamQuestions(questions.map((q) => q.toMap()).toList());
      await _loadExistingQuestions();
      _userAnswers.clear();
      _evaluations.clear();
      _submitted = false;

      if (mounted) setState(() => _isGenerating = false);
      _tabController.animateTo(1);
    } catch (e) {
      if (mounted) {
        setState(() => _isGenerating = false);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e'), backgroundColor: AppColors.hard));
      }
    }
  }

  Future<void> _submitExam() async {
    final user = context.read<AppProvider>().user!;
    setState(() => _submitted = true);

    for (final question in _questions) {
      final userAnswer = _userAnswers[question.id] ?? '';
      Map<String, dynamic> eval;

      if (question.questionType == 'mcq') {
        final isCorrect = userAnswer.trim().toLowerCase() == question.correctAnswer.trim().toLowerCase();
        eval = {
          'is_correct': isCorrect,
          'score': isCorrect ? 100 : 0,
          'feedback': isCorrect ? 'Correct!' : 'Incorrect. The correct answer is: ${question.correctAnswer}',
          'missed_points': [],
          'correct_points': [],
        };
      } else {
        try {
          eval = await AIService.instance.evaluateAnswer(
            question: question.questionText,
            userAnswer: userAnswer,
            correctAnswer: question.correctAnswer,
            modelAnswer: question.modelAnswer ?? '',
            questionType: question.questionType,
          );
        } catch (e) {
          eval = {
            'is_correct': false,
            'score': 0,
            'feedback': 'Could not evaluate automatically',
            'missed_points': [],
            'correct_points': [],
          };
        }
      }

      _evaluations[question.id] = eval;

      await DatabaseHelper.instance.insertExamAttempt({
        'id': const Uuid().v4(),
        'question_id': question.id,
        'user_id': user.id,
        'user_answer': userAnswer,
        'is_correct': (eval['is_correct'] ?? false) ? 1 : 0,
        'attempted_at': DateTime.now().toIso8601String(),
      });
    }

    setState(() {});
  }

  int get _totalScore {
    if (_evaluations.isEmpty) return 0;
    final total = _evaluations.values.fold<int>(0, (sum, eval) => sum + (eval['score'] as int? ?? 0));
    return total ~/ _evaluations.length;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Exam Preparation'),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: AppColors.primary,
          labelColor: AppColors.primary,
          unselectedLabelColor: AppColors.textSecondary,
          tabs: const [Tab(text: 'Generate'), Tab(text: 'Practice')],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [_buildGenerateTab(), _buildPracticeTab()],
      ),
    );
  }

  Widget _buildGenerateTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(gradient: const LinearGradient(colors: AppColors.gradientOrange), borderRadius: BorderRadius.circular(16)),
            child: Row(
              children: [
                const Icon(Icons.quiz_rounded, color: Colors.white),
                const SizedBox(width: 10),
                Expanded(child: Text(widget.document.title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontFamily: 'Poppins'), maxLines: 1, overflow: TextOverflow.ellipsis)),
              ],
            ),
          ),
          const SizedBox(height: 24),

          const Text('Question Type', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600, fontFamily: 'Poppins')),
          const SizedBox(height: 12),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            childAspectRatio: 2,
            children: _questionTypes.map((type) {
              final isSelected = _questionType == type['key'];
              return GestureDetector(
                onTap: () => setState(() => _questionType = type['key'] as String),
                child: Container(
                  decoration: BoxDecoration(
                    color: isSelected ? AppColors.primaryLight : AppColors.surface,
                    border: Border.all(color: isSelected ? AppColors.primary : AppColors.surfaceAlt, width: 2),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(type['icon'] as IconData, color: isSelected ? AppColors.primary : AppColors.textHint, size: 20),
                      const SizedBox(width: 8),
                      Text(type['label'] as String, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: isSelected ? AppColors.primary : AppColors.textSecondary, fontFamily: 'Poppins')),
                    ],
                  ),
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 20),

          Row(
            children: [
              const Text('Questions: ', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600, fontFamily: 'Poppins')),
              Text('$_questionCount', style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: AppColors.primary, fontFamily: 'Poppins')),
            ],
          ),
          Slider(value: _questionCount.toDouble(), min: 5, max: 20, divisions: 3, activeColor: AppColors.primary, onChanged: (v) => setState(() => _questionCount = v.toInt())),
          const SizedBox(height: 12),

          GradientButton(
            text: 'Generate Questions',
            icon: Icons.auto_awesome_rounded,
            colors: AppColors.gradientOrange,
            isLoading: _isGenerating,
            onPressed: _generateQuestions,
          ),

          if (_isGenerating) const Padding(padding: EdgeInsets.all(16), child: AIThinkingIndicator()),
        ],
      ),
    );
  }

  Widget _buildPracticeTab() {
    if (_questions.isEmpty) {
      return const EmptyState(icon: Icons.quiz_rounded, title: 'No questions yet', subtitle: 'Generate exam questions first from the Generate tab');
    }

    return Column(
      children: [
        if (_submitted) _buildScoreHeader(),
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: _questions.length,
            itemBuilder: (ctx, index) => _buildQuestionCard(_questions[index], index),
          ),
        ),
        if (!_submitted)
          Padding(
            padding: const EdgeInsets.all(16),
            child: GradientButton(
              text: 'Submit Exam',
              colors: AppColors.gradientOrange,
              onPressed: () async {
                if (_userAnswers.length < _questions.length) {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please answer all questions first')));
                  return;
                }
                await _submitExam();
              },
            ),
          ),
      ],
    );
  }

  Widget _buildScoreHeader() {
    final score = _totalScore;
    final color = score >= 70 ? AppColors.easy : score >= 50 ? AppColors.warning : AppColors.hard;
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(16), border: Border.all(color: color.withOpacity(0.3))),
      child: Row(
        children: [
          Icon(score >= 70 ? Icons.emoji_events_rounded : Icons.insights_rounded, color: color, size: 32),
          const SizedBox(width: 16),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Score: $score%', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: color, fontFamily: 'Poppins')),
              Text('${_evaluations.values.where((e) => e['is_correct'] == true).length}/${_questions.length} correct', style: const TextStyle(color: AppColors.textSecondary, fontFamily: 'Poppins')),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildQuestionCard(ExamQuestionModel question, int index) {
    final eval = _evaluations[question.id];
    final isCorrect = eval?['is_correct'] == true;
    Color? borderColor;
    if (_submitted && eval != null) borderColor = isCorrect ? AppColors.easy : AppColors.hard;

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderColor ?? AppColors.surfaceAlt, width: borderColor != null ? 2 : 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text('Q${index + 1}', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.primary, fontFamily: 'Poppins')),
              const SizedBox(width: 8),
              DifficultyBadge(difficulty: question.difficulty),
              const Spacer(),
              if (question.topic != null) Text(question.topic!, style: const TextStyle(fontSize: 11, color: AppColors.textHint, fontFamily: 'Poppins')),
            ],
          ),
          const SizedBox(height: 12),
          Text(question.questionText, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: AppColors.textPrimary, fontFamily: 'Poppins', height: 1.4)),
          const SizedBox(height: 12),

          if (question.questionType == 'mcq' && question.options != null)
            ...question.options!.map((option) {
              final isSelected = _userAnswers[question.id] == option;
              final isCorrectOption = _submitted && option == question.correctAnswer;
              Color optionColor = isCorrectOption ? AppColors.easy : (isSelected && _submitted && !isCorrect) ? AppColors.hard : isSelected ? AppColors.primary : AppColors.surfaceAlt;

              return GestureDetector(
                onTap: _submitted ? null : () => setState(() => _userAnswers[question.id] = option),
                child: Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: (isSelected || isCorrectOption) ? optionColor.withOpacity(0.1) : AppColors.surfaceAlt,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: (isSelected || isCorrectOption) ? optionColor : Colors.transparent, width: 2),
                  ),
                  child: Text(option, style: TextStyle(fontSize: 13, color: (isSelected || isCorrectOption) ? optionColor : AppColors.textPrimary, fontFamily: 'Poppins', fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal)),
                ),
              );
            }),

          if (question.questionType != 'mcq')
            TextField(
              enabled: !_submitted,
              maxLines: question.questionType == 'long_form' ? 6 : 3,
              decoration: InputDecoration(hintText: question.questionType == 'long_form' ? 'Write your essay answer here...' : 'Write your answer here...'),
              onChanged: (v) => _userAnswers[question.id] = v,
            ),

          if (_submitted && eval != null) ...[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: (eval['is_correct'] == true ? AppColors.easy : AppColors.hard).withOpacity(0.08), borderRadius: BorderRadius.circular(10)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(eval['is_correct'] == true ? Icons.check_circle_rounded : Icons.cancel_rounded, color: eval['is_correct'] == true ? AppColors.easy : AppColors.hard, size: 16),
                      const SizedBox(width: 6),
                      Text(eval['is_correct'] == true ? 'Correct!' : 'Incorrect', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: eval['is_correct'] == true ? AppColors.easy : AppColors.hard, fontFamily: 'Poppins')),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(eval['feedback'] as String? ?? '', style: const TextStyle(fontSize: 12, color: AppColors.textSecondary, fontFamily: 'Poppins')),
                  if (question.modelAnswer != null) ...[
                    const SizedBox(height: 8),
                    const Text('Model Answer:', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.textPrimary, fontFamily: 'Poppins')),
                    Text(question.modelAnswer!, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary, fontFamily: 'Poppins', height: 1.5)),
                  ],
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}
