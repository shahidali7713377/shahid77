import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../core/constants/app_colors.dart';
import '../../core/services/app_provider.dart';
import '../../core/database/database_helper.dart';
import '../../widgets/common_widgets.dart';
import '../documents/documents_screen.dart';
import '../summaries/summary_screen.dart';
import '../flashcards/flashcards_screen.dart';
import '../exam/exam_screen.dart';
import '../chat/chat_screen.dart';
import '../../core/models/models.dart';

class HomeDashboard extends StatefulWidget {
  const HomeDashboard({super.key});

  @override
  State<HomeDashboard> createState() => _HomeDashboardState();
}

class _HomeDashboardState extends State<HomeDashboard> {
  Map<String, dynamic> _analytics = {};
  List<Map<String, dynamic>> _todaySessions = [];
  bool _loadingAnalytics = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final provider = context.read<AppProvider>();
    if (provider.user == null) return;

    final analytics = await DatabaseHelper.instance.getAnalyticsSummary(provider.user!.id);
    final today = DateFormat('yyyy-MM-dd').format(DateTime.now());
    final sessions = await DatabaseHelper.instance.getStudySessions(provider.user!.id, date: today);

    if (mounted) {
      setState(() {
        _analytics = analytics;
        _todaySessions = sessions;
        _loadingAnalytics = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AppProvider>().user;
    final docs = context.watch<AppProvider>().documents;
    final hour = DateTime.now().hour;
    final greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';

    return Scaffold(
      body: RefreshIndicator(
        onRefresh: _loadData,
        color: AppColors.primary,
        child: CustomScrollView(
          slivers: [
            SliverAppBar(
              expandedHeight: 180,
              pinned: true,
              backgroundColor: AppColors.background,
              flexibleSpace: FlexibleSpaceBar(
                background: Container(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: AppColors.gradientPurple,
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                  ),
                  padding: const EdgeInsets.fromLTRB(20, 60, 20, 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                '$greeting! 👋',
                                style: const TextStyle(color: Colors.white70, fontSize: 14, fontFamily: 'Poppins'),
                              ),
                              Text(
                                user?.fullName ?? 'Student',
                                style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w700, fontFamily: 'Poppins'),
                              ),
                            ],
                          ),
                          CircleAvatar(
                            radius: 24,
                            backgroundColor: Colors.white.withOpacity(0.3),
                            child: Text(
                              (user?.fullName?.isNotEmpty == true ? user!.fullName![0] : 'S').toUpperCase(),
                              style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w700),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Text(
                        '${docs.length} documents · ${_analytics['total_flashcards'] ?? 0} flashcards',
                        style: const TextStyle(color: Colors.white70, fontSize: 13, fontFamily: 'Poppins'),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            SliverPadding(
              padding: const EdgeInsets.all(20),
              sliver: SliverList(
                delegate: SliverChildListDelegate([
                  // Quick Stats
                  _buildStatsRow(),
                  const SizedBox(height: 28),

                  // Today's Plan
                  if (_todaySessions.isNotEmpty) ...[
                    const SectionHeader(title: "Today's Sessions"),
                    const SizedBox(height: 12),
                    _buildTodaySessions(),
                    const SizedBox(height: 28),
                  ],

                  // Feature Grid
                  const SectionHeader(title: 'AI Features'),
                  const SizedBox(height: 12),
                  _buildFeatureGrid(),
                  const SizedBox(height: 28),

                  // Recent Documents
                  SectionHeader(
                    title: 'Recent Materials',
                    actionText: 'See All',
                    onAction: () {},
                  ),
                  const SizedBox(height: 12),
                  if (docs.isEmpty)
                    EmptyState(
                      icon: Icons.upload_file_rounded,
                      title: 'No materials yet',
                      subtitle: 'Upload PDFs, images or type notes to get started',
                      buttonText: 'Upload Material',
                      onButton: () {},
                    )
                  else
                    ...docs.take(3).map((doc) => _buildDocCard(doc)),
                  const SizedBox(height: 20),
                ]),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatsRow() {
    final totalMin = (_analytics['total_study_minutes'] ?? 0) as int;
    final hours = totalMin ~/ 60;
    final cards = (_analytics['total_flashcards'] ?? 0) as int;
    final examTotal = (_analytics['exam_total'] ?? 0) as int;
    final examCorrect = (_analytics['exam_correct'] ?? 0) as int;
    final accuracy = examTotal > 0 ? (examCorrect / examTotal * 100).toInt() : 0;

    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisSpacing: 12,
      mainAxisSpacing: 12,
      childAspectRatio: 1.5,
      children: [
        StatCard(label: 'Study Hours', value: '${hours}h', icon: Icons.timer_rounded, color: AppColors.primary),
        StatCard(label: 'Flashcards', value: '$cards', icon: Icons.style_rounded, color: AppColors.secondary),
        StatCard(label: 'Accuracy', value: '$accuracy%', icon: Icons.track_changes_rounded, color: AppColors.warning),
        StatCard(label: 'Documents', value: '${_analytics['total_documents'] ?? 0}', icon: Icons.description_rounded, color: AppColors.accent),
      ],
    );
  }

  Widget _buildTodaySessions() {
    return Column(
      children: _todaySessions.map((session) {
        final status = session['status'] as String;
        Color statusColor;
        IconData statusIcon;
        switch (status) {
          case 'completed':
            statusColor = AppColors.easy;
            statusIcon = Icons.check_circle_rounded;
            break;
          case 'in_progress':
            statusColor = AppColors.warning;
            statusIcon = Icons.play_circle_rounded;
            break;
          case 'missed':
            statusColor = AppColors.hard;
            statusIcon = Icons.cancel_rounded;
            break;
          default:
            statusColor = AppColors.textHint;
            statusIcon = Icons.radio_button_unchecked;
        }

        return Container(
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.surfaceAlt),
          ),
          child: Row(
            children: [
              Icon(statusIcon, color: statusColor, size: 20),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(session['subject'] as String, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: AppColors.textPrimary, fontFamily: 'Poppins')),
                    if (session['topic'] != null)
                      Text(session['topic'] as String, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary, fontFamily: 'Poppins')),
                  ],
                ),
              ),
              Text(
                '${session['duration_minutes'] ?? 60} min',
                style: const TextStyle(fontSize: 12, color: AppColors.textSecondary, fontFamily: 'Poppins'),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }

  Widget _buildFeatureGrid() {
    final features = [
      {'title': 'Smart Summary', 'subtitle': 'AI-powered notes', 'icon': Icons.auto_awesome_rounded, 'colors': AppColors.gradientPurple, 'screen': 'summary'},
      {'title': 'Flashcards', 'subtitle': 'Spaced repetition', 'icon': Icons.style_rounded, 'colors': AppColors.gradientTeal, 'screen': 'flashcards'},
      {'title': 'Exam Prep', 'subtitle': 'Predicted questions', 'icon': Icons.quiz_rounded, 'colors': AppColors.gradientOrange, 'screen': 'exam'},
      {'title': 'AI Tutor', 'subtitle': 'Ask anything', 'icon': Icons.chat_bubble_rounded, 'colors': AppColors.gradientBlue, 'screen': 'chat'},
    ];

    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisSpacing: 12,
      mainAxisSpacing: 12,
      childAspectRatio: 0.9,
      children: features.map((f) => FeatureCard(
        title: f['title'] as String,
        subtitle: f['subtitle'] as String,
        icon: f['icon'] as IconData,
        colors: f['colors'] as List<Color>,
        onTap: () {
          final docs = context.read<AppProvider>().documents;
          if (docs.isEmpty) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Upload a document first!'), backgroundColor: AppColors.warning),
            );
            return;
          }
          Widget screen;
          switch (f['screen']) {
            case 'summary':
              screen = SummaryScreen(document: docs.first);
              break;
            case 'flashcards':
              screen = const FlashcardsScreen();
              break;
            case 'exam':
              screen = ExamScreen(document: docs.first);
              break;
            case 'chat':
              screen = ChatScreen(document: docs.first);
              break;
            default:
              return;
          }
          Navigator.push(context, MaterialPageRoute(builder: (_) => screen));
        },
      )).toList(),
    );
  }

  Widget _buildDocCard(DocumentModel doc) {
    final iconMap = {'pdf': Icons.picture_as_pdf_rounded, 'image': Icons.image_rounded, 'text': Icons.text_snippet_rounded};
    final colorMap = {'pdf': AppColors.hard, 'image': AppColors.secondary, 'text': AppColors.primary};

    return GestureDetector(
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SummaryScreen(document: doc))),
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.surfaceAlt),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: (colorMap[doc.fileType] ?? AppColors.primary).withOpacity(0.1),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(iconMap[doc.fileType] ?? Icons.description_rounded, color: colorMap[doc.fileType] ?? AppColors.primary, size: 22),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(doc.title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: AppColors.textPrimary, fontFamily: 'Poppins'), maxLines: 1, overflow: TextOverflow.ellipsis),
                  Text(doc.contentPreview, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary, fontFamily: 'Poppins'), maxLines: 1, overflow: TextOverflow.ellipsis),
                ],
              ),
            ),
            const Icon(Icons.chevron_right_rounded, color: AppColors.textHint),
          ],
        ),
      ),
    );
  }
}
