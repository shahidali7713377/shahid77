import 'dart:math';
import 'package:flutter/material.dart';
import '../../core/constants/app_colors.dart';
import '../../core/models/models.dart';
import '../../core/services/spaced_repetition_service.dart';
import '../../widgets/common_widgets.dart';

class FlashcardStudyScreen extends StatefulWidget {
  final List<FlashcardModel> flashcards;
  const FlashcardStudyScreen({super.key, required this.flashcards});

  @override
  State<FlashcardStudyScreen> createState() => _FlashcardStudyScreenState();
}

class _FlashcardStudyScreenState extends State<FlashcardStudyScreen> with SingleTickerProviderStateMixin {
  late List<FlashcardModel> _cards;
  int _currentIndex = 0;
  bool _showAnswer = false;
  bool _isCompleted = false;
  int _correctCount = 0;
  late AnimationController _flipController;
  late Animation<double> _flipAnimation;

  @override
  void initState() {
    super.initState();
    _cards = List.from(widget.flashcards)..shuffle(Random());
    _flipController = AnimationController(vsync: this, duration: const Duration(milliseconds: 400));
    _flipAnimation = TweenSequence([
      TweenSequenceItem(tween: Tween(begin: 0.0, end: pi / 2).chain(CurveTween(curve: Curves.easeIn)), weight: 50),
      TweenSequenceItem(tween: Tween(begin: -pi / 2, end: 0.0).chain(CurveTween(curve: Curves.easeOut)), weight: 50),
    ]).animate(_flipController);
  }

  @override
  void dispose() {
    _flipController.dispose();
    super.dispose();
  }

  void _flipCard() {
    if (!_showAnswer) {
      _flipController.forward(from: 0);
      setState(() => _showAnswer = true);
    }
  }

  Future<void> _rateCard(int quality) async {
    final card = _cards[_currentIndex];
    final updated = SpacedRepetitionService.instance.updateCard(card, quality);
    await SpacedRepetitionService.instance.recordReview(updated, quality);

    if (quality >= 3) _correctCount++;

    if (_currentIndex < _cards.length - 1) {
      setState(() {
        _currentIndex++;
        _showAnswer = false;
      });
      _flipController.reset();
    } else {
      setState(() => _isCompleted = true);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isCompleted) return _buildCompletionScreen();

    final card = _cards[_currentIndex];
    final progress = (_currentIndex + 1) / _cards.length;

    return Scaffold(
      appBar: AppBar(
        title: Text('${_currentIndex + 1} / ${_cards.length}'),
        actions: [
          TextButton(
            onPressed: () => setState(() => _isCompleted = true),
            child: const Text('Finish', style: TextStyle(color: AppColors.primary, fontFamily: 'Poppins')),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            // Progress bar
            LinearProgressIndicator(
              value: progress,
              backgroundColor: AppColors.surfaceAlt,
              valueColor: const AlwaysStoppedAnimation<Color>(AppColors.primary),
              minHeight: 6,
              borderRadius: BorderRadius.circular(3),
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('${(_currentIndex).toInt()} done', style: const TextStyle(fontSize: 12, color: AppColors.textSecondary, fontFamily: 'Poppins')),
                DifficultyBadge(difficulty: card.difficulty),
                Text('${_cards.length - _currentIndex - 1} remaining', style: const TextStyle(fontSize: 12, color: AppColors.textSecondary, fontFamily: 'Poppins')),
              ],
            ),
            const SizedBox(height: 24),

            // Flashcard
            Expanded(
              child: GestureDetector(
                onTap: _flipCard,
                child: AnimatedBuilder(
                  animation: _flipAnimation,
                  builder: (ctx, child) {
                    return Transform(
                      alignment: Alignment.center,
                      transform: Matrix4.identity()..rotateY(_flipAnimation.value),
                      child: _showAnswer && _flipController.value >= 0.5
                          ? _buildCardFace(card.answer, isAnswer: true, topic: card.topic)
                          : _buildCardFace(card.question, isAnswer: false),
                    );
                  },
                ),
              ),
            ),
            const SizedBox(height: 20),

            if (!_showAnswer)
              GestureDetector(
                onTap: _flipCard,
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    border: Border.all(color: AppColors.primary, width: 2),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.touch_app_rounded, color: AppColors.primary, size: 20),
                      SizedBox(width: 8),
                      Text('Tap to reveal answer', style: TextStyle(color: AppColors.primary, fontWeight: FontWeight.w600, fontFamily: 'Poppins')),
                    ],
                  ),
                ),
              ),

            if (_showAnswer) ...[
              const Text('How well did you know this?', style: TextStyle(fontSize: 14, color: AppColors.textSecondary, fontFamily: 'Poppins')),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(child: _ratingButton('Again', AppColors.hard, 1)),
                  const SizedBox(width: 8),
                  Expanded(child: _ratingButton('Hard', AppColors.warning, 2)),
                  const SizedBox(width: 8),
                  Expanded(child: _ratingButton('Good', AppColors.secondary, 4)),
                  const SizedBox(width: 8),
                  Expanded(child: _ratingButton('Easy', AppColors.easy, 5)),
                ],
              ),
            ],
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  Widget _buildCardFace(String text, {required bool isAnswer, String? topic}) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: isAnswer ? AppColors.secondaryLight : AppColors.primaryLight,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: isAnswer ? AppColors.secondary : AppColors.primary, width: 2),
        boxShadow: [BoxShadow(color: (isAnswer ? AppColors.secondary : AppColors.primary).withOpacity(0.2), blurRadius: 20, offset: const Offset(0, 8))],
      ),
      padding: const EdgeInsets.all(28),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            decoration: BoxDecoration(
              color: (isAnswer ? AppColors.secondary : AppColors.primary).withOpacity(0.15),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              isAnswer ? 'ANSWER' : 'QUESTION',
              style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: isAnswer ? AppColors.secondary : AppColors.primary, letterSpacing: 1.5, fontFamily: 'Poppins'),
            ),
          ),
          const SizedBox(height: 24),
          Text(
            text,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600, color: AppColors.textPrimary, fontFamily: 'Poppins', height: 1.5),
            textAlign: TextAlign.center,
          ),
          if (topic != null) ...[
            const SizedBox(height: 16),
            Text(topic, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary, fontFamily: 'Poppins')),
          ],
        ],
      ),
    );
  }

  Widget _ratingButton(String label, Color color, int quality) {
    return GestureDetector(
      onTap: () => _rateCard(quality),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: color.withOpacity(0.12),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Text(label, textAlign: TextAlign.center, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: color, fontFamily: 'Poppins')),
      ),
    );
  }

  Widget _buildCompletionScreen() {
    final accuracy = _cards.isNotEmpty ? (_correctCount / _cards.length * 100).toInt() : 0;
    return Scaffold(
      appBar: AppBar(title: const Text('Session Complete')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(28),
                decoration: const BoxDecoration(color: AppColors.primaryLight, shape: BoxShape.circle),
                child: const Icon(Icons.emoji_events_rounded, size: 56, color: AppColors.primary),
              ),
              const SizedBox(height: 24),
              const Text('Session Complete! 🎉', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w700, color: AppColors.textPrimary, fontFamily: 'Poppins')),
              const SizedBox(height: 8),
              Text('You reviewed ${_cards.length} flashcards', style: const TextStyle(color: AppColors.textSecondary, fontFamily: 'Poppins')),
              const SizedBox(height: 32),
              _statRow('Cards Reviewed', '${_cards.length}', Icons.style_rounded, AppColors.primary),
              _statRow('Correct Answers', '$_correctCount', Icons.check_circle_rounded, AppColors.easy),
              _statRow('Accuracy Rate', '$accuracy%', Icons.track_changes_rounded, AppColors.warning),
              const SizedBox(height: 32),
              GradientButton(text: 'Study Again', icon: Icons.refresh_rounded, onPressed: () {
                setState(() {
                  _cards.shuffle(Random());
                  _currentIndex = 0;
                  _showAnswer = false;
                  _isCompleted = false;
                  _correctCount = 0;
                });
              }),
              const SizedBox(height: 12),
              TextButton(onPressed: () => Navigator.pop(context), child: const Text('Back to Flashcards', style: TextStyle(color: AppColors.textSecondary, fontFamily: 'Poppins'))),
            ],
          ),
        ),
      ),
    );
  }

  Widget _statRow(String label, String value, IconData icon, Color color) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.surfaceAlt)),
      child: Row(
        children: [
          Icon(icon, color: color, size: 20),
          const SizedBox(width: 12),
          Text(label, style: const TextStyle(fontSize: 14, color: AppColors.textSecondary, fontFamily: 'Poppins')),
          const Spacer(),
          Text(value, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: color, fontFamily: 'Poppins')),
        ],
      ),
    );
  }
}
