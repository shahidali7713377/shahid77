import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../core/models/models.dart';
import '../../core/services/app_provider.dart';
import '../../core/services/spaced_repetition_service.dart';
import '../../core/database/database_helper.dart';
import '../../widgets/common_widgets.dart';
import 'flashcard_study_screen.dart';
import 'flashcard_generator_screen.dart';

class FlashcardsScreen extends StatefulWidget {
  const FlashcardsScreen({super.key});

  @override
  State<FlashcardsScreen> createState() => _FlashcardsScreenState();
}

class _FlashcardsScreenState extends State<FlashcardsScreen> {
  List<FlashcardModel> _dueCards = [];
  List<FlashcardModel> _allCards = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadCards();
  }

  Future<void> _loadCards() async {
    final user = context.read<AppProvider>().user;
    if (user == null) return;

    final due = await SpacedRepetitionService.instance.getDueCards(user.id);
    final allMaps = await DatabaseHelper.instance.getAllUserFlashcards(user.id);
    final all = allMaps.map(FlashcardModel.fromMap).toList();

    if (mounted) {
      setState(() {
        _dueCards = due;
        _allCards = all;
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final docs = context.watch<AppProvider>().documents;

    return Scaffold(
      appBar: AppBar(title: const Text('Flashcards')),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: AppColors.primary))
          : RefreshIndicator(
              onRefresh: _loadCards,
              color: AppColors.primary,
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // Stats row
                    Row(
                      children: [
                        Expanded(child: StatCard(label: 'Total Cards', value: '${_allCards.length}', icon: Icons.style_rounded, color: AppColors.primary)),
                        const SizedBox(width: 12),
                        Expanded(child: StatCard(label: 'Due Today', value: '${_dueCards.length}', icon: Icons.today_rounded, color: _dueCards.isEmpty ? AppColors.easy : AppColors.warning)),
                      ],
                    ),
                    const SizedBox(height: 24),

                    // Due cards CTA
                    if (_dueCards.isNotEmpty) ...[
                      Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(colors: AppColors.gradientOrange),
                          borderRadius: BorderRadius.circular(18),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                const Icon(Icons.notifications_active_rounded, color: Colors.white, size: 20),
                                const SizedBox(width: 8),
                                Text('${_dueCards.length} cards due for review!', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontFamily: 'Poppins')),
                              ],
                            ),
                            const SizedBox(height: 12),
                            GestureDetector(
                              onTap: () async {
                                await Navigator.push(context, MaterialPageRoute(builder: (_) => FlashcardStudyScreen(flashcards: _dueCards)));
                                _loadCards();
                              },
                              child: Container(
                                padding: const EdgeInsets.symmetric(vertical: 12),
                                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12)),
                                child: const Center(child: Text('Start Review Session', style: TextStyle(color: AppColors.accent, fontWeight: FontWeight.w700, fontFamily: 'Poppins'))),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 24),
                    ],

                    if (_allCards.isEmpty && _dueCards.isEmpty) ...[
                      EmptyState(
                        icon: Icons.style_rounded,
                        title: 'No flashcards yet',
                        subtitle: 'Generate flashcards from your study documents',
                        buttonText: docs.isNotEmpty ? 'Generate from Document' : null,
                        onButton: docs.isNotEmpty ? () => Navigator.push(context, MaterialPageRoute(builder: (_) => FlashcardGeneratorScreen(document: docs.first))) : null,
                      ),
                    ] else ...[
                      SectionHeader(
                        title: 'All Flashcards (${_allCards.length})',
                        actionText: _allCards.isNotEmpty ? 'Study All' : null,
                        onAction: () async {
                          await Navigator.push(context, MaterialPageRoute(builder: (_) => FlashcardStudyScreen(flashcards: _allCards)));
                          _loadCards();
                        },
                      ),
                      const SizedBox(height: 12),
                      ..._buildCardsByDifficulty(),
                    ],

                    if (docs.isNotEmpty) ...[
                      const SizedBox(height: 24),
                      OutlinedButton.icon(
                        onPressed: () async {
                          await Navigator.push(context, MaterialPageRoute(builder: (_) => FlashcardGeneratorScreen(document: docs.first)));
                          _loadCards();
                        },
                        icon: const Icon(Icons.add_rounded, color: AppColors.primary),
                        label: const Text('Generate More Cards', style: TextStyle(color: AppColors.primary, fontFamily: 'Poppins', fontWeight: FontWeight.w600)),
                        style: OutlinedButton.styleFrom(side: const BorderSide(color: AppColors.primary), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)), padding: const EdgeInsets.symmetric(vertical: 14)),
                      ),
                    ],
                  ],
                ),
              ),
            ),
    );
  }

  List<Widget> _buildCardsByDifficulty() {
    final byDiff = <String, List<FlashcardModel>>{};
    for (final card in _allCards) {
      byDiff.putIfAbsent(card.difficulty, () => []).add(card);
    }

    final result = <Widget>[];
    for (final entry in byDiff.entries) {
      final color = entry.key == 'easy' ? AppColors.easy : entry.key == 'hard' ? AppColors.hard : AppColors.medium;
      result.add(
        Container(
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.surfaceAlt)),
          child: Row(
            children: [
              DifficultyBadge(difficulty: entry.key),
              const SizedBox(width: 12),
              Text('${entry.value.length} cards', style: const TextStyle(fontSize: 14, color: AppColors.textSecondary, fontFamily: 'Poppins')),
              const Spacer(),
              GestureDetector(
                onTap: () async {
                  await Navigator.push(context, MaterialPageRoute(builder: (_) => FlashcardStudyScreen(flashcards: entry.value)));
                  _loadCards();
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(color: color.withOpacity(0.12), borderRadius: BorderRadius.circular(8)),
                  child: Text('Study', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: color, fontFamily: 'Poppins')),
                ),
              ),
            ],
          ),
        ),
      );
    }
    return result;
  }
}
