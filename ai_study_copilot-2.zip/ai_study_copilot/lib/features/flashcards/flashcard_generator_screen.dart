import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';
import '../../core/constants/app_colors.dart';
import '../../core/models/models.dart';
import '../../core/services/ai_service.dart';
import '../../core/services/app_provider.dart';
import '../../core/database/database_helper.dart';
import '../../widgets/common_widgets.dart';
import 'flashcard_study_screen.dart';

class FlashcardGeneratorScreen extends StatefulWidget {
  final DocumentModel document;
  const FlashcardGeneratorScreen({super.key, required this.document});

  @override
  State<FlashcardGeneratorScreen> createState() => _FlashcardGeneratorScreenState();
}

class _FlashcardGeneratorScreenState extends State<FlashcardGeneratorScreen> {
  int _cardCount = 15;
  bool _isGenerating = false;
  List<FlashcardModel> _generatedCards = [];
  List<FlashcardModel> _existingCards = [];
  FlashcardModel? _editingCard;

  @override
  void initState() {
    super.initState();
    _loadExistingCards();
  }

  Future<void> _loadExistingCards() async {
    final maps = await DatabaseHelper.instance.getFlashcards(widget.document.id);
    setState(() => _existingCards = maps.map(FlashcardModel.fromMap).toList());
  }

  Future<void> _generateFlashcards() async {
    final user = context.read<AppProvider>().user!;
    setState(() { _isGenerating = true; _generatedCards = []; });

    try {
      final cardsData = await AIService.instance.generateFlashcards(
        content: widget.document.content,
        documentTitle: widget.document.title,
        count: _cardCount,
      );

      final cards = cardsData.map((data) => FlashcardModel(
        id: const Uuid().v4(),
        documentId: widget.document.id,
        userId: user.id,
        question: data['question'] as String,
        answer: data['answer'] as String,
        difficulty: data['difficulty'] as String? ?? 'medium',
        topic: data['topic'] as String?,
        createdAt: DateTime.now(),
      )).toList();

      await DatabaseHelper.instance.insertFlashcards(cards.map((c) => c.toMap()).toList());
      await _loadExistingCards();

      if (mounted) setState(() { _generatedCards = cards; _isGenerating = false; });
    } catch (e) {
      if (mounted) {
        setState(() => _isGenerating = false);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e'), backgroundColor: AppColors.hard));
      }
    }
  }

  void _showEditDialog(FlashcardModel card) {
    final qCtrl = TextEditingController(text: card.question);
    final aCtrl = TextEditingController(text: card.answer);
    String diff = card.difficulty;

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: const Text('Edit Flashcard', style: TextStyle(fontFamily: 'Poppins', fontWeight: FontWeight.w700)),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                AppTextField(label: 'Question', controller: qCtrl, maxLines: 3),
                const SizedBox(height: 12),
                AppTextField(label: 'Answer', controller: aCtrl, maxLines: 4),
                const SizedBox(height: 12),
                Row(
                  children: ['easy', 'medium', 'hard'].map((d) => Expanded(
                    child: GestureDetector(
                      onTap: () => setDialogState(() => diff = d),
                      child: Container(
                        margin: const EdgeInsets.symmetric(horizontal: 3),
                        padding: const EdgeInsets.symmetric(vertical: 8),
                        decoration: BoxDecoration(
                          color: diff == d ? (d == 'easy' ? AppColors.easy : d == 'medium' ? AppColors.medium : AppColors.hard) : AppColors.surfaceAlt,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(d.toUpperCase(), textAlign: TextAlign.center, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: diff == d ? Colors.white : AppColors.textSecondary, fontFamily: 'Poppins')),
                      ),
                    ),
                  )).toList(),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
            ElevatedButton(
              onPressed: () async {
                card.question = qCtrl.text;
                card.answer = aCtrl.text;
                card.difficulty = diff;
                card.isEdited = true;
                await DatabaseHelper.instance.updateFlashcard(card.id, card.toMap());
                if (mounted) { Navigator.pop(ctx); setState(() {}); }
              },
              child: const Text('Save'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Flashcard Generator'),
        actions: [
          if (_existingCards.isNotEmpty)
            TextButton.icon(
              icon: const Icon(Icons.play_arrow_rounded, color: AppColors.primary),
              label: const Text('Study', style: TextStyle(color: AppColors.primary, fontFamily: 'Poppins', fontWeight: FontWeight.w600)),
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => FlashcardStudyScreen(flashcards: _existingCards))),
            ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(gradient: const LinearGradient(colors: AppColors.gradientTeal), borderRadius: BorderRadius.circular(16)),
              child: Row(
                children: [
                  const Icon(Icons.style_rounded, color: Colors.white),
                  const SizedBox(width: 10),
                  Expanded(child: Text(widget.document.title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontFamily: 'Poppins'), maxLines: 1, overflow: TextOverflow.ellipsis)),
                ],
              ),
            ),
            const SizedBox(height: 24),

            Row(
              children: [
                const Text('Number of cards: ', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600, fontFamily: 'Poppins')),
                Text('$_cardCount', style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: AppColors.primary, fontFamily: 'Poppins')),
              ],
            ),
            Slider(
              value: _cardCount.toDouble(),
              min: 5,
              max: 30,
              divisions: 5,
              activeColor: AppColors.primary,
              onChanged: (v) => setState(() => _cardCount = v.toInt()),
            ),
            const SizedBox(height: 12),
            GradientButton(
              text: 'Generate ${_cardCount} Flashcards',
              icon: Icons.auto_awesome_rounded,
              colors: AppColors.gradientTeal,
              isLoading: _isGenerating,
              onPressed: _generateFlashcards,
            ),
            const SizedBox(height: 24),

            if (_isGenerating) const Center(child: AIThinkingIndicator()),

            if (_existingCards.isNotEmpty) ...[
              SectionHeader(
                title: 'All Flashcards (${_existingCards.length})',
                actionText: 'Study Now',
                onAction: () => Navigator.push(context, MaterialPageRoute(builder: (_) => FlashcardStudyScreen(flashcards: _existingCards))),
              ),
              const SizedBox(height: 12),
              ..._existingCards.map((card) => _buildCardTile(card)),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildCardTile(FlashcardModel card) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.surfaceAlt),
      ),
      child: Theme(
        data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
        child: ExpansionTile(
          tilePadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          leading: DifficultyBadge(difficulty: card.difficulty),
          title: Text(card.question, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: AppColors.textPrimary, fontFamily: 'Poppins')),
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(color: AppColors.secondaryLight, borderRadius: BorderRadius.circular(10)),
                    child: Text(card.answer, style: const TextStyle(fontSize: 13, color: AppColors.textPrimary, fontFamily: 'Poppins', height: 1.5)),
                  ),
                  const SizedBox(height: 8),
                  if (card.topic != null)
                    Text('Topic: ${card.topic}', style: const TextStyle(fontSize: 11, color: AppColors.textSecondary, fontFamily: 'Poppins')),
                  Align(
                    alignment: Alignment.centerRight,
                    child: TextButton.icon(
                      icon: const Icon(Icons.edit_rounded, size: 16),
                      label: const Text('Edit', style: TextStyle(fontFamily: 'Poppins')),
                      onPressed: () => _showEditDialog(card),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
