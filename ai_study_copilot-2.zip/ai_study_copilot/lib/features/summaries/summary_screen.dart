import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';
import '../../core/constants/app_colors.dart';
import '../../core/models/models.dart';
import '../../core/services/ai_service.dart';
import '../../core/services/app_provider.dart';
import '../../core/database/database_helper.dart';
import '../../widgets/common_widgets.dart';

class SummaryScreen extends StatefulWidget {
  final DocumentModel document;
  const SummaryScreen({super.key, required this.document});

  @override
  State<SummaryScreen> createState() => _SummaryScreenState();
}

class _SummaryScreenState extends State<SummaryScreen> {
  String _selectedType = 'medium';
  String? _summaryContent;
  bool _isGenerating = false;
  List<SummaryModel> _savedSummaries = [];

  final List<Map<String, dynamic>> _summaryTypes = [
    {'key': 'short', 'label': 'Short', 'icon': Icons.short_text_rounded, 'desc': '~300 words'},
    {'key': 'medium', 'label': 'Medium', 'icon': Icons.notes_rounded, 'desc': '~500 words'},
    {'key': 'detailed', 'label': 'Detailed', 'icon': Icons.article_rounded, 'desc': '~1000 words'},
    {'key': 'bullet', 'label': 'Bullet Points', 'icon': Icons.format_list_bulleted_rounded, 'desc': 'Key points'},
    {'key': 'concept', 'label': 'Concepts', 'icon': Icons.hub_rounded, 'desc': 'Core ideas'},
    {'key': 'eli5', 'label': 'ELI5', 'icon': Icons.child_care_rounded, 'desc': 'Simple language'},
  ];

  @override
  void initState() {
    super.initState();
    _loadSavedSummaries();
  }

  Future<void> _loadSavedSummaries() async {
    final summaries = await DatabaseHelper.instance.getSummaries(widget.document.id);
    setState(() => _savedSummaries = summaries.map(SummaryModel.fromMap).toList());
  }

  Future<void> _generateSummary() async {
    final user = context.read<AppProvider>().user;
    setState(() { _isGenerating = true; _summaryContent = null; });

    try {
      final content = await AIService.instance.generateSummary(
        content: widget.document.content,
        summaryType: _selectedType,
        educationLevel: user?.educationLevel ?? 'University',
      );

      final summary = SummaryModel(
        id: const Uuid().v4(),
        documentId: widget.document.id,
        userId: user!.id,
        summaryType: _selectedType,
        content: content,
        createdAt: DateTime.now(),
      );

      await DatabaseHelper.instance.insertSummary(summary.toMap());
      await _loadSavedSummaries();

      if (mounted) setState(() { _summaryContent = content; _isGenerating = false; });
    } catch (e) {
      if (mounted) {
        setState(() => _isGenerating = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: ${e.toString()}'), backgroundColor: AppColors.hard),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('AI Summary'),
        actions: [
          if (_summaryContent != null)
            IconButton(
              icon: const Icon(Icons.copy_rounded),
              onPressed: () {
                Clipboard.setData(ClipboardData(text: _summaryContent!));
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Copied to clipboard!')));
              },
            ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Document info
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: AppColors.gradientPurple),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Row(
                children: [
                  const Icon(Icons.description_rounded, color: Colors.white, size: 20),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(widget.document.title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontFamily: 'Poppins'), maxLines: 1, overflow: TextOverflow.ellipsis),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            const Text('Summary Type', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: AppColors.textPrimary, fontFamily: 'Poppins')),
            const SizedBox(height: 12),

            // Type selector
            GridView.count(
              crossAxisCount: 3,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
              childAspectRatio: 1.2,
              children: _summaryTypes.map((type) {
                final isSelected = _selectedType == type['key'];
                return GestureDetector(
                  onTap: () => setState(() => _selectedType = type['key'] as String),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    decoration: BoxDecoration(
                      color: isSelected ? AppColors.primaryLight : AppColors.surface,
                      border: Border.all(color: isSelected ? AppColors.primary : AppColors.surfaceAlt, width: 2),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(type['icon'] as IconData, color: isSelected ? AppColors.primary : AppColors.textHint, size: 24),
                        const SizedBox(height: 6),
                        Text(type['label'] as String, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: isSelected ? AppColors.primary : AppColors.textSecondary, fontFamily: 'Poppins')),
                        Text(type['desc'] as String, style: const TextStyle(fontSize: 10, color: AppColors.textHint, fontFamily: 'Poppins')),
                      ],
                    ),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 20),

            GradientButton(
              text: 'Generate Summary',
              icon: Icons.auto_awesome_rounded,
              isLoading: _isGenerating,
              onPressed: _generateSummary,
            ),
            const SizedBox(height: 24),

            if (_isGenerating)
              const Center(child: AIThinkingIndicator()),

            if (_summaryContent != null) ...[
              Row(
                children: [
                  const Icon(Icons.auto_awesome_rounded, color: AppColors.primary, size: 18),
                  const SizedBox(width: 8),
                  const Text('Generated Summary', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: AppColors.textPrimary, fontFamily: 'Poppins')),
                  const Spacer(),
                  Text(_selectedType.toUpperCase(), style: const TextStyle(fontSize: 11, color: AppColors.primary, fontWeight: FontWeight.w600, fontFamily: 'Poppins')),
                ],
              ),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppColors.primaryLight),
                  boxShadow: [BoxShadow(color: AppColors.primary.withOpacity(0.08), blurRadius: 12)],
                ),
                child: SelectableText(
                  _summaryContent!,
                  style: const TextStyle(fontSize: 14, color: AppColors.textPrimary, fontFamily: 'Poppins', height: 1.7),
                ),
              ),
            ],

            if (_savedSummaries.isNotEmpty) ...[
              const SizedBox(height: 28),
              const SectionHeader(title: 'Previous Summaries'),
              const SizedBox(height: 12),
              ..._savedSummaries.take(5).map((s) => GestureDetector(
                onTap: () => setState(() => _summaryContent = s.content),
                child: Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: AppColors.surfaceAlt),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.history_rounded, color: AppColors.textHint, size: 18),
                      const SizedBox(width: 10),
                      Text(s.summaryType.toUpperCase(), style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.primary, fontFamily: 'Poppins')),
                      const SizedBox(width: 10),
                      Text('${s.content.split(' ').length} words', style: const TextStyle(fontSize: 12, color: AppColors.textSecondary, fontFamily: 'Poppins')),
                      const Spacer(),
                      const Icon(Icons.chevron_right_rounded, color: AppColors.textHint, size: 18),
                    ],
                  ),
                ),
              )),
            ],
          ],
        ),
      ),
    );
  }
}
