import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:intl/intl.dart';
import '../../core/constants/app_colors.dart';
import '../../core/services/app_provider.dart';
import '../../core/services/ai_service.dart';
import '../../core/database/database_helper.dart';
import '../../widgets/common_widgets.dart';

class AnalyticsScreen extends StatefulWidget {
  const AnalyticsScreen({super.key});

  @override
  State<AnalyticsScreen> createState() => _AnalyticsScreenState();
}

class _AnalyticsScreenState extends State<AnalyticsScreen> {
  Map<String, dynamic> _analytics = {};
  Map<String, dynamic>? _aiInsights;
  List<Map<String, dynamic>> _weeklyPerformance = [];
  bool _loading = true;
  bool _loadingInsights = false;

  @override
  void initState() {
    super.initState();
    _loadAnalytics();
  }

  Future<void> _loadAnalytics() async {
    final user = context.read<AppProvider>().user;
    if (user == null) return;

    final analytics = await DatabaseHelper.instance.getAnalyticsSummary(user.id);
    
    // Get weekly session data
    final weekStart = DateTime.now().subtract(const Duration(days: 7));
    final sessions = await DatabaseHelper.instance.getStudySessions(user.id);
    
    // Group sessions by day for the past week
    final weeklyData = <Map<String, dynamic>>[];
    for (int i = 6; i >= 0; i--) {
      final date = DateTime.now().subtract(Duration(days: i));
      final dateStr = DateFormat('yyyy-MM-dd').format(date);
      final daySessions = sessions.where((s) {
        final sessionDate = DateFormat('yyyy-MM-dd').format(DateTime.parse(s['planned_date'] as String));
        return sessionDate == dateStr && s['status'] == 'completed';
      }).toList();
      final totalMinutes = daySessions.fold<int>(0, (sum, s) => sum + (s['duration_minutes'] as int? ?? 0));
      weeklyData.add({'day': DateFormat('EEE').format(date), 'minutes': totalMinutes});
    }

    if (mounted) {
      setState(() {
        _analytics = analytics;
        _weeklyPerformance = weeklyData;
        _loading = false;
      });
    }
  }

  Future<void> _getAIInsights() async {
    final user = context.read<AppProvider>().user!;
    setState(() => _loadingInsights = true);

    try {
      final attempts = await DatabaseHelper.instance.getExamAttempts(user.id);
      final reviews = await DatabaseHelper.instance.getFlashcards(user.id);

      final insights = await AIService.instance.analyzePerformance(
        examAttempts: attempts.take(30).map((a) => Map<String, dynamic>.from(a)).toList(),
        flashcardReviews: reviews.take(30).map((r) => Map<String, dynamic>.from(r)).toList(),
        subject: 'Overall',
      );

      if (mounted) setState(() { _aiInsights = insights; _loadingInsights = false; });
    } catch (e) {
      if (mounted) setState(() => _loadingInsights = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator(color: AppColors.primary));

    final totalMin = (_analytics['total_study_minutes'] ?? 0) as int;
    final hours = totalMin ~/ 60;
    final examTotal = (_analytics['exam_total'] ?? 1) as int;
    final examCorrect = (_analytics['exam_correct'] ?? 0) as int;
    final accuracy = examTotal > 0 ? (examCorrect / examTotal * 100).toInt() : 0;
    final flashcardReviews = (_analytics['flashcard_reviews'] ?? 0) as int;
    final avgQuality = (_analytics['avg_flashcard_quality'] ?? 0.0) as double;

    return Scaffold(
      appBar: AppBar(title: const Text('Analytics')),
      body: RefreshIndicator(
        onRefresh: _loadAnalytics,
        color: AppColors.primary,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Overview stats
              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                childAspectRatio: 1.4,
                children: [
                  StatCard(label: 'Study Hours', value: '${hours}h', icon: Icons.timer_rounded, color: AppColors.primary),
                  StatCard(label: 'Exam Accuracy', value: '$accuracy%', icon: Icons.track_changes_rounded, color: accuracy >= 70 ? AppColors.easy : accuracy >= 50 ? AppColors.warning : AppColors.hard),
                  StatCard(label: 'Cards Reviewed', value: '$flashcardReviews', icon: Icons.style_rounded, color: AppColors.secondary),
                  StatCard(label: 'Total Sessions', value: '${_analytics['total_sessions'] ?? 0}', icon: Icons.event_rounded, color: AppColors.warning),
                ],
              ),
              const SizedBox(height: 28),

              // Weekly study chart
              const SectionHeader(title: 'Weekly Study Activity'),
              const SizedBox(height: 16),
              Container(
                height: 200,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: AppColors.surfaceAlt),
                ),
                child: _weeklyPerformance.isEmpty
                    ? const Center(child: Text('No data yet', style: TextStyle(color: AppColors.textHint, fontFamily: 'Poppins')))
                    : BarChart(
                        BarChartData(
                          barGroups: _weeklyPerformance.asMap().entries.map((entry) {
                            final minutes = (entry.value['minutes'] as int).toDouble();
                            return BarChartGroupData(
                              x: entry.key,
                              barRods: [
                                BarChartRodData(
                                  toY: minutes / 60.0,
                                  gradient: const LinearGradient(colors: AppColors.gradientPurple, begin: Alignment.bottomCenter, end: Alignment.topCenter),
                                  width: 24,
                                  borderRadius: BorderRadius.circular(6),
                                ),
                              ],
                            );
                          }).toList(),
                          titlesData: FlTitlesData(
                            bottomTitles: AxisTitles(
                              sideTitles: SideTitles(
                                showTitles: true,
                                getTitlesWidget: (value, meta) {
                                  final idx = value.toInt();
                                  if (idx < _weeklyPerformance.length) {
                                    return Text(_weeklyPerformance[idx]['day'] as String, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary, fontFamily: 'Poppins'));
                                  }
                                  return const Text('');
                                },
                              ),
                            ),
                            leftTitles: AxisTitles(sideTitles: SideTitles(showTitles: true, getTitlesWidget: (v, m) => Text('${v.toInt()}h', style: const TextStyle(fontSize: 10, color: AppColors.textHint, fontFamily: 'Poppins')), reservedSize: 30)),
                            topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                            rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                          ),
                          gridData: FlGridData(drawVerticalLine: false, horizontalInterval: 1, getDrawingHorizontalLine: (v) => FlLine(color: AppColors.surfaceAlt, strokeWidth: 1)),
                          borderData: FlBorderData(show: false),
                        ),
                      ),
              ),
              const SizedBox(height: 28),

              // Retention meter
              if (flashcardReviews > 0) ...[
                const SectionHeader(title: 'Flashcard Retention'),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(18), border: Border.all(color: AppColors.surfaceAlt)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('${(avgQuality / 5 * 100).toInt()}%', style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w700, color: AppColors.secondary, fontFamily: 'Poppins')),
                                const Text('Retention Rate', style: TextStyle(color: AppColors.textSecondary, fontFamily: 'Poppins')),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 80,
                            height: 80,
                            child: CircularProgressIndicator(
                              value: avgQuality / 5,
                              backgroundColor: AppColors.surfaceAlt,
                              valueColor: const AlwaysStoppedAnimation<Color>(AppColors.secondary),
                              strokeWidth: 8,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Text('Based on $flashcardReviews card reviews', style: const TextStyle(fontSize: 12, color: AppColors.textHint, fontFamily: 'Poppins')),
                    ],
                  ),
                ),
                const SizedBox(height: 28),
              ],

              // AI Insights
              const SectionHeader(title: 'AI Learning Insights'),
              const SizedBox(height: 12),
              if (_aiInsights == null)
                GradientButton(
                  text: 'Analyze My Performance',
                  icon: Icons.psychology_rounded,
                  isLoading: _loadingInsights,
                  onPressed: _getAIInsights,
                )
              else ...[
                _buildInsightsCard(),
              ],
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInsightsCard() {
    final insights = _aiInsights!;
    final readiness = ((insights['estimated_readiness'] as double? ?? 0.5) * 100).toInt();
    final weakTopics = List<String>.from(insights['weak_topics'] ?? []);
    final recommendations = List<String>.from(insights['recommendations'] ?? []);

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.primaryLight, width: 2),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.psychology_rounded, color: AppColors.primary, size: 20),
              const SizedBox(width: 8),
              const Text('AI Analysis', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: AppColors.primary, fontFamily: 'Poppins')),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(color: AppColors.primaryLight, borderRadius: BorderRadius.circular(8)),
                child: Text('$readiness% Ready', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.primary, fontFamily: 'Poppins')),
              ),
            ],
          ),
          const SizedBox(height: 16),

          if (insights['overall_assessment'] != null) ...[
            Text(insights['overall_assessment'] as String, style: const TextStyle(fontSize: 14, color: AppColors.textPrimary, fontFamily: 'Poppins', height: 1.5)),
            const SizedBox(height: 16),
          ],

          if (weakTopics.isNotEmpty) ...[
            const Text('Areas to Focus On:', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textPrimary, fontFamily: 'Poppins')),
            const SizedBox(height: 8),
            Wrap(spacing: 8, runSpacing: 8, children: weakTopics.map((t) => Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(color: AppColors.hard.withOpacity(0.1), borderRadius: BorderRadius.circular(8), border: Border.all(color: AppColors.hard.withOpacity(0.3))),
              child: Text(t, style: const TextStyle(fontSize: 12, color: AppColors.hard, fontFamily: 'Poppins')),
            )).toList()),
            const SizedBox(height: 16),
          ],

          if (recommendations.isNotEmpty) ...[
            const Text('Recommendations:', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textPrimary, fontFamily: 'Poppins')),
            const SizedBox(height: 8),
            ...recommendations.take(3).map((r) => Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.arrow_right_rounded, color: AppColors.secondary, size: 18),
                  const SizedBox(width: 4),
                  Expanded(child: Text(r, style: const TextStyle(fontSize: 13, color: AppColors.textSecondary, fontFamily: 'Poppins', height: 1.4))),
                ],
              ),
            )),
          ],

          const SizedBox(height: 12),
          TextButton.icon(
            icon: const Icon(Icons.refresh_rounded, size: 16),
            label: const Text('Refresh Analysis', style: TextStyle(fontFamily: 'Poppins')),
            onPressed: _getAIInsights,
          ),
        ],
      ),
    );
  }
}
