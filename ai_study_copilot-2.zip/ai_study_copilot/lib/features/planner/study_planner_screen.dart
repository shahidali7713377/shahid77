import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';
import 'package:intl/intl.dart';
import '../../core/constants/app_colors.dart';
import '../../core/models/models.dart';
import '../../core/services/ai_service.dart';
import '../../core/services/app_provider.dart';
import '../../core/database/database_helper.dart';
import '../../widgets/common_widgets.dart';

class StudyPlannerScreen extends StatefulWidget {
  const StudyPlannerScreen({super.key});

  @override
  State<StudyPlannerScreen> createState() => _StudyPlannerScreenState();
}

class _StudyPlannerScreenState extends State<StudyPlannerScreen> {
  List<StudyPlanModel> _plans = [];
  List<StudySessionModel> _todaySessions = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadPlans();
  }

  Future<void> _loadPlans() async {
    final user = context.read<AppProvider>().user;
    if (user == null) return;

    final planMaps = await DatabaseHelper.instance.getStudyPlans(user.id);
    final today = DateFormat('yyyy-MM-dd').format(DateTime.now());
    final sessionMaps = await DatabaseHelper.instance.getStudySessions(user.id, date: today);

    if (mounted) {
      setState(() {
        _plans = planMaps.map(StudyPlanModel.fromMap).toList();
        _todaySessions = sessionMaps.map(StudySessionModel.fromMap).toList();
        _loading = false;
      });
    }
  }

  Future<void> _showCreatePlanDialog() async {
    final subjectCtrl = TextEditingController();
    final topicsCtrl = TextEditingController();
    DateTime? examDate;
    double dailyHours = 2.0;

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheetState) => Container(
          height: MediaQuery.of(ctx).size.height * 0.85,
          decoration: const BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          ),
          padding: EdgeInsets.only(left: 24, right: 24, top: 24, bottom: MediaQuery.of(ctx).viewInsets.bottom + 24),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Container(width: 40, height: 4, decoration: BoxDecoration(color: AppColors.surfaceAlt, borderRadius: BorderRadius.circular(2)), alignment: Alignment.center),
                const SizedBox(height: 16),
                const Text('Create Study Plan', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700, fontFamily: 'Poppins')),
                const SizedBox(height: 20),
                AppTextField(label: 'Subject', hint: 'e.g., Mathematics, Physics', controller: subjectCtrl),
                const SizedBox(height: 16),
                AppTextField(label: 'Topics to cover', hint: 'e.g., Calculus, Algebra, Statistics (comma-separated)', controller: topicsCtrl, maxLines: 2),
                const SizedBox(height: 16),
                GestureDetector(
                  onTap: () async {
                    final date = await showDatePicker(
                      context: ctx,
                      initialDate: DateTime.now().add(const Duration(days: 30)),
                      firstDate: DateTime.now().add(const Duration(days: 1)),
                      lastDate: DateTime.now().add(const Duration(days: 365)),
                    );
                    if (date != null) setSheetState(() => examDate = date);
                  },
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(color: AppColors.surfaceAlt, borderRadius: BorderRadius.circular(14)),
                    child: Row(
                      children: [
                        const Icon(Icons.calendar_today_rounded, color: AppColors.textHint, size: 18),
                        const SizedBox(width: 10),
                        Text(
                          examDate != null ? 'Exam: ${DateFormat('MMM d, yyyy').format(examDate!)}' : 'Select Exam Date',
                          style: TextStyle(color: examDate != null ? AppColors.textPrimary : AppColors.textHint, fontFamily: 'Poppins'),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Row(children: [const Text('Daily study hours: ', style: TextStyle(fontFamily: 'Poppins', fontWeight: FontWeight.w500)), Text('${dailyHours.toStringAsFixed(1)}h', style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.w700, fontFamily: 'Poppins'))]),
                Slider(value: dailyHours, min: 0.5, max: 8, divisions: 15, activeColor: AppColors.primary, onChanged: (v) => setSheetState(() => dailyHours = v)),
                const SizedBox(height: 20),
                GradientButton(
                  text: 'Generate AI Study Plan',
                  icon: Icons.auto_awesome_rounded,
                  onPressed: () async {
                    if (subjectCtrl.text.isEmpty || examDate == null) return;
                    Navigator.pop(ctx);
                    await _generatePlan(
                      subject: subjectCtrl.text,
                      examDate: examDate!,
                      dailyHours: dailyHours,
                      topics: topicsCtrl.text.split(',').map((t) => t.trim()).where((t) => t.isNotEmpty).toList(),
                    );
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _generatePlan({
    required String subject,
    required DateTime examDate,
    required double dailyHours,
    required List<String> topics,
  }) async {
    final user = context.read<AppProvider>().user!;

    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Row(children: [CircularProgressIndicator(strokeWidth: 2, color: Colors.white), SizedBox(width: 12), Text('Generating your study plan...')]), backgroundColor: AppColors.primary, duration: Duration(seconds: 30)));

    try {
      final sessionsData = await AIService.instance.generateStudyPlan(
        subject: subject,
        examDate: examDate,
        dailyHours: dailyHours,
        topics: topics,
        weakTopics: [],
      );

      final plan = StudyPlanModel(
        id: const Uuid().v4(),
        userId: user.id,
        subject: subject,
        examDate: examDate,
        dailyHours: dailyHours,
        createdAt: DateTime.now(),
      );

      await DatabaseHelper.instance.insertStudyPlan(plan.toMap());

      final sessions = sessionsData.map((s) {
        final dateOffset = (s['date_offset'] as int?) ?? 0;
        return StudySessionModel(
          id: const Uuid().v4(),
          planId: plan.id,
          userId: user.id,
          subject: subject,
          topic: s['topic'] as String?,
          plannedDate: DateTime.now().add(Duration(days: dateOffset - 1)),
          durationMinutes: s['duration_minutes'] as int? ?? 60,
          notes: s['notes'] as String?,
        );
      }).toList();

      await DatabaseHelper.instance.insertStudySessions(sessions.map((s) => s.toMap()).toList());
      ScaffoldMessenger.of(context).hideCurrentSnackBar();
      await _loadPlans();
    } catch (e) {
      ScaffoldMessenger.of(context).hideCurrentSnackBar();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e'), backgroundColor: AppColors.hard));
    }
  }

  Future<void> _markSessionStatus(StudySessionModel session, String status) async {
    await DatabaseHelper.instance.updateStudySession(session.id, {
      'status': status,
      if (status == 'completed') 'actual_end': DateTime.now().toIso8601String(),
    });
    await _loadPlans();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Study Planner')),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: AppColors.primary))
          : RefreshIndicator(
              onRefresh: _loadPlans,
              color: AppColors.primary,
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // Today's sessions
                    if (_todaySessions.isNotEmpty) ...[
                      const SectionHeader(title: "Today's Schedule"),
                      const SizedBox(height: 12),
                      ..._todaySessions.map((session) => _buildSessionCard(session)),
                      const SizedBox(height: 24),
                    ],

                    // Plans
                    SectionHeader(title: 'Study Plans (${_plans.length})', actionText: 'Create Plan', onAction: _showCreatePlanDialog),
                    const SizedBox(height: 12),

                    if (_plans.isEmpty)
                      EmptyState(
                        icon: Icons.calendar_month_rounded,
                        title: 'No study plans',
                        subtitle: 'Create an AI-powered study plan with your exam date and daily hours',
                        buttonText: 'Create Plan',
                        onButton: _showCreatePlanDialog,
                      )
                    else
                      ..._plans.map((plan) => _buildPlanCard(plan)),
                  ],
                ),
              ),
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showCreatePlanDialog,
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add_rounded),
        label: const Text('New Plan', style: TextStyle(fontFamily: 'Poppins', fontWeight: FontWeight.w600)),
      ),
    );
  }

  Widget _buildSessionCard(StudySessionModel session) {
    final statusColor = session.status == 'completed' ? AppColors.easy : session.status == 'missed' ? AppColors.hard : AppColors.warning;

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: statusColor.withOpacity(0.3), width: 2)),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(color: statusColor.withOpacity(0.1), borderRadius: BorderRadius.circular(10)),
            child: Icon(Icons.book_rounded, color: statusColor, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(session.subject, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, fontFamily: 'Poppins')),
                if (session.topic != null) Text(session.topic!, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary, fontFamily: 'Poppins')),
                Text('${session.durationMinutes ?? 60} min', style: const TextStyle(fontSize: 12, color: AppColors.textHint, fontFamily: 'Poppins')),
              ],
            ),
          ),
          if (session.status == 'pending') ...[
            GestureDetector(
              onTap: () => _markSessionStatus(session, 'completed'),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(color: AppColors.easy.withOpacity(0.1), borderRadius: BorderRadius.circular(8)),
                child: const Text('Done', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.easy, fontFamily: 'Poppins')),
              ),
            ),
            const SizedBox(width: 8),
            GestureDetector(
              onTap: () => _markSessionStatus(session, 'missed'),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(color: AppColors.hard.withOpacity(0.1), borderRadius: BorderRadius.circular(8)),
                child: const Text('Skip', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.hard, fontFamily: 'Poppins')),
              ),
            ),
          ] else
            Icon(session.status == 'completed' ? Icons.check_circle_rounded : Icons.cancel_rounded, color: statusColor),
        ],
      ),
    );
  }

  Widget _buildPlanCard(StudyPlanModel plan) {
    final daysLeft = plan.examDate.difference(DateTime.now()).inDays;
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.surfaceAlt),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8, offset: const Offset(0, 2))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(gradient: const LinearGradient(colors: AppColors.gradientPurple), borderRadius: BorderRadius.circular(12)),
                child: const Icon(Icons.school_rounded, color: Colors.white, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(plan.subject, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, fontFamily: 'Poppins')),
                    Text('${plan.dailyHours}h daily · Exam: ${DateFormat('MMM d').format(plan.examDate)}', style: const TextStyle(fontSize: 12, color: AppColors.textSecondary, fontFamily: 'Poppins')),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: daysLeft < 7 ? AppColors.hard.withOpacity(0.1) : AppColors.primaryLight,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text('$daysLeft days', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: daysLeft < 7 ? AppColors.hard : AppColors.primary, fontFamily: 'Poppins')),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
