import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../core/models/models.dart';
import '../../core/services/app_provider.dart';
import '../../widgets/common_widgets.dart';
import '../home/home_screen.dart';

class ProfileSetupScreen extends StatefulWidget {
  final UserModel user;
  const ProfileSetupScreen({super.key, required this.user});

  @override
  State<ProfileSetupScreen> createState() => _ProfileSetupScreenState();
}

class _ProfileSetupScreenState extends State<ProfileSetupScreen> {
  int _step = 0;
  String? _educationLevel;
  String? _examType;
  final List<String> _selectedSubjects = [];
  final _goalsCtrl = TextEditingController();
  bool _isLoading = false;

  final List<String> _educationLevels = ['High School', 'Undergraduate', 'Postgraduate', 'Competitive Exam'];
  final List<String> _examTypes = ['GCSEs', 'A-Levels', 'SAT/ACT', 'IELTS/TOEFL', 'GRE/GMAT', 'IIT-JEE', 'NEET', 'UPSC', 'Bar Exam', 'Medical Board', 'Other'];
  final List<String> _subjects = ['Mathematics', 'Physics', 'Chemistry', 'Biology', 'History', 'Geography', 'Literature', 'Economics', 'Computer Science', 'Psychology', 'Law', 'Medicine', 'Business', 'Languages', 'Art & Design'];

  Future<void> _complete() async {
    setState(() => _isLoading = true);
    final updated = widget.user
      ..educationLevel = _educationLevel
      ..examType = _examType
      ..studyGoals = _goalsCtrl.text
      ..subjects = _selectedSubjects;
    await context.read<AppProvider>().updateProfile(updated);
    if (mounted) {
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const HomeScreen()));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Progress indicator
              Row(
                children: List.generate(3, (i) => Expanded(
                  child: Container(
                    height: 4,
                    margin: EdgeInsets.only(right: i < 2 ? 8 : 0),
                    decoration: BoxDecoration(
                      color: i <= _step ? AppColors.primary : AppColors.surfaceAlt,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                )),
              ),
              const SizedBox(height: 32),
              Expanded(child: _buildStep()),
              const SizedBox(height: 16),
              GradientButton(
                text: _step < 2 ? 'Continue' : 'Get Started',
                isLoading: _isLoading,
                onPressed: () {
                  if (_step < 2) {
                    setState(() => _step++);
                  } else {
                    _complete();
                  }
                },
              ),
              if (_step > 0) ...[
                const SizedBox(height: 12),
                TextButton(
                  onPressed: () => setState(() => _step--),
                  child: const Text('Back', style: TextStyle(color: AppColors.textSecondary, fontFamily: 'Poppins')),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStep() {
    switch (_step) {
      case 0:
        return _buildEducationStep();
      case 1:
        return _buildSubjectsStep();
      case 2:
        return _buildGoalsStep();
      default:
        return const SizedBox();
    }
  }

  Widget _buildEducationStep() {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('What\'s your education level? 📚', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: AppColors.textPrimary, fontFamily: 'Poppins')),
          const SizedBox(height: 8),
          const Text('This helps us customize content for you', style: TextStyle(color: AppColors.textSecondary, fontFamily: 'Poppins')),
          const SizedBox(height: 24),
          ..._educationLevels.map((level) => GestureDetector(
            onTap: () => setState(() => _educationLevel = level),
            child: Container(
              margin: const EdgeInsets.only(bottom: 12),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: _educationLevel == level ? AppColors.primaryLight : AppColors.surface,
                border: Border.all(color: _educationLevel == level ? AppColors.primary : AppColors.surfaceAlt, width: 2),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Row(
                children: [
                  Text(level, style: TextStyle(fontSize: 15, fontWeight: FontWeight.w500, color: _educationLevel == level ? AppColors.primary : AppColors.textPrimary, fontFamily: 'Poppins')),
                  const Spacer(),
                  if (_educationLevel == level) const Icon(Icons.check_circle, color: AppColors.primary),
                ],
              ),
            ),
          )),
          const SizedBox(height: 16),
          const Text('Exam type (optional)', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: AppColors.textPrimary, fontFamily: 'Poppins')),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: _examTypes.map((exam) => GestureDetector(
              onTap: () => setState(() => _examType = exam),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  color: _examType == exam ? AppColors.primary : AppColors.surfaceAlt,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(exam, style: TextStyle(fontSize: 13, color: _examType == exam ? Colors.white : AppColors.textSecondary, fontFamily: 'Poppins')),
              ),
            )).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildSubjectsStep() {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Which subjects are you studying? 🎯', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: AppColors.textPrimary, fontFamily: 'Poppins')),
          const SizedBox(height: 8),
          const Text('Select all that apply', style: TextStyle(color: AppColors.textSecondary, fontFamily: 'Poppins')),
          const SizedBox(height: 24),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: _subjects.map((subject) {
              final selected = _selectedSubjects.contains(subject);
              return GestureDetector(
                onTap: () => setState(() {
                  if (selected) {
                    _selectedSubjects.remove(subject);
                  } else {
                    _selectedSubjects.add(subject);
                  }
                }),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  decoration: BoxDecoration(
                    color: selected ? AppColors.primary : AppColors.surface,
                    border: Border.all(color: selected ? AppColors.primary : AppColors.surfaceAlt),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(subject, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500, color: selected ? Colors.white : AppColors.textPrimary, fontFamily: 'Poppins')),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildGoalsStep() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('What are your study goals? 🌟', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: AppColors.textPrimary, fontFamily: 'Poppins')),
        const SizedBox(height: 8),
        const Text('Tell us what you want to achieve', style: TextStyle(color: AppColors.textSecondary, fontFamily: 'Poppins')),
        const SizedBox(height: 24),
        AppTextField(
          label: 'Study Goals',
          hint: 'e.g., Pass my finals with distinction, Improve my memory retention...',
          controller: _goalsCtrl,
          maxLines: 5,
        ),
        const SizedBox(height: 24),
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: AppColors.gradientPurple),
            borderRadius: BorderRadius.circular(16),
          ),
          child: const Row(
            children: [
              Icon(Icons.auto_awesome, color: Colors.white),
              SizedBox(width: 12),
              Expanded(
                child: Text(
                  'AI will use your goals to personalize your study experience',
                  style: TextStyle(color: Colors.white, fontSize: 14, fontFamily: 'Poppins'),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
