import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._internal();
  static Database? _database;

  DatabaseHelper._internal();

  Future<Database> get database async {
    _database ??= await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'study_copilot.db');
    return await openDatabase(path, version: 1, onCreate: _createDb);
  }

  Future<void> _createDb(Database db, int version) async {
    await db.execute('''
      CREATE TABLE users (
        id TEXT PRIMARY KEY,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        full_name TEXT,
        education_level TEXT,
        exam_type TEXT,
        study_goals TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE user_subjects (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        subject TEXT NOT NULL,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE documents (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        title TEXT NOT NULL,
        file_path TEXT,
        content TEXT NOT NULL,
        file_type TEXT NOT NULL,
        file_size INTEGER,
        page_count INTEGER,
        created_at TEXT NOT NULL,
        subject TEXT,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE summaries (
        id TEXT PRIMARY KEY,
        document_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        summary_type TEXT NOT NULL,
        content TEXT NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY (document_id) REFERENCES documents(id) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE flashcards (
        id TEXT PRIMARY KEY,
        document_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        question TEXT NOT NULL,
        answer TEXT NOT NULL,
        difficulty TEXT NOT NULL DEFAULT 'medium',
        topic TEXT,
        ease_factor REAL DEFAULT 2.5,
        interval INTEGER DEFAULT 1,
        repetitions INTEGER DEFAULT 0,
        next_review TEXT,
        last_reviewed TEXT,
        created_at TEXT NOT NULL,
        is_edited INTEGER DEFAULT 0,
        FOREIGN KEY (document_id) REFERENCES documents(id) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE flashcard_reviews (
        id TEXT PRIMARY KEY,
        flashcard_id TEXT NOT NULL,
        quality INTEGER NOT NULL,
        reviewed_at TEXT NOT NULL,
        FOREIGN KEY (flashcard_id) REFERENCES flashcards(id) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE exam_questions (
        id TEXT PRIMARY KEY,
        document_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        question_text TEXT NOT NULL,
        question_type TEXT NOT NULL,
        options TEXT,
        correct_answer TEXT NOT NULL,
        model_answer TEXT,
        difficulty TEXT NOT NULL,
        topic TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY (document_id) REFERENCES documents(id) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE exam_attempts (
        id TEXT PRIMARY KEY,
        question_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        user_answer TEXT NOT NULL,
        is_correct INTEGER NOT NULL,
        attempted_at TEXT NOT NULL,
        FOREIGN KEY (question_id) REFERENCES exam_questions(id) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE study_plans (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        subject TEXT NOT NULL,
        exam_date TEXT NOT NULL,
        daily_hours REAL NOT NULL,
        created_at TEXT NOT NULL,
        is_active INTEGER DEFAULT 1
      )
    ''');

    await db.execute('''
      CREATE TABLE study_sessions (
        id TEXT PRIMARY KEY,
        plan_id TEXT,
        user_id TEXT NOT NULL,
        subject TEXT NOT NULL,
        topic TEXT,
        planned_date TEXT NOT NULL,
        actual_start TEXT,
        actual_end TEXT,
        duration_minutes INTEGER,
        status TEXT DEFAULT 'pending',
        notes TEXT,
        FOREIGN KEY (plan_id) REFERENCES study_plans(id) ON DELETE SET NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE chat_messages (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        document_id TEXT,
        subject TEXT,
        role TEXT NOT NULL,
        content TEXT NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY (document_id) REFERENCES documents(id) ON DELETE SET NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE performance_records (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        subject TEXT NOT NULL,
        topic TEXT,
        accuracy_rate REAL,
        retention_rate REAL,
        study_time_minutes INTEGER,
        recorded_at TEXT NOT NULL
      )
    ''');
  }

  // ===== USER OPERATIONS =====

  Future<int> insertUser(Map<String, dynamic> user) async {
    final db = await database;
    return await db.insert('users', user, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<Map<String, dynamic>?> getUserByEmail(String email) async {
    final db = await database;
    final results = await db.query('users', where: 'email = ?', whereArgs: [email]);
    return results.isNotEmpty ? results.first : null;
  }

  Future<Map<String, dynamic>?> getUserById(String id) async {
    final db = await database;
    final results = await db.query('users', where: 'id = ?', whereArgs: [id]);
    return results.isNotEmpty ? results.first : null;
  }

  Future<int> updateUser(String id, Map<String, dynamic> updates) async {
    final db = await database;
    return await db.update('users', updates, where: 'id = ?', whereArgs: [id]);
  }

  Future<void> insertUserSubjects(String userId, List<String> subjects) async {
    final db = await database;
    await db.delete('user_subjects', where: 'user_id = ?', whereArgs: [userId]);
    for (final subject in subjects) {
      await db.insert('user_subjects', {
        'id': '${userId}_$subject',
        'user_id': userId,
        'subject': subject,
      });
    }
  }

  Future<List<String>> getUserSubjects(String userId) async {
    final db = await database;
    final results = await db.query('user_subjects', where: 'user_id = ?', whereArgs: [userId]);
    return results.map((r) => r['subject'] as String).toList();
  }

  // ===== DOCUMENT OPERATIONS =====

  Future<String> insertDocument(Map<String, dynamic> doc) async {
    final db = await database;
    await db.insert('documents', doc);
    return doc['id'] as String;
  }

  Future<List<Map<String, dynamic>>> getDocuments(String userId) async {
    final db = await database;
    return await db.query('documents', where: 'user_id = ?', whereArgs: [userId], orderBy: 'created_at DESC');
  }

  Future<Map<String, dynamic>?> getDocument(String id) async {
    final db = await database;
    final results = await db.query('documents', where: 'id = ?', whereArgs: [id]);
    return results.isNotEmpty ? results.first : null;
  }

  Future<int> deleteDocument(String id) async {
    final db = await database;
    return await db.delete('documents', where: 'id = ?', whereArgs: [id]);
  }

  // ===== SUMMARY OPERATIONS =====

  Future<void> insertSummary(Map<String, dynamic> summary) async {
    final db = await database;
    await db.insert('summaries', summary, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<Map<String, dynamic>>> getSummaries(String documentId) async {
    final db = await database;
    return await db.query('summaries', where: 'document_id = ?', whereArgs: [documentId], orderBy: 'created_at DESC');
  }

  // ===== FLASHCARD OPERATIONS =====

  Future<void> insertFlashcards(List<Map<String, dynamic>> cards) async {
    final db = await database;
    final batch = db.batch();
    for (final card in cards) {
      batch.insert('flashcards', card, conflictAlgorithm: ConflictAlgorithm.replace);
    }
    await batch.commit();
  }

  Future<List<Map<String, dynamic>>> getFlashcards(String documentId) async {
    final db = await database;
    return await db.query('flashcards', where: 'document_id = ?', whereArgs: [documentId]);
  }

  Future<List<Map<String, dynamic>>> getDueFlashcards(String userId) async {
    final db = await database;
    final now = DateTime.now().toIso8601String();
    return await db.query(
      'flashcards',
      where: 'user_id = ? AND (next_review IS NULL OR next_review <= ?)',
      whereArgs: [userId, now],
      orderBy: 'next_review ASC',
    );
  }

  Future<List<Map<String, dynamic>>> getAllUserFlashcards(String userId) async {
    final db = await database;
    return await db.query('flashcards', where: 'user_id = ?', whereArgs: [userId]);
  }

  Future<int> updateFlashcard(String id, Map<String, dynamic> updates) async {
    final db = await database;
    return await db.update('flashcards', updates, where: 'id = ?', whereArgs: [id]);
  }

  Future<void> insertFlashcardReview(Map<String, dynamic> review) async {
    final db = await database;
    await db.insert('flashcard_reviews', review);
  }

  // ===== EXAM QUESTION OPERATIONS =====

  Future<void> insertExamQuestions(List<Map<String, dynamic>> questions) async {
    final db = await database;
    final batch = db.batch();
    for (final q in questions) {
      batch.insert('exam_questions', q, conflictAlgorithm: ConflictAlgorithm.replace);
    }
    await batch.commit();
  }

  Future<List<Map<String, dynamic>>> getExamQuestions(String documentId) async {
    final db = await database;
    return await db.query('exam_questions', where: 'document_id = ?', whereArgs: [documentId], orderBy: 'difficulty ASC');
  }

  Future<List<Map<String, dynamic>>> getAllUserQuestions(String userId) async {
    final db = await database;
    return await db.query('exam_questions', where: 'user_id = ?', whereArgs: [userId]);
  }

  Future<void> insertExamAttempt(Map<String, dynamic> attempt) async {
    final db = await database;
    await db.insert('exam_attempts', attempt);
  }

  Future<List<Map<String, dynamic>>> getExamAttempts(String userId) async {
    final db = await database;
    return await db.query('exam_attempts', where: 'user_id = ?', whereArgs: [userId], orderBy: 'attempted_at DESC');
  }

  // ===== STUDY PLAN OPERATIONS =====

  Future<void> insertStudyPlan(Map<String, dynamic> plan) async {
    final db = await database;
    await db.insert('study_plans', plan);
  }

  Future<List<Map<String, dynamic>>> getStudyPlans(String userId) async {
    final db = await database;
    return await db.query('study_plans', where: 'user_id = ?', whereArgs: [userId], orderBy: 'created_at DESC');
  }

  Future<void> insertStudySessions(List<Map<String, dynamic>> sessions) async {
    final db = await database;
    final batch = db.batch();
    for (final s in sessions) {
      batch.insert('study_sessions', s);
    }
    await batch.commit();
  }

  Future<List<Map<String, dynamic>>> getStudySessions(String userId, {String? date}) async {
    final db = await database;
    if (date != null) {
      return await db.query(
        'study_sessions',
        where: 'user_id = ? AND planned_date LIKE ?',
        whereArgs: [userId, '$date%'],
        orderBy: 'planned_date ASC',
      );
    }
    return await db.query('study_sessions', where: 'user_id = ?', whereArgs: [userId], orderBy: 'planned_date ASC');
  }

  Future<int> updateStudySession(String id, Map<String, dynamic> updates) async {
    final db = await database;
    return await db.update('study_sessions', updates, where: 'id = ?', whereArgs: [id]);
  }

  // ===== CHAT OPERATIONS =====

  Future<void> insertChatMessage(Map<String, dynamic> message) async {
    final db = await database;
    await db.insert('chat_messages', message);
  }

  Future<List<Map<String, dynamic>>> getChatHistory(String userId, {String? documentId}) async {
    final db = await database;
    if (documentId != null) {
      return await db.query(
        'chat_messages',
        where: 'user_id = ? AND document_id = ?',
        whereArgs: [userId, documentId],
        orderBy: 'created_at ASC',
      );
    }
    return await db.query('chat_messages', where: 'user_id = ?', whereArgs: [userId], orderBy: 'created_at ASC');
  }

  Future<void> clearChatHistory(String userId, String? documentId) async {
    final db = await database;
    if (documentId != null) {
      await db.delete('chat_messages', where: 'user_id = ? AND document_id = ?', whereArgs: [userId, documentId]);
    } else {
      await db.delete('chat_messages', where: 'user_id = ?', whereArgs: [userId]);
    }
  }

  // ===== ANALYTICS OPERATIONS =====

  Future<void> insertPerformanceRecord(Map<String, dynamic> record) async {
    final db = await database;
    await db.insert('performance_records', record);
  }

  Future<List<Map<String, dynamic>>> getPerformanceRecords(String userId, {String? subject}) async {
    final db = await database;
    if (subject != null) {
      return await db.query('performance_records', where: 'user_id = ? AND subject = ?', whereArgs: [userId, subject], orderBy: 'recorded_at DESC');
    }
    return await db.query('performance_records', where: 'user_id = ?', whereArgs: [userId], orderBy: 'recorded_at DESC');
  }

  Future<Map<String, dynamic>> getAnalyticsSummary(String userId) async {
    final db = await database;
    
    final sessions = await db.rawQuery(
      'SELECT SUM(duration_minutes) as total_minutes, COUNT(*) as total_sessions FROM study_sessions WHERE user_id = ? AND status = "completed"',
      [userId],
    );
    
    final flashcardReviews = await db.rawQuery(
      'SELECT COUNT(*) as count, AVG(quality) as avg_quality FROM flashcard_reviews fr JOIN flashcards f ON fr.flashcard_id = f.id WHERE f.user_id = ?',
      [userId],
    );
    
    final examAccuracy = await db.rawQuery(
      'SELECT COUNT(*) as total, SUM(is_correct) as correct FROM exam_attempts WHERE user_id = ?',
      [userId],
    );

    final totalDocs = await db.rawQuery('SELECT COUNT(*) as count FROM documents WHERE user_id = ?', [userId]);
    final totalCards = await db.rawQuery('SELECT COUNT(*) as count FROM flashcards WHERE user_id = ?', [userId]);

    return {
      'total_study_minutes': sessions.first['total_minutes'] ?? 0,
      'total_sessions': sessions.first['total_sessions'] ?? 0,
      'flashcard_reviews': flashcardReviews.first['count'] ?? 0,
      'avg_flashcard_quality': flashcardReviews.first['avg_quality'] ?? 0,
      'exam_total': examAccuracy.first['total'] ?? 0,
      'exam_correct': examAccuracy.first['correct'] ?? 0,
      'total_documents': totalDocs.first['count'] ?? 0,
      'total_flashcards': totalCards.first['count'] ?? 0,
    };
  }
}
