import 'dart:convert';

// ===== USER MODEL =====
class UserModel {
  final String id;
  final String email;
  final String passwordHash;
  String? fullName;
  String? educationLevel;
  String? examType;
  String? studyGoals;
  List<String> subjects;
  final DateTime createdAt;
  DateTime updatedAt;

  UserModel({
    required this.id,
    required this.email,
    required this.passwordHash,
    this.fullName,
    this.educationLevel,
    this.examType,
    this.studyGoals,
    this.subjects = const [],
    required this.createdAt,
    required this.updatedAt,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'email': email,
    'password_hash': passwordHash,
    'full_name': fullName,
    'education_level': educationLevel,
    'exam_type': examType,
    'study_goals': studyGoals,
    'created_at': createdAt.toIso8601String(),
    'updated_at': updatedAt.toIso8601String(),
  };

  factory UserModel.fromMap(Map<String, dynamic> map) => UserModel(
    id: map['id'],
    email: map['email'],
    passwordHash: map['password_hash'],
    fullName: map['full_name'],
    educationLevel: map['education_level'],
    examType: map['exam_type'],
    studyGoals: map['study_goals'],
    createdAt: DateTime.parse(map['created_at']),
    updatedAt: DateTime.parse(map['updated_at']),
  );
}

// ===== DOCUMENT MODEL =====
class DocumentModel {
  final String id;
  final String userId;
  final String title;
  final String? filePath;
  final String content;
  final String fileType;
  final int? fileSize;
  final int? pageCount;
  final DateTime createdAt;
  String? subject;

  DocumentModel({
    required this.id,
    required this.userId,
    required this.title,
    this.filePath,
    required this.content,
    required this.fileType,
    this.fileSize,
    this.pageCount,
    required this.createdAt,
    this.subject,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'user_id': userId,
    'title': title,
    'file_path': filePath,
    'content': content,
    'file_type': fileType,
    'file_size': fileSize,
    'page_count': pageCount,
    'created_at': createdAt.toIso8601String(),
    'subject': subject,
  };

  factory DocumentModel.fromMap(Map<String, dynamic> map) => DocumentModel(
    id: map['id'],
    userId: map['user_id'],
    title: map['title'],
    filePath: map['file_path'],
    content: map['content'],
    fileType: map['file_type'],
    fileSize: map['file_size'],
    pageCount: map['page_count'],
    createdAt: DateTime.parse(map['created_at']),
    subject: map['subject'],
  );

  String get contentPreview => content.length > 200 ? '${content.substring(0, 200)}...' : content;
}

// ===== SUMMARY MODEL =====
class SummaryModel {
  final String id;
  final String documentId;
  final String userId;
  final String summaryType; // short, medium, detailed, bullet, concept, eli5
  final String content;
  final DateTime createdAt;

  SummaryModel({
    required this.id,
    required this.documentId,
    required this.userId,
    required this.summaryType,
    required this.content,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'document_id': documentId,
    'user_id': userId,
    'summary_type': summaryType,
    'content': content,
    'created_at': createdAt.toIso8601String(),
  };

  factory SummaryModel.fromMap(Map<String, dynamic> map) => SummaryModel(
    id: map['id'],
    documentId: map['document_id'],
    userId: map['user_id'],
    summaryType: map['summary_type'],
    content: map['content'],
    createdAt: DateTime.parse(map['created_at']),
  );
}

// ===== FLASHCARD MODEL =====
class FlashcardModel {
  final String id;
  final String documentId;
  final String userId;
  String question;
  String answer;
  String difficulty;
  String? topic;
  double easeFactor;
  int interval;
  int repetitions;
  DateTime? nextReview;
  DateTime? lastReviewed;
  final DateTime createdAt;
  bool isEdited;

  FlashcardModel({
    required this.id,
    required this.documentId,
    required this.userId,
    required this.question,
    required this.answer,
    required this.difficulty,
    this.topic,
    this.easeFactor = 2.5,
    this.interval = 1,
    this.repetitions = 0,
    this.nextReview,
    this.lastReviewed,
    required this.createdAt,
    this.isEdited = false,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'document_id': documentId,
    'user_id': userId,
    'question': question,
    'answer': answer,
    'difficulty': difficulty,
    'topic': topic,
    'ease_factor': easeFactor,
    'interval': interval,
    'repetitions': repetitions,
    'next_review': nextReview?.toIso8601String(),
    'last_reviewed': lastReviewed?.toIso8601String(),
    'created_at': createdAt.toIso8601String(),
    'is_edited': isEdited ? 1 : 0,
  };

  factory FlashcardModel.fromMap(Map<String, dynamic> map) => FlashcardModel(
    id: map['id'],
    documentId: map['document_id'],
    userId: map['user_id'],
    question: map['question'],
    answer: map['answer'],
    difficulty: map['difficulty'] ?? 'medium',
    topic: map['topic'],
    easeFactor: (map['ease_factor'] as num?)?.toDouble() ?? 2.5,
    interval: map['interval'] ?? 1,
    repetitions: map['repetitions'] ?? 0,
    nextReview: map['next_review'] != null ? DateTime.parse(map['next_review']) : null,
    lastReviewed: map['last_reviewed'] != null ? DateTime.parse(map['last_reviewed']) : null,
    createdAt: DateTime.parse(map['created_at']),
    isEdited: (map['is_edited'] ?? 0) == 1,
  );
}

// ===== EXAM QUESTION MODEL =====
class ExamQuestionModel {
  final String id;
  final String documentId;
  final String userId;
  final String questionText;
  final String questionType; // mcq, short_answer, long_form
  final List<String>? options;
  final String correctAnswer;
  final String? modelAnswer;
  final String difficulty;
  final String? topic;
  final DateTime createdAt;

  ExamQuestionModel({
    required this.id,
    required this.documentId,
    required this.userId,
    required this.questionText,
    required this.questionType,
    this.options,
    required this.correctAnswer,
    this.modelAnswer,
    required this.difficulty,
    this.topic,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'document_id': documentId,
    'user_id': userId,
    'question_text': questionText,
    'question_type': questionType,
    'options': options != null ? jsonEncode(options) : null,
    'correct_answer': correctAnswer,
    'model_answer': modelAnswer,
    'difficulty': difficulty,
    'topic': topic,
    'created_at': createdAt.toIso8601String(),
  };

  factory ExamQuestionModel.fromMap(Map<String, dynamic> map) => ExamQuestionModel(
    id: map['id'],
    documentId: map['document_id'],
    userId: map['user_id'],
    questionText: map['question_text'],
    questionType: map['question_type'],
    options: map['options'] != null ? List<String>.from(jsonDecode(map['options'])) : null,
    correctAnswer: map['correct_answer'],
    modelAnswer: map['model_answer'],
    difficulty: map['difficulty'],
    topic: map['topic'],
    createdAt: DateTime.parse(map['created_at']),
  );
}

// ===== STUDY PLAN MODEL =====
class StudyPlanModel {
  final String id;
  final String userId;
  final String subject;
  final DateTime examDate;
  final double dailyHours;
  final DateTime createdAt;
  bool isActive;
  List<StudySessionModel> sessions;

  StudyPlanModel({
    required this.id,
    required this.userId,
    required this.subject,
    required this.examDate,
    required this.dailyHours,
    required this.createdAt,
    this.isActive = true,
    this.sessions = const [],
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'user_id': userId,
    'subject': subject,
    'exam_date': examDate.toIso8601String(),
    'daily_hours': dailyHours,
    'created_at': createdAt.toIso8601String(),
    'is_active': isActive ? 1 : 0,
  };

  factory StudyPlanModel.fromMap(Map<String, dynamic> map) => StudyPlanModel(
    id: map['id'],
    userId: map['user_id'],
    subject: map['subject'],
    examDate: DateTime.parse(map['exam_date']),
    dailyHours: (map['daily_hours'] as num).toDouble(),
    createdAt: DateTime.parse(map['created_at']),
    isActive: (map['is_active'] ?? 1) == 1,
  );
}

// ===== STUDY SESSION MODEL =====
class StudySessionModel {
  final String id;
  final String? planId;
  final String userId;
  final String subject;
  final String? topic;
  final DateTime plannedDate;
  DateTime? actualStart;
  DateTime? actualEnd;
  int? durationMinutes;
  String status; // pending, in_progress, completed, missed
  String? notes;

  StudySessionModel({
    required this.id,
    this.planId,
    required this.userId,
    required this.subject,
    this.topic,
    required this.plannedDate,
    this.actualStart,
    this.actualEnd,
    this.durationMinutes,
    this.status = 'pending',
    this.notes,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'plan_id': planId,
    'user_id': userId,
    'subject': subject,
    'topic': topic,
    'planned_date': plannedDate.toIso8601String(),
    'actual_start': actualStart?.toIso8601String(),
    'actual_end': actualEnd?.toIso8601String(),
    'duration_minutes': durationMinutes,
    'status': status,
    'notes': notes,
  };

  factory StudySessionModel.fromMap(Map<String, dynamic> map) => StudySessionModel(
    id: map['id'],
    planId: map['plan_id'],
    userId: map['user_id'],
    subject: map['subject'],
    topic: map['topic'],
    plannedDate: DateTime.parse(map['planned_date']),
    actualStart: map['actual_start'] != null ? DateTime.parse(map['actual_start']) : null,
    actualEnd: map['actual_end'] != null ? DateTime.parse(map['actual_end']) : null,
    durationMinutes: map['duration_minutes'],
    status: map['status'] ?? 'pending',
    notes: map['notes'],
  );
}

// ===== CHAT MESSAGE MODEL =====
class ChatMessageModel {
  final String id;
  final String userId;
  final String? documentId;
  final String? subject;
  final String role; // user, assistant
  final String content;
  final DateTime createdAt;

  ChatMessageModel({
    required this.id,
    required this.userId,
    this.documentId,
    this.subject,
    required this.role,
    required this.content,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'user_id': userId,
    'document_id': documentId,
    'subject': subject,
    'role': role,
    'content': content,
    'created_at': createdAt.toIso8601String(),
  };

  factory ChatMessageModel.fromMap(Map<String, dynamic> map) => ChatMessageModel(
    id: map['id'],
    userId: map['user_id'],
    documentId: map['document_id'],
    subject: map['subject'],
    role: map['role'],
    content: map['content'],
    createdAt: DateTime.parse(map['created_at']),
  );
}
