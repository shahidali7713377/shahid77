class AppStrings {
  static const String appName = 'Study Copilot';
  static const String tagline = 'Study Smarter, Not Harder';

  // Auth
  static const String login = 'Login';
  static const String register = 'Register';
  static const String email = 'Email';
  static const String password = 'Password';
  static const String confirmPassword = 'Confirm Password';
  static const String forgotPassword = 'Forgot Password?';
  static const String noAccount = "Don't have an account? ";
  static const String hasAccount = "Already have an account? ";
  static const String signUp = 'Sign Up';
  static const String signIn = 'Sign In';

  // Profile
  static const String educationLevel = 'Education Level';
  static const String subjects = 'Subjects';
  static const String examType = 'Exam Type';
  static const String studyGoals = 'Study Goals';

  // Navigation
  static const String home = 'Home';
  static const String documents = 'Documents';
  static const String flashcards = 'Flashcards';
  static const String planner = 'Planner';
  static const String analytics = 'Analytics';

  // Features
  static const String uploadMaterial = 'Upload Material';
  static const String generateSummary = 'Generate Summary';
  static const String generateFlashcards = 'Generate Flashcards';
  static const String predictExam = 'Predict Exam';
  static const String chatTutor = 'AI Tutor';

  // Difficulty
  static const String easy = 'Easy';
  static const String medium = 'Medium';
  static const String hard = 'Hard';

  // Summary types
  static const String shortSummary = 'Short';
  static const String mediumSummary = 'Medium';
  static const String detailedSummary = 'Detailed';

  // AI status
  static const String aiProcessing = 'AI is thinking...';
  static const String generatingContent = 'Generating content...';

  // Errors
  static const String somethingWrong = 'Something went wrong';
  static const String networkError = 'Please check your internet connection';
  static const String apiKeyMissing = 'API key not configured';

  // ─────────────────────────────────────────────────────────────────────────
  // Google Gemini API  ★ 100% FREE — no credit card, no billing account
  //
  // HOW TO GET YOUR FREE KEY (30 seconds):
  //   1. Visit  https://aistudio.google.com/app/apikey
  //   2. Sign in with any Gmail / Google account
  //   3. Click "Create API Key" → copy the key (starts with AIza...)
  //   4. Paste it below, replacing AIzaSyBUO6H6aSxvBQ1Tb4OYl33doYhygmfXM1c
  //
  // Free tier limits (plenty for a study app):
  //   ✅  1,500 requests / day
  //   ✅  15  requests / minute
  //   ✅  1,000,000 tokens / minute
  // ─────────────────────────────────────────────────────────────────────────
  static const String geminiApiKey = 'AIzaSyBUO6H6aSxvBQ1Tb4OYl33doYhygmfXM1c'; // AIzaSy...
  static const String geminiModel  = 'gemini-1.5-flash';    // fast + free

  static String get geminiApiUrl =>
      'https://generativelanguage.googleapis.com/v1beta/models'
      '/$geminiModel:generateContent?key=$geminiApiKey';
}
