import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:image_picker/image_picker.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:syncfusion_flutter_pdf/pdf.dart';
import 'package:uuid/uuid.dart';
import 'package:path_provider/path_provider.dart';
import '../database/database_helper.dart';
import '../models/models.dart';

class DocumentService {
  static final DocumentService instance = DocumentService._internal();
  DocumentService._internal();

  Future<DocumentModel?> pickAndProcessFile(String userId) async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf', 'doc', 'docx', 'txt'],
      withData: true,
    );

    if (result == null || result.files.isEmpty) return null;

    final file = result.files.first;
    final extension = file.extension?.toLowerCase() ?? 'txt';
    
    String content = '';
    String? savedPath;

    // Save file locally
    final appDir = await getApplicationDocumentsDirectory();
    final userDir = Directory('${appDir.path}/documents/$userId');
    await userDir.create(recursive: true);
    
    final fileName = '${const Uuid().v4()}.$extension';
    final filePath = '${userDir.path}/$fileName';
    
    if (file.bytes != null) {
      await File(filePath).writeAsBytes(file.bytes!);
      savedPath = filePath;
    }

    if (extension == 'pdf' && file.bytes != null) {
      content = await _extractPdfText(file.bytes!);
    } else if (extension == 'txt') {
      content = file.bytes != null ? String.fromCharCodes(file.bytes!) : '';
    } else {
      // For doc/docx, attempt basic text extraction
      content = file.bytes != null ? _extractBasicText(file.bytes!) : '';
    }

    if (content.trim().isEmpty) {
      content = 'Content could not be extracted automatically. Please add text manually.';
    }

    final doc = DocumentModel(
      id: const Uuid().v4(),
      userId: userId,
      title: file.name.replaceAll(RegExp(r'\.[^.]+$'), ''),
      filePath: savedPath,
      content: content,
      fileType: extension,
      fileSize: file.size,
      createdAt: DateTime.now(),
    );

    await DatabaseHelper.instance.insertDocument(doc.toMap());
    return doc;
  }

  Future<DocumentModel?> pickImageAndOCR(String userId) async {
    final picker = ImagePicker();
    final image = await picker.pickImage(source: ImageSource.gallery, imageQuality: 85);
    if (image == null) return null;

    final inputImage = InputImage.fromFilePath(image.path);
    final textRecognizer = TextRecognizer(script: TextRecognitionScript.latin);
    
    try {
      final recognized = await textRecognizer.processImage(inputImage);
      final content = recognized.text;

      final doc = DocumentModel(
        id: const Uuid().v4(),
        userId: userId,
        title: 'Scanned Image ${DateTime.now().day}/${DateTime.now().month}',
        filePath: image.path,
        content: content.isEmpty ? 'No text detected in image' : content,
        fileType: 'image',
        createdAt: DateTime.now(),
      );

      await DatabaseHelper.instance.insertDocument(doc.toMap());
      return doc;
    } finally {
      textRecognizer.close();
    }
  }

  Future<DocumentModel> createFromText({
    required String userId,
    required String title,
    required String content,
    String? subject,
  }) async {
    final doc = DocumentModel(
      id: const Uuid().v4(),
      userId: userId,
      title: title,
      content: content,
      fileType: 'text',
      createdAt: DateTime.now(),
      subject: subject,
    );

    await DatabaseHelper.instance.insertDocument(doc.toMap());
    return doc;
  }

  Future<String> _extractPdfText(List<int> bytes) async {
    try {
      final document = PdfDocument(inputBytes: bytes);
      final extractor = PdfTextExtractor(document);
      final text = extractor.extractText();
      document.dispose();
      return text;
    } catch (e) {
      return '';
    }
  }

  String _extractBasicText(List<int> bytes) {
    try {
      // Basic text extraction - filters printable ASCII
      final buffer = StringBuffer();
      for (int i = 0; i < bytes.length; i++) {
        final byte = bytes[i];
        if ((byte >= 32 && byte <= 126) || byte == 10 || byte == 13) {
          buffer.writeCharCode(byte);
        }
      }
      final raw = buffer.toString();
      // Clean up excessive whitespace
      return raw.replaceAll(RegExp(r'\s+'), ' ').trim();
    } catch (e) {
      return '';
    }
  }

  Future<List<DocumentModel>> getDocuments(String userId) async {
    final maps = await DatabaseHelper.instance.getDocuments(userId);
    return maps.map(DocumentModel.fromMap).toList();
  }

  Future<void> deleteDocument(String id) async {
    await DatabaseHelper.instance.deleteDocument(id);
  }
}
