import 'package:flutter/material.dart';
import '../models/models.dart';
import '../services/auth_service.dart';
import '../services/document_service.dart';
import '../database/database_helper.dart';

class AppProvider extends ChangeNotifier {
  UserModel? _user;
  List<DocumentModel> _documents = [];
  bool _isLoading = false;
  String? _error;

  UserModel? get user => _user;
  List<DocumentModel> get documents => _documents;
  bool get isLoading => _isLoading;
  String? get error => _error;
  bool get isLoggedIn => _user != null;

  void setLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }

  void setError(String? error) {
    _error = error;
    notifyListeners();
  }

  Future<void> tryAutoLogin() async {
    final user = await AuthService.instance.autoLogin();
    if (user != null) {
      _user = user;
      await loadDocuments();
      notifyListeners();
    }
  }

  Future<void> login(String email, String password) async {
    setLoading(true);
    setError(null);
    try {
      _user = await AuthService.instance.login(email: email, password: password);
      await loadDocuments();
      notifyListeners();
    } catch (e) {
      setError(e.toString().replaceAll('Exception: ', ''));
      rethrow;
    } finally {
      setLoading(false);
    }
  }

  Future<void> register(String email, String password, String fullName) async {
    setLoading(true);
    setError(null);
    try {
      _user = await AuthService.instance.register(email: email, password: password, fullName: fullName);
      notifyListeners();
    } catch (e) {
      setError(e.toString().replaceAll('Exception: ', ''));
      rethrow;
    } finally {
      setLoading(false);
    }
  }

  Future<void> logout() async {
    await AuthService.instance.logout();
    _user = null;
    _documents = [];
    notifyListeners();
  }

  Future<void> updateProfile(UserModel updatedUser) async {
    await AuthService.instance.updateProfile(updatedUser);
    _user = updatedUser;
    notifyListeners();
  }

  Future<void> loadDocuments() async {
    if (_user == null) return;
    final docs = await DocumentService.instance.getDocuments(_user!.id);
    _documents = docs;
    notifyListeners();
  }

  Future<DocumentModel?> uploadDocument(BuildContext context) async {
    if (_user == null) return null;
    final doc = await DocumentService.instance.pickAndProcessFile(_user!.id);
    if (doc != null) {
      _documents.insert(0, doc);
      notifyListeners();
    }
    return doc;
  }

  Future<DocumentModel?> scanImage() async {
    if (_user == null) return null;
    final doc = await DocumentService.instance.pickImageAndOCR(_user!.id);
    if (doc != null) {
      _documents.insert(0, doc);
      notifyListeners();
    }
    return doc;
  }

  Future<DocumentModel> createTextDocument({required String title, required String content, String? subject}) async {
    final doc = await DocumentService.instance.createFromText(
      userId: _user!.id,
      title: title,
      content: content,
      subject: subject,
    );
    _documents.insert(0, doc);
    notifyListeners();
    return doc;
  }

  Future<void> deleteDocument(String docId) async {
    await DocumentService.instance.deleteDocument(docId);
    _documents.removeWhere((d) => d.id == docId);
    notifyListeners();
  }

  Future<Map<String, dynamic>> getAnalytics() async {
    if (_user == null) return {};
    return await DatabaseHelper.instance.getAnalyticsSummary(_user!.id);
  }
}
