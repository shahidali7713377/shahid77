import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';
import '../database/database_helper.dart';
import '../models/models.dart';

class AuthService {
  static final AuthService instance = AuthService._internal();
  AuthService._internal();

  static const String _userIdKey = 'current_user_id';
  UserModel? _currentUser;

  UserModel? get currentUser => _currentUser;

  String _hashPassword(String password) {
    final bytes = utf8.encode(password);
    return sha256.convert(bytes).toString();
  }

  Future<UserModel> register({
    required String email,
    required String password,
    required String fullName,
  }) async {
    final existing = await DatabaseHelper.instance.getUserByEmail(email);
    if (existing != null) {
      throw Exception('Email already registered');
    }

    final user = UserModel(
      id: const Uuid().v4(),
      email: email.toLowerCase().trim(),
      passwordHash: _hashPassword(password),
      fullName: fullName,
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );

    await DatabaseHelper.instance.insertUser(user.toMap());
    await _saveCurrentUser(user.id);
    _currentUser = user;
    return user;
  }

  Future<UserModel> login({required String email, required String password}) async {
    final userData = await DatabaseHelper.instance.getUserByEmail(email.toLowerCase().trim());
    if (userData == null) {
      throw Exception('No account found with this email');
    }

    final passwordHash = _hashPassword(password);
    if (userData['password_hash'] != passwordHash) {
      throw Exception('Incorrect password');
    }

    final user = UserModel.fromMap(userData);
    user.subjects = await DatabaseHelper.instance.getUserSubjects(user.id);
    await _saveCurrentUser(user.id);
    _currentUser = user;
    return user;
  }

  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_userIdKey);
    _currentUser = null;
  }

  Future<UserModel?> autoLogin() async {
    final prefs = await SharedPreferences.getInstance();
    final userId = prefs.getString(_userIdKey);
    if (userId == null) return null;

    final userData = await DatabaseHelper.instance.getUserById(userId);
    if (userData == null) return null;

    final user = UserModel.fromMap(userData);
    user.subjects = await DatabaseHelper.instance.getUserSubjects(user.id);
    _currentUser = user;
    return user;
  }

  Future<void> updateProfile(UserModel user) async {
    final updates = {
      'full_name': user.fullName,
      'education_level': user.educationLevel,
      'exam_type': user.examType,
      'study_goals': user.studyGoals,
      'updated_at': DateTime.now().toIso8601String(),
    };
    await DatabaseHelper.instance.updateUser(user.id, updates);
    await DatabaseHelper.instance.insertUserSubjects(user.id, user.subjects);
    _currentUser = user;
  }

  Future<void> _saveCurrentUser(String userId) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_userIdKey, userId);
  }
}
