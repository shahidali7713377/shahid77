import 'dart:convert';
import 'package:http/http.dart' as http;
import '../constants/app_strings.dart';
import '../models/models.dart';

class AIService {
  static final AIService instance = AIService._internal();
  AIService._internal();

  // ── Gemini request/response format ───────────────────────────────────────
  //
  // REQUEST body:
  // {
  //   "system_instruction": { "parts": [{"text": "..."}] },
  //   "contents": [
  //     {"role": "user",  "parts": [{"text": "..."}]},
  //     {"role": "model", "parts": [{"text": "..."}]}   // ← "model" not "assistant"
  //   ],
  //   "generationConfig": { "maxOutputTokens": 2000, "temperature": 0.7 }
  // }
  //
  // RESPONSE body:
  // { "candidates": [{ "content": { "parts": [{"text": "..."}] } }] }
  // ─────────────────────────────────────────────────────────────────────────

  Future<String> _callGemini(
    String systemPrompt,
    String userMessage, {
    int maxTokens = 2000,
  }) async {
    return _callGeminiWithHistory(
      systemPrompt,
      [
        {'role': 'user', 'content': userMessage},
      ],
      maxTokens: maxTokens,
    );
  }

  Future<String> _callGeminiWithHistory(
    String systemPrompt,
    List<Map<String, String>> messages, {
    int maxTokens = 2000,
  }) async {
    // Convert messages to Gemini format.
    // Gemini uses "model" instead of "assistant" for AI turns.
    final geminiContents = messages.map((m) {
      final role = m['role'] == 'assistant' ? 'model' : m['role']!;
      return {
        'role': role,
        'parts': [
          {'text': m['content']!}
        ],
      };
    }).toList();

    final body = jsonEncode({
      'system_instruction': {
        'parts': [
          {'text': systemPrompt}
        ]
      },
      'contents': geminiContents,
      'generationConfig': {
        'maxOutputTokens': maxTokens,
        'temperature': 0.7,
      },
    });

    final response = await http.post(
      Uri.parse(AppStrings.geminiApiUrl),
      headers: {'Content-Type': 'application/json'},
      body: body,
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      // Navigate: candidates[0].content.parts[0].text
      final text = data['candidates'][0]['content']['parts'][0]['text'] as String;
      return text;
    } else {
      final data = jsonDecode(response.body);
      final errMsg = data['error']?['message'] ?? response.body;
      throw Exception('Gemini API error ${response.statusCode}: $errMsg');
    }
  }

  // ═════════════════════════════════════════════════════════════════════════
  // SUMMARIZATION
  // ═════════════════════════════════════════════════════════════════════════

  Future<String> generateSummary({
    required String content,
    required String summaryType,
    required String educationLevel,
  }) async {
    String typeInstruction;
    switch (summaryType) {
      case 'short':
        typeInstruction =
            'Generate a concise 1-page summary (max 300 words) capturing the key points.';
        break;
      case 'medium':
        typeInstruction =
            'Generate a medium-length summary (400-600 words) with key concepts and details.';
        break;
      case 'detailed':
        typeInstruction =
            'Generate a comprehensive detailed summary (800-1200 words) covering all important aspects.';
        break;
      case 'bullet':
        typeInstruction =
            'Generate a bullet-point summary with clear hierarchical structure. Use • for main points and - for sub-points.';
        break;
      case 'concept':
        typeInstruction =
            'Generate a concept-focused summary that explains core ideas, definitions, and relationships between concepts.';
        break;
      case 'eli5':
        typeInstruction =
            'Explain this content as if explaining to a 10-year-old. Use simple words, analogies, and everyday examples.';
        break;
      default:
        typeInstruction = 'Generate a clear, concise summary.';
    }

    final system = '''You are an expert educational summarizer.
The student education level is: $educationLevel.
Adapt complexity and vocabulary accordingly.
Be clear, structured, and focus on what matters most for studying and exams.''';

    return _callGemini(
      system,
      '$typeInstruction\n\nContent to summarize:\n\n$content',
      maxTokens: 2000,
    );
  }

  // ═════════════════════════════════════════════════════════════════════════
  // FLASHCARD GENERATION
  // ═════════════════════════════════════════════════════════════════════════

  Future<List<Map<String, dynamic>>> generateFlashcards({
    required String content,
    required String documentTitle,
    int count = 15,
  }) async {
    final system = '''You are an expert educator creating study flashcards.
Generate flashcards that test understanding, not just memorization.
ALWAYS respond with valid JSON only — no markdown fences, no extra text.''';

    final prompt = '''Create $count flashcards from this study material: "$documentTitle"

Content:
$content

Respond with ONLY a JSON array in this exact format:
[
  {
    "question": "Clear, specific question",
    "answer": "Comprehensive but concise answer",
    "difficulty": "easy|medium|hard",
    "topic": "specific topic name"
  }
]

Vary difficulty levels. Focus on key concepts, definitions, and important facts.''';

    final response = await _callGemini(system, prompt, maxTokens: 3000);
    return _parseJsonArray(response, 'flashcards');
  }

  // ═════════════════════════════════════════════════════════════════════════
  // EXAM QUESTION GENERATION
  // ═════════════════════════════════════════════════════════════════════════

  Future<List<Map<String, dynamic>>> generateExamQuestions({
    required String content,
    required String documentTitle,
    required String questionType,
    int count = 10,
  }) async {
    final system = '''You are an expert exam question creator.
Generate challenging, educational exam questions.
ALWAYS respond with valid JSON only — no markdown fences, no extra text.''';

    String typeInstruction;
    String format;

    if (questionType == 'mcq') {
      typeInstruction = 'Create multiple choice questions with 4 options each.';
      format = '''[{"question_text":"...","question_type":"mcq","options":["A) ...","B) ...","C) ...","D) ..."],"correct_answer":"A) ...","model_answer":"explanation","difficulty":"easy|medium|hard","topic":"topic name"}]''';
    } else if (questionType == 'short_answer') {
      typeInstruction = 'Create short answer questions requiring 2-5 sentence responses.';
      format = '''[{"question_text":"...","question_type":"short_answer","options":null,"correct_answer":"key points","model_answer":"model answer","difficulty":"easy|medium|hard","topic":"topic name"}]''';
    } else if (questionType == 'long_form') {
      typeInstruction = 'Create essay questions requiring detailed responses.';
      format = '''[{"question_text":"...","question_type":"long_form","options":null,"correct_answer":"key themes","model_answer":"comprehensive answer","difficulty":"medium|hard","topic":"topic name"}]''';
    } else {
      typeInstruction = 'Create a mix of MCQ, short answer, and long-form questions.';
      format = '''[{"question_text":"...","question_type":"mcq|short_answer|long_form","options":["A)...","B)...","C)...","D)..."] or null,"correct_answer":"...","model_answer":"...","difficulty":"easy|medium|hard","topic":"..."}]''';
    }

    final prompt = '''$typeInstruction
Generate $count questions from: "$documentTitle"

Content:
$content

Respond with ONLY a JSON array in this format:
$format

Aim for 30% easy, 40% medium, 30% hard.''';

    final response = await _callGemini(system, prompt, maxTokens: 4000);
    return _parseJsonArray(response, 'exam questions');
  }

  // ═════════════════════════════════════════════════════════════════════════
  // STUDY PLAN GENERATION
  // ═════════════════════════════════════════════════════════════════════════

  Future<List<Map<String, dynamic>>> generateStudyPlan({
    required String subject,
    required DateTime examDate,
    required double dailyHours,
    required List<String> topics,
    required List<String> weakTopics,
  }) async {
    final daysUntilExam = examDate.difference(DateTime.now()).inDays;

    final system = '''You are an adaptive study planner.
Create evidence-based study schedules using spaced repetition.
ALWAYS respond with valid JSON only — no markdown fences, no extra text.''';

    final prompt = '''Create a study plan for: $subject
Days until exam: $daysUntilExam
Daily hours: $dailyHours
Topics: ${topics.join(', ')}
Weak areas (prioritize): ${weakTopics.isEmpty ? 'none specified' : weakTopics.join(', ')}

Respond with ONLY a JSON array:
[{"date_offset":1,"topic":"specific topic","duration_minutes":90,"session_type":"learn|review|practice|mixed","notes":"focus note"}]

Rules:
- Prioritize weak topics
- Include spaced review sessions
- Stay within $dailyHours hours/day
- Cover all $daysUntilExam days''';

    final response = await _callGemini(system, prompt, maxTokens: 4000);
    return _parseJsonArray(response, 'study plan');
  }

  // ═════════════════════════════════════════════════════════════════════════
  // AI CHAT TUTOR
  // ═════════════════════════════════════════════════════════════════════════

  Future<String> chatWithTutor({
    required String userMessage,
    required String documentContent,
    required String documentTitle,
    required List<ChatMessageModel> chatHistory,
    required String educationLevel,
  }) async {
    final system = '''You are an intelligent AI study tutor.
Document being studied: "$documentTitle"
Student education level: $educationLevel

Your role:
- Answer questions based on the provided study material
- Explain concepts clearly at the appropriate level
- Use examples and analogies when helpful
- Be encouraging and supportive
- Break down complex topics step by step

Study Material:
---
$documentContent
---''';

    // Build message history — last 10 turns for context
    final recentHistory = chatHistory.length > 10
        ? chatHistory.sublist(chatHistory.length - 10)
        : chatHistory;

    final messages = <Map<String, String>>[
      for (final m in recentHistory) {'role': m.role, 'content': m.content},
      {'role': 'user', 'content': userMessage},
    ];

    return _callGeminiWithHistory(system, messages, maxTokens: 1500);
  }

  // ═════════════════════════════════════════════════════════════════════════
  // PERFORMANCE ANALYSIS / KNOWLEDGE GAP DETECTION
  // ═════════════════════════════════════════════════════════════════════════

  Future<Map<String, dynamic>> analyzePerformance({
    required List<Map<String, dynamic>> examAttempts,
    required List<Map<String, dynamic>> flashcardReviews,
    required String subject,
  }) async {
    final system = '''You are a learning analytics expert.
Analyze student performance to identify knowledge gaps.
ALWAYS respond with valid JSON only — no markdown fences, no extra text.''';

    final prompt = '''Analyze performance for subject: $subject

Exam attempts (sample): ${jsonEncode(examAttempts.take(30).toList())}
Flashcard reviews (sample): ${jsonEncode(flashcardReviews.take(30).toList())}

Respond with ONLY this JSON structure:
{
  "weak_topics": ["topic1","topic2"],
  "strong_topics": ["topic1","topic2"],
  "overall_assessment": "brief honest assessment",
  "recommendations": ["action1","action2","action3"],
  "focus_areas": ["area1","area2"],
  "estimated_readiness": 0.75
}''';

    final response = await _callGemini(system, prompt, maxTokens: 1000);

    try {
      return _parseJsonObject(response);
    } catch (_) {
      return {
        'weak_topics': [],
        'strong_topics': [],
        'overall_assessment': 'Analysis unavailable',
        'recommendations': ['Continue reviewing your study materials'],
        'focus_areas': [],
        'estimated_readiness': 0.5,
      };
    }
  }

  // ═════════════════════════════════════════════════════════════════════════
  // ANSWER EVALUATION
  // ═════════════════════════════════════════════════════════════════════════

  Future<Map<String, dynamic>> evaluateAnswer({
    required String question,
    required String userAnswer,
    required String correctAnswer,
    required String modelAnswer,
    required String questionType,
  }) async {
    final system = '''You are an expert examiner evaluating student answers.
Be fair, constructive, and educational.
ALWAYS respond with valid JSON only — no markdown fences, no extra text.''';

    final prompt = '''Evaluate this student answer:

Question: $question
Type: $questionType
Student Answer: $userAnswer
Correct Answer / Key Points: $correctAnswer
Model Answer: $modelAnswer

Respond with ONLY this JSON:
{
  "is_correct": true,
  "score": 85,
  "feedback": "specific constructive feedback",
  "missed_points": ["point1"],
  "correct_points": ["point1"]
}''';

    final response = await _callGemini(system, prompt, maxTokens: 800);

    try {
      return _parseJsonObject(response);
    } catch (_) {
      return {
        'is_correct': userAnswer.toLowerCase().trim() ==
            correctAnswer.toLowerCase().trim(),
        'score': 0,
        'feedback': 'Could not evaluate automatically.',
        'missed_points': [],
        'correct_points': [],
      };
    }
  }

  // ═════════════════════════════════════════════════════════════════════════
  // JSON PARSING HELPERS
  // Gemini sometimes wraps JSON in markdown fences — strip them first
  // ═════════════════════════════════════════════════════════════════════════

  String _stripMarkdownFences(String raw) {
    // Remove ```json ... ``` or ``` ... ```
    return raw
        .replaceAll(RegExp(r'```json\s*', multiLine: true), '')
        .replaceAll(RegExp(r'```\s*',   multiLine: true), '')
        .trim();
  }

  List<Map<String, dynamic>> _parseJsonArray(String raw, String label) {
    final cleaned = _stripMarkdownFences(raw);
    final start = cleaned.indexOf('[');
    final end   = cleaned.lastIndexOf(']');
    if (start == -1 || end == -1) {
      throw Exception('Failed to parse $label — no JSON array found');
    }
    final List<dynamic> list = jsonDecode(cleaned.substring(start, end + 1));
    return list.map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Map<String, dynamic> _parseJsonObject(String raw) {
    final cleaned = _stripMarkdownFences(raw);
    final start = cleaned.indexOf('{');
    final end   = cleaned.lastIndexOf('}');
    if (start == -1 || end == -1) {
      throw Exception('No JSON object found in response');
    }
    return Map<String, dynamic>.from(
        jsonDecode(cleaned.substring(start, end + 1)) as Map);
  }
}
