import 'package:uuid/uuid.dart';
import '../database/database_helper.dart';
import '../models/models.dart';

class SpacedRepetitionService {
  static final SpacedRepetitionService instance = SpacedRepetitionService._internal();
  SpacedRepetitionService._internal();

  /// SM-2 Algorithm
  /// quality: 0-5 (0=complete blackout, 5=perfect response)
  FlashcardModel updateCard(FlashcardModel card, int quality) {
    if (quality < 0 || quality > 5) throw ArgumentError('Quality must be 0-5');

    double newEaseFactor = card.easeFactor + (0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02));
    if (newEaseFactor < 1.3) newEaseFactor = 1.3;

    int newInterval;
    int newRepetitions;

    if (quality >= 3) {
      if (card.repetitions == 0) {
        newInterval = 1;
      } else if (card.repetitions == 1) {
        newInterval = 6;
      } else {
        newInterval = (card.interval * newEaseFactor).round();
      }
      newRepetitions = card.repetitions + 1;
    } else {
      newInterval = 1;
      newRepetitions = 0;
    }

    return FlashcardModel(
      id: card.id,
      documentId: card.documentId,
      userId: card.userId,
      question: card.question,
      answer: card.answer,
      difficulty: _getDifficulty(quality),
      topic: card.topic,
      easeFactor: newEaseFactor,
      interval: newInterval,
      repetitions: newRepetitions,
      nextReview: DateTime.now().add(Duration(days: newInterval)),
      lastReviewed: DateTime.now(),
      createdAt: card.createdAt,
      isEdited: card.isEdited,
    );
  }

  String _getDifficulty(int quality) {
    if (quality <= 2) return 'hard';
    if (quality <= 3) return 'medium';
    return 'easy';
  }

  Future<void> recordReview(FlashcardModel updatedCard, int quality) async {
    await DatabaseHelper.instance.updateFlashcard(updatedCard.id, updatedCard.toMap());
    await DatabaseHelper.instance.insertFlashcardReview({
      'id': const Uuid().v4(),
      'flashcard_id': updatedCard.id,
      'quality': quality,
      'reviewed_at': DateTime.now().toIso8601String(),
    });
  }

  Future<List<FlashcardModel>> getDueCards(String userId) async {
    final maps = await DatabaseHelper.instance.getDueFlashcards(userId);
    return maps.map(FlashcardModel.fromMap).toList();
  }

  int qualityFromResponse(String response) {
    switch (response) {
      case 'perfect': return 5;
      case 'good': return 4;
      case 'okay': return 3;
      case 'hard': return 2;
      case 'failed': return 1;
      default: return 0;
    }
  }
}
