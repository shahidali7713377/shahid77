# 🎓 AI Study Copilot - Flutter App

An intelligent AI-powered study assistant that transforms your study materials into optimized revision systems using Claude AI.

---

## ✨ Features Implemented

### 🔐 Authentication & Profile
- Email/password registration with SHA-256 hashing
- Profile setup: education level, subjects, exam type, study goals
- Auto-login with SharedPreferences token persistence

### 📁 Document Management
- **PDF upload** — text extracted via syncfusion_flutter_pdf
- **Image OCR** — text recognition via google_mlkit_text_recognition  
- **Manual text input** — type or paste notes directly
- Local file storage in app documents directory

### 🤖 AI Smart Summary Engine (Claude API)
- 6 summary modes: Short, Medium, Detailed, Bullet Points, Concept-focused, ELI5
- Adaptive content based on user education level
- Saved summaries per document with history

### 🃏 Flashcard System
- AI generates 5–30 cards from any document
- Spaced Repetition (SM-2 algorithm) for optimal scheduling
- 4-rating system: Again / Hard / Good / Easy
- Full card editing capability
- Study session with animated card flip

### 📝 Exam Preparation
- 4 question types: MCQ, Short Answer, Essay, Mixed
- AI-generated model answers
- Difficulty categorization (Easy/Medium/Hard)
- Automatic AI evaluation of written answers
- Score tracking and detailed feedback

### 📅 Adaptive Study Planner
- Input exam date + daily hours → AI generates full schedule
- Daily session tracking (complete/skip)
- Plan management with countdown to exam

### 📊 Analytics Dashboard
- Weekly study activity bar chart (fl_chart)
- Flashcard retention rate circular indicator
- AI-powered performance analysis
- Knowledge gap detection with recommendations

### 💬 AI Chat Tutor
- Contextual Q&A based on uploaded documents
- Full conversation history per document
- Quick-prompt shortcuts
- Typing animation indicator
- Clear chat functionality

---

## 🚀 Setup Instructions

### 1. Prerequisites
- Flutter SDK >= 3.0.0
- Dart >= 3.0.0
- Android Studio or VS Code

### 2. Configure API Key
Open `lib/core/constants/app_strings.dart` and replace:
```dart
static const String anthropicApiKey = 'YOUR_ANTHROPIC_API_KEY';
```
with your actual Anthropic API key from https://console.anthropic.com

### 3. Install Dependencies
```bash
flutter pub get
```

### 4. Add Assets
Create the required directories:
```bash
mkdir -p assets/images assets/animations assets/fonts
```
Download Poppins font from Google Fonts and add to `assets/fonts/`

### 5. Run
```bash
flutter run
```

---

## 🏗️ Architecture

```
lib/
├── core/
│   ├── constants/       # Colors, strings, theme
│   ├── database/        # SQLite with DatabaseHelper
│   ├── models/          # All data models
│   └── services/        # AI, Auth, Document, SpacedRepetition, AppProvider
├── features/
│   ├── auth/            # Login, Register, Profile Setup
│   ├── home/            # Dashboard with stats
│   ├── documents/       # Upload & manage materials
│   ├── summaries/       # AI summary generation
│   ├── flashcards/      # Generator + Study session
│   ├── exam/            # Exam question practice
│   ├── planner/         # Study schedule management
│   ├── analytics/       # Performance charts & AI insights
│   └── chat/            # AI tutor conversation
├── widgets/             # Shared UI components
└── main.dart            # App entry with splash
```

## 💾 Database Schema

SQLite with 11 tables:
- `users` — authentication & profile
- `user_subjects` — many-to-many subjects
- `documents` — uploaded materials with extracted text
- `summaries` — AI-generated summaries
- `flashcards` — cards with SM-2 scheduling data
- `flashcard_reviews` — review history
- `exam_questions` — AI-generated questions
- `exam_attempts` — user answer history
- `study_plans` — AI study schedules
- `study_sessions` — individual sessions with status
- `chat_messages` — per-document conversation history
- `performance_records` — analytics data

## 🔑 Environment Variables

| Variable | Description | Where |
|----------|-------------|-------|
| `anthropicApiKey` | Your Anthropic API key | app_strings.dart |

## 📱 Android Permissions
- INTERNET — API calls
- READ/WRITE_EXTERNAL_STORAGE — file access
- CAMERA — image capture for OCR

---

## 🎨 Design System

- **Primary:** Purple `#6C63FF`
- **Secondary:** Teal `#00BFA5`
- **Accent:** Pink `#FF6584`
- **Font:** Poppins
- **Style:** Clean minimal cards, gradient accents, no visual clutter

---

Built with ❤️ using Flutter + Claude AI
