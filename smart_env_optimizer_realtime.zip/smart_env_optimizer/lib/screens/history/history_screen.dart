// lib/screens/history/history_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:gap/gap.dart';
import 'package:iconsax/iconsax.dart';
import 'package:intl/intl.dart';
import 'package:fl_chart/fl_chart.dart';
import '../../core/theme/app_theme.dart';
import '../../services/storage_service.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  List<Map<String, dynamic>> _sessions = [];
  Map<String, double> _stats = {};
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _loadData();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _loadData() async {
    final storage = context.read<StorageService>();
    final sessions = await storage.getRecentSessions(limit: 30);
    final stats = await storage.getSessionStats();
    setState(() {
      _sessions = sessions;
      _stats = stats;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg0,
      appBar: AppBar(
        backgroundColor: AppColors.bg0,
        title: const Text('History & Analytics'),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: AppColors.primary,
          labelColor: AppColors.primary,
          unselectedLabelColor: AppColors.textMuted,
          tabs: const [
            Tab(text: 'Sessions'),
            Tab(text: 'Analytics'),
          ],
        ),
      ),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(color: AppColors.primary),
            )
          : TabBarView(
              controller: _tabController,
              children: [
                _buildSessionsTab(),
                _buildAnalyticsTab(),
              ],
            ),
    );
  }

  Widget _buildSessionsTab() {
    if (_sessions.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Iconsax.clipboard, size: 64, color: AppColors.textMuted),
            const Gap(16),
            const Text(
              'No sessions yet',
              style: TextStyle(color: AppColors.textMuted, fontSize: 16),
            ),
            const Gap(8),
            Text(
              'Start a Focus or Sleep session to track your environment.',
              style: const TextStyle(color: AppColors.textMuted, fontSize: 13),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(20),
      itemCount: _sessions.length,
      itemBuilder: (context, index) {
        final session = _sessions[index];
        return Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: _SessionCard(session: session)
              .animate()
              .fadeIn(delay: Duration(milliseconds: index * 50)),
        );
      },
    );
  }

  Widget _buildAnalyticsTab() {
    final totalSessions = (_stats['totalSessions'] ?? 0).toInt();
    final avgRating = _stats['avgRating'] ?? 0.0;
    final avgFocusScore = _stats['avgFocusScore'] ?? 0.0;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Gap(4),
          // Stats summary row
          Row(
            children: [
              Expanded(
                child: _StatCard(
                  label: 'Total Sessions',
                  value: '$totalSessions',
                  icon: Iconsax.timer_1,
                  color: AppColors.primary,
                ),
              ),
              const Gap(12),
              Expanded(
                child: _StatCard(
                  label: 'Avg Rating',
                  value: avgRating.toStringAsFixed(1),
                  icon: Iconsax.star,
                  color: AppColors.warning,
                ),
              ),
              const Gap(12),
              Expanded(
                child: _StatCard(
                  label: 'Avg Focus',
                  value: '${(avgFocusScore * 100).toInt()}%',
                  icon: Iconsax.cpu,
                  color: AppColors.focus,
                ),
              ),
            ],
          ).animate().fadeIn(),

          const Gap(28),

          Text(
            'Focus Score Trend',
            style: Theme.of(context).textTheme.titleMedium,
          ),
          const Gap(16),
          _buildFocusScoreChart(),

          const Gap(28),

          Text(
            'Rating Distribution',
            style: Theme.of(context).textTheme.titleMedium,
          ),
          const Gap(16),
          _buildRatingChart(),

          const Gap(28),

          Text(
            'Session Type Breakdown',
            style: Theme.of(context).textTheme.titleMedium,
          ),
          const Gap(16),
          _buildSessionTypeBreakdown(),
        ],
      ),
    );
  }

  Widget _buildFocusScoreChart() {
    final focusSessions = _sessions
        .where((s) => s['sessionType'] == 'focus')
        .take(14)
        .toList()
        .reversed
        .toList();

    if (focusSessions.isEmpty) {
      return _emptyChart('No focus sessions yet');
    }

    final spots = focusSessions.asMap().entries.map((e) {
      final score = (e.value['avgFocusScore'] as double? ?? 0) * 100;
      return FlSpot(e.key.toDouble(), score);
    }).toList();

    return Container(
      height: 160,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.bg2,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: LineChart(
        LineChartData(
          gridData: FlGridData(
            show: true,
            drawVerticalLine: false,
            getDrawingHorizontalLine: (_) =>
                const FlLine(color: AppColors.border, strokeWidth: 1),
          ),
          titlesData: FlTitlesData(
            rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            bottomTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            leftTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                interval: 50,
                reservedSize: 28,
                getTitlesWidget: (v, _) => Text(
                  '${v.toInt()}%',
                  style: const TextStyle(color: AppColors.textMuted, fontSize: 9),
                ),
              ),
            ),
          ),
          borderData: FlBorderData(show: false),
          minY: 0,
          maxY: 100,
          lineBarsData: [
            LineChartBarData(
              spots: spots,
              isCurved: true,
              curveSmoothness: 0.5,
              color: AppColors.focus,
              barWidth: 2.5,
              dotData: FlDotData(
                show: true,
                getDotPainter: (spot, percent, bar, index) =>
                    FlDotCirclePainter(
                  radius: 3,
                  color: AppColors.focus,
                  strokeWidth: 0,
                ),
              ),
              belowBarData: BarAreaData(
                show: true,
                color: AppColors.focus.withOpacity(0.1),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRatingChart() {
    final ratingCounts = List.filled(5, 0);
    for (final s in _sessions) {
      final rating = (s['userProductivityRating'] as int?) ?? 0;
      if (rating >= 1 && rating <= 5) {
        ratingCounts[rating - 1]++;
      }
    }

    if (ratingCounts.every((c) => c == 0)) {
      return _emptyChart('No ratings yet');
    }

    return Container(
      height: 140,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.bg2,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: BarChart(
        BarChartData(
          alignment: BarChartAlignment.spaceAround,
          maxY: (ratingCounts.reduce((a, b) => a > b ? a : b) + 1).toDouble(),
          barTouchData: BarTouchData(enabled: false),
          titlesData: FlTitlesData(
            show: true,
            rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                getTitlesWidget: (value, _) => Text(
                  '⭐${value.toInt() + 1}',
                  style: const TextStyle(fontSize: 12),
                ),
              ),
            ),
          ),
          gridData: const FlGridData(show: false),
          borderData: FlBorderData(show: false),
          barGroups: ratingCounts
              .asMap()
              .entries
              .map((e) => BarChartGroupData(
                    x: e.key,
                    barRods: [
                      BarChartRodData(
                        toY: e.value.toDouble(),
                        color: AppColors.warning,
                        width: 24,
                        borderRadius: BorderRadius.circular(6),
                      ),
                    ],
                  ))
              .toList(),
        ),
      ),
    );
  }

  Widget _buildSessionTypeBreakdown() {
    final focus = _sessions.where((s) => s['sessionType'] == 'focus').length;
    final sleep = _sessions.where((s) => s['sessionType'] == 'sleep').length;
    final total = focus + sleep;

    if (total == 0) return _emptyChart('No sessions yet');

    return Row(
      children: [
        Expanded(
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.focus.withOpacity(0.1),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: AppColors.focus.withOpacity(0.3)),
            ),
            child: Column(
              children: [
                Text(
                  '$focus',
                  style: const TextStyle(
                    color: AppColors.focus,
                    fontSize: 32,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const Text(
                  'Focus',
                  style: TextStyle(color: AppColors.textSecondary, fontSize: 13),
                ),
              ],
            ),
          ),
        ),
        const Gap(12),
        Expanded(
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.sleep.withOpacity(0.1),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: AppColors.sleep.withOpacity(0.3)),
            ),
            child: Column(
              children: [
                Text(
                  '$sleep',
                  style: const TextStyle(
                    color: AppColors.sleep,
                    fontSize: 32,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const Text(
                  'Sleep',
                  style: TextStyle(color: AppColors.textSecondary, fontSize: 13),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _emptyChart(String label) {
    return Container(
      height: 100,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: AppColors.bg2,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Text(label, style: const TextStyle(color: AppColors.textMuted)),
    );
  }
}

class _SessionCard extends StatelessWidget {
  final Map<String, dynamic> session;
  const _SessionCard({required this.session});

  @override
  Widget build(BuildContext context) {
    final type = session['sessionType'] as String? ?? 'focus';
    final startTime = DateTime.tryParse(session['startTime'] as String? ?? '') ??
        DateTime.now();
    final rating = session['userProductivityRating'] as int?;
    final focusScore = session['avgFocusScore'] as double? ?? 0;
    final isCompleted = session['isCompleted'] as bool? ?? false;

    final isFocus = type == 'focus';
    final color = isFocus ? AppColors.focus : AppColors.sleep;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.bg2,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: color.withOpacity(0.15),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              isFocus ? Iconsax.cpu : Iconsax.moon,
              color: color,
              size: 20,
            ),
          ),
          const Gap(14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  isFocus ? 'Focus Session' : 'Sleep Session',
                  style: const TextStyle(
                    color: AppColors.textPrimary,
                    fontWeight: FontWeight.w600,
                    fontSize: 14,
                  ),
                ),
                const Gap(2),
                Text(
                  DateFormat('MMM d, h:mm a').format(startTime),
                  style: const TextStyle(
                    color: AppColors.textMuted,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                '${(focusScore * 100).toInt()}%',
                style: TextStyle(
                  color: color,
                  fontWeight: FontWeight.w700,
                  fontSize: 15,
                ),
              ),
              if (rating != null) ...[
                const Gap(2),
                Row(
                  children: List.generate(
                    rating,
                    (_) => const Icon(Icons.star_rounded,
                        size: 10, color: AppColors.warning),
                  ),
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color color;

  const _StatCard({
    required this.label,
    required this.value,
    required this.icon,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.bg2,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: color, size: 18),
          const Gap(8),
          Text(
            value,
            style: TextStyle(
              color: color,
              fontSize: 20,
              fontWeight: FontWeight.w700,
            ),
          ),
          const Gap(2),
          Text(
            label,
            style: const TextStyle(
              color: AppColors.textMuted,
              fontSize: 10,
            ),
          ),
        ],
      ),
    );
  }
}
