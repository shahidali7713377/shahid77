// lib/screens/home/home_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:gap/gap.dart';
import 'package:iconsax/iconsax.dart';
import 'package:fl_chart/fl_chart.dart';
import '../../blocs/sensor/sensor_bloc.dart';
import '../../blocs/sensor/sensor_event.dart';
import '../../blocs/sensor/sensor_state.dart';
import '../../blocs/environment/environment_bloc.dart';
import '../../blocs/recommendation/recommendation_bloc.dart';
import '../../blocs/session/session_bloc.dart';
import '../../core/theme/app_theme.dart';
import '../../core/constants/app_constants.dart';
import '../../models/sensor_data.dart';
import '../../models/recommendation.dart';
import '../../widgets/environment_score_gauge.dart';
import '../../widgets/sensor_metric_card.dart';
import '../../widgets/recommendation_card.dart';
import '../../widgets/live_waveform.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _pulseController;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg0,
      body: CustomScrollView(
        slivers: [
          _buildSliverAppBar(context),
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            sliver: SliverList(
              delegate: SliverChildListDelegate([
                const Gap(20),
                _buildEnvironmentScoreSection(context),
                const Gap(24),
                _buildSensorMetricsRow(context),
                const Gap(24),
                _buildQuickActionsRow(context),
                const Gap(24),
                _buildRecommendationsSection(context),
                const Gap(24),
                _buildHistoryChartSection(context),
                const Gap(100),
              ]),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSliverAppBar(BuildContext context) {
    return SliverAppBar(
      expandedHeight: 120,
      floating: false,
      pinned: true,
      backgroundColor: AppColors.bg0,
      surfaceTintColor: Colors.transparent,
      flexibleSpace: FlexibleSpaceBar(
        titlePadding: const EdgeInsets.only(left: 20, bottom: 16),
        title: BlocBuilder<SensorBloc, SensorState>(
          builder: (context, state) {
            final isActive = state is SensorActive;
            String statusText = 'Initializing...';
            Color statusColor = AppColors.textMuted;

            if (state is SensorActive) {
              statusText = 'Live Monitoring';
              statusColor = AppColors.success;
            } else if (state is SensorError) {
              statusText = 'Sensor Error';
              statusColor = AppColors.error;
            } else if (state is SensorPermissionRequired) {
              statusText = 'Permission Required';
              statusColor = AppColors.warning;
            } else if (state is SensorLoading) {
              statusText = 'Starting sensors...';
              statusColor = AppColors.textMuted;
            }

            return Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    AnimatedBuilder(
                      animation: _pulseController,
                      builder: (_, __) => Container(
                        width: 8,
                        height: 8,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: isActive
                              ? Color.lerp(statusColor,
                                  statusColor.withOpacity(0.3),
                                  _pulseController.value)!
                              : statusColor,
                          boxShadow: isActive
                              ? [
                                  BoxShadow(
                                    color: statusColor.withOpacity(
                                        0.5 * _pulseController.value),
                                    blurRadius: 8,
                                    spreadRadius: 2,
                                  )
                                ]
                              : null,
                        ),
                      ),
                    ),
                    const Gap(6),
                    Text(
                      statusText,
                      style: TextStyle(
                        fontSize: 11,
                        color: statusColor,
                        fontWeight: FontWeight.w500,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ],
                ),
                Text(
                  AppConstants.appName,
                  style: Theme.of(context).textTheme.headlineMedium,
                ),
              ],
            );
          },
        ),
        background: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [AppColors.bg0, AppColors.bg1],
            ),
          ),
        ),
      ),
      actions: [
        IconButton(
          icon: const Icon(Iconsax.notification, size: 22),
          color: AppColors.textSecondary,
          onPressed: () {},
        ),
        IconButton(
          icon: const Icon(Iconsax.setting_2, size: 22),
          color: AppColors.textSecondary,
          onPressed: () => Navigator.pushNamed(context, AppRoutes.settings),
        ),
        const Gap(8),
      ],
    );
  }

  Widget _buildEnvironmentScoreSection(BuildContext context) {
    return BlocBuilder<EnvironmentBloc, EnvironmentState>(
      builder: (context, state) {
        double focusScore = 0;
        double sleepScore = 0;
        String issue = '';

        if (state is EnvironmentAnalysisCompleted) {
          focusScore = state.analysis.focusScore;
          sleepScore = state.analysis.sleepScore;
          issue = state.analysis.dominantIssue;
        }

        return Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [AppColors.bg2, AppColors.bg2.withBlue(45)],
            ),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: AppColors.border),
          ),
          child: Column(
            children: [
              Row(
                children: [
                  Expanded(
                    child: EnvironmentScoreGauge(
                      score: focusScore,
                      label: 'Focus',
                      colors: AppColors.focusGradient,
                    )
                        .animate()
                        .fadeIn(duration: 600.ms)
                        .scale(
                          begin: const Offset(0.8, 0.8),
                          duration: 600.ms,
                          curve: Curves.elasticOut,
                        ),
                  ),
                  Container(
                    width: 1,
                    height: 80,
                    color: AppColors.border,
                    margin: const EdgeInsets.symmetric(horizontal: 20),
                  ),
                  Expanded(
                    child: EnvironmentScoreGauge(
                      score: sleepScore,
                      label: 'Sleep',
                      colors: AppColors.sleepGradient,
                    )
                        .animate()
                        .fadeIn(duration: 600.ms, delay: 200.ms)
                        .scale(
                          begin: const Offset(0.8, 0.8),
                          duration: 600.ms,
                          delay: 200.ms,
                          curve: Curves.elasticOut,
                        ),
                  ),
                ],
              ),
              if (issue.isNotEmpty && issue != 'none') ...[
                const Gap(16),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    color: AppColors.warning.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(8),
                    border:
                        Border.all(color: AppColors.warning.withOpacity(0.3)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Iconsax.warning_2,
                          size: 14, color: AppColors.warning),
                      const Gap(6),
                      Text(
                        _issueToLabel(issue),
                        style: const TextStyle(
                          fontSize: 12,
                          color: AppColors.warning,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ],
          ),
        );
      },
    );
  }

  String _issueToLabel(String issue) {
    switch (issue) {
      case 'insufficient_light':
        return 'Lighting too low for optimal focus';
      case 'excess_light':
        return 'Glare detected – reduce brightness';
      case 'high_noise':
        return 'Noise level is affecting concentration';
      case 'multiple_issues':
        return 'Multiple environment factors need attention';
      default:
        return 'Environment could be optimized';
    }
  }

  Widget _buildSensorMetricsRow(BuildContext context) {
    return BlocBuilder<SensorBloc, SensorState>(
      builder: (context, state) {
        // ── Extract real sensor values ───────────────────────────────────
        double lux = 0;
        double db = 0;
        LightCondition lightCond = LightCondition.unknown;
        SoundCondition soundCond = SoundCondition.unknown;
        bool isActive = false;
        bool lightSensorAvailable = true;
        bool micAvailable = true;

        if (state is SensorActive) {
          isActive = true;
          lux = state.currentData.luxValue;
          db = state.currentData.decibelValue;
          lightCond = state.currentData.lightCondition;
          soundCond = state.currentData.soundCondition;
          lightSensorAvailable = state.isLightAvailable;
          micAvailable = state.isMicAvailable;
        }

        // Format lux — don't show decimal, but show "–" if unavailable
        final luxDisplay = !isActive
            ? '–'
            : !lightSensorAvailable
                ? 'N/A'
                : lux <= 0
                    ? '0 lux'
                    : '${lux.round()} lux';

        // Format dB — noise_meter can give fractional; round to int
        final dbDisplay = !isActive
            ? '–'
            : !micAvailable
                ? 'N/A'
                : db <= 0
                    ? '0 dB'
                    : '${db.round()} dB';

        final lightLabel = !lightSensorAvailable
            ? 'No Sensor'
            : lux <= 0 && isActive
                ? 'No Signal'
                : lightCond.label;

        final soundLabel = !micAvailable
            ? 'No Mic'
            : db <= 0 && isActive
                ? 'No Signal'
                : soundCond.label;

        return Row(
          children: [
            Expanded(
              child: SensorMetricCard(
                icon: Iconsax.sun_1,
                label: 'Light',
                value: luxDisplay,
                subLabel: lightLabel,
                color: _lightColor(lightCond),
                showPulse: isActive && lux > 0,
              ).animate().slideX(begin: -0.2, duration: 400.ms),
            ),
            const Gap(12),
            Expanded(
              child: SensorMetricCard(
                icon: Iconsax.microphone,
                label: 'Sound',
                value: dbDisplay,
                subLabel: soundLabel,
                color: _soundColor(soundCond),
                showPulse: isActive && db > 0,
                customWidget: (isActive && db > 0)
                    ? LiveWaveform(decibelValue: db)
                    : null,
              ).animate().slideX(begin: 0.2, duration: 400.ms),
            ),
          ],
        );
      },
    );
  }

  Color _lightColor(LightCondition c) {
    switch (c) {
      case LightCondition.dark:
        return AppColors.dark;
      case LightCondition.dim:
        return AppColors.dim;
      case LightCondition.optimal:
        return AppColors.optimal;
      case LightCondition.overexposed:
        return AppColors.overexposed;
      case LightCondition.unknown:
        return AppColors.textMuted;
    }
  }

  Color _soundColor(SoundCondition c) {
    switch (c) {
      case SoundCondition.silent:
        return AppColors.silent;
      case SoundCondition.backgroundNoise:
        return AppColors.backgroundNoise;
      case SoundCondition.conversation:
        return AppColors.conversation;
      case SoundCondition.traffic:
        return AppColors.traffic;
      case SoundCondition.highDistraction:
        return AppColors.highDistraction;
      case SoundCondition.unknown:
        return AppColors.textMuted;
    }
  }

  Widget _buildQuickActionsRow(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: _QuickActionButton(
            icon: Iconsax.cpu,
            label: 'Focus Mode',
            gradient: AppColors.focusGradient,
            onTap: () => Navigator.pushNamed(context, AppRoutes.focusMode),
          ),
        ),
        const Gap(12),
        Expanded(
          child: _QuickActionButton(
            icon: Iconsax.moon,
            label: 'Sleep Mode',
            gradient: AppColors.sleepGradient,
            onTap: () => Navigator.pushNamed(context, AppRoutes.sleepMode),
          ),
        ),
      ],
    ).animate().fadeIn(delay: 300.ms);
  }

  Widget _buildRecommendationsSection(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('Recommendations',
                style: Theme.of(context).textTheme.titleLarge),
            TextButton(
              onPressed: () {},
              child: const Text('See all',
                  style: TextStyle(color: AppColors.primary, fontSize: 13)),
            ),
          ],
        ),
        const Gap(12),
        BlocBuilder<RecommendationBloc, RecommendationState>(
          builder: (context, state) {
            List<Recommendation> recs = [];
            if (state is RecommendationGenerated) {
              recs = state.activeRecommendations;
            } else if (state is RecommendationUpdated) {
              recs =
                  state.recommendations.where((r) => !r.isDismissed).toList();
            }

            if (recs.isEmpty) return _buildNoRecommendations();

            return Column(
              children: recs
                  .take(3)
                  .toList()
                  .asMap()
                  .entries
                  .map((e) => Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: RecommendationCard(
                          recommendation: e.value,
                          onDismiss: () {
                            context.read<RecommendationBloc>().add(
                                RecommendationDismissEvent(e.value.id));
                          },
                          onActedOn: () {
                            context.read<RecommendationBloc>().add(
                                RecommendationActedOnEvent(e.value.id));
                          },
                        ).animate().slideY(
                              begin: 0.3,
                              duration: 400.ms,
                              delay:
                                  Duration(milliseconds: e.key * 100),
                            ),
                      ))
                  .toList(),
            );
          },
        ),
      ],
    );
  }

  Widget _buildNoRecommendations() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: AppColors.bg2,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: const Center(
        child: Column(
          children: [
            Icon(Iconsax.tick_circle, color: AppColors.success, size: 32),
            Gap(10),
            Text(
              'Your environment looks great!',
              style: TextStyle(color: AppColors.textSecondary, fontSize: 14),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHistoryChartSection(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text("Today's Environment",
            style: Theme.of(context).textTheme.titleLarge),
        const Gap(16),
        _HistoryLineChart(),
      ],
    );
  }
}

// ─── Quick Action Button ───────────────────────────────────────────────────────

class _QuickActionButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final List<Color> gradient;
  final VoidCallback onTap;

  const _QuickActionButton({
    required this.icon,
    required this.label,
    required this.gradient,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 16),
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: gradient),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: gradient.first.withOpacity(0.3),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            Icon(icon, color: Colors.white, size: 20),
            const Gap(10),
            Text(
              label,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w600,
                fontSize: 14,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── History Line Chart ────────────────────────────────────────────────────────

class _HistoryLineChart extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<EnvironmentBloc, EnvironmentState>(
      builder: (context, state) {
        List<FlSpot> focusSpots = [];
        List<FlSpot> sleepSpots = [];

        if (state is EnvironmentAnalysisCompleted &&
            state.history.isNotEmpty) {
          final history = state.history.take(60).toList();
          for (int i = 0; i < history.length; i++) {
            focusSpots
                .add(FlSpot(i.toDouble(), history[i].focusScore * 100));
            sleepSpots
                .add(FlSpot(i.toDouble(), history[i].sleepScore * 100));
          }
        }

        if (focusSpots.isEmpty) {
          return Container(
            height: 180,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.bg2,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppColors.border),
            ),
            child: const Center(
              child: Text(
                'Waiting for sensor data...',
                style: TextStyle(color: AppColors.textMuted, fontSize: 13),
              ),
            ),
          );
        }

        return Container(
          height: 180,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppColors.bg2,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.border),
          ),
          child: LineChart(
            LineChartData(
              gridData: FlGridData(
                show: true,
                drawVerticalLine: false,
                getDrawingHorizontalLine: (_) =>
                    const FlLine(color: AppColors.border, strokeWidth: 1),
              ),
              titlesData: FlTitlesData(
                show: true,
                rightTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false)),
                topTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false)),
                bottomTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false)),
                leftTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    interval: 50,
                    reservedSize: 32,
                    getTitlesWidget: (value, meta) => Text(
                      '${value.toInt()}',
                      style: const TextStyle(
                          color: AppColors.textMuted, fontSize: 10),
                    ),
                  ),
                ),
              ),
              borderData: FlBorderData(show: false),
              minY: 0,
              maxY: 100,
              lineBarsData: [
                LineChartBarData(
                  spots: focusSpots,
                  isCurved: true,
                  curveSmoothness: 0.3,
                  color: AppColors.focus,
                  barWidth: 2,
                  isStrokeCapRound: true,
                  dotData: const FlDotData(show: false),
                  belowBarData: BarAreaData(
                    show: true,
                    color: AppColors.focus.withOpacity(0.08),
                  ),
                ),
                LineChartBarData(
                  spots: sleepSpots,
                  isCurved: true,
                  curveSmoothness: 0.3,
                  color: AppColors.sleep,
                  barWidth: 2,
                  isStrokeCapRound: true,
                  dotData: const FlDotData(show: false),
                  belowBarData: BarAreaData(
                    show: true,
                    color: AppColors.sleep.withOpacity(0.08),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
