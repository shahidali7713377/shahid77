// lib/screens/settings/settings_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:gap/gap.dart';
import 'package:iconsax/iconsax.dart';
import '../../core/theme/app_theme.dart';
import '../../services/storage_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _notificationsEnabled = true;
  bool _backgroundMonitoring = false;
  int _focusStartHour = 9;
  int _focusEndHour = 18;
  int _sleepStartHour = 22;
  int _defaultFocusDuration = 25;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final storage = context.read<StorageService>();
    setState(() {
      _notificationsEnabled =
          storage.getPreference('notifications', defaultValue: true) as bool;
      _backgroundMonitoring =
          storage.getPreference('bg_monitoring', defaultValue: false) as bool;
      _focusStartHour =
          storage.getPreference('focus_start_hour', defaultValue: 9) as int;
      _focusEndHour =
          storage.getPreference('focus_end_hour', defaultValue: 18) as int;
      _sleepStartHour =
          storage.getPreference('sleep_start_hour', defaultValue: 22) as int;
      _defaultFocusDuration =
          storage.getPreference('default_focus_min', defaultValue: 25) as int;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg0,
      appBar: AppBar(
        backgroundColor: AppColors.bg0,
        title: const Text('Settings'),
        leading: IconButton(
          icon: const Icon(Iconsax.arrow_left, size: 22),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSection(
              title: 'Schedule',
              children: [
                _buildTimeSetting(
                  'Focus Hours Start',
                  '${_focusStartHour}:00',
                  Iconsax.cpu,
                  () => _pickHour(
                    initial: _focusStartHour,
                    onSelected: (h) {
                      setState(() => _focusStartHour = h);
                      context
                          .read<StorageService>()
                          .setPreference('focus_start_hour', h);
                    },
                  ),
                ),
                _buildTimeSetting(
                  'Focus Hours End',
                  '${_focusEndHour}:00',
                  Iconsax.cpu,
                  () => _pickHour(
                    initial: _focusEndHour,
                    onSelected: (h) {
                      setState(() => _focusEndHour = h);
                      context
                          .read<StorageService>()
                          .setPreference('focus_end_hour', h);
                    },
                  ),
                ),
                _buildTimeSetting(
                  'Sleep Bedtime',
                  '${_sleepStartHour}:00',
                  Iconsax.moon,
                  () => _pickHour(
                    initial: _sleepStartHour,
                    onSelected: (h) {
                      setState(() => _sleepStartHour = h);
                      context
                          .read<StorageService>()
                          .setPreference('sleep_start_hour', h);
                    },
                  ),
                ),
              ],
            ).animate().fadeIn(delay: 100.ms),

            const Gap(20),

            _buildSection(
              title: 'Focus Session',
              children: [
                _buildSliderSetting(
                  'Default Duration',
                  '$_defaultFocusDuration min',
                  Iconsax.timer_1,
                  _defaultFocusDuration.toDouble(),
                  15,
                  90,
                  (v) {
                    setState(() => _defaultFocusDuration = v.toInt());
                    context
                        .read<StorageService>()
                        .setPreference('default_focus_min', v.toInt());
                  },
                ),
              ],
            ).animate().fadeIn(delay: 200.ms),

            const Gap(20),

            _buildSection(
              title: 'Monitoring',
              children: [
                _buildSwitchSetting(
                  'Notifications',
                  'Get environment alerts',
                  Iconsax.notification,
                  _notificationsEnabled,
                  (v) {
                    setState(() => _notificationsEnabled = v);
                    context
                        .read<StorageService>()
                        .setPreference('notifications', v);
                  },
                ),
                _buildSwitchSetting(
                  'Background Monitoring',
                  'Monitor environment when app is closed (uses more battery)',
                  Iconsax.cpu,
                  _backgroundMonitoring,
                  (v) {
                    setState(() => _backgroundMonitoring = v);
                    context
                        .read<StorageService>()
                        .setPreference('bg_monitoring', v);
                  },
                ),
              ],
            ).animate().fadeIn(delay: 300.ms),

            const Gap(20),

            _buildSection(
              title: 'Privacy',
              children: [
                _buildInfoTile(
                  'Audio Storage',
                  'No audio recordings are stored. Only decibel level measurements.',
                  Iconsax.microphone_slash,
                  AppColors.success,
                ),
                _buildInfoTile(
                  'Data Location',
                  'All data is stored locally on your device. No cloud uploads.',
                  Iconsax.lock,
                  AppColors.success,
                ),
                _buildInfoTile(
                  'Internet Usage',
                  'This app is 100% offline. No external API calls are made.',
                  Iconsax.wifi_square,
                  AppColors.success,
                ),
              ],
            ).animate().fadeIn(delay: 400.ms),

            const Gap(20),

            _buildSection(
              title: 'Data',
              children: [
                _buildActionTile(
                  'Clear History',
                  'Delete all session records',
                  Iconsax.trash,
                  AppColors.error,
                  () => _showClearDataDialog(context),
                ),
              ],
            ).animate().fadeIn(delay: 500.ms),

            const Gap(40),

            Center(
              child: Column(
                children: [
                  Text(
                    AppConstants.appName,
                    style: const TextStyle(
                      color: AppColors.textMuted,
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const Gap(4),
                  Text(
                    'v${AppConstants.appVersion} • 100% Offline',
                    style: const TextStyle(
                      color: AppColors.textMuted,
                      fontSize: 11,
                    ),
                  ),
                ],
              ),
            ),

            const Gap(40),
          ],
        ),
      ),
    );
  }

  Widget _buildSection({required String title, required List<Widget> children}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title.toUpperCase(),
          style: const TextStyle(
            color: AppColors.textMuted,
            fontSize: 11,
            fontWeight: FontWeight.w600,
            letterSpacing: 1.2,
          ),
        ),
        const Gap(10),
        Container(
          decoration: BoxDecoration(
            color: AppColors.bg2,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.border),
          ),
          child: Column(
            children: children
                .asMap()
                .entries
                .map((e) => Column(
                      children: [
                        e.value,
                        if (e.key < children.length - 1)
                          const Divider(height: 0, color: AppColors.border),
                      ],
                    ))
                .toList(),
          ),
        ),
      ],
    );
  }

  Widget _buildSwitchSetting(
    String label,
    String sublabel,
    IconData icon,
    bool value,
    ValueChanged<bool> onChanged,
  ) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        children: [
          Icon(icon, size: 20, color: AppColors.textSecondary),
          const Gap(14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: const TextStyle(
                    color: AppColors.textPrimary,
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                Text(
                  sublabel,
                  style: const TextStyle(
                    color: AppColors.textMuted,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
          Switch(value: value, onChanged: onChanged),
        ],
      ),
    );
  }

  Widget _buildTimeSetting(
    String label,
    String value,
    IconData icon,
    VoidCallback onTap,
  ) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Row(
          children: [
            Icon(icon, size: 20, color: AppColors.textSecondary),
            const Gap(14),
            Expanded(
              child: Text(
                label,
                style: const TextStyle(
                  color: AppColors.textPrimary,
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
            Text(
              value,
              style: const TextStyle(
                color: AppColors.primary,
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
            ),
            const Gap(8),
            const Icon(Iconsax.arrow_right_3, size: 16, color: AppColors.textMuted),
          ],
        ),
      ),
    );
  }

  Widget _buildSliderSetting(
    String label,
    String value,
    IconData icon,
    double current,
    double min,
    double max,
    ValueChanged<double> onChanged,
  ) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Column(
        children: [
          Row(
            children: [
              Icon(icon, size: 20, color: AppColors.textSecondary),
              const Gap(14),
              Expanded(
                child: Text(
                  label,
                  style: const TextStyle(
                    color: AppColors.textPrimary,
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
              Text(
                value,
                style: const TextStyle(
                  color: AppColors.primary,
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          Slider(
            value: current,
            min: min,
            max: max,
            divisions: ((max - min) ~/ 5),
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }

  Widget _buildInfoTile(
    String label,
    String description,
    IconData icon,
    Color color,
  ) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 18, color: color),
          const Gap(14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: const TextStyle(
                    color: AppColors.textPrimary,
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const Gap(2),
                Text(
                  description,
                  style: const TextStyle(
                    color: AppColors.textMuted,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionTile(
    String label,
    String sublabel,
    IconData icon,
    Color color,
    VoidCallback onTap,
  ) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Row(
          children: [
            Icon(icon, size: 20, color: color),
            const Gap(14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: TextStyle(
                      color: color,
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  Text(
                    sublabel,
                    style: const TextStyle(
                      color: AppColors.textMuted,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _pickHour({required int initial, required ValueChanged<int> onSelected}) {
    showDialog(
      context: context,
      builder: (_) => _HourPickerDialog(
        initial: initial,
        onSelected: onSelected,
      ),
    );
  }

  void _showClearDataDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.bg2,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Clear All Data?'),
        content: const Text(
          'This will permanently delete all session records and history. This cannot be undone.',
          style: TextStyle(color: AppColors.textSecondary),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () async {
              await context.read<StorageService>().clearAllData();
              if (mounted) Navigator.pop(context);
            },
            child: const Text('Clear', style: TextStyle(color: AppColors.error)),
          ),
        ],
      ),
    );
  }
}

class _HourPickerDialog extends StatefulWidget {
  final int initial;
  final ValueChanged<int> onSelected;

  const _HourPickerDialog({required this.initial, required this.onSelected});

  @override
  State<_HourPickerDialog> createState() => _HourPickerDialogState();
}

class _HourPickerDialogState extends State<_HourPickerDialog> {
  late int _selected;

  @override
  void initState() {
    super.initState();
    _selected = widget.initial;
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: AppColors.bg2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      title: const Text('Select Hour'),
      content: SizedBox(
        width: double.maxFinite,
        height: 240,
        child: GridView.builder(
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 6,
            childAspectRatio: 1,
            crossAxisSpacing: 4,
            mainAxisSpacing: 4,
          ),
          itemCount: 24,
          itemBuilder: (_, i) {
            final isSelected = i == _selected;
            return GestureDetector(
              onTap: () => setState(() => _selected = i),
              child: Container(
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: isSelected ? AppColors.primary : AppColors.bg3,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  i.toString().padLeft(2, '0'),
                  style: TextStyle(
                    color: isSelected ? AppColors.bg0 : AppColors.textSecondary,
                    fontSize: 12,
                    fontWeight:
                        isSelected ? FontWeight.w700 : FontWeight.w400,
                  ),
                ),
              ),
            );
          },
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        TextButton(
          onPressed: () {
            widget.onSelected(_selected);
            Navigator.pop(context);
          },
          child:
              const Text('OK', style: TextStyle(color: AppColors.primary)),
        ),
      ],
    );
  }
}
