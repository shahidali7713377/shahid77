// lib/screens/onboarding/onboarding_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:gap/gap.dart';
import 'package:iconsax/iconsax.dart';
import 'package:permission_handler/permission_handler.dart';
import '../../core/theme/app_theme.dart';
import '../../core/constants/app_constants.dart';
import '../../services/storage_service.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController _pageController = PageController();
  int _currentPage = 0;
  bool _micGranted = false;
  bool _cameraGranted = false;
  bool _notificationGranted = false;

  final _pages = [
    _OnboardingPage(
      icon: '🧠',
      title: 'Intelligent\nEnvironment',
      subtitle:
          'EnvIQ learns the precise lighting and noise conditions under which you perform best—entirely on your device.',
      color: AppColors.primary,
    ),
    _OnboardingPage(
      icon: '🔒',
      title: 'Completely\nPrivate',
      subtitle:
          'Zero cloud uploads. No recordings stored. All AI inference runs locally on your device—your data never leaves.',
      color: AppColors.sleep,
    ),
    _OnboardingPage(
      icon: '📡',
      title: 'Sensor\nAccess',
      subtitle:
          'EnvIQ needs microphone access to measure ambient noise (decibel level only—no recordings) and camera for light estimation.',
      color: AppColors.warning,
      isPermissionPage: true,
    ),
  ];

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg0,
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: PageView.builder(
                controller: _pageController,
                onPageChanged: (i) => setState(() => _currentPage = i),
                itemCount: _pages.length,
                itemBuilder: (_, i) => _buildPage(_pages[i], i),
              ),
            ),
            _buildBottomSection(),
          ],
        ),
      ),
    );
  }

  Widget _buildPage(_OnboardingPage page, int index) {
    return Padding(
      padding: const EdgeInsets.all(32),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            page.icon,
            style: const TextStyle(fontSize: 80),
          ).animate(key: ValueKey(index)).scale(
            duration: 600.ms,
            curve: Curves.elasticOut,
          ),
          const Gap(40),
          Text(
            page.title,
            style: Theme.of(context).textTheme.displaySmall?.copyWith(
                  color: page.color,
                  height: 1.1,
                ),
            textAlign: TextAlign.center,
          ).animate(key: ValueKey('title_$index')).fadeIn(delay: 200.ms).slideY(
                begin: 0.2,
                duration: 400.ms,
                delay: 200.ms,
              ),
          const Gap(16),
          Text(
            page.subtitle,
            style: const TextStyle(
              color: AppColors.textSecondary,
              fontSize: 15,
              height: 1.6,
            ),
            textAlign: TextAlign.center,
          ).animate(key: ValueKey('sub_$index')).fadeIn(delay: 300.ms),

          if (page.isPermissionPage) ...[
            const Gap(40),
            _buildPermissionsList(),
          ],
        ],
      ),
    );
  }

  Widget _buildPermissionsList() {
    return Column(
      children: [
        _PermissionRow(
          icon: Iconsax.microphone,
          label: 'Microphone',
          description: 'Measure ambient noise (dB only)',
          isGranted: _micGranted,
          onRequest: _requestMic,
        ),
        const Gap(10),
        _PermissionRow(
          icon: Iconsax.camera,
          label: 'Camera',
          description: 'Estimate ambient light levels',
          isGranted: _cameraGranted,
          onRequest: _requestCamera,
        ),
        const Gap(10),
        _PermissionRow(
          icon: Iconsax.notification,
          label: 'Notifications',
          description: 'Get environment alerts',
          isGranted: _notificationGranted,
          onRequest: _requestNotifications,
          isOptional: true,
        ),
      ],
    ).animate().fadeIn(delay: 400.ms);
  }

  Future<void> _requestMic() async {
    final status = await Permission.microphone.request();
    setState(() => _micGranted = status.isGranted);
  }

  Future<void> _requestCamera() async {
    final status = await Permission.camera.request();
    setState(() => _cameraGranted = status.isGranted);
  }

  Future<void> _requestNotifications() async {
    final status = await Permission.notification.request();
    setState(() => _notificationGranted = status.isGranted);
  }

  Widget _buildBottomSection() {
    final isLastPage = _currentPage == _pages.length - 1;
    final canProceed = !isLastPage || _micGranted || _cameraGranted;

    return Padding(
      padding: const EdgeInsets.all(32),
      child: Column(
        children: [
          // Page indicators
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(
              _pages.length,
              (i) => AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                margin: const EdgeInsets.symmetric(horizontal: 4),
                width: i == _currentPage ? 24 : 6,
                height: 6,
                decoration: BoxDecoration(
                  color: i == _currentPage
                      ? AppColors.primary
                      : AppColors.textMuted,
                  borderRadius: BorderRadius.circular(3),
                ),
              ),
            ),
          ),
          const Gap(24),

          Row(
            children: [
              if (_currentPage > 0)
                TextButton(
                  onPressed: () => _pageController.previousPage(
                    duration: const Duration(milliseconds: 300),
                    curve: Curves.easeInOut,
                  ),
                  child: const Text('Back',
                      style: TextStyle(color: AppColors.textMuted)),
                ),
              const Spacer(),
              ElevatedButton(
                onPressed: canProceed
                    ? () async {
                        if (isLastPage) {
                          HapticFeedback.mediumImpact();
                          await context
                              .read<StorageService>()
                              .markOnboardingCompleted();
                          if (mounted) {
                            Navigator.pushReplacementNamed(
                                context, AppRoutes.home);
                          }
                        } else {
                          _pageController.nextPage(
                            duration: const Duration(milliseconds: 300),
                            curve: Curves.easeInOut,
                          );
                        }
                      }
                    : null,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 32, vertical: 14),
                ),
                child: Text(isLastPage ? 'Get Started' : 'Next'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _OnboardingPage {
  final String icon;
  final String title;
  final String subtitle;
  final Color color;
  final bool isPermissionPage;

  const _OnboardingPage({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.color,
    this.isPermissionPage = false,
  });
}

class _PermissionRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String description;
  final bool isGranted;
  final VoidCallback onRequest;
  final bool isOptional;

  const _PermissionRow({
    required this.icon,
    required this.label,
    required this.description,
    required this.isGranted,
    required this.onRequest,
    this.isOptional = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.bg2,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: isGranted
              ? AppColors.success.withOpacity(0.4)
              : AppColors.border,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: isGranted
                  ? AppColors.success.withOpacity(0.15)
                  : AppColors.bg3,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(
              icon,
              size: 18,
              color: isGranted ? AppColors.success : AppColors.textSecondary,
            ),
          ),
          const Gap(12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      label,
                      style: const TextStyle(
                        color: AppColors.textPrimary,
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    if (isOptional) ...[
                      const Gap(6),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 5, vertical: 1),
                        decoration: BoxDecoration(
                          color: AppColors.textMuted.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: const Text(
                          'optional',
                          style: TextStyle(
                              color: AppColors.textMuted, fontSize: 9),
                        ),
                      ),
                    ],
                  ],
                ),
                Text(
                  description,
                  style: const TextStyle(
                    color: AppColors.textMuted,
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ),
          if (isGranted)
            const Icon(Iconsax.tick_circle, color: AppColors.success, size: 20)
          else
            TextButton(
              onPressed: onRequest,
              style: TextButton.styleFrom(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                minimumSize: Size.zero,
                tapTargetSize: MaterialTapTargetSize.shrinkWrap,
              ),
              child: const Text(
                'Allow',
                style: TextStyle(
                  color: AppColors.primary,
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
        ],
      ),
    );
  }
}
