// lib/screens/sleep/sleep_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:gap/gap.dart';
import 'package:iconsax/iconsax.dart';
import 'package:percent_indicator/percent_indicator.dart';
import '../../blocs/session/session_bloc.dart';
import '../../blocs/environment/environment_bloc.dart';
import '../../blocs/recommendation/recommendation_bloc.dart';
import '../../core/theme/app_theme.dart';
import '../../core/constants/app_constants.dart';
import '../../models/recommendation.dart';
import '../../widgets/recommendation_card.dart';
import '../../widgets/session_feedback_sheet.dart';

class SleepScreen extends StatefulWidget {
  const SleepScreen({super.key});

  @override
  State<SleepScreen> createState() => _SleepScreenState();
}

class _SleepScreenState extends State<SleepScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _starController;

  @override
  void initState() {
    super.initState();
    _starController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat(reverse: true);

    // Generate sleep-specific recommendations
    final envState = context.read<EnvironmentBloc>().state;
    if (envState is EnvironmentAnalysisCompleted) {
      context.read<RecommendationBloc>().add(
        RecommendationGenerateEvent(
          analysis: envState.analysis,
          isSleepMode: true,
        ),
      );
    }
  }

  @override
  void dispose() {
    _starController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener<SessionBloc, SessionState>(
      listener: (context, state) {
        if (state is SessionFeedbackRequired) {
          _showFeedbackSheet(context, state);
        }
      },
      child: Scaffold(
        backgroundColor: AppColors.bg0,
        body: CustomScrollView(
          slivers: [
            SliverAppBar(
              pinned: true,
              backgroundColor: AppColors.bg0,
              leading: IconButton(
                icon: const Icon(Iconsax.arrow_left, size: 22),
                onPressed: () => Navigator.pop(context),
              ),
              title: const Text('Sleep Mode'),
              actions: const [Gap(16)],
            ),
            SliverPadding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              sliver: SliverList(
                delegate: SliverChildListDelegate([
                  const Gap(20),
                  _buildSleepReadinessScore(context),
                  const Gap(24),
                  _buildChecklist(context),
                  const Gap(24),
                  _buildRecommendations(context),
                  const Gap(24),
                  _buildStartSleepButton(context),
                  const Gap(100),
                ]),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSleepReadinessScore(BuildContext context) {
    return BlocBuilder<EnvironmentBloc, EnvironmentState>(
      builder: (context, state) {
        double sleepScore = 0;
        if (state is EnvironmentAnalysisCompleted) {
          sleepScore = state.analysis.sleepScore;
        }

        return Container(
          padding: const EdgeInsets.all(28),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: AppColors.sleepGradient,
            ),
            borderRadius: BorderRadius.circular(24),
            boxShadow: [
              BoxShadow(
                color: AppColors.sleep.withOpacity(0.3),
                blurRadius: 24,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Sleep Readiness',
                        style: TextStyle(
                          color: Colors.white70,
                          fontSize: 13,
                          letterSpacing: 0.5,
                        ),
                      ),
                      const Gap(4),
                      Text(
                        '${(sleepScore * 100).toInt()}%',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 52,
                          fontWeight: FontWeight.w700,
                          height: 1,
                        ),
                      ),
                      const Gap(4),
                      Text(
                        _sleepReadinessLabel(sleepScore),
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.8),
                          fontSize: 15,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                  AnimatedBuilder(
                    animation: _starController,
                    builder: (_, __) => Stack(
                      alignment: Alignment.center,
                      children: [
                        Container(
                          width: 90,
                          height: 90,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors.white.withOpacity(
                              0.05 + _starController.value * 0.05,
                            ),
                          ),
                        ),
                        const Text('🌙', style: TextStyle(fontSize: 44)),
                      ],
                    ),
                  ),
                ],
              ),
              const Gap(20),
              LinearProgressIndicator(
                value: sleepScore,
                backgroundColor: Colors.white.withOpacity(0.2),
                valueColor: const AlwaysStoppedAnimation<Color>(Colors.white),
                borderRadius: BorderRadius.circular(4),
                minHeight: 6,
              ),
            ],
          ),
        ).animate().fadeIn(duration: 600.ms).slideY(begin: 0.2);
      },
    );
  }

  String _sleepReadinessLabel(double score) {
    if (score >= 0.8) return 'Ready for deep sleep';
    if (score >= 0.6) return 'Almost ready';
    if (score >= 0.4) return 'Needs improvement';
    return 'Poor sleep conditions';
  }

  Widget _buildChecklist(BuildContext context) {
    return BlocBuilder<EnvironmentBloc, EnvironmentState>(
      builder: (context, state) {
        double lux = 0;
        double db = 0;
        bool isNightTime = false;

        if (state is EnvironmentAnalysisCompleted) {
          lux = state.analysis.sensorData.luxValue;
          db = state.analysis.sensorData.decibelValue;
          isNightTime = DateTime.now().hour >= 20 || DateTime.now().hour < 7;
        }

        final checks = [
          _SleepCheck(
            label: 'Room lighting',
            description: '${lux.toInt()} lux',
            isGood: lux < AppConstants.luxDim,
            icon: Iconsax.sun_1,
          ),
          _SleepCheck(
            label: 'Noise level',
            description: '${db.toInt()} dB',
            isGood: db < AppConstants.dbBackground,
            icon: Iconsax.microphone,
          ),
          _SleepCheck(
            label: 'Sleep window',
            description: isNightTime ? 'Good time to sleep' : 'Not ideal yet',
            isGood: isNightTime,
            icon: Iconsax.clock,
          ),
        ];

        return Container(
          decoration: BoxDecoration(
            color: AppColors.bg2,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.border),
          ),
          child: Column(
            children: checks
                .asMap()
                .entries
                .map((e) => Column(
                      children: [
                        _buildCheckRow(e.value),
                        if (e.key < checks.length - 1)
                          const Divider(height: 0, color: AppColors.border),
                      ],
                    ))
                .toList(),
          ),
        ).animate().fadeIn(delay: 200.ms);
      },
    );
  }

  Widget _buildCheckRow(_SleepCheck check) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: check.isGood
                  ? AppColors.success.withOpacity(0.15)
                  : AppColors.error.withOpacity(0.15),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(
              check.icon,
              color: check.isGood ? AppColors.success : AppColors.error,
              size: 18,
            ),
          ),
          const Gap(12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  check.label,
                  style: const TextStyle(
                    color: AppColors.textPrimary,
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                Text(
                  check.description,
                  style: const TextStyle(
                    color: AppColors.textMuted,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
          Icon(
            check.isGood ? Iconsax.tick_circle : Iconsax.close_circle,
            color: check.isGood ? AppColors.success : AppColors.error,
            size: 20,
          ),
        ],
      ),
    );
  }

  Widget _buildRecommendations(BuildContext context) {
    return BlocBuilder<RecommendationBloc, RecommendationState>(
      builder: (context, state) {
        List<Recommendation> recs = [];
        if (state is RecommendationGenerated) {
          recs = state.activeRecommendations
              .where((r) => r.category == RecommendationCategory.sleep)
              .take(3)
              .toList();
        }

        if (recs.isEmpty) return const SizedBox();

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Sleep Optimization',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            const Gap(12),
            ...recs.map((rec) => Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: RecommendationCard(
                    recommendation: rec,
                    accentColor: AppColors.sleep,
                    onDismiss: () => context
                        .read<RecommendationBloc>()
                        .add(RecommendationDismissEvent(rec.id)),
                    onActedOn: () => context
                        .read<RecommendationBloc>()
                        .add(RecommendationActedOnEvent(rec.id)),
                  ),
                )),
          ],
        );
      },
    );
  }

  Widget _buildStartSleepButton(BuildContext context) {
    return BlocBuilder<SessionBloc, SessionState>(
      builder: (context, state) {
        final isActive = state is SessionActive && state.sessionType == 'sleep';

        if (isActive) {
          return OutlinedButton(
            onPressed: () {
              HapticFeedback.heavyImpact();
              context.read<SessionBloc>().add(const SessionEndEvent());
            },
            style: OutlinedButton.styleFrom(
              foregroundColor: AppColors.sleep,
              side: const BorderSide(color: AppColors.sleep),
              minimumSize: const Size(double.infinity, 56),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
            ),
            child: const Text('End Sleep Tracking'),
          );
        }

        return ElevatedButton(
          onPressed: () {
            HapticFeedback.mediumImpact();
            context.read<SessionBloc>().add(const SessionStartSleepEvent());
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.sleep,
            minimumSize: const Size(double.infinity, 56),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
          ),
          child: const Text(
            'Start Sleep Tracking',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: Colors.white,
            ),
          ),
        );
      },
    );
  }

  void _showFeedbackSheet(BuildContext context, SessionFeedbackRequired state) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => SessionFeedbackSheet(
        sessionType: state.sessionType,
        duration: state.totalDuration,
        avgScore: state.avgSleepScore,
        onSubmit: (rating, notes) {
          context
              .read<SessionBloc>()
              .add(SessionRateFeedbackEvent(rating: rating, notes: notes));
          Navigator.pop(context);
          Navigator.pop(context);
        },
      ),
    );
  }
}

class _SleepCheck {
  final String label;
  final String description;
  final bool isGood;
  final IconData icon;

  _SleepCheck({
    required this.label,
    required this.description,
    required this.isGood,
    required this.icon,
  });
}
