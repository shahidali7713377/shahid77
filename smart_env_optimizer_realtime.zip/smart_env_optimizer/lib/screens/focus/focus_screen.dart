// lib/screens/focus/focus_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:gap/gap.dart';
import 'package:iconsax/iconsax.dart';
import 'package:percent_indicator/percent_indicator.dart';
import '../../blocs/session/session_bloc.dart';
import '../../blocs/environment/environment_bloc.dart';
import '../../blocs/recommendation/recommendation_bloc.dart';
import '../../core/theme/app_theme.dart';
import '../../core/constants/app_constants.dart';
import '../../models/sensor_data.dart';
import '../../models/recommendation.dart';
import '../../widgets/recommendation_card.dart';
import '../../widgets/session_feedback_sheet.dart';

class FocusScreen extends StatefulWidget {
  const FocusScreen({super.key});

  @override
  State<FocusScreen> createState() => _FocusScreenState();
}

class _FocusScreenState extends State<FocusScreen>
    with TickerProviderStateMixin {
  int _selectedDurationMin = AppConstants.defaultFocusDurationMin;
  late AnimationController _breathController;
  bool _sessionStarted = false;

  final List<int> _durationOptions = [15, 25, 45, 60, 90];

  @override
  void initState() {
    super.initState();
    _breathController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat(reverse: true);

    // Start generating recommendations in focus context
    final envState = context.read<EnvironmentBloc>().state;
    if (envState is EnvironmentAnalysisCompleted) {
      context.read<RecommendationBloc>().add(
        RecommendationGenerateEvent(
          analysis: envState.analysis,
          isFocusMode: true,
        ),
      );
    }
  }

  @override
  void dispose() {
    _breathController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener<SessionBloc, SessionState>(
      listener: (context, state) {
        if (state is SessionFeedbackRequired) {
          _showFeedbackSheet(context, state);
        } else if (state is SessionCompleted) {
          _showCompletionDialog(context, state);
        }
      },
      child: Scaffold(
        backgroundColor: AppColors.bg0,
        appBar: AppBar(
          backgroundColor: AppColors.bg0,
          leading: IconButton(
            icon: const Icon(Iconsax.arrow_left, size: 22),
            onPressed: () => _onBackPressed(context),
          ),
          title: const Text('Focus Mode'),
          actions: [
            BlocBuilder<SessionBloc, SessionState>(
              builder: (context, state) {
                if (state is! SessionActive) return const SizedBox();
                return IconButton(
                  icon: Icon(
                    state.isPaused ? Iconsax.play : Iconsax.pause,
                    size: 22,
                  ),
                  color: AppColors.focus,
                  onPressed: () {
                    if (state.isPaused) {
                      context.read<SessionBloc>().add(const SessionResumeEvent());
                    } else {
                      context.read<SessionBloc>().add(const SessionPauseEvent());
                    }
                  },
                );
              },
            ),
            const Gap(8),
          ],
        ),
        body: BlocBuilder<SessionBloc, SessionState>(
          builder: (context, state) {
            if (state is SessionActive && state.sessionType == 'focus') {
              return _buildActiveSession(context, state);
            }
            return _buildSetupScreen(context);
          },
        ),
      ),
    );
  }

  Widget _buildSetupScreen(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const Gap(20),
          // Environment pre-check
          _buildEnvironmentPreCheck(context),
          const Gap(32),

          // Duration selector
          Text(
            'Set Focus Duration',
            style: Theme.of(context).textTheme.headlineSmall,
          ).animate().fadeIn(),
          const Gap(20),

          Wrap(
            spacing: 10,
            children: _durationOptions.map((min) {
              final isSelected = min == _selectedDurationMin;
              return GestureDetector(
                onTap: () => setState(() => _selectedDurationMin = min),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                  decoration: BoxDecoration(
                    color: isSelected
                        ? AppColors.focus.withOpacity(0.15)
                        : AppColors.bg2,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: isSelected ? AppColors.focus : AppColors.border,
                      width: isSelected ? 1.5 : 1,
                    ),
                  ),
                  child: Text(
                    '${min}m',
                    style: TextStyle(
                      color: isSelected ? AppColors.focus : AppColors.textSecondary,
                      fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
                      fontSize: 15,
                    ),
                  ),
                ),
              );
            }).toList(),
          ).animate().fadeIn(delay: 200.ms),

          const Gap(40),

          // Animated breath circle as visual cue
          AnimatedBuilder(
            animation: _breathController,
            builder: (context, _) {
              final scale = 0.85 + _breathController.value * 0.15;
              return Transform.scale(
                scale: scale,
                child: Container(
                  width: 180,
                  height: 180,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(
                      colors: [
                        AppColors.focus.withOpacity(0.3),
                        AppColors.focus.withOpacity(0.05),
                        Colors.transparent,
                      ],
                    ),
                    border: Border.all(
                      color: AppColors.focus.withOpacity(0.4),
                      width: 1.5,
                    ),
                  ),
                  child: Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          '$_selectedDurationMin',
                          style: const TextStyle(
                            fontSize: 52,
                            fontWeight: FontWeight.w700,
                            color: AppColors.focus,
                            height: 1,
                          ),
                        ),
                        const Text(
                          'minutes',
                          style: TextStyle(
                            color: AppColors.textMuted,
                            fontSize: 13,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          ).animate().scale(duration: 600.ms, curve: Curves.elasticOut),

          const Gap(40),

          // Start button
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {
                HapticFeedback.mediumImpact();
                context.read<SessionBloc>().add(
                  SessionStartFocusEvent(durationMinutes: _selectedDurationMin),
                );
                setState(() => _sessionStarted = true);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.focus,
                padding: const EdgeInsets.symmetric(vertical: 18),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
              child: const Text(
                'Start Focus Session',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: AppColors.bg0,
                ),
              ),
            ),
          ).animate().slideY(begin: 0.3, delay: 400.ms),

          const Gap(24),
          _buildRecommendationsSection(context),
        ],
      ),
    );
  }

  Widget _buildEnvironmentPreCheck(BuildContext context) {
    return BlocBuilder<EnvironmentBloc, EnvironmentState>(
      builder: (context, state) {
        double score = 0;
        if (state is EnvironmentAnalysisCompleted) {
          score = state.analysis.focusScore;
        }

        final color = score > 0.7
            ? AppColors.success
            : score > 0.4
                ? AppColors.warning
                : AppColors.error;
        final label = score > 0.7
            ? 'Great environment for focus!'
            : score > 0.4
                ? 'Fair environment – improvements suggested'
                : 'Poor environment – check recommendations';

        return Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: color.withOpacity(0.08),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: color.withOpacity(0.3)),
          ),
          child: Row(
            children: [
              Icon(
                score > 0.7
                    ? Iconsax.tick_circle
                    : score > 0.4
                        ? Iconsax.warning_2
                        : Iconsax.close_circle,
                color: color,
                size: 20,
              ),
              const Gap(10),
              Expanded(
                child: Text(
                  label,
                  style: TextStyle(
                    color: color,
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
              Text(
                '${(score * 100).toInt()}%',
                style: TextStyle(
                  color: color,
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildActiveSession(BuildContext context, SessionActive state) {
    return Column(
      children: [
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Column(
              children: [
                const Gap(32),
                // Main timer
                _buildTimerCircle(context, state),
                const Gap(32),

                // Live metrics row
                _buildLiveMetricsRow(context, state),
                const Gap(24),

                // Live score history sparkline
                _buildScoreHistory(state),
                const Gap(24),

                // Recommendations
                _buildRecommendationsSection(context),
                const Gap(40),
              ],
            ),
          ),
        ),

        // End session button
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: SizedBox(
              width: double.infinity,
              child: OutlinedButton(
                onPressed: () {
                  HapticFeedback.heavyImpact();
                  context.read<SessionBloc>().add(const SessionEndEvent());
                },
                style: OutlinedButton.styleFrom(
                  foregroundColor: AppColors.error,
                  side: const BorderSide(color: AppColors.error),
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
                child: const Text(
                  'End Session',
                  style: TextStyle(fontWeight: FontWeight.w600),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildTimerCircle(BuildContext context, SessionActive state) {
    return Stack(
      alignment: Alignment.center,
      children: [
        // Outer glow ring
        AnimatedBuilder(
          animation: _breathController,
          builder: (_, __) => Container(
            width: 240,
            height: 240,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: AppColors.focus.withOpacity(
                    0.1 + _breathController.value * 0.15,
                  ),
                  blurRadius: 40,
                  spreadRadius: 10,
                ),
              ],
            ),
          ),
        ),
        CircularPercentIndicator(
          radius: 110,
          lineWidth: 6,
          percent: (1 - state.progressFraction).clamp(0.0, 1.0),
          progressColor: AppColors.focus,
          backgroundColor: AppColors.bg3,
          circularStrokeCap: CircularStrokeCap.round,
          center: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (state.isPaused)
                const Icon(Iconsax.pause, color: AppColors.focus, size: 24),
              Text(
                state.formattedRemaining,
                style: const TextStyle(
                  fontSize: 44,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textPrimary,
                  height: 1,
                ),
              ),
              const Gap(4),
              Text(
                state.isPaused ? 'Paused' : 'remaining',
                style: const TextStyle(
                  fontSize: 13,
                  color: AppColors.textMuted,
                ),
              ),
              const Gap(12),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(
                  color: AppColors.focus.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  'Focus: ${(state.avgFocusScore * 100).toInt()}%',
                  style: const TextStyle(
                    fontSize: 12,
                    color: AppColors.focus,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildLiveMetricsRow(BuildContext context, SessionActive state) {
    return Row(
      children: [
        _MetricChip(
          icon: Iconsax.sun_1,
          label: '${state.currentLux.toInt()} lux',
          color: AppColors.focus,
        ),
        const Gap(10),
        _MetricChip(
          icon: Iconsax.microphone,
          label: '${state.currentDb.toInt()} dB',
          color: AppColors.focus,
        ),
        const Gap(10),
        _MetricChip(
          icon: Iconsax.timer_1,
          label: _formatElapsed(state.elapsedSeconds),
          color: AppColors.textSecondary,
        ),
      ],
    );
  }

  String _formatElapsed(int seconds) {
    final m = seconds ~/ 60;
    final s = seconds % 60;
    return '${m}m ${s}s';
  }

  Widget _buildScoreHistory(SessionActive state) {
    if (state.focusScoreHistory.isEmpty) return const SizedBox();

    final maxScore = state.focusScoreHistory.isNotEmpty
        ? state.focusScoreHistory.reduce((a, b) => a > b ? a : b)
        : 1.0;

    return Container(
      height: 60,
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: state.focusScoreHistory
            .take(30)
            .toList()
            .asMap()
            .entries
            .map((e) {
          final height = maxScore > 0 ? (e.value / maxScore) * 50 : 2;
          return Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 1),
              child: Container(
                height: height.clamp(2, 50),
                decoration: BoxDecoration(
                  color: AppColors.focus.withOpacity(0.6),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildRecommendationsSection(BuildContext context) {
    return BlocBuilder<RecommendationBloc, RecommendationState>(
      builder: (context, state) {
        List<Recommendation> recs = [];
        if (state is RecommendationGenerated) {
          recs = state.activeRecommendations.take(2).toList();
        }

        if (recs.isEmpty) return const SizedBox();

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Quick Tips',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    color: AppColors.textSecondary,
                  ),
            ),
            const Gap(10),
            ...recs.map((rec) => Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: RecommendationCard(
                    recommendation: rec,
                    compact: true,
                    onDismiss: () => context
                        .read<RecommendationBloc>()
                        .add(RecommendationDismissEvent(rec.id)),
                    onActedOn: () => context
                        .read<RecommendationBloc>()
                        .add(RecommendationActedOnEvent(rec.id)),
                  ),
                )),
          ],
        );
      },
    );
  }

  void _showFeedbackSheet(BuildContext context, SessionFeedbackRequired state) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => SessionFeedbackSheet(
        sessionType: state.sessionType,
        duration: state.totalDuration,
        avgScore: state.avgFocusScore,
        onSubmit: (rating, notes) {
          context.read<SessionBloc>().add(
            SessionRateFeedbackEvent(rating: rating, notes: notes),
          );
          Navigator.pop(context);
        },
      ),
    );
  }

  void _showCompletionDialog(BuildContext context, SessionCompleted state) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.bg2,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Session Complete! 🎯'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Great work! You stayed focused for ${state.totalDuration.inMinutes} minutes.',
              style: const TextStyle(color: AppColors.textSecondary),
            ),
            const Gap(16),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(
                5,
                (i) => Icon(
                  Icons.star_rounded,
                  color: i < state.userRating
                      ? AppColors.warning
                      : AppColors.textMuted,
                  size: 24,
                ),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.popUntil(context, (r) => r.isFirst),
            child: const Text('Done', style: TextStyle(color: AppColors.focus)),
          ),
        ],
      ),
    );
  }

  void _onBackPressed(BuildContext context) {
    final sessionState = context.read<SessionBloc>().state;
    if (sessionState is SessionActive) {
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          backgroundColor: AppColors.bg2,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: const Text('End Session?'),
          content: const Text(
            'Your focus session is still running. End it now?',
            style: TextStyle(color: AppColors.textSecondary),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Continue'),
            ),
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                context.read<SessionBloc>().add(const SessionEndEvent());
              },
              child: const Text('End', style: TextStyle(color: AppColors.error)),
            ),
          ],
        ),
      );
    } else {
      Navigator.pop(context);
    }
  }
}

class _MetricChip extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;

  const _MetricChip({
    required this.icon,
    required this.label,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: AppColors.bg2,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: color, size: 14),
          const Gap(6),
          Text(
            label,
            style: TextStyle(
              color: color,
              fontSize: 12,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
}
