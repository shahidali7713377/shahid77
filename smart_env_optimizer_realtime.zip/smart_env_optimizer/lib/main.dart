// lib/main.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'services/storage_service.dart';
import 'app.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Lock to portrait orientation
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  // Transparent status bar
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: Color(0xFF080B14),
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );

  // Initialize local storage
  final storageService = StorageService();
  await storageService.initialize();

  // Check if onboarding has been completed
  final showOnboarding = !(await storageService.isOnboardingCompleted());

  runApp(
    SmartEnvApp(
      storageService: storageService,
      showOnboarding: showOnboarding,
    ),
  );
}
