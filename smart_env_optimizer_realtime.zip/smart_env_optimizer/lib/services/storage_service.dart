// lib/services/storage_service.dart
import 'package:hive_flutter/hive_flutter.dart';
import 'package:uuid/uuid.dart';
import '../models/sensor_data.dart';
import '../models/recommendation.dart';
import '../core/constants/app_constants.dart';

class StorageService {
  late Box<dynamic> _sessionsBox;
  late Box<dynamic> _profileBox;
  late Box<dynamic> _sensorLogsBox;
  late Box<dynamic> _prefsBox;

  final _uuid = const Uuid();

  Future<void> initialize() async {
    await Hive.initFlutter();

    // Register adapters (hand-written; normally via build_runner)
    if (!Hive.isAdapterRegistered(HiveTypeIds.sensorData)) {
      Hive.registerAdapter(SensorDataAdapter());
    }
    if (!Hive.isAdapterRegistered(HiveTypeIds.recommendation)) {
      Hive.registerAdapter(RecommendationAdapter());
    }
    if (!Hive.isAdapterRegistered(HiveTypeIds.sessionRecord)) {
      Hive.registerAdapter(SessionRecordAdapter());
    }

    _sessionsBox = await Hive.openBox(AppConstants.sessionsBox);
    _profileBox = await Hive.openBox(AppConstants.userProfileBox);
    _sensorLogsBox = await Hive.openBox(AppConstants.sensorLogsBox);
    _prefsBox = await Hive.openBox(AppConstants.prefsKey);
  }

  // ─── User Profile ──────────────────────────────────────────────────────────

  Future<Map<String, dynamic>?> getUserProfile() async {
    final raw = _profileBox.get('current');
    if (raw == null) return null;
    return Map<String, dynamic>.from(raw as Map);
  }

  Future<void> saveUserProfile(Map<String, dynamic> profile) async {
    await _profileBox.put('current', profile);
  }

  Future<bool> isOnboardingCompleted() async {
    return _prefsBox.get('onboarding_completed', defaultValue: false) as bool;
  }

  Future<void> markOnboardingCompleted() async {
    await _prefsBox.put('onboarding_completed', true);
  }

  // ─── Sessions ─────────────────────────────────────────────────────────────

  Future<void> saveSession(SessionRecord session) async {
    final data = {
      'id': session.id,
      'sessionType': session.sessionType,
      'startTime': session.startTime.toIso8601String(),
      'endTime': session.endTime?.toIso8601String(),
      'avgLux': session.avgLux,
      'avgDecibel': session.avgDecibel,
      'avgFocusScore': session.avgFocusScore,
      'avgSleepScore': session.avgSleepScore,
      'userProductivityRating': session.userProductivityRating,
      'userNotes': session.userNotes,
      'isCompleted': session.isCompleted,
    };
    await _sessionsBox.put(session.id, data);
  }

  Future<List<Map<String, dynamic>>> getRecentSessions({int limit = 30}) async {
    final all = _sessionsBox.values
        .whereType<Map>()
        .map((e) => Map<String, dynamic>.from(e))
        .toList();

    all.sort((a, b) {
      final aTime =
          DateTime.tryParse(a['startTime'] as String? ?? '') ?? DateTime(0);
      final bTime =
          DateTime.tryParse(b['startTime'] as String? ?? '') ?? DateTime(0);
      return bTime.compareTo(aTime);
    });

    return all.take(limit).toList();
  }

  Future<Map<String, double>> getSessionStats() async {
    final sessions = await getRecentSessions(limit: 100);
    if (sessions.isEmpty) {
      return {
        'totalSessions': 0,
        'totalFocusSessions': 0,
        'avgRating': 0,
        'avgFocusScore': 0,
      };
    }

    final focusSessions =
        sessions.where((s) => s['sessionType'] == 'focus').toList();
    final ratings = sessions
        .where((s) => s['userProductivityRating'] != null)
        .map((s) => (s['userProductivityRating'] as int).toDouble())
        .toList();

    final avgRating = ratings.isEmpty
        ? 0.0
        : ratings.reduce((a, b) => a + b) / ratings.length;

    final focusScores = focusSessions
        .map((s) => (s['avgFocusScore'] as double?) ?? 0.0)
        .toList();
    final avgFocusScore = focusScores.isEmpty
        ? 0.0
        : focusScores.reduce((a, b) => a + b) / focusScores.length;

    return {
      'totalSessions': sessions.length.toDouble(),
      'totalFocusSessions': focusSessions.length.toDouble(),
      'avgRating': avgRating,
      'avgFocusScore': avgFocusScore,
    };
  }

  // ─── Sensor Logs ──────────────────────────────────────────────────────────

  Future<void> saveSensorLog(SensorData data) async {
    final key = data.timestamp.millisecondsSinceEpoch.toString();
    final logData = {
      'luxValue': data.luxValue,
      'decibelValue': data.decibelValue,
      'timestamp': data.timestamp.toIso8601String(),
      'lightCondition': data.lightConditionStr,
      'soundCondition': data.soundConditionStr,
    };
    await _sensorLogsBox.put(key, logData);

    // Keep only last 1000 logs
    if (_sensorLogsBox.length > 1000) {
      final oldestKey = _sensorLogsBox.keys.first;
      await _sensorLogsBox.delete(oldestKey);
    }
  }

  Future<List<Map<String, dynamic>>> getSensorLogs({
    DateTime? from,
    DateTime? to,
    int limit = 100,
  }) async {
    var logs = _sensorLogsBox.values
        .whereType<Map>()
        .map((e) => Map<String, dynamic>.from(e))
        .toList();

    if (from != null) {
      logs = logs.where((log) {
        final ts = DateTime.tryParse(log['timestamp'] as String? ?? '');
        return ts != null && ts.isAfter(from);
      }).toList();
    }
    if (to != null) {
      logs = logs.where((log) {
        final ts = DateTime.tryParse(log['timestamp'] as String? ?? '');
        return ts != null && ts.isBefore(to);
      }).toList();
    }

    logs.sort((a, b) {
      final aTime =
          DateTime.tryParse(a['timestamp'] as String? ?? '') ?? DateTime(0);
      final bTime =
          DateTime.tryParse(b['timestamp'] as String? ?? '') ?? DateTime(0);
      return bTime.compareTo(aTime);
    });

    return logs.take(limit).toList();
  }

  // ─── Environment Analysis Storage ─────────────────────────────────────────

  Future<void> saveAnalysis(EnvironmentAnalysis analysis) async {
    await saveSensorLog(analysis.sensorData);
  }

  // ─── Pattern Learning ─────────────────────────────────────────────────────

  Future<void> updateEnvironmentEffectiveness({
    required double avgLux,
    required double avgDb,
    required double productivityScore,
  }) async {
    const key = 'env_effectiveness';
    final existing =
        _prefsBox.get(key) as Map? ?? <dynamic, dynamic>{};
    final effectMap = Map<String, double>.from(
      existing.map((k, v) =>
          MapEntry(k.toString(), (v as num).toDouble())),
    );

    final envKey = '${_bucketLux(avgLux)}_${_bucketDb(avgDb)}';
    final current = effectMap[envKey] ?? 0.5;
    effectMap[envKey] = current * 0.9 + productivityScore * 0.1;

    await _prefsBox.put(key, effectMap);
  }

  Future<Map<String, double>> getEnvironmentEffectiveness() async {
    final data = _prefsBox.get('env_effectiveness') as Map? ?? {};
    return Map<String, double>.from(
      data.map((k, v) =>
          MapEntry(k.toString(), (v as num).toDouble())),
    );
  }

  // ─── Preferences ──────────────────────────────────────────────────────────

  Future<void> setPreference(String key, dynamic value) async {
    await _prefsBox.put(key, value);
  }

  dynamic getPreference(String key, {dynamic defaultValue}) {
    return _prefsBox.get(key, defaultValue: defaultValue);
  }

  // ─── Helpers ──────────────────────────────────────────────────────────────

  String _bucketLux(double lux) {
    if (lux < 50) return 'dark';
    if (lux < 200) return 'dim';
    if (lux < 1000) return 'optimal';
    return 'bright';
  }

  String _bucketDb(double db) {
    if (db < 30) return 'silent';
    if (db < 50) return 'quiet';
    if (db < 65) return 'moderate';
    return 'loud';
  }

  Future<void> clearAllData() async {
    await _sessionsBox.clear();
    await _sensorLogsBox.clear();
    await _prefsBox.clear();
  }
}
