// lib/services/ml_service.dart
import 'dart:math' as math;
import '../models/sensor_data.dart';
import '../core/constants/app_constants.dart';

/// On-device ML inference engine.
/// Production: use TFLite models for sound classification.
/// This implements the hybrid rule-based + scoring model.
class MLService {
  // User-specific calibration weights (updated via incremental learning)
  double _userOptimalLux = 500.0;
  double _userOptimalDb = 40.0;
  final Map<String, double> _environmentEffectiveness = {};

  // Learned environment profile weights
  final List<_EnvironmentSample> _sampleBuffer = [];
  static const int _maxSamples = 500;

  bool _isInitialized = false;

  Future<void> initialize() async {
    // In production: load TFLite model from assets
    // await _loadTFLiteModel();
    _isInitialized = true;
  }

  void loadUserProfile(String profileId) {
    // Load user-specific calibration from storage
    // This would be populated from Hive storage
  }

  /// Core analysis method - runs in <200ms
  Future<EnvironmentAnalysis> analyzeEnvironment(SensorData data) async {
    final stopwatch = Stopwatch()..start();

    // 1. Compute feature scores
    final lightScore = _computeLightScore(data.luxValue);
    final soundScore = _computeSoundScore(data.decibelValue);
    final timeScore = _computeTimeScore();

    // 2. Compute weighted composite scores
    final focusScore = _computeFocusScore(
      lightScore: lightScore,
      soundScore: soundScore,
      timeScore: timeScore,
    );

    final sleepScore = _computeSleepScore(
      luxValue: data.luxValue,
      decibelValue: data.decibelValue,
      lightCondition: data.lightCondition,
      soundCondition: data.soundCondition,
    );

    // 3. Overall environment score
    final overallScore = (focusScore + sleepScore) / 2;

    // 4. Identify dominant issue
    final dominantIssue = _identifyDominantIssue(
      data: data,
      lightScore: lightScore,
      soundScore: soundScore,
    );

    // 5. Add to sample buffer for pattern learning
    _addSample(data, focusScore);

    stopwatch.stop();

    // Ensure we meet <200ms constraint
    assert(stopwatch.elapsedMilliseconds < AppConstants.maxInferenceTimeMs,
        'ML inference exceeded 200ms: ${stopwatch.elapsedMilliseconds}ms');

    return EnvironmentAnalysis(
      sensorData: data,
      focusScore: focusScore,
      sleepScore: sleepScore,
      overallScore: overallScore,
      dominantIssue: dominantIssue,
      analysisTime: DateTime.now(),
      featureScores: {
        'light': lightScore,
        'sound': soundScore,
        'time': timeScore,
      },
    );
  }

  // ─── Light Scoring (Gaussian curve around optimal) ────────────────────────

  double _computeLightScore(double lux) {
    if (lux <= 0) return 0.3;

    // Gaussian curve centered at optimal lux for smooth scoring
    final diff = (lux - _userOptimalLux).abs();
    final sigma = _userOptimalLux * 0.6;
    final gaussian = math.exp(-(diff * diff) / (2 * sigma * sigma));

    // Apply penalties for extremes
    if (lux < AppConstants.luxDark) return gaussian * 0.3;
    if (lux > AppConstants.luxOverexposed) return gaussian * 0.5;

    return gaussian.clamp(0.0, 1.0);
  }

  // ─── Sound Scoring ────────────────────────────────────────────────────────

  double _computeSoundScore(double db) {
    // Optimal is slight background noise (~40dB) - pure silence can be distracting
    final condition = SensorData.classifySound(db);
    final baseScore = condition.productivityScore;

    // User personalization: some users prefer different sound levels
    final userDiff = (db - _userOptimalDb).abs();
    final personalizationFactor = 1.0 - (userDiff / 100).clamp(0.0, 0.3);

    return (baseScore * personalizationFactor).clamp(0.0, 1.0);
  }

  // ─── Time-based Scoring ───────────────────────────────────────────────────

  double _computeTimeScore() {
    final hour = DateTime.now().hour;
    // Peak cognitive performance hours (circadian rhythm model)
    // Two peaks: 9-11 AM and 2-4 PM based on research
    double score;

    if (hour >= 9 && hour <= 11) {
      score = 0.95; // Morning peak
    } else if (hour >= 14 && hour <= 16) {
      score = 0.85; // Afternoon peak
    } else if (hour >= 7 && hour < 9) {
      score = 0.70; // Morning ramp-up
    } else if (hour >= 12 && hour < 14) {
      score = 0.65; // Post-lunch dip
    } else if (hour >= 17 && hour < 20) {
      score = 0.60; // Evening
    } else if (hour >= 6 && hour < 7) {
      score = 0.45; // Early morning
    } else {
      score = 0.30; // Night hours
    }

    return score;
  }

  // ─── Composite Score Computation ──────────────────────────────────────────

  double _computeFocusScore({
    required double lightScore,
    required double soundScore,
    required double timeScore,
  }) {
    // Weighted combination
    double score = lightScore * AppConstants.lightWeight +
        soundScore * AppConstants.soundWeight +
        timeScore * AppConstants.timeWeight;

    // Apply learned effectiveness multiplier if we have history
    final envKey = _getEnvKey();
    if (_environmentEffectiveness.containsKey(envKey)) {
      final learnedBoost = _environmentEffectiveness[envKey]!;
      score = score * 0.85 + learnedBoost * 0.15; // Slight influence from learning
    }

    return score.clamp(0.0, 1.0);
  }

  double _computeSleepScore({
    required double luxValue,
    required double decibelValue,
    required LightCondition lightCondition,
    required SoundCondition soundCondition,
  }) {
    final lightSleepScore = lightCondition.sleepScore;
    final soundSleepScore = soundCondition.sleepScore;

    // Sleep is more sensitive to light than sound
    return (lightSleepScore * 0.55 + soundSleepScore * 0.45).clamp(0.0, 1.0);
  }

  // ─── Pattern Learning (Incremental) ───────────────────────────────────────

  void _addSample(SensorData data, double focusScore) {
    _sampleBuffer.add(_EnvironmentSample(
      luxValue: data.luxValue,
      dbValue: data.decibelValue,
      score: focusScore,
      timestamp: DateTime.now(),
    ));

    if (_sampleBuffer.length > _maxSamples) {
      _sampleBuffer.removeAt(0);
    }

    // Periodic model update (every 50 samples)
    if (_sampleBuffer.length % 50 == 0) {
      _updateUserProfile();
    }
  }

  void updateFromFeedback(double productivityRating, SensorData envData) {
    // Incremental learning from explicit user feedback
    final envKey = _getEnvKey(data: envData);
    final current = _environmentEffectiveness[envKey] ?? 0.5;
    final normalizedRating = productivityRating / AppConstants.maxProductivityRating;

    _environmentEffectiveness[envKey] = current * (1 - AppConstants.patternLearningRate) +
        normalizedRating * AppConstants.patternLearningRate;

    // Update optimal sensor values
    if (productivityRating >= 4) {
      _userOptimalLux = _userOptimalLux * 0.95 + envData.luxValue * 0.05;
      _userOptimalDb = _userOptimalDb * 0.95 + envData.decibelValue * 0.05;
    }
  }

  void _updateUserProfile() {
    // Find the conditions under which score was highest
    final highScoreSamples = _sampleBuffer
        .where((s) => s.score > 0.75)
        .toList();

    if (highScoreSamples.isEmpty) return;

    // Calculate mean optimal values
    final meanLux = highScoreSamples.map((s) => s.luxValue).reduce((a, b) => a + b) /
        highScoreSamples.length;
    final meanDb = highScoreSamples.map((s) => s.dbValue).reduce((a, b) => a + b) /
        highScoreSamples.length;

    // Slowly shift user optimal toward learned values
    _userOptimalLux = _userOptimalLux * 0.98 + meanLux * 0.02;
    _userOptimalDb = _userOptimalDb * 0.98 + meanDb * 0.02;
  }

  String _identifyDominantIssue({
    required SensorData data,
    required double lightScore,
    required double soundScore,
  }) {
    if (lightScore < soundScore && lightScore < 0.4) {
      if (data.luxValue < AppConstants.luxDark) return 'insufficient_light';
      if (data.luxValue > AppConstants.luxOverexposed) return 'excess_light';
      return 'suboptimal_light';
    }
    if (soundScore < 0.4) {
      return 'high_noise';
    }
    if (lightScore < 0.6 && soundScore < 0.6) {
      return 'multiple_issues';
    }
    return 'none';
  }

  String _getEnvKey({SensorData? data}) {
    final d = data;
    if (d == null) return 'unknown';
    return '${d.lightConditionStr}_${d.soundConditionStr}';
  }

  // TFLite integration placeholder
  // Future<void> _loadTFLiteModel() async {
  //   _interpreter = await Interpreter.fromAsset('assets/models/sound_classifier.tflite');
  // }
  //
  // Future<String> _classifySoundWithTFLite(List<double> audioBuffer) async {
  //   var input = [audioBuffer];
  //   var output = List.filled(5, 0.0).reshape([1, 5]);
  //   _interpreter?.run(input, output);
  //   final scores = output[0] as List<double>;
  //   final maxIdx = scores.indexWhere((s) => s == scores.reduce(math.max));
  //   return SoundCondition.values[maxIdx].name;
  // }
}

class _EnvironmentSample {
  final double luxValue;
  final double dbValue;
  final double score;
  final DateTime timestamp;

  _EnvironmentSample({
    required this.luxValue,
    required this.dbValue,
    required this.score,
    required this.timestamp,
  });
}
