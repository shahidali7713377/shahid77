// lib/services/recommendation_service.dart
import 'package:uuid/uuid.dart';
import '../models/recommendation.dart';
import '../models/sensor_data.dart';
import '../core/constants/app_constants.dart';

class RecommendationService {
  final _uuid = const Uuid();

  Future<List<Recommendation>> generate({
    required EnvironmentAnalysis analysis,
    bool isFocusMode = false,
    bool isSleepMode = false,
  }) async {
    final recommendations = <Recommendation>[];
    final data = analysis.sensorData;
    final now = DateTime.now();

    if (isFocusMode) {
      recommendations.addAll(_generateFocusRecommendations(data, analysis, now));
    } else if (isSleepMode) {
      recommendations.addAll(_generateSleepRecommendations(data, analysis, now));
    } else {
      // Context-aware: mix based on time and scores
      final isNightTime = now.hour >= 21 || now.hour < 7;
      if (isNightTime && analysis.sleepScore < 0.6) {
        recommendations.addAll(_generateSleepRecommendations(data, analysis, now));
      } else if (analysis.focusScore < 0.6) {
        recommendations.addAll(_generateFocusRecommendations(data, analysis, now));
      }

      // Always add general recommendations
      recommendations.addAll(_generateGeneralRecommendations(data, analysis, now));
    }

    // Limit to top 5 recommendations
    return recommendations.take(5).toList();
  }

  List<Recommendation> _generateFocusRecommendations(
    SensorData data,
    EnvironmentAnalysis analysis,
    DateTime now,
  ) {
    final recs = <Recommendation>[];

    // Light recommendations
    if (data.lightCondition == LightCondition.dark) {
      recs.add(_buildRecommendation(
        type: RecommendationType.increaseLight,
        category: RecommendationCategory.focus,
        confidence: 0.95,
        priority: 10,
        now: now,
        reasoning:
            'Current light level (${data.luxValue.toInt()} lux) is too dim for sustained focus. '
            'Research shows 500+ lux significantly improves cognitive performance.',
      ));
    } else if (data.lightCondition == LightCondition.dim) {
      recs.add(_buildRecommendation(
        type: RecommendationType.openBlinds,
        category: RecommendationCategory.focus,
        confidence: 0.78,
        priority: 7,
        now: now,
        reasoning:
            'Natural light (${data.luxValue.toInt()} lux) is slightly below optimal. '
            'Opening blinds can bring you to the ideal 300-1000 lux range.',
      ));
    } else if (data.lightCondition == LightCondition.overexposed) {
      recs.add(_buildRecommendation(
        type: RecommendationType.decreaseLight,
        category: RecommendationCategory.focus,
        confidence: 0.80,
        priority: 6,
        now: now,
        reasoning:
            'Glare detected (${data.luxValue.toInt()} lux). Excessive brightness '
            'causes eye strain and reduces concentration over time.',
      ));
    }

    // Sound recommendations
    if (data.soundCondition == SoundCondition.highDistraction) {
      recs.add(_buildRecommendation(
        type: RecommendationType.useHeadphones,
        category: RecommendationCategory.focus,
        confidence: 0.92,
        priority: 10,
        now: now,
        reasoning:
            'High distraction noise detected (${data.decibelValue.toInt()} dB). '
            'Noise-cancelling headphones can reduce cognitive load by up to 40%.',
      ));
      recs.add(_buildRecommendation(
        type: RecommendationType.switchRoom,
        category: RecommendationCategory.focus,
        confidence: 0.75,
        priority: 8,
        now: now,
        reasoning:
            'Environment noise is severely impacting focus potential. '
            'Moving to a quieter space may be your best option.',
      ));
    } else if (data.soundCondition == SoundCondition.conversation ||
        data.soundCondition == SoundCondition.traffic) {
      recs.add(_buildRecommendation(
        type: RecommendationType.connectWhiteNoise,
        category: RecommendationCategory.focus,
        confidence: 0.83,
        priority: 7,
        now: now,
        reasoning:
            'Intermittent noise (${data.decibelValue.toInt()} dB) is breaking your '
            'concentration. White noise can mask distracting sounds effectively.',
      ));
    }

    return recs;
  }

  List<Recommendation> _generateSleepRecommendations(
    SensorData data,
    EnvironmentAnalysis analysis,
    DateTime now,
  ) {
    final recs = <Recommendation>[];

    // Light for sleep
    if (data.lightCondition != LightCondition.dark &&
        data.lightCondition != LightCondition.dim) {
      recs.add(_buildRecommendation(
        type: RecommendationType.dimLights,
        category: RecommendationCategory.sleep,
        confidence: 0.93,
        priority: 10,
        now: now,
        reasoning:
            'Bright light (${data.luxValue.toInt()} lux) suppresses melatonin production. '
            'Dimming lights 1-2 hours before sleep helps trigger your sleep cycle.',
      ));
    }

    recs.add(_buildRecommendation(
      type: RecommendationType.enableNightMode,
      category: RecommendationCategory.sleep,
      confidence: 0.88,
      priority: 8,
      now: now,
      reasoning:
          'Blue light from screens delays sleep onset by 1-3 hours. '
          'Night mode shifts display to warm tones to protect your circadian rhythm.',
    ));

    // Sound for sleep
    if (data.soundCondition != SoundCondition.silent &&
        data.soundCondition != SoundCondition.backgroundNoise) {
      recs.add(_buildRecommendation(
        type: RecommendationType.moveToQuieterSpace,
        category: RecommendationCategory.sleep,
        confidence: 0.85,
        priority: 9,
        now: now,
        reasoning:
            'Noise level (${data.decibelValue.toInt()} dB) will disrupt sleep cycles. '
            'Even moderate noise can prevent deep restorative sleep phases.',
      ));
    }

    // Time-based sleep adjustment
    final sleepHour = now.hour;
    if (sleepHour >= 0 && sleepHour < 2) {
      recs.add(_buildRecommendation(
        type: RecommendationType.adjustSleepTime,
        category: RecommendationCategory.sleep,
        confidence: 0.70,
        priority: 6,
        now: now,
        reasoning:
            'Late bedtime detected. Consistently sleeping after midnight '
            'disrupts circadian rhythm and reduces sleep quality by 30%.',
      ));
    }

    return recs;
  }

  List<Recommendation> _generateGeneralRecommendations(
    SensorData data,
    EnvironmentAnalysis analysis,
    DateTime now,
  ) {
    final recs = <Recommendation>[];

    if (analysis.overallScore < 0.5) {
      recs.add(_buildRecommendation(
        type: RecommendationType.takeBreak,
        category: RecommendationCategory.general,
        confidence: 0.72,
        priority: 5,
        now: now,
        reasoning:
            'Your environment score (${analysis.scorePercentage}%) is below optimal. '
            'A short break while conditions improve can reset your focus.',
      ));
    }

    return recs;
  }

  Recommendation _buildRecommendation({
    required RecommendationType type,
    required RecommendationCategory category,
    required double confidence,
    required int priority,
    required DateTime now,
    required String reasoning,
  }) {
    return Recommendation(
      id: _uuid.v4(),
      typeStr: type.name,
      categoryStr: category.name,
      confidenceScore: confidence,
      reasoning: reasoning,
      generatedAt: now,
      priority: priority,
    );
  }
}
