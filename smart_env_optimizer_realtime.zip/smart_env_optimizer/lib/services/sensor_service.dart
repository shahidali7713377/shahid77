// lib/services/sensor_service.dart
import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/foundation.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:light_sensor/light_sensor.dart';
import 'package:noise_meter/noise_meter.dart';

// ─── Abstract Interface ────────────────────────────────────────────────────────

abstract class SensorService {
  Future<bool> checkPermissions();
  Future<List<String>> getMissingPermissions();
  Future<bool> isLightSensorAvailable();
  Stream<double> lightStream();
  Future<void> dispose();
}

// ─── Real Device Implementation ───────────────────────────────────────────────

class SensorServiceImpl implements SensorService {
  StreamController<double>? _lightController;
  StreamSubscription<int>? _lightSubscription;
  bool _lightSensorAvailable = false;

  @override
  Future<bool> checkPermissions() async {
    // Request both camera (light fallback) and microphone
    final results = await [
      Permission.camera,
      Permission.microphone,
    ].request();
    return results.values.every((s) => s.isGranted || s.isLimited);
  }

  @override
  Future<List<String>> getMissingPermissions() async {
    final missing = <String>[];
    if (!await Permission.camera.isGranted) missing.add('Camera');
    if (!await Permission.microphone.isGranted) missing.add('Microphone');
    return missing;
  }

  @override
  Future<bool> isLightSensorAvailable() async {
    try {
      _lightSensorAvailable = await LightSensor.hasSensor();
      return _lightSensorAvailable;
    } catch (e) {
      debugPrint('[SensorService] Light sensor check failed: $e');
      _lightSensorAvailable = false;
      return false;
    }
  }

  @override
  Stream<double> lightStream() {
    // Close any existing stream
    _lightSubscription?.cancel();
    _lightController?.close();
    _lightController = StreamController<double>.broadcast();

    if (_lightSensorAvailable) {
      _startRealLightSensor();
    } else {
      // Fallback: camera-based estimation using average pixel brightness
      _startCameraLightEstimation();
    }

    return _lightController!.stream;
  }

  /// Uses the hardware ambient light sensor (most Android devices have this).
  void _startRealLightSensor() {
    try {
      // LightSensor.luxStream() emits int lux values directly from hardware
      _lightSubscription = LightSensor.luxStream().listen(
        (int lux) {
          if (!(_lightController?.isClosed ?? true)) {
            _lightController?.add(lux.toDouble());
          }
        },
        onError: (error) {
          debugPrint('[SensorService] Light sensor error: $error');
          // Gracefully fall back to camera estimation on error
          _startCameraLightEstimation();
        },
        cancelOnError: false,
      );
    } catch (e) {
      debugPrint('[SensorService] Failed to start light sensor: $e');
      _startCameraLightEstimation();
    }
  }

  /// Camera-based light estimation for devices without ambient light sensor.
  /// Captures periodic frames and computes average luminance.
  void _startCameraLightEstimation() {
    debugPrint('[SensorService] Using camera-based light estimation fallback');
    // Camera luminance estimation — in a full implementation use:
    //   CameraController + ImageStream → convert YUV frame → avg Y channel
    // For now emit a stable value and note in logs
    // This keeps the stream alive for the BLoC without crashing.
    Timer.periodic(const Duration(seconds: 2), (t) {
      if (_lightController?.isClosed ?? true) {
        t.cancel();
        return;
      }
      // Emit 0 to signal unavailable — UI should show "Unavailable"
      _lightController?.add(0.0);
    });
  }

  @override
  Future<void> dispose() async {
    await _lightSubscription?.cancel();
    await _lightController?.close();
    _lightController = null;
  }
}

// ─── Real Audio Service ────────────────────────────────────────────────────────

class AudioService {
  NoiseMeter? _noiseMeter;
  StreamSubscription<NoiseReading>? _noiseSubscription;
  StreamController<double>? _decibelController;

  // Rolling average to smooth rapid spikes without masking real changes
  final List<double> _rollingBuffer = [];
  static const int _rollingWindowSize = 5;

  Future<bool> isMicrophoneAvailable() async {
    final status = await Permission.microphone.status;
    if (!status.isGranted) {
      final result = await Permission.microphone.request();
      return result.isGranted;
    }
    return true;
  }

  /// Returns a stream of real-time decibel values from the device microphone.
  /// Uses noise_meter which reads actual audio input — no recordings stored.
  Stream<double> decibelStream() {
    _noiseSubscription?.cancel();
    _decibelController?.close();
    _decibelController = StreamController<double>.broadcast();

    _startRealAudioMonitoring();

    return _decibelController!.stream;
  }

  Future<void> _startRealAudioMonitoring() async {
    final hasPermission = await isMicrophoneAvailable();
    if (!hasPermission) {
      debugPrint('[AudioService] Microphone permission denied');
      _emitFallbackValue(0.0);
      return;
    }

    try {
      _noiseMeter = NoiseMeter();
      _noiseSubscription = _noiseMeter!.noise.listen(
        (NoiseReading reading) {
          if (_decibelController?.isClosed ?? true) return;

          // noise_meter gives meanDecibel and maxDecibel
          // meanDecibel is the RMS average — best for environment assessment
          final rawDb = reading.meanDecibel;

          // Sanity check: noise_meter can emit -inf or NaN on silence
          if (rawDb.isInfinite || rawDb.isNaN || rawDb < 0) {
            _rollingBuffer.add(0.0);
          } else {
            // Clamp to realistic audible range (20dB = very quiet room, 120dB = jet engine)
            _rollingBuffer.add(rawDb.clamp(20.0, 120.0));
          }

          // Keep rolling window
          if (_rollingBuffer.length > _rollingWindowSize) {
            _rollingBuffer.removeAt(0);
          }

          // Emit smoothed value — reduces jitter while staying reactive
          final smoothed = _rollingBuffer.isEmpty
              ? 0.0
              : _rollingBuffer.reduce((a, b) => a + b) / _rollingBuffer.length;

          _decibelController?.add(smoothed);
        },
        onError: (error) {
          debugPrint('[AudioService] Noise meter error: $error');
          // On error, emit last known value or 0
          _decibelController?.add(0.0);
        },
        cancelOnError: false,
      );
    } catch (e) {
      debugPrint('[AudioService] Failed to start noise meter: $e');
      _emitFallbackValue(0.0);
    }
  }

  void _emitFallbackValue(double value) {
    // Emit a stable fallback so the UI doesn't freeze
    Timer.periodic(const Duration(seconds: 2), (t) {
      if (_decibelController?.isClosed ?? true) {
        t.cancel();
        return;
      }
      _decibelController?.add(value);
    });
  }

  Future<void> dispose() async {
    await _noiseSubscription?.cancel();
    await _decibelController?.close();
    _noiseMeter = null;
    _noiseSubscription = null;
    _decibelController = null;
    _rollingBuffer.clear();
  }
}
