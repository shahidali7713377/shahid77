// lib/blocs/recommendation/recommendation_bloc.dart

import 'dart:async';
import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../models/recommendation.dart';
import '../../models/sensor_data.dart';
import '../../services/recommendation_service.dart';
import '../../services/storage_service.dart';

// ─── Events ───────────────────────────────────────────────────────────────────

abstract class RecommendationEvent extends Equatable {
  const RecommendationEvent();
  @override
  List<Object?> get props => [];
}

class RecommendationGenerateEvent extends RecommendationEvent {
  final EnvironmentAnalysis analysis;
  final bool isFocusMode;
  final bool isSleepMode;
  const RecommendationGenerateEvent({
    required this.analysis,
    this.isFocusMode = false,
    this.isSleepMode = false,
  });
  @override
  List<Object?> get props => [analysis, isFocusMode, isSleepMode];
}

class RecommendationDismissEvent extends RecommendationEvent {
  final String recommendationId;
  const RecommendationDismissEvent(this.recommendationId);
  @override
  List<Object?> get props => [recommendationId];
}

class RecommendationActedOnEvent extends RecommendationEvent {
  final String recommendationId;
  const RecommendationActedOnEvent(this.recommendationId);
  @override
  List<Object?> get props => [recommendationId];
}

class RecommendationClearEvent extends RecommendationEvent {
  const RecommendationClearEvent();
}

// ─── States ───────────────────────────────────────────────────────────────────

abstract class RecommendationState extends Equatable {
  const RecommendationState();
  @override
  List<Object?> get props => [];
}

class RecommendationInitial extends RecommendationState {
  const RecommendationInitial();
}

class RecommendationGenerated extends RecommendationState {
  final List<Recommendation> recommendations;
  final DateTime generatedAt;

  const RecommendationGenerated({
    required this.recommendations,
    required this.generatedAt,
  });

  List<Recommendation> get activeRecommendations =>
      recommendations.where((r) => !r.isDismissed).toList();

  @override
  List<Object?> get props => [recommendations, generatedAt];
}

class RecommendationUpdated extends RecommendationState {
  final List<Recommendation> recommendations;
  const RecommendationUpdated(this.recommendations);
  @override
  List<Object?> get props => [recommendations];
}

// ─── Bloc ─────────────────────────────────────────────────────────────────────

class RecommendationBloc
    extends Bloc<RecommendationEvent, RecommendationState> {
  final RecommendationService _recommendationService;
  final StorageService _storageService;

  List<Recommendation> _currentRecommendations = [];

  RecommendationBloc({
    required RecommendationService recommendationService,
    required StorageService storageService,
  })  : _recommendationService = recommendationService,
        _storageService = storageService,
        super(const RecommendationInitial()) {
    on<RecommendationGenerateEvent>(_onGenerate);
    on<RecommendationDismissEvent>(_onDismiss);
    on<RecommendationActedOnEvent>(_onActedOn);
    on<RecommendationClearEvent>(_onClear);
  }

  Future<void> _onGenerate(
    RecommendationGenerateEvent event,
    Emitter<RecommendationState> emit,
  ) async {
    final newRecs = await _recommendationService.generate(
      analysis: event.analysis,
      isFocusMode: event.isFocusMode,
      isSleepMode: event.isSleepMode,
    );

    _currentRecommendations = _mergeRecommendations(
      _currentRecommendations,
      newRecs,
    );

    _currentRecommendations.sort((a, b) {
      final priorityComp = b.priority.compareTo(a.priority);
      if (priorityComp != 0) return priorityComp;
      return b.confidenceScore.compareTo(a.confidenceScore);
    });

    emit(RecommendationGenerated(
      recommendations: List.from(_currentRecommendations),
      generatedAt: DateTime.now(),
    ));
  }

  List<Recommendation> _mergeRecommendations(
    List<Recommendation> existing,
    List<Recommendation> fresh,
  ) {
    final freshTypes = fresh.map((r) => r.typeStr).toSet();
    final filtered = existing
        .where((r) =>
            !r.isDismissed &&
            !freshTypes.contains(r.typeStr) &&
            DateTime.now().difference(r.generatedAt).inMinutes < 10)
        .toList();

    return [...filtered, ...fresh];
  }

  void _onDismiss(
      RecommendationDismissEvent event, Emitter<RecommendationState> emit) {
    final idx = _currentRecommendations
        .indexWhere((r) => r.id == event.recommendationId);
    if (idx >= 0) _currentRecommendations[idx].isDismissed = true;
    emit(RecommendationUpdated(List.from(_currentRecommendations)));
  }

  void _onActedOn(
      RecommendationActedOnEvent event, Emitter<RecommendationState> emit) {
    final idx = _currentRecommendations
        .indexWhere((r) => r.id == event.recommendationId);
    if (idx >= 0) {
      _currentRecommendations[idx].isActedOn = true;
      _currentRecommendations[idx].isDismissed = true;
    }
    emit(RecommendationUpdated(List.from(_currentRecommendations)));
  }

  void _onClear(
      RecommendationClearEvent event, Emitter<RecommendationState> emit) {
    _currentRecommendations = [];
    emit(const RecommendationInitial());
  }
}
