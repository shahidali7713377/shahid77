// lib/blocs/session/session_bloc.dart

import 'dart:async';
import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:uuid/uuid.dart';
import '../../models/recommendation.dart';
import '../../services/storage_service.dart';

// ─── Events ───────────────────────────────────────────────────────────────────

abstract class SessionEvent extends Equatable {
  const SessionEvent();
  @override
  List<Object?> get props => [];
}

class SessionStartFocusEvent extends SessionEvent {
  final int durationMinutes;
  const SessionStartFocusEvent({this.durationMinutes = 25});
  @override
  List<Object?> get props => [durationMinutes];
}

class SessionStartSleepEvent extends SessionEvent {
  const SessionStartSleepEvent();
}

class SessionPauseEvent extends SessionEvent {
  const SessionPauseEvent();
}

class SessionResumeEvent extends SessionEvent {
  const SessionResumeEvent();
}

class SessionEndEvent extends SessionEvent {
  const SessionEndEvent();
}

class SessionTickEvent extends SessionEvent {
  const SessionTickEvent();
}

class SessionRateFeedbackEvent extends SessionEvent {
  final int rating;
  final String? notes;
  const SessionRateFeedbackEvent({required this.rating, this.notes});
  @override
  List<Object?> get props => [rating, notes];
}

class SessionUpdateMetricsEvent extends SessionEvent {
  final double currentFocusScore;
  final double currentSleepScore;
  final double currentLux;
  final double currentDb;
  const SessionUpdateMetricsEvent({
    required this.currentFocusScore,
    required this.currentSleepScore,
    required this.currentLux,
    required this.currentDb,
  });
}

// ─── States ───────────────────────────────────────────────────────────────────

abstract class SessionState extends Equatable {
  const SessionState();
  @override
  List<Object?> get props => [];
}

class SessionIdle extends SessionState {
  const SessionIdle();
}

class SessionActive extends SessionState {
  final String sessionId;
  final String sessionType;
  final DateTime startTime;
  final int targetDurationMinutes;
  final int elapsedSeconds;
  final bool isPaused;
  final double avgFocusScore;
  final double avgSleepScore;
  final double currentLux;
  final double currentDb;
  final List<double> focusScoreHistory;

  const SessionActive({
    required this.sessionId,
    required this.sessionType,
    required this.startTime,
    required this.targetDurationMinutes,
    required this.elapsedSeconds,
    required this.isPaused,
    required this.avgFocusScore,
    required this.avgSleepScore,
    required this.currentLux,
    required this.currentDb,
    required this.focusScoreHistory,
  });

  int get remainingSeconds =>
      (targetDurationMinutes * 60) - elapsedSeconds;

  double get progressFraction =>
      (elapsedSeconds / (targetDurationMinutes * 60)).clamp(0.0, 1.0);

  String get formattedRemaining {
    final r = remainingSeconds.clamp(0, targetDurationMinutes * 60);
    final m = r ~/ 60;
    final s = r % 60;
    return '${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
  }

  bool get isComplete => elapsedSeconds >= targetDurationMinutes * 60;

  SessionActive copyWith({
    int? elapsedSeconds,
    bool? isPaused,
    double? avgFocusScore,
    double? avgSleepScore,
    double? currentLux,
    double? currentDb,
    List<double>? focusScoreHistory,
  }) {
    return SessionActive(
      sessionId: sessionId,
      sessionType: sessionType,
      startTime: startTime,
      targetDurationMinutes: targetDurationMinutes,
      elapsedSeconds: elapsedSeconds ?? this.elapsedSeconds,
      isPaused: isPaused ?? this.isPaused,
      avgFocusScore: avgFocusScore ?? this.avgFocusScore,
      avgSleepScore: avgSleepScore ?? this.avgSleepScore,
      currentLux: currentLux ?? this.currentLux,
      currentDb: currentDb ?? this.currentDb,
      focusScoreHistory: focusScoreHistory ?? this.focusScoreHistory,
    );
  }

  @override
  List<Object?> get props => [
        sessionId,
        elapsedSeconds,
        isPaused,
        avgFocusScore,
        currentLux,
        currentDb,
      ];
}

class SessionFeedbackRequired extends SessionState {
  final String sessionId;
  final String sessionType;
  final Duration totalDuration;
  final double avgFocusScore;
  final double avgSleepScore;

  const SessionFeedbackRequired({
    required this.sessionId,
    required this.sessionType,
    required this.totalDuration,
    required this.avgFocusScore,
    required this.avgSleepScore,
  });

  @override
  List<Object?> get props => [sessionId, totalDuration];
}

class SessionCompleted extends SessionState {
  final String sessionId;
  final String sessionType;
  final Duration totalDuration;
  final double avgFocusScore;
  final int userRating;

  const SessionCompleted({
    required this.sessionId,
    required this.sessionType,
    required this.totalDuration,
    required this.avgFocusScore,
    required this.userRating,
  });

  @override
  List<Object?> get props => [sessionId, userRating];
}

// ─── Bloc ─────────────────────────────────────────────────────────────────────

class SessionBloc extends Bloc<SessionEvent, SessionState> {
  final StorageService _storageService;
  Timer? _ticker;

  final List<double> _focusScoreBuffer = [];
  final List<double> _sleepScoreBuffer = [];
  final List<double> _luxBuffer = [];
  final List<double> _dbBuffer = [];

  SessionBloc({required StorageService storageService})
      : _storageService = storageService,
        super(const SessionIdle()) {
    on<SessionStartFocusEvent>(_onStartFocus);
    on<SessionStartSleepEvent>(_onStartSleep);
    on<SessionPauseEvent>(_onPause);
    on<SessionResumeEvent>(_onResume);
    on<SessionEndEvent>(_onEnd);
    on<SessionTickEvent>(_onTick);
    on<SessionRateFeedbackEvent>(_onRateFeedback);
    on<SessionUpdateMetricsEvent>(_onUpdateMetrics);
  }

  void _startTicker() {
    _ticker?.cancel();
    _ticker =
        Timer.periodic(const Duration(seconds: 1), (_) => add(const SessionTickEvent()));
  }

  Future<void> _onStartFocus(
    SessionStartFocusEvent event,
    Emitter<SessionState> emit,
  ) async {
    _clearBuffers();
    final sessionId = const Uuid().v4();

    emit(SessionActive(
      sessionId: sessionId,
      sessionType: 'focus',
      startTime: DateTime.now(),
      targetDurationMinutes: event.durationMinutes,
      elapsedSeconds: 0,
      isPaused: false,
      avgFocusScore: 0.5,
      avgSleepScore: 0.5,
      currentLux: 0,
      currentDb: 0,
      focusScoreHistory: const [],
    ));

    _startTicker();
  }

  Future<void> _onStartSleep(
    SessionStartSleepEvent event,
    Emitter<SessionState> emit,
  ) async {
    _clearBuffers();
    final sessionId = const Uuid().v4();

    emit(SessionActive(
      sessionId: sessionId,
      sessionType: 'sleep',
      startTime: DateTime.now(),
      targetDurationMinutes: 480,
      elapsedSeconds: 0,
      isPaused: false,
      avgFocusScore: 0.5,
      avgSleepScore: 0.5,
      currentLux: 0,
      currentDb: 0,
      focusScoreHistory: const [],
    ));

    _startTicker();
  }

  void _onPause(SessionPauseEvent event, Emitter<SessionState> emit) {
    if (state is! SessionActive) return;
    _ticker?.cancel();
    emit((state as SessionActive).copyWith(isPaused: true));
  }

  void _onResume(SessionResumeEvent event, Emitter<SessionState> emit) {
    if (state is! SessionActive) return;
    emit((state as SessionActive).copyWith(isPaused: false));
    _startTicker();
  }

  Future<void> _onEnd(
      SessionEndEvent event, Emitter<SessionState> emit) async {
    _ticker?.cancel();
    if (state is! SessionActive) return;

    final active = state as SessionActive;
    final avgFocus = _average(_focusScoreBuffer);
    final avgSleep = _average(_sleepScoreBuffer);

    emit(SessionFeedbackRequired(
      sessionId: active.sessionId,
      sessionType: active.sessionType,
      totalDuration: DateTime.now().difference(active.startTime),
      avgFocusScore: avgFocus,
      avgSleepScore: avgSleep,
    ));
  }

  void _onTick(SessionTickEvent event, Emitter<SessionState> emit) {
    if (state is! SessionActive) return;
    final active = state as SessionActive;
    if (active.isPaused) return;

    final newElapsed = active.elapsedSeconds + 1;

    if (newElapsed >= active.targetDurationMinutes * 60 &&
        active.sessionType == 'focus') {
      _ticker?.cancel();
      add(const SessionEndEvent());
      return;
    }

    final updatedHistory = List<double>.from(active.focusScoreHistory)
      ..add(active.avgFocusScore);
    if (updatedHistory.length > 60) updatedHistory.removeAt(0);

    emit(active.copyWith(
      elapsedSeconds: newElapsed,
      focusScoreHistory: updatedHistory,
    ));
  }

  void _onUpdateMetrics(
    SessionUpdateMetricsEvent event,
    Emitter<SessionState> emit,
  ) {
    if (state is! SessionActive) return;
    final active = state as SessionActive;

    _focusScoreBuffer.add(event.currentFocusScore);
    _sleepScoreBuffer.add(event.currentSleepScore);
    _luxBuffer.add(event.currentLux);
    _dbBuffer.add(event.currentDb);

    emit(active.copyWith(
      avgFocusScore: _average(_focusScoreBuffer),
      avgSleepScore: _average(_sleepScoreBuffer),
      currentLux: event.currentLux,
      currentDb: event.currentDb,
    ));
  }

  Future<void> _onRateFeedback(
    SessionRateFeedbackEvent event,
    Emitter<SessionState> emit,
  ) async {
    if (state is! SessionFeedbackRequired) return;
    final feedback = state as SessionFeedbackRequired;

    final session = SessionRecord(
      id: feedback.sessionId,
      sessionType: feedback.sessionType,
      startTime: DateTime.now().subtract(feedback.totalDuration),
      endTime: DateTime.now(),
      avgLux: _average(_luxBuffer),
      avgDecibel: _average(_dbBuffer),
      avgFocusScore: feedback.avgFocusScore,
      avgSleepScore: feedback.avgSleepScore,
      userProductivityRating: event.rating,
      userNotes: event.notes,
      recommendationIds: const [],
      isCompleted: true,
    );

    await _storageService.saveSession(session);
    await _storageService.updateEnvironmentEffectiveness(
      avgLux: _average(_luxBuffer),
      avgDb: _average(_dbBuffer),
      productivityScore: event.rating / 5.0,
    );

    emit(SessionCompleted(
      sessionId: feedback.sessionId,
      sessionType: feedback.sessionType,
      totalDuration: feedback.totalDuration,
      avgFocusScore: feedback.avgFocusScore,
      userRating: event.rating,
    ));
  }

  void _clearBuffers() {
    _focusScoreBuffer.clear();
    _sleepScoreBuffer.clear();
    _luxBuffer.clear();
    _dbBuffer.clear();
  }

  double _average(List<double> values) {
    if (values.isEmpty) return 0.0;
    return values.reduce((a, b) => a + b) / values.length;
  }

  @override
  Future<void> close() {
    _ticker?.cancel();
    return super.close();
  }
}
