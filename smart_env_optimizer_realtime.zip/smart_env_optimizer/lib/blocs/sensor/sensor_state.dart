// lib/blocs/sensor/sensor_state.dart
import 'package:equatable/equatable.dart';
import '../../models/sensor_data.dart';

abstract class SensorState extends Equatable {
  const SensorState();
  @override
  List<Object?> get props => [];
}

class SensorInitial extends SensorState {
  const SensorInitial();
}

class SensorLoading extends SensorState {
  const SensorLoading();
}

class SensorPermissionRequired extends SensorState {
  final List<String> requiredPermissions;
  const SensorPermissionRequired(this.requiredPermissions);
  @override
  List<Object?> get props => [requiredPermissions];
}

class SensorActive extends SensorState {
  final SensorData currentData;
  final List<SensorData> recentHistory;
  final bool isLightAvailable;
  final bool isMicAvailable;
  final DateTime lastUpdated;

  const SensorActive({
    required this.currentData,
    required this.recentHistory,
    required this.isLightAvailable,
    required this.isMicAvailable,
    required this.lastUpdated,
  });

  SensorActive copyWith({
    SensorData? currentData,
    List<SensorData>? recentHistory,
    bool? isLightAvailable,
    bool? isMicAvailable,
    DateTime? lastUpdated,
  }) {
    return SensorActive(
      currentData: currentData ?? this.currentData,
      recentHistory: recentHistory ?? this.recentHistory,
      isLightAvailable: isLightAvailable ?? this.isLightAvailable,
      isMicAvailable: isMicAvailable ?? this.isMicAvailable,
      lastUpdated: lastUpdated ?? this.lastUpdated,
    );
  }

  @override
  List<Object?> get props => [currentData, recentHistory, lastUpdated];
}

class SensorPaused extends SensorState {
  final SensorData lastData;
  const SensorPaused(this.lastData);
  @override
  List<Object?> get props => [lastData];
}

class SensorError extends SensorState {
  final String message;
  const SensorError(this.message);
  @override
  List<Object?> get props => [message];
}
