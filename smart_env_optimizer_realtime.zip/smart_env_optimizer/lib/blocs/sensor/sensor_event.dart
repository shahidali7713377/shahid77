// lib/blocs/sensor/sensor_event.dart
import 'package:equatable/equatable.dart';
import '../../models/sensor_data.dart';

abstract class SensorEvent extends Equatable {
  const SensorEvent();
  @override
  List<Object?> get props => [];
}

class SensorInitializeEvent extends SensorEvent {
  const SensorInitializeEvent();
}

class SensorStartStreamingEvent extends SensorEvent {
  const SensorStartStreamingEvent();
}

class SensorStopStreamingEvent extends SensorEvent {
  const SensorStopStreamingEvent();
}

class SensorDataUpdatedEvent extends SensorEvent {
  final SensorData data;
  const SensorDataUpdatedEvent(this.data);
  @override
  List<Object?> get props => [data];
}

class SensorLightUpdatedEvent extends SensorEvent {
  final double lux;
  const SensorLightUpdatedEvent(this.lux);
  @override
  List<Object?> get props => [lux];
}

class SensorSoundUpdatedEvent extends SensorEvent {
  final double decibels;
  const SensorSoundUpdatedEvent(this.decibels);
  @override
  List<Object?> get props => [decibels];
}

class SensorPermissionsGrantedEvent extends SensorEvent {
  const SensorPermissionsGrantedEvent();
}

class SensorPermissionsDeniedEvent extends SensorEvent {
  final List<String> deniedPermissions;
  const SensorPermissionsDeniedEvent(this.deniedPermissions);
  @override
  List<Object?> get props => [deniedPermissions];
}

class SensorErrorEvent extends SensorEvent {
  final String message;
  const SensorErrorEvent(this.message);
  @override
  List<Object?> get props => [message];
}

// lib/blocs/sensor/sensor_state.dart
abstract class SensorState extends Equatable {
  const SensorState();
  @override
  List<Object?> get props => [];
}

class SensorInitial extends SensorState {
  const SensorInitial();
}

class SensorLoading extends SensorState {
  const SensorLoading();
}

class SensorPermissionRequired extends SensorState {
  final List<String> requiredPermissions;
  const SensorPermissionRequired(this.requiredPermissions);
  @override
  List<Object?> get props => [requiredPermissions];
}

class SensorActive extends SensorState {
  final SensorData currentData;
  final List<SensorData> recentHistory;
  final bool isLightAvailable;
  final bool isMicAvailable;
  final DateTime lastUpdated;

  const SensorActive({
    required this.currentData,
    required this.recentHistory,
    required this.isLightAvailable,
    required this.isMicAvailable,
    required this.lastUpdated,
  });

  SensorActive copyWith({
    SensorData? currentData,
    List<SensorData>? recentHistory,
    bool? isLightAvailable,
    bool? isMicAvailable,
    DateTime? lastUpdated,
  }) {
    return SensorActive(
      currentData: currentData ?? this.currentData,
      recentHistory: recentHistory ?? this.recentHistory,
      isLightAvailable: isLightAvailable ?? this.isLightAvailable,
      isMicAvailable: isMicAvailable ?? this.isMicAvailable,
      lastUpdated: lastUpdated ?? this.lastUpdated,
    );
  }

  @override
  List<Object?> get props => [currentData, recentHistory, lastUpdated];
}

class SensorPaused extends SensorState {
  final SensorData lastData;
  const SensorPaused(this.lastData);
  @override
  List<Object?> get props => [lastData];
}

class SensorError extends SensorState {
  final String message;
  const SensorError(this.message);
  @override
  List<Object?> get props => [message];
}
