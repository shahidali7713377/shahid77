// lib/blocs/sensor/sensor_bloc.dart
import 'dart:async';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:rxdart/rxdart.dart';
import '../../models/sensor_data.dart';
import '../../services/sensor_service.dart';
import '../../core/constants/app_constants.dart';
import 'sensor_event.dart';
import 'sensor_state.dart';

export 'sensor_event.dart';
export 'sensor_state.dart';

class SensorBloc extends Bloc<SensorEvent, SensorState> {
  final SensorService _sensorService;
  final AudioService _audioService;

  StreamSubscription<double>? _lightSubscription;
  StreamSubscription<double>? _soundSubscription;

  // Exponential Moving Average smoothing for display stability
  // α = 0.3 means ~30% weight on new reading — responsive but not jittery
  static const double _lightAlpha = 0.3;
  static const double _soundAlpha = 0.4; // Sound reacts faster

  double _smoothedLux = -1; // -1 = not yet initialized
  double _smoothedDb = -1;

  final List<SensorData> _recentHistory = [];
  static const int _maxHistorySize = 120; // 2 minutes at 1Hz

  SensorBloc({
    required SensorService sensorService,
    required AudioService audioService,
  })  : _sensorService = sensorService,
        _audioService = audioService,
        super(const SensorInitial()) {
    on<SensorInitializeEvent>(_onInitialize);
    on<SensorStartStreamingEvent>(_onStartStreaming);
    on<SensorStopStreamingEvent>(_onStopStreaming);
    on<SensorLightUpdatedEvent>(_onLightUpdated);
    on<SensorSoundUpdatedEvent>(_onSoundUpdated);
    on<SensorPermissionsGrantedEvent>(_onPermissionsGranted);
    on<SensorPermissionsDeniedEvent>(_onPermissionsDenied);
    on<SensorErrorEvent>(_onError);
  }

  Future<void> _onInitialize(
    SensorInitializeEvent event,
    Emitter<SensorState> emit,
  ) async {
    emit(const SensorLoading());
    try {
      final hasPermissions = await _sensorService.checkPermissions();
      if (!hasPermissions) {
        final missing = await _sensorService.getMissingPermissions();
        emit(SensorPermissionRequired(missing));
        return;
      }

      // Check hardware availability
      final lightAvailable = await _sensorService.isLightSensorAvailable();
      final micAvailable = await _audioService.isMicrophoneAvailable();

      emit(SensorActive(
        currentData: SensorData.empty(),
        recentHistory: const [],
        isLightAvailable: lightAvailable,
        isMicAvailable: micAvailable,
        lastUpdated: DateTime.now(),
      ));

      add(const SensorStartStreamingEvent());
    } catch (e) {
      emit(SensorError('Failed to initialize sensors: $e'));
    }
  }

  Future<void> _onStartStreaming(
    SensorStartStreamingEvent event,
    Emitter<SensorState> emit,
  ) async {
    if (state is! SensorActive) return;

    // ── Light Sensor Stream ────────────────────────────────────────────────
    // Throttle to max 4 updates/sec — hardware can emit very rapidly
    _lightSubscription?.cancel();
    _lightSubscription = _sensorService
        .lightStream()
        .throttleTime(
          const Duration(milliseconds: 250),
          leading: true,
          trailing: true,
        )
        .listen(
          (lux) => add(SensorLightUpdatedEvent(lux)),
          onError: (e) {
            add(SensorErrorEvent('Light sensor error: $e'));
          },
          cancelOnError: false,
        );

    // ── Microphone / Noise Stream ──────────────────────────────────────────
    // Throttle to 2 updates/sec for display — noise_meter can be very fast
    _soundSubscription?.cancel();
    _soundSubscription = _audioService
        .decibelStream()
        .throttleTime(
          const Duration(milliseconds: 500),
          leading: true,
          trailing: true,
        )
        .listen(
          (db) => add(SensorSoundUpdatedEvent(db)),
          onError: (e) {
            add(SensorErrorEvent('Audio sensor error: $e'));
          },
          cancelOnError: false,
        );
  }

  void _onLightUpdated(
    SensorLightUpdatedEvent event,
    Emitter<SensorState> emit,
  ) {
    if (state is! SensorActive) return;

    // First reading: initialize directly (no smoothing)
    if (_smoothedLux < 0) {
      _smoothedLux = event.lux;
    } else {
      // EMA: new = α * raw + (1-α) * previous
      _smoothedLux =
          _lightAlpha * event.lux + (1 - _lightAlpha) * _smoothedLux;
    }

    _pushUpdate(state as SensorActive, emit);
  }

  void _onSoundUpdated(
    SensorSoundUpdatedEvent event,
    Emitter<SensorState> emit,
  ) {
    if (state is! SensorActive) return;

    final clampedDb = event.decibels.clamp(0.0, 120.0);

    if (_smoothedDb < 0) {
      _smoothedDb = clampedDb;
    } else {
      _smoothedDb =
          _soundAlpha * clampedDb + (1 - _soundAlpha) * _smoothedDb;
    }

    _pushUpdate(state as SensorActive, emit);
  }

  void _pushUpdate(SensorActive current, Emitter<SensorState> emit) {
    // Use smoothed values for display; classify using smoothed too
    final displayLux = _smoothedLux.clamp(0.0, 100000.0);
    final displayDb = _smoothedDb.clamp(0.0, 120.0);

    final lightCondition = SensorData.classifyLight(displayLux);
    final soundCondition = SensorData.classifySound(displayDb);

    final newData = SensorData(
      luxValue: displayLux,
      decibelValue: displayDb,
      timestamp: DateTime.now(),
      lightConditionStr: lightCondition.name,
      soundConditionStr: soundCondition.name,
    );

    // Maintain rolling history for chart
    _recentHistory.add(newData);
    if (_recentHistory.length > _maxHistorySize) {
      _recentHistory.removeAt(0);
    }

    emit(current.copyWith(
      currentData: newData,
      recentHistory: List.unmodifiable(_recentHistory),
      lastUpdated: DateTime.now(),
    ));
  }

  Future<void> _onStopStreaming(
    SensorStopStreamingEvent event,
    Emitter<SensorState> emit,
  ) async {
    await _lightSubscription?.cancel();
    await _soundSubscription?.cancel();
    _lightSubscription = null;
    _soundSubscription = null;

    if (state is SensorActive) {
      emit(SensorPaused((state as SensorActive).currentData));
    }
  }

  Future<void> _onPermissionsGranted(
    SensorPermissionsGrantedEvent event,
    Emitter<SensorState> emit,
  ) async {
    add(const SensorInitializeEvent());
  }

  void _onPermissionsDenied(
    SensorPermissionsDeniedEvent event,
    Emitter<SensorState> emit,
  ) {
    emit(SensorError(
      'Required permissions denied: ${event.deniedPermissions.join(", ")}. '
      'Please grant permissions in Settings.',
    ));
  }

  void _onError(SensorErrorEvent event, Emitter<SensorState> emit) {
    // Don't crash the whole bloc for sensor errors — log and continue
    // Only emit error state for critical failures
    if (event.message.contains('permission')) {
      emit(SensorError(event.message));
    }
    // For hardware errors, just log — the stream will continue
  }

  @override
  Future<void> close() async {
    await _lightSubscription?.cancel();
    await _soundSubscription?.cancel();
    await _sensorService.dispose();
    await _audioService.dispose();
    return super.close();
  }
}
