// lib/blocs/environment/environment_event.dart
// lib/blocs/environment/environment_state.dart
// lib/blocs/environment/environment_bloc.dart

import 'dart:async';
import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../models/sensor_data.dart';
import '../../services/ml_service.dart';
import '../../services/storage_service.dart';
import '../../core/constants/app_constants.dart';

// ─── Events ───────────────────────────────────────────────────────────────────

abstract class EnvironmentEvent extends Equatable {
  const EnvironmentEvent();
  @override
  List<Object?> get props => [];
}

class EnvironmentAnalyzeEvent extends EnvironmentEvent {
  final SensorData sensorData;
  const EnvironmentAnalyzeEvent(this.sensorData);
  @override
  List<Object?> get props => [sensorData];
}

class EnvironmentResetEvent extends EnvironmentEvent {
  const EnvironmentResetEvent();
}

class EnvironmentApplyUserProfileEvent extends EnvironmentEvent {
  final String profileId;
  const EnvironmentApplyUserProfileEvent(this.profileId);
  @override
  List<Object?> get props => [profileId];
}

// ─── States ───────────────────────────────────────────────────────────────────

abstract class EnvironmentState extends Equatable {
  const EnvironmentState();
  @override
  List<Object?> get props => [];
}

class EnvironmentIdle extends EnvironmentState {
  const EnvironmentIdle();
}

class EnvironmentProcessing extends EnvironmentState {
  const EnvironmentProcessing();
}

class EnvironmentAnalysisCompleted extends EnvironmentState {
  final EnvironmentAnalysis analysis;
  final List<EnvironmentAnalysis> history;

  const EnvironmentAnalysisCompleted({
    required this.analysis,
    required this.history,
  });

  @override
  List<Object?> get props => [analysis, history];
}

class EnvironmentAnalysisFailure extends EnvironmentState {
  final String reason;
  const EnvironmentAnalysisFailure(this.reason);
  @override
  List<Object?> get props => [reason];
}

// ─── Bloc ─────────────────────────────────────────────────────────────────────

class EnvironmentBloc extends Bloc<EnvironmentEvent, EnvironmentState> {
  final MLService _mlService;
  final StorageService _storageService;

  final List<EnvironmentAnalysis> _analysisHistory = [];
  static const int _maxHistory = 100;

  Timer? _debounceTimer;
  SensorData? _pendingData;

  EnvironmentBloc({
    required MLService mlService,
    required StorageService storageService,
  })  : _mlService = mlService,
        _storageService = storageService,
        super(const EnvironmentIdle()) {
    on<EnvironmentAnalyzeEvent>(_onAnalyze);
    on<EnvironmentResetEvent>(_onReset);
    on<EnvironmentApplyUserProfileEvent>(_onApplyProfile);
  }

  Future<void> _onAnalyze(
    EnvironmentAnalyzeEvent event,
    Emitter<EnvironmentState> emit,
  ) async {
    _pendingData = event.sensorData;
    _debounceTimer?.cancel();

    final completer = Completer<void>();
    _debounceTimer = Timer(
      const Duration(milliseconds: AppConstants.aiInferenceIntervalMs),
      () async {
        if (_pendingData != null) {
          await _runAnalysis(_pendingData!, emit);
        }
        if (!completer.isCompleted) completer.complete();
      },
    );

    if (state is EnvironmentIdle) {
      emit(const EnvironmentProcessing());
    }

    await completer.future;
  }

  Future<void> _runAnalysis(
    SensorData data,
    Emitter<EnvironmentState> emit,
  ) async {
    try {
      final analysis = await _mlService.analyzeEnvironment(data);

      _analysisHistory.add(analysis);
      if (_analysisHistory.length > _maxHistory) {
        _analysisHistory.removeAt(0);
      }

      unawaited(_storageService.saveAnalysis(analysis));

      emit(EnvironmentAnalysisCompleted(
        analysis: analysis,
        history: List.from(_analysisHistory),
      ));
    } catch (e) {
      emit(EnvironmentAnalysisFailure('Analysis failed: $e'));
    }
  }

  void _onReset(EnvironmentResetEvent event, Emitter<EnvironmentState> emit) {
    _analysisHistory.clear();
    _debounceTimer?.cancel();
    emit(const EnvironmentIdle());
  }

  void _onApplyProfile(
    EnvironmentApplyUserProfileEvent event,
    Emitter<EnvironmentState> emit,
  ) {
    _mlService.loadUserProfile(event.profileId);
  }

  @override
  Future<void> close() {
    _debounceTimer?.cancel();
    return super.close();
  }
}
