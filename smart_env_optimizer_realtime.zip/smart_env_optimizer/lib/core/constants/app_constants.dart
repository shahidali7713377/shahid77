// lib/core/constants/app_constants.dart

class AppConstants {
  AppConstants._();

  // App Info
  static const String appName = 'EnvIQ';
  static const String appVersion = '1.0.0';

  // Sensor Sampling
  static const int sensorSamplingIntervalMs = 500;
  static const int audioSamplingIntervalMs = 1000;
  static const int aiInferenceIntervalMs = 2000;
  static const int backgroundThrottleMs = 5000;

  // Light Thresholds (Lux)
  static const double luxDark = 50.0;
  static const double luxDim = 200.0;
  static const double luxOptimalMin = 300.0;
  static const double luxOptimalMax = 1000.0;
  static const double luxOverexposed = 2000.0;

  // Decibel Thresholds (dB)
  static const double dbSilent = 30.0;
  static const double dbBackground = 50.0;
  static const double dbConversation = 65.0;
  static const double dbTraffic = 75.0;
  static const double dbHighDistraction = 85.0;

  // AI Inference
  static const int audioBufferSize = 44100;
  static const int audioSampleRate = 16000;
  static const double confidenceThreshold = 0.65;
  static const int maxInferenceTimeMs = 200;

  // Session
  static const int minSessionDurationSec = 60;
  static const int defaultFocusDurationMin = 25;
  static const int shortBreakMin = 5;
  static const int longBreakMin = 15;

  // Storage Keys
  static const String userProfileBox = 'user_profile';
  static const String sessionsBox = 'sessions';
  static const String sensorLogsBox = 'sensor_logs';
  static const String recommendationsBox = 'recommendations';
  static const String prefsKey = 'user_preferences';

  // Environment Score Weights
  static const double lightWeight = 0.35;
  static const double soundWeight = 0.40;
  static const double timeWeight = 0.25;

  // Productivity Score
  static const int maxProductivityRating = 5;
  static const double patternLearningRate = 0.1;

  // Battery optimization
  static const int batteryThresholdPercent = 15;
  static const Duration backgroundSyncInterval = Duration(minutes: 15);
}

class HiveTypeIds {
  HiveTypeIds._();
  static const int sensorData = 0;
  static const int sessionRecord = 1;
  static const int userProfile = 2;
  static const int recommendation = 3;
  static const int environmentProfile = 4;
  static const int feedbackRecord = 5;
}

class AppRoutes {
  AppRoutes._();
  static const String splash = '/';
  static const String onboarding = '/onboarding';
  static const String home = '/home';
  static const String focusMode = '/focus';
  static const String sleepMode = '/sleep';
  static const String history = '/history';
  static const String settings = '/settings';
  static const String permissions = '/permissions';
  static const String sessionSummary = '/session-summary';
}
