// lib/widgets/environment_score_gauge.dart
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import '../core/theme/app_theme.dart';

class EnvironmentScoreGauge extends StatefulWidget {
  final double score;
  final String label;
  final List<Color> colors;

  const EnvironmentScoreGauge({
    super.key,
    required this.score,
    required this.label,
    required this.colors,
  });

  @override
  State<EnvironmentScoreGauge> createState() => _EnvironmentScoreGaugeState();
}

class _EnvironmentScoreGaugeState extends State<EnvironmentScoreGauge>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scoreAnimation;
  double _previousScore = 0;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _scoreAnimation =
        Tween<double>(begin: 0, end: widget.score).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic),
    );
    _controller.forward();
  }

  @override
  void didUpdateWidget(EnvironmentScoreGauge old) {
    super.didUpdateWidget(old);
    if ((old.score - widget.score).abs() > 0.005) {
      _scoreAnimation = Tween<double>(
        begin: _previousScore,
        end: widget.score,
      ).animate(
        CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic),
      );
      _previousScore = widget.score;
      _controller.forward(from: 0);
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _scoreAnimation,
      builder: (context, _) {
        final score = _scoreAnimation.value;
        final percent = (score * 100).toInt();

        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Stack(
              alignment: Alignment.center,
              children: [
                SizedBox(
                  width: 90,
                  height: 90,
                  child: CircularProgressIndicator(
                    value: score.clamp(0.0, 1.0),
                    backgroundColor: AppColors.bg3,
                    valueColor: AlwaysStoppedAnimation<Color>(
                        widget.colors.first),
                    strokeWidth: 5,
                    strokeCap: StrokeCap.round,
                  ),
                ),
                Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      '$percent',
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.w700,
                        color: widget.colors.first,
                        height: 1,
                      ),
                    ),
                    Text(
                      '%',
                      style: TextStyle(
                        fontSize: 11,
                        color: widget.colors.first.withOpacity(0.7),
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            const Gap(8),
            Text(
              widget.label,
              style: const TextStyle(
                color: AppColors.textSecondary,
                fontSize: 13,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        );
      },
    );
  }
}

// ─── Sensor Metric Card ───────────────────────────────────────────────────────

import 'package:iconsax/iconsax.dart';

class SensorMetricCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final String subLabel;
  final Color color;
  final bool showPulse;
  final Widget? customWidget;

  const SensorMetricCard({
    super.key,
    required this.icon,
    required this.label,
    required this.value,
    required this.subLabel,
    required this.color,
    this.showPulse = false,
    this.customWidget,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.bg2,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: showPulse ? color.withOpacity(0.3) : AppColors.border,
          width: showPulse ? 1.5 : 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: color, size: 18),
              const Gap(6),
              Text(
                label,
                style: const TextStyle(
                  color: AppColors.textMuted,
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const Spacer(),
              // Live indicator dot
              if (showPulse)
                _PulsingDot(color: color),
            ],
          ),
          const Gap(10),
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 300),
            transitionBuilder: (child, anim) => FadeTransition(
              opacity: anim,
              child: SlideTransition(
                position: Tween<Offset>(
                  begin: const Offset(0, 0.3),
                  end: Offset.zero,
                ).animate(anim),
                child: child,
              ),
            ),
            child: Text(
              value,
              key: ValueKey(value),
              style: TextStyle(
                color: color,
                fontSize: 22,
                fontWeight: FontWeight.w700,
                height: 1,
              ),
            ),
          ),
          const Gap(4),
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 300),
            child: Container(
              key: ValueKey(subLabel),
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                color: color.withOpacity(0.12),
                borderRadius: BorderRadius.circular(4),
              ),
              child: Text(
                subLabel,
                style: TextStyle(
                  color: color,
                  fontSize: 10,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ),
          if (customWidget != null) ...[
            const Gap(8),
            customWidget!,
          ],
        ],
      ),
    );
  }
}

/// Small pulsing dot shown on the sensor card when real data is flowing
class _PulsingDot extends StatefulWidget {
  final Color color;
  const _PulsingDot({required this.color});

  @override
  State<_PulsingDot> createState() => _PulsingDotState();
}

class _PulsingDotState extends State<_PulsingDot>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) => Container(
        width: 6,
        height: 6,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: Color.lerp(
              widget.color, widget.color.withOpacity(0.2), _c.value),
          boxShadow: [
            BoxShadow(
              color: widget.color.withOpacity(0.4 * (1 - _c.value)),
              blurRadius: 4,
              spreadRadius: 1,
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Recommendation Card ──────────────────────────────────────────────────────

import '../models/recommendation.dart';

class RecommendationCard extends StatelessWidget {
  final Recommendation recommendation;
  final VoidCallback onDismiss;
  final VoidCallback onActedOn;
  final bool compact;
  final Color accentColor;

  const RecommendationCard({
    super.key,
    required this.recommendation,
    required this.onDismiss,
    required this.onActedOn,
    this.compact = false,
    this.accentColor = AppColors.primary,
  });

  @override
  Widget build(BuildContext context) {
    final type = recommendation.type;

    return Dismissible(
      key: Key(recommendation.id),
      direction: DismissDirection.endToStart,
      onDismissed: (_) => onDismiss(),
      background: Container(
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 20),
        decoration: BoxDecoration(
          color: AppColors.error.withOpacity(0.15),
          borderRadius: BorderRadius.circular(14),
        ),
        child: const Icon(Icons.close, color: AppColors.error),
      ),
      child: Container(
        padding: EdgeInsets.all(compact ? 12 : 16),
        decoration: BoxDecoration(
          color: AppColors.bg2,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: accentColor.withOpacity(0.2)),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(type.iconPath, style: TextStyle(fontSize: compact ? 20 : 26)),
            const Gap(12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          type.title,
                          style: TextStyle(
                            color: AppColors.textPrimary,
                            fontSize: compact ? 13 : 14,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: accentColor.withOpacity(0.12),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          '${recommendation.confidencePercent}%',
                          style: TextStyle(
                            color: accentColor,
                            fontSize: 10,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ],
                  ),
                  if (!compact) ...[
                    const Gap(4),
                    Text(
                      recommendation.reasoning,
                      style: const TextStyle(
                        color: AppColors.textSecondary,
                        fontSize: 12,
                        height: 1.4,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const Gap(10),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton(
                            onPressed: onActedOn,
                            style: OutlinedButton.styleFrom(
                              foregroundColor: accentColor,
                              side: BorderSide(
                                  color: accentColor.withOpacity(0.5)),
                              padding:
                                  const EdgeInsets.symmetric(vertical: 8),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                              minimumSize: Size.zero,
                            ),
                            child: const Text('Done',
                                style: TextStyle(fontSize: 12)),
                          ),
                        ),
                        const Gap(8),
                        Expanded(
                          child: TextButton(
                            onPressed: onDismiss,
                            style: TextButton.styleFrom(
                              padding:
                                  const EdgeInsets.symmetric(vertical: 8),
                              minimumSize: Size.zero,
                            ),
                            child: const Text(
                              'Dismiss',
                              style: TextStyle(
                                  color: AppColors.textMuted, fontSize: 12),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Live Audio Waveform ──────────────────────────────────────────────────────

import 'dart:math' as math;

class LiveWaveform extends StatefulWidget {
  final double decibelValue;
  const LiveWaveform({super.key, required this.decibelValue});

  @override
  State<LiveWaveform> createState() => _LiveWaveformState();
}

class _LiveWaveformState extends State<LiveWaveform>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  final List<double> _amplitudes = List.filled(24, 0.05);
  final math.Random _rng = math.Random();

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 80),
    )..addListener(_tick)..repeat();
  }

  void _tick() {
    if (!mounted) return;
    setState(() {
      _amplitudes.removeAt(0);
      // Normalize dB: 20dB silent → 0.05, 100dB loud → 1.0
      final normalized =
          ((widget.decibelValue - 20) / 80).clamp(0.05, 1.0);
      // Add slight randomness so adjacent bars look organic
      final jitter = (_rng.nextDouble() - 0.5) * 0.15;
      _amplitudes.add((normalized + jitter).clamp(0.02, 1.0));
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 24,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: _amplitudes
            .map((amp) => Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 1),
                    child: Container(
                      height: (amp * 22).clamp(2.0, 22.0),
                      decoration: BoxDecoration(
                        color: AppColors.focus.withOpacity(0.65),
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  ),
                ))
            .toList(),
      ),
    );
  }
}

// ─── Session Feedback Sheet ───────────────────────────────────────────────────

class SessionFeedbackSheet extends StatefulWidget {
  final String sessionType;
  final Duration duration;
  final double avgScore;
  final void Function(int rating, String? notes) onSubmit;

  const SessionFeedbackSheet({
    super.key,
    required this.sessionType,
    required this.duration,
    required this.avgScore,
    required this.onSubmit,
  });

  @override
  State<SessionFeedbackSheet> createState() => _SessionFeedbackSheetState();
}

class _SessionFeedbackSheetState extends State<SessionFeedbackSheet> {
  int _rating = 0;
  final _notesController = TextEditingController();

  @override
  void dispose() {
    _notesController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: AppColors.bg1,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      padding: EdgeInsets.only(
        left: 24,
        right: 24,
        top: 24,
        bottom: MediaQuery.of(context).viewInsets.bottom + 24,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(
            child: Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: AppColors.textMuted,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          const Gap(20),
          Text('How did it go?',
              style: Theme.of(context).textTheme.headlineSmall),
          const Gap(8),
          Text(
            '${widget.sessionType == 'focus' ? 'Focus' : 'Sleep'} • '
            '${widget.duration.inMinutes}m ${widget.duration.inSeconds % 60}s • '
            'Score: ${(widget.avgScore * 100).toInt()}%',
            style: const TextStyle(color: AppColors.textMuted, fontSize: 13),
          ),
          const Gap(24),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(
              5,
              (i) => GestureDetector(
                onTap: () => setState(() => _rating = i + 1),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 6),
                  child: Icon(
                    Icons.star_rounded,
                    size: 44,
                    color: i < _rating ? AppColors.warning : AppColors.bg3,
                  ),
                ),
              ),
            ),
          ),
          const Gap(20),
          TextField(
            controller: _notesController,
            style: const TextStyle(
                color: AppColors.textPrimary, fontSize: 14),
            decoration: const InputDecoration(
              hintText: 'Add a note (optional)...',
              hintStyle: TextStyle(color: AppColors.textMuted),
            ),
            maxLines: 2,
          ),
          const Gap(20),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _rating == 0
                  ? null
                  : () => widget.onSubmit(
                        _rating,
                        _notesController.text.isEmpty
                            ? null
                            : _notesController.text,
                      ),
              style: ElevatedButton.styleFrom(
                disabledBackgroundColor: AppColors.bg3,
                padding: const EdgeInsets.symmetric(vertical: 16),
              ),
              child:
                  Text(_rating == 0 ? 'Rate your session' : 'Submit'),
            ),
          ),
        ],
      ),
    );
  }
}
