// lib/widgets/live_waveform.dart
// LiveWaveform is defined in environment_score_gauge.dart (widget bundle)
// This file exists for import compatibility
export 'environment_score_gauge.dart' show LiveWaveform;
