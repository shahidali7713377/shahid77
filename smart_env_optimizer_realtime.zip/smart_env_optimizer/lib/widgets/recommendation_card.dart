// lib/widgets/recommendation_card.dart
export 'environment_score_gauge.dart' show RecommendationCard;
