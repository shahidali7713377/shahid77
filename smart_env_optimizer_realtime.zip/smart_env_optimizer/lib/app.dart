// lib/app.dart
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'core/theme/app_theme.dart';
import 'core/constants/app_constants.dart';
import 'blocs/sensor/sensor_bloc.dart';
import 'blocs/sensor/sensor_event.dart';
import 'blocs/environment/environment_bloc.dart';
import 'blocs/recommendation/recommendation_bloc.dart';
import 'blocs/session/session_bloc.dart';
import 'services/sensor_service.dart';
import 'services/ml_service.dart';
import 'services/storage_service.dart';
import 'services/recommendation_service.dart';
import 'screens/main_shell.dart';
import 'screens/onboarding/onboarding_screen.dart';
import 'screens/focus/focus_screen.dart';
import 'screens/sleep/sleep_screen.dart';

class SmartEnvApp extends StatelessWidget {
  final StorageService storageService;
  final bool showOnboarding;

  const SmartEnvApp({
    super.key,
    required this.storageService,
    required this.showOnboarding,
  });

  @override
  Widget build(BuildContext context) {
    final sensorService = SensorServiceImpl();
    final audioService = AudioService();
    final mlService = MLService();
    final recommendationService = RecommendationService();

    return MultiRepositoryProvider(
      providers: [
        RepositoryProvider<StorageService>.value(value: storageService),
        RepositoryProvider<MLService>.value(value: mlService),
        RepositoryProvider<RecommendationService>.value(
            value: recommendationService),
      ],
      child: MultiBlocProvider(
        providers: [
          BlocProvider<SensorBloc>(
            create: (_) => SensorBloc(
              sensorService: sensorService,
              audioService: audioService,
            )..add(const SensorInitializeEvent()),
          ),
          BlocProvider<EnvironmentBloc>(
            create: (ctx) => EnvironmentBloc(
              mlService: ctx.read<MLService>(),
              storageService: ctx.read<StorageService>(),
            ),
          ),
          BlocProvider<RecommendationBloc>(
            create: (ctx) => RecommendationBloc(
              recommendationService: ctx.read<RecommendationService>(),
              storageService: ctx.read<StorageService>(),
            ),
          ),
          BlocProvider<SessionBloc>(
            create: (ctx) =>
                SessionBloc(storageService: ctx.read<StorageService>()),
          ),
        ],
        child: _AppBlocBridge(
          child: MaterialApp(
            title: AppConstants.appName,
            debugShowCheckedModeBanner: false,
            theme: AppTheme.darkTheme,
            darkTheme: AppTheme.darkTheme,
            themeMode: ThemeMode.dark,
            initialRoute:
                showOnboarding ? AppRoutes.onboarding : AppRoutes.home,
            routes: {
              AppRoutes.onboarding: (_) => const OnboardingScreen(),
              AppRoutes.home: (_) => const MainShell(),
              AppRoutes.focusMode: (_) => const FocusScreen(),
              AppRoutes.sleepMode: (_) => const SleepScreen(),
            },
          ),
        ),
      ),
    );
  }
}

/// Bridge widget that connects SensorBloc → EnvironmentBloc → RecommendationBloc
/// Listens to sensor updates and automatically triggers ML analysis
class _AppBlocBridge extends StatefulWidget {
  final Widget child;
  const _AppBlocBridge({required this.child});

  @override
  State<_AppBlocBridge> createState() => _AppBlocBridgeState();
}

class _AppBlocBridgeState extends State<_AppBlocBridge> {
  @override
  Widget build(BuildContext context) {
    return BlocListener<SensorBloc, SensorState>(
      listener: (context, sensorState) {
        if (sensorState is SensorActive) {
          // Pipe sensor data into environment analysis
          context.read<EnvironmentBloc>().add(
                EnvironmentAnalyzeEvent(sensorState.currentData),
              );
        }
      },
      child: BlocListener<EnvironmentBloc, EnvironmentState>(
        listener: (context, envState) {
          if (envState is EnvironmentAnalysisCompleted) {
            // Update session metrics if a session is active
            final sessionState = context.read<SessionBloc>().state;
            if (sessionState is SessionActive) {
              context.read<SessionBloc>().add(
                    SessionUpdateMetricsEvent(
                      currentFocusScore: envState.analysis.focusScore,
                      currentSleepScore: envState.analysis.sleepScore,
                      currentLux: envState.analysis.sensorData.luxValue,
                      currentDb: envState.analysis.sensorData.decibelValue,
                    ),
                  );
            }

            // Auto-generate recommendations (not during active focus timer to reduce interruptions)
            final recState = context.read<RecommendationBloc>().state;
            final shouldGenerate = sessionState is! SessionActive ||
                sessionState.elapsedSeconds % 60 == 0;

            if (shouldGenerate) {
              context.read<RecommendationBloc>().add(
                    RecommendationGenerateEvent(
                      analysis: envState.analysis,
                      isFocusMode: sessionState is SessionActive &&
                          sessionState.sessionType == 'focus',
                      isSleepMode: sessionState is SessionActive &&
                          sessionState.sessionType == 'sleep',
                    ),
                  );
            }
          }
        },
        child: widget.child,
      ),
    );
  }
}
