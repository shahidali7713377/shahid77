// lib/models/recommendation.g.dart
// Hand-written Hive adapter for Recommendation and SessionRecord
// In production run: flutter pub run build_runner build

part of 'recommendation.dart';

class RecommendationAdapter extends TypeAdapter<Recommendation> {
  @override
  final int typeId = HiveTypeIds.recommendation;

  @override
  Recommendation read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return Recommendation(
      id: fields[0] as String,
      typeStr: fields[1] as String,
      categoryStr: fields[2] as String,
      confidenceScore: (fields[3] as num).toDouble(),
      reasoning: fields[4] as String,
      generatedAt: fields[5] as DateTime,
      priority: fields[6] as int,
      isDismissed: fields[7] as bool? ?? false,
      isActedOn: fields[8] as bool? ?? false,
    );
  }

  @override
  void write(BinaryWriter writer, Recommendation obj) {
    writer
      ..writeByte(9)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.typeStr)
      ..writeByte(2)
      ..write(obj.categoryStr)
      ..writeByte(3)
      ..write(obj.confidenceScore)
      ..writeByte(4)
      ..write(obj.reasoning)
      ..writeByte(5)
      ..write(obj.generatedAt)
      ..writeByte(6)
      ..write(obj.priority)
      ..writeByte(7)
      ..write(obj.isDismissed)
      ..writeByte(8)
      ..write(obj.isActedOn);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is RecommendationAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class SessionRecordAdapter extends TypeAdapter<SessionRecord> {
  @override
  final int typeId = HiveTypeIds.sessionRecord;

  @override
  SessionRecord read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return SessionRecord(
      id: fields[0] as String,
      sessionType: fields[1] as String,
      startTime: fields[2] as DateTime,
      endTime: fields[3] as DateTime?,
      avgLux: (fields[4] as num).toDouble(),
      avgDecibel: (fields[5] as num).toDouble(),
      avgFocusScore: (fields[6] as num).toDouble(),
      avgSleepScore: (fields[7] as num).toDouble(),
      userProductivityRating: fields[8] as int?,
      userNotes: fields[9] as String?,
      recommendationIds: (fields[10] as List?)?.cast<String>() ?? [],
      isCompleted: fields[11] as bool? ?? false,
    );
  }

  @override
  void write(BinaryWriter writer, SessionRecord obj) {
    writer
      ..writeByte(12)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.sessionType)
      ..writeByte(2)
      ..write(obj.startTime)
      ..writeByte(3)
      ..write(obj.endTime)
      ..writeByte(4)
      ..write(obj.avgLux)
      ..writeByte(5)
      ..write(obj.avgDecibel)
      ..writeByte(6)
      ..write(obj.avgFocusScore)
      ..writeByte(7)
      ..write(obj.avgSleepScore)
      ..writeByte(8)
      ..write(obj.userProductivityRating)
      ..writeByte(9)
      ..write(obj.userNotes)
      ..writeByte(10)
      ..write(obj.recommendationIds)
      ..writeByte(11)
      ..write(obj.isCompleted);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is SessionRecordAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
