// lib/models/sensor_data.dart
import 'package:equatable/equatable.dart';
import 'package:hive/hive.dart';
import '../core/constants/app_constants.dart';

part 'sensor_data.g.dart';

enum LightCondition { dark, dim, optimal, overexposed, unknown }

enum SoundCondition { silent, backgroundNoise, conversation, traffic, highDistraction, unknown }

extension LightConditionX on LightCondition {
  String get label {
    switch (this) {
      case LightCondition.dark:
        return 'Dark';
      case LightCondition.dim:
        return 'Dim';
      case LightCondition.optimal:
        return 'Optimal';
      case LightCondition.overexposed:
        return 'Overexposed';
      case LightCondition.unknown:
        return 'Unknown';
    }
  }

  double get productivityScore {
    switch (this) {
      case LightCondition.dark:
        return 0.2;
      case LightCondition.dim:
        return 0.55;
      case LightCondition.optimal:
        return 1.0;
      case LightCondition.overexposed:
        return 0.6;
      case LightCondition.unknown:
        return 0.5;
    }
  }

  double get sleepScore {
    switch (this) {
      case LightCondition.dark:
        return 1.0;
      case LightCondition.dim:
        return 0.7;
      case LightCondition.optimal:
        return 0.3;
      case LightCondition.overexposed:
        return 0.1;
      case LightCondition.unknown:
        return 0.5;
    }
  }
}

extension SoundConditionX on SoundCondition {
  String get label {
    switch (this) {
      case SoundCondition.silent:
        return 'Silent';
      case SoundCondition.backgroundNoise:
        return 'Background';
      case SoundCondition.conversation:
        return 'Conversation';
      case SoundCondition.traffic:
        return 'Traffic';
      case SoundCondition.highDistraction:
        return 'High Distraction';
      case SoundCondition.unknown:
        return 'Unknown';
    }
  }

  double get productivityScore {
    switch (this) {
      case SoundCondition.silent:
        return 0.90;
      case SoundCondition.backgroundNoise:
        return 1.0;
      case SoundCondition.conversation:
        return 0.55;
      case SoundCondition.traffic:
        return 0.40;
      case SoundCondition.highDistraction:
        return 0.15;
      case SoundCondition.unknown:
        return 0.5;
    }
  }

  double get sleepScore {
    switch (this) {
      case SoundCondition.silent:
        return 1.0;
      case SoundCondition.backgroundNoise:
        return 0.65;
      case SoundCondition.conversation:
        return 0.30;
      case SoundCondition.traffic:
        return 0.20;
      case SoundCondition.highDistraction:
        return 0.05;
      case SoundCondition.unknown:
        return 0.5;
    }
  }
}

@HiveType(typeId: 0)
class SensorData extends HiveObject with EquatableMixin {
  @HiveField(0)
  final double luxValue;

  @HiveField(1)
  final double decibelValue;

  @HiveField(2)
  final DateTime timestamp;

  @HiveField(3)
  final String lightConditionStr;

  @HiveField(4)
  final String soundConditionStr;

  @HiveField(5)
  final double temperature;

  SensorData({
    required this.luxValue,
    required this.decibelValue,
    required this.timestamp,
    required this.lightConditionStr,
    required this.soundConditionStr,
    this.temperature = 0.0,
  });

  LightCondition get lightCondition =>
      LightCondition.values.firstWhere(
        (e) => e.name == lightConditionStr,
        orElse: () => LightCondition.unknown,
      );

  SoundCondition get soundCondition =>
      SoundCondition.values.firstWhere(
        (e) => e.name == soundConditionStr,
        orElse: () => SoundCondition.unknown,
      );

  static LightCondition classifyLight(double lux) {
    if (lux < AppConstants.luxDark) return LightCondition.dark;
    if (lux < AppConstants.luxDim) return LightCondition.dim;
    if (lux <= AppConstants.luxOptimalMax) return LightCondition.optimal;
    return LightCondition.overexposed;
  }

  static SoundCondition classifySound(double db) {
    if (db < AppConstants.dbSilent) return SoundCondition.silent;
    if (db < AppConstants.dbBackground) return SoundCondition.backgroundNoise;
    if (db < AppConstants.dbConversation) return SoundCondition.conversation;
    if (db < AppConstants.dbTraffic) return SoundCondition.traffic;
    return SoundCondition.highDistraction;
  }

  SensorData copyWith({
    double? luxValue,
    double? decibelValue,
    DateTime? timestamp,
    String? lightConditionStr,
    String? soundConditionStr,
    double? temperature,
  }) {
    return SensorData(
      luxValue: luxValue ?? this.luxValue,
      decibelValue: decibelValue ?? this.decibelValue,
      timestamp: timestamp ?? this.timestamp,
      lightConditionStr: lightConditionStr ?? this.lightConditionStr,
      soundConditionStr: soundConditionStr ?? this.soundConditionStr,
      temperature: temperature ?? this.temperature,
    );
  }

  @override
  List<Object?> get props => [
        luxValue,
        decibelValue,
        timestamp,
        lightConditionStr,
        soundConditionStr,
      ];

  static SensorData empty() => SensorData(
        luxValue: 0,
        decibelValue: 0,
        timestamp: DateTime.now(),
        lightConditionStr: LightCondition.unknown.name,
        soundConditionStr: SoundCondition.unknown.name,
      );
}

// lib/models/environment_analysis.dart - inline
class EnvironmentAnalysis extends Equatable {
  final SensorData sensorData;
  final double focusScore;
  final double sleepScore;
  final double overallScore;
  final String dominantIssue;
  final DateTime analysisTime;
  final Map<String, double> featureScores;

  const EnvironmentAnalysis({
    required this.sensorData,
    required this.focusScore,
    required this.sleepScore,
    required this.overallScore,
    required this.dominantIssue,
    required this.analysisTime,
    required this.featureScores,
  });

  String get qualityLabel {
    if (overallScore >= 0.8) return 'Excellent';
    if (overallScore >= 0.6) return 'Good';
    if (overallScore >= 0.4) return 'Fair';
    return 'Poor';
  }

  int get scorePercentage => (overallScore * 100).round();

  static EnvironmentAnalysis empty() => EnvironmentAnalysis(
        sensorData: SensorData.empty(),
        focusScore: 0,
        sleepScore: 0,
        overallScore: 0,
        dominantIssue: '',
        analysisTime: DateTime.now(),
        featureScores: {},
      );

  @override
  List<Object?> get props => [
        sensorData,
        focusScore,
        sleepScore,
        overallScore,
        dominantIssue,
        analysisTime,
      ];
}
