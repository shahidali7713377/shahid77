// lib/models/recommendation.dart
import 'package:equatable/equatable.dart';
import 'package:hive/hive.dart';
import '../core/constants/app_constants.dart';

part 'recommendation.g.dart';

enum RecommendationType {
  increaseLight,
  decreaseLight,
  reduceNoise,
  useHeadphones,
  switchRoom,
  dimLights,
  enableNightMode,
  adjustSleepTime,
  takeBreak,
  moveToQuieterSpace,
  openBlinds,
  connectWhiteNoise,
}

enum RecommendationCategory { focus, sleep, general }

extension RecommendationTypeX on RecommendationType {
  String get title {
    switch (this) {
      case RecommendationType.increaseLight:
        return 'Increase Lighting';
      case RecommendationType.decreaseLight:
        return 'Reduce Brightness';
      case RecommendationType.reduceNoise:
        return 'Reduce Noise';
      case RecommendationType.useHeadphones:
        return 'Use Headphones';
      case RecommendationType.switchRoom:
        return 'Switch Room';
      case RecommendationType.dimLights:
        return 'Dim the Lights';
      case RecommendationType.enableNightMode:
        return 'Enable Night Mode';
      case RecommendationType.adjustSleepTime:
        return 'Adjust Sleep Time';
      case RecommendationType.takeBreak:
        return 'Take a Break';
      case RecommendationType.moveToQuieterSpace:
        return 'Move to Quieter Space';
      case RecommendationType.openBlinds:
        return 'Open the Blinds';
      case RecommendationType.connectWhiteNoise:
        return 'Use White Noise';
    }
  }

  String get description {
    switch (this) {
      case RecommendationType.increaseLight:
        return 'Current lighting is too low for optimal focus. Turn on additional lights or increase brightness.';
      case RecommendationType.decreaseLight:
        return 'Excessive light is straining your eyes. Reduce screen brightness or close blinds.';
      case RecommendationType.reduceNoise:
        return 'Background noise is reducing your concentration. Consider noise-cancelling solutions.';
      case RecommendationType.useHeadphones:
        return 'Ambient noise detected. Headphones with white noise or music can boost your focus significantly.';
      case RecommendationType.switchRoom:
        return 'Current environment is not optimal. Moving to a different room could improve conditions.';
      case RecommendationType.dimLights:
        return 'Dimming lights signals your brain to produce melatonin, preparing for quality sleep.';
      case RecommendationType.enableNightMode:
        return 'Blue light disrupts sleep. Enable Night Mode to shift to warm tones.';
      case RecommendationType.adjustSleepTime:
        return 'Your environment suggests you could benefit from adjusting your sleep schedule.';
      case RecommendationType.takeBreak:
        return 'You\'ve been in a non-optimal environment for a while. A short break may help.';
      case RecommendationType.moveToQuieterSpace:
        return 'High noise levels detected. Moving to a quieter space will significantly improve sleep quality.';
      case RecommendationType.openBlinds:
        return 'Natural light is ideal for focus and circadian rhythm. Let in some daylight.';
      case RecommendationType.connectWhiteNoise:
        return 'A consistent white noise background can mask distracting sounds and improve concentration.';
    }
  }

  String get iconPath {
    switch (this) {
      case RecommendationType.increaseLight:
        return '☀️';
      case RecommendationType.decreaseLight:
        return '🌅';
      case RecommendationType.reduceNoise:
        return '🔇';
      case RecommendationType.useHeadphones:
        return '🎧';
      case RecommendationType.switchRoom:
        return '🚪';
      case RecommendationType.dimLights:
        return '🌙';
      case RecommendationType.enableNightMode:
        return '📱';
      case RecommendationType.adjustSleepTime:
        return '⏰';
      case RecommendationType.takeBreak:
        return '☕';
      case RecommendationType.moveToQuieterSpace:
        return '🏃';
      case RecommendationType.openBlinds:
        return '🪟';
      case RecommendationType.connectWhiteNoise:
        return '🌊';
    }
  }
}

@HiveType(typeId: 3)
class Recommendation extends HiveObject with EquatableMixin {
  @HiveField(0)
  final String id;

  @HiveField(1)
  final String typeStr;

  @HiveField(2)
  final String categoryStr;

  @HiveField(3)
  final double confidenceScore;

  @HiveField(4)
  final String reasoning;

  @HiveField(5)
  final DateTime generatedAt;

  @HiveField(6)
  final int priority;

  @HiveField(7)
  bool isDismissed;

  @HiveField(8)
  bool isActedOn;

  Recommendation({
    required this.id,
    required this.typeStr,
    required this.categoryStr,
    required this.confidenceScore,
    required this.reasoning,
    required this.generatedAt,
    required this.priority,
    this.isDismissed = false,
    this.isActedOn = false,
  });

  RecommendationType get type =>
      RecommendationType.values.firstWhere(
        (e) => e.name == typeStr,
        orElse: () => RecommendationType.takeBreak,
      );

  RecommendationCategory get category =>
      RecommendationCategory.values.firstWhere(
        (e) => e.name == categoryStr,
        orElse: () => RecommendationCategory.general,
      );

  int get confidencePercent => (confidenceScore * 100).round();

  @override
  List<Object?> get props => [id, typeStr, confidenceScore, generatedAt];
}

// lib/models/session.dart - inline
@HiveType(typeId: 1)
class SessionRecord extends HiveObject with EquatableMixin {
  @HiveField(0)
  final String id;

  @HiveField(1)
  final String sessionType; // 'focus' | 'sleep'

  @HiveField(2)
  final DateTime startTime;

  @HiveField(3)
  DateTime? endTime;

  @HiveField(4)
  final double avgLux;

  @HiveField(5)
  final double avgDecibel;

  @HiveField(6)
  final double avgFocusScore;

  @HiveField(7)
  final double avgSleepScore;

  @HiveField(8)
  int? userProductivityRating;

  @HiveField(9)
  String? userNotes;

  @HiveField(10)
  final List<String> recommendationIds;

  @HiveField(11)
  bool isCompleted;

  SessionRecord({
    required this.id,
    required this.sessionType,
    required this.startTime,
    this.endTime,
    required this.avgLux,
    required this.avgDecibel,
    required this.avgFocusScore,
    required this.avgSleepScore,
    this.userProductivityRating,
    this.userNotes,
    required this.recommendationIds,
    this.isCompleted = false,
  });

  Duration get duration {
    final end = endTime ?? DateTime.now();
    return end.difference(startTime);
  }

  String get formattedDuration {
    final d = duration;
    final h = d.inHours;
    final m = d.inMinutes % 60;
    final s = d.inSeconds % 60;
    if (h > 0) return '${h}h ${m}m';
    if (m > 0) return '${m}m ${s}s';
    return '${s}s';
  }

  @override
  List<Object?> get props => [id, sessionType, startTime, endTime];
}

// lib/models/user_profile.dart - inline
@HiveType(typeId: 2)
class UserProfile extends HiveObject with EquatableMixin {
  @HiveField(0)
  final String id;

  @HiveField(1)
  String name;

  @HiveField(2)
  int focusStartHour;

  @HiveField(3)
  int focusEndHour;

  @HiveField(4)
  int sleepStartHour;

  @HiveField(5)
  int sleepEndHour;

  @HiveField(6)
  double optimalLux;

  @HiveField(7)
  double optimalDecibel;

  @HiveField(8)
  int totalSessions;

  @HiveField(9)
  double avgProductivityRating;

  @HiveField(10)
  final DateTime createdAt;

  @HiveField(11)
  DateTime updatedAt;

  @HiveField(12)
  bool onboardingCompleted;

  @HiveField(13)
  Map<String, double> environmentEffectivenessMap;

  @HiveField(14)
  bool notificationsEnabled;

  @HiveField(15)
  bool backgroundMonitoringEnabled;

  UserProfile({
    required this.id,
    required this.name,
    this.focusStartHour = 9,
    this.focusEndHour = 18,
    this.sleepStartHour = 22,
    this.sleepEndHour = 7,
    this.optimalLux = 500.0,
    this.optimalDecibel = 40.0,
    this.totalSessions = 0,
    this.avgProductivityRating = 0.0,
    required this.createdAt,
    required this.updatedAt,
    this.onboardingCompleted = false,
    Map<String, double>? environmentEffectivenessMap,
    this.notificationsEnabled = true,
    this.backgroundMonitoringEnabled = false,
  }) : environmentEffectivenessMap = environmentEffectivenessMap ?? {};

  bool get isFocusHour {
    final now = DateTime.now();
    final hour = now.hour;
    if (focusStartHour < focusEndHour) {
      return hour >= focusStartHour && hour < focusEndHour;
    }
    return hour >= focusStartHour || hour < focusEndHour;
  }

  bool get isSleepHour {
    final now = DateTime.now();
    final hour = now.hour;
    if (sleepStartHour < sleepEndHour) {
      return hour >= sleepStartHour && hour < sleepEndHour;
    }
    return hour >= sleepStartHour || hour < sleepEndHour;
  }

  void updateEffectiveness(String envKey, double score) {
    final current = environmentEffectivenessMap[envKey] ?? 0.5;
    environmentEffectivenessMap[envKey] =
        current * (1 - AppConstants.patternLearningRate) +
        score * AppConstants.patternLearningRate;
  }

  @override
  List<Object?> get props => [id, name, updatedAt];
}
