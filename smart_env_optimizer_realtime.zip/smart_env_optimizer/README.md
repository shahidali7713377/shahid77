# EnvIQ — AI Smart Environment Optimizer

> **100% Offline · On-Device AI · BLoC Architecture · Flutter**

EnvIQ intelligently analyzes environmental conditions (light, sound, time) via device sensors and provides AI-driven recommendations to optimize focus, productivity, and sleep quality — entirely offline, with all inference executed on-device.

---

## 🏗️ Architecture Overview

```
lib/
├── main.dart                          # Entry point, Hive init, orientation lock
├── app.dart                           # DI, MultiBlocProvider, routing, BlocBridge
│
├── core/
│   ├── constants/app_constants.dart   # Thresholds, keys, weights, intervals
│   └── theme/app_theme.dart           # Dark theme, AppColors, typography
│
├── models/
│   ├── sensor_data.dart               # SensorData, LightCondition, SoundCondition
│   ├── sensor_data.g.dart             # Hive adapter (hand-written / build_runner)
│   ├── recommendation.dart            # Recommendation, SessionRecord, UserProfile
│   └── recommendation.g.dart         # Hive adapters
│
├── blocs/
│   ├── sensor/
│   │   ├── sensor_event.dart          # Init, start/stop, light/sound updates
│   │   ├── sensor_state.dart          # Initial, Loading, Active, Paused, Error
│   │   └── sensor_bloc.dart           # EMA smoothing, stream subscriptions
│   │
│   ├── environment/
│   │   └── environment_bloc.dart      # Debounced ML analysis pipeline
│   │
│   ├── recommendation/
│   │   └── recommendation_bloc.dart   # Context-aware generation, merge/sort
│   │
│   └── session/
│       └── session_bloc.dart          # Focus timer, sleep tracker, feedback
│
├── services/
│   ├── sensor_service.dart            # Light sensor + camera fallback abstraction
│   ├── ml_service.dart                # Gaussian scoring, EMA learning, TFLite hook
│   ├── recommendation_service.dart    # Rule engine with confidence scoring
│   └── storage_service.dart          # Hive CRUD, session stats, pattern persistence
│
├── screens/
│   ├── main_shell.dart                # Bottom nav shell with IndexedStack
│   ├── onboarding/onboarding_screen.dart  # 3-page onboarding + permission requests
│   ├── home/home_screen.dart          # Live dashboard, score gauges, recs
│   ├── focus/focus_screen.dart        # Focus timer, live metrics, sparkline
│   ├── sleep/sleep_screen.dart        # Sleep readiness, checklist, tracking
│   ├── history/history_screen.dart    # Sessions list + analytics charts
│   └── settings/settings_screen.dart # Schedule, monitoring, privacy panel
│
└── widgets/
    └── environment_score_gauge.dart   # ScoreGauge, SensorCard, RecCard,
                                       # LiveWaveform, FeedbackSheet
```

---

## 🧠 AI / ML Architecture

### Fully Offline Inference Pipeline

```
SensorBloc (raw lux + dB)
    │  EMA smoothing (α = 0.2)
    ▼
EnvironmentBloc (debounced, 2s)
    │  MLService.analyzeEnvironment()
    ▼
┌─────────────────────────────────────────────────┐
│  Hybrid Rule-Based + ML Scoring Engine          │
│                                                 │
│  lightScore  = Gaussian(lux, μ=userOptimalLux)  │
│  soundScore  = condition.productivityScore      │
│               × personalizationFactor          │
│  timeScore   = circadianRhythmModel(hour)       │
│                                                 │
│  focusScore  = 0.35×light + 0.40×sound          │
│               + 0.25×time                      │
│  sleepScore  = 0.55×lightSleep + 0.45×soundSleep│
│                                                 │
│  Incremental Learning:                          │
│   • Sample buffer (500 pts)                    │
│   • User feedback → EMA weight update          │
│   • Optimal lux/dB profile convergence         │
└─────────────────────────────────────────────────┘
    │  <200ms guaranteed
    ▼
RecommendationBloc
    │  Priority-sorted, context-aware rules
    ▼
UI (live scores, recommendations)
```

### TFLite Integration (Production)
The `MLService` includes commented hooks for a TFLite sound classifier:
```dart
// Uncomment in ml_service.dart to enable:
// _interpreter = await Interpreter.fromAsset('assets/models/sound_classifier.tflite');
// final label = await _classifySoundWithTFLite(audioBuffer);
```
Place your `.tflite` model in `assets/models/` and update `pubspec.yaml`.

---

## 🔄 BLoC Data Flow

```
SensorBloc ──────────────────────────────────────────────────────┐
    │ SensorActive(data)                                          │
    ▼                                                             │
_AppBlocBridge (in app.dart)                                      │
    │ EnvironmentAnalyzeEvent                                     │
    ▼                                                             │
EnvironmentBloc ──────────────────────────────────────────────── │
    │ EnvironmentAnalysisCompleted(analysis)                      │
    ▼                                                             │
_AppBlocBridge                                                    │
    ├──► SessionBloc.SessionUpdateMetricsEvent                    │
    └──► RecommendationBloc.RecommendationGenerateEvent           │
                                                                  │
SessionBloc ─────────────────────────────────────────────────────┘
    • Focus timer with 1-second tick
    • Sleep session tracker
    • Feedback → StorageService → pattern learning
```

---

## 🚀 Getting Started

### Prerequisites
- Flutter SDK ≥ 3.19.0
- Dart SDK ≥ 3.3.0
- Android SDK 21+ / iOS 14+

### Installation

```bash
# Clone repository
git clone https://github.com/your-org/smart_env_optimizer.git
cd smart_env_optimizer

# Install dependencies
flutter pub get

# Run code generation (Hive adapters)
dart run build_runner build --delete-conflicting-outputs

# Run on device
flutter run --release
```

### Running Tests
```bash
flutter test
```

---

## 📱 Platform Setup

### Android
Permissions are declared in `android/app/src/main/AndroidManifest.xml`:
- `RECORD_AUDIO` — microphone for dB measurement
- `CAMERA` — light estimation fallback
- `FOREGROUND_SERVICE` — background monitoring
- `POST_NOTIFICATIONS` — environment alerts

### iOS
Privacy strings in `ios/Runner/Info.plist`:
- `NSMicrophoneUsageDescription`
- `NSCameraUsageDescription`
- Background modes: `fetch`, `processing`

---

## ⚙️ Configuration

### Sensor Thresholds (`app_constants.dart`)
| Constant | Default | Description |
|----------|---------|-------------|
| `luxDark` | 50 | Dark threshold (lux) |
| `luxOptimalMin` | 300 | Optimal light minimum |
| `luxOptimalMax` | 1000 | Optimal light maximum |
| `dbSilent` | 30 | Silent environment (dB) |
| `dbBackground` | 50 | Background noise |
| `dbHighDistraction` | 85 | High distraction threshold |

### AI Weights
| Weight | Default | Factor |
|--------|---------|--------|
| `lightWeight` | 0.35 | Light contribution to focus |
| `soundWeight` | 0.40 | Sound contribution to focus |
| `timeWeight` | 0.25 | Time-of-day contribution |
| `patternLearningRate` | 0.1 | EMA learning rate |

---

## 🔒 Privacy

- ✅ **Zero audio storage** — only instantaneous dB readings
- ✅ **No cloud uploads** — all data in Hive local storage
- ✅ **No external APIs** — 100% offline operation
- ✅ **Transparent permissions** — onboarding explains each permission
- ✅ **User-controlled data** — Settings > Clear History deletes all records

---

## 📊 Local Storage Schema (Hive)

| Box | Key Type | Value | Retention |
|-----|----------|-------|-----------|
| `sessions` | Session UUID | Session record map | Indefinite |
| `sensor_logs` | Timestamp ms | Sensor reading map | Last 1000 entries |
| `user_profile` | `'current'` | Profile map | Indefinite |
| `user_preferences` | String | Mixed | Indefinite |

---

## 🧪 Testing Strategy

```
test/
├── blocs/
│   ├── sensor_bloc_test.dart        # Stream subscription, state transitions
│   ├── environment_bloc_test.dart   # ML analysis pipeline, debounce
│   ├── recommendation_bloc_test.dart # Generation, merge, dismiss
│   └── session_bloc_test.dart       # Timer, metrics, feedback
│
├── services/
│   ├── ml_service_test.dart         # Score computation, learning
│   ├── recommendation_service_test.dart # Context-aware rules
│   └── storage_service_test.dart    # CRUD, stats
│
└── widgets/
    ├── environment_score_gauge_test.dart
    └── recommendation_card_test.dart
```

---

## 🔮 Future Enhancements

- **TFLite Sound Classifier** — Replace rule-based with trained model
- **Wearable Integration** — Heart rate as proxy for cognitive state
- **Smart Light Automation** — Control smart bulbs via local LAN
- **Reinforcement Learning** — Advanced multi-arm bandit for personalization
- **Circadian Rhythm Model** — Chronotype-specific scoring profiles
- **Apple Watch / Wear OS** — Companion app for ambient HRV monitoring

---

## 📄 License

MIT License — see [LICENSE](LICENSE) for details.

---

*Built with Flutter · BLoC · Hive · TFLite · fl_chart · flutter_animate*
