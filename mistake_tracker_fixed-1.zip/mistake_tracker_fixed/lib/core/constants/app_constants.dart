// lib/core/constants/app_constants.dart

class AppConstants {
  AppConstants._();

  // App
  static const String appName = 'ErrorLog';
  static const String appVersion = '1.0.0';

  // Database
  static const String dbName = 'mistake_tracker.db';
  static const int dbVersion = 3; // v3: FTS triggers fully removed (caused INSERT crash)

  // Tables
  static const String mistakeTable = 'mistakes';
  static const String categoryTable = 'categories';
  static const String neverAgainTable = 'never_again_rules';

  // Default Categories
  static const List<String> defaultCategories = [
    'Financial',
    'Career',
    'Relationship',
    'Health',
    'Education',
    'Business',
    'Personal Discipline',
  ];

  // Similarity threshold for repeat detection (0.0 - 1.0)
  static const double similarityThreshold = 0.45;

  // Color coding thresholds
  static const int highImpactThreshold = 7;    // emotional score >= 7 = red
  static const int mediumImpactThreshold = 4;  // emotional score >= 4 = orange
                                                // else green

  // Overlay
  static const String overlayId = 'mistake_tracker_overlay';

  // Shared prefs keys
  static const String themeKey = 'theme_mode';
  static const String onboardedKey = 'onboarded';
}
