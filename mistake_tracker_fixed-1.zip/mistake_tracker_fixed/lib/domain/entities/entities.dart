// lib/domain/entities/mistake_entity.dart

class MistakeEntity {
  final int? id;
  final String title;
  final String description;
  final String category;
  final double? financialCost;
  final double? timeCostHours;
  final int emotionalScore; // 1-10
  final String lessonLearned;
  final String preventiveStrategy;
  final List<String> tags;
  final DateTime incidentDate;
  final DateTime loggedDate;
  final int repeatCount;

  const MistakeEntity({
    this.id,
    required this.title,
    required this.description,
    required this.category,
    this.financialCost,
    this.timeCostHours,
    required this.emotionalScore,
    required this.lessonLearned,
    required this.preventiveStrategy,
    required this.tags,
    required this.incidentDate,
    required this.loggedDate,
    this.repeatCount = 0,
  });

  MistakeEntity copyWith({
    int? id,
    String? title,
    String? description,
    String? category,
    double? financialCost,
    double? timeCostHours,
    int? emotionalScore,
    String? lessonLearned,
    String? preventiveStrategy,
    List<String>? tags,
    DateTime? incidentDate,
    DateTime? loggedDate,
    int? repeatCount,
  }) {
    return MistakeEntity(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      category: category ?? this.category,
      financialCost: financialCost ?? this.financialCost,
      timeCostHours: timeCostHours ?? this.timeCostHours,
      emotionalScore: emotionalScore ?? this.emotionalScore,
      lessonLearned: lessonLearned ?? this.lessonLearned,
      preventiveStrategy: preventiveStrategy ?? this.preventiveStrategy,
      tags: tags ?? this.tags,
      incidentDate: incidentDate ?? this.incidentDate,
      loggedDate: loggedDate ?? this.loggedDate,
      repeatCount: repeatCount ?? this.repeatCount,
    );
  }

  // Impact level for color coding
  ImpactLevel get impactLevel {
    if (emotionalScore >= 7) return ImpactLevel.high;
    if (emotionalScore >= 4) return ImpactLevel.medium;
    return ImpactLevel.low;
  }

  bool get hasFinancialCost => financialCost != null && financialCost! > 0;
  bool get hasTimeCost => timeCostHours != null && timeCostHours! > 0;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is MistakeEntity && runtimeType == other.runtimeType && id == other.id;

  @override
  int get hashCode => id.hashCode;
}

enum ImpactLevel { low, medium, high }

// lib/domain/entities/category_entity.dart
class CategoryEntity {
  final int? id;
  final String name;
  final bool isDefault;
  final int mistakeCount;

  const CategoryEntity({
    this.id,
    required this.name,
    this.isDefault = false,
    this.mistakeCount = 0,
  });

  CategoryEntity copyWith({
    int? id,
    String? name,
    bool? isDefault,
    int? mistakeCount,
  }) {
    return CategoryEntity(
      id: id ?? this.id,
      name: name ?? this.name,
      isDefault: isDefault ?? this.isDefault,
      mistakeCount: mistakeCount ?? this.mistakeCount,
    );
  }
}

// lib/domain/entities/never_again_rule_entity.dart
class NeverAgainRuleEntity {
  final int? id;
  final String rule;
  final String? context;
  final DateTime createdAt;
  final bool isActive;

  const NeverAgainRuleEntity({
    this.id,
    required this.rule,
    this.context,
    required this.createdAt,
    this.isActive = true,
  });

  NeverAgainRuleEntity copyWith({
    int? id,
    String? rule,
    String? context,
    DateTime? createdAt,
    bool? isActive,
  }) {
    return NeverAgainRuleEntity(
      id: id ?? this.id,
      rule: rule ?? this.rule,
      context: context ?? this.context,
      createdAt: createdAt ?? this.createdAt,
      isActive: isActive ?? this.isActive,
    );
  }
}

// lib/domain/entities/analytics_entity.dart
class AnalyticsEntity {
  final int totalMistakes;
  final String? mostCommonCategory;
  final double totalFinancialLoss;
  final double totalTimeLost;
  final double averageEmotionalImpact;
  final List<CategoryCount> categoryBreakdown;
  final List<MonthlyCount> monthlyTrend;
  final List<EmotionalPoint> emotionalTrend;
  final List<String> recurringPatterns;
  final List<MistakeEntity> topCostlyMistakes;

  const AnalyticsEntity({
    required this.totalMistakes,
    this.mostCommonCategory,
    required this.totalFinancialLoss,
    required this.totalTimeLost,
    required this.averageEmotionalImpact,
    required this.categoryBreakdown,
    required this.monthlyTrend,
    required this.emotionalTrend,
    required this.recurringPatterns,
    required this.topCostlyMistakes,
  });
}

class CategoryCount {
  final String category;
  final int count;
  CategoryCount({required this.category, required this.count});
}

class MonthlyCount {
  final String month;
  final int count;
  MonthlyCount({required this.month, required this.count});
}

class EmotionalPoint {
  final String date;
  final double avgScore;
  EmotionalPoint({required this.date, required this.avgScore});
}

// Import for MistakeEntity in AnalyticsEntity
import 'mistake_entity.dart';
