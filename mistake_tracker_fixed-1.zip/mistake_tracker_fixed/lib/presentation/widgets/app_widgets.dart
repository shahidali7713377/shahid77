// lib/presentation/widgets/app_widgets.dart

import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/constants/app_theme.dart';
import '../../domain/entities/entities.dart';

// ── IMPACT BADGE ─────────────────────────────────────────────
class ImpactBadge extends StatelessWidget {
  final ImpactLevel level;
  final int score;

  const ImpactBadge({super.key, required this.level, required this.score});

  Color get color => switch (level) {
    ImpactLevel.high => AppColors.highImpact,
    ImpactLevel.medium => AppColors.mediumImpact,
    ImpactLevel.low => AppColors.lowImpact,
  };

  String get label => switch (level) {
    ImpactLevel.high => 'HIGH',
    ImpactLevel.medium => 'MED',
    ImpactLevel.low => 'LOW',
  };

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: color.withOpacity(0.4)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 6, height: 6,
            decoration: BoxDecoration(color: color, shape: BoxShape.circle),
          ),
          const SizedBox(width: 5),
          Text(
            label,
            style: GoogleFonts.spaceGrotesk(
              fontSize: 10,
              fontWeight: FontWeight.w700,
              color: color,
              letterSpacing: 0.5,
            ),
          ),
          const SizedBox(width: 4),
          Text(
            '$score/10',
            style: GoogleFonts.spaceGrotesk(
              fontSize: 10,
              fontWeight: FontWeight.w500,
              color: color.withOpacity(0.7),
            ),
          ),
        ],
      ),
    );
  }
}

// ── MISTAKE CARD ──────────────────────────────────────────────
class MistakeCard extends StatelessWidget {
  final MistakeEntity mistake;
  final VoidCallback? onTap;
  final VoidCallback? onEdit;
  final VoidCallback? onDelete;
  final int index;

  const MistakeCard({
    super.key,
    required this.mistake,
    this.onTap,
    this.onEdit,
    this.onDelete,
    this.index = 0,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final color = switch (mistake.impactLevel) {
      ImpactLevel.high => AppColors.highImpact,
      ImpactLevel.medium => AppColors.mediumImpact,
      ImpactLevel.low => AppColors.lowImpact,
    };

    return Animate(
      effects: [
        FadeEffect(delay: Duration(milliseconds: index * 40), duration: 300.ms),
        SlideEffect(
          begin: const Offset(0, 0.08),
          end: Offset.zero,
          delay: Duration(milliseconds: index * 40),
          duration: 300.ms,
          curve: Curves.easeOut,
        ),
      ],
      child: Dismissible(
        key: Key('mistake_${mistake.id}'),
        direction: DismissDirection.endToStart,
        background: Container(
          alignment: Alignment.centerRight,
          padding: const EdgeInsets.only(right: 20),
          margin: const EdgeInsets.symmetric(vertical: 5),
          decoration: BoxDecoration(
            color: AppColors.highImpact.withOpacity(0.15),
            borderRadius: BorderRadius.circular(16),
          ),
          child: const Icon(Icons.delete_outline, color: AppColors.highImpact),
        ),
        confirmDismiss: (direction) async {
          return await showDialog<bool>(
            context: context,
            builder: (ctx) => _DeleteConfirmDialog(title: mistake.title),
          ) ?? false;
        },
        onDismissed: (_) => onDelete?.call(),
        child: GestureDetector(
          onTap: onTap,
          child: Container(
            margin: const EdgeInsets.symmetric(vertical: 5),
            decoration: BoxDecoration(
              color: isDark ? AppColors.bgCard : AppColors.bgCardLight,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: color.withOpacity(0.2),
                width: 1,
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Top colored accent strip
                Container(
                  height: 3,
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.6),
                    borderRadius: const BorderRadius.vertical(
                        top: Radius.circular(16)),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              mistake.title,
                              style: Theme.of(context).textTheme.titleMedium,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          const SizedBox(width: 8),
                          ImpactBadge(
                              level: mistake.impactLevel,
                              score: mistake.emotionalScore),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(
                        mistake.description,
                        style: Theme.of(context).textTheme.bodySmall,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          _InfoChip(
                            icon: Icons.folder_outlined,
                            label: mistake.category,
                            color: color,
                          ),
                          if (mistake.hasFinancialCost) ...[
                            const SizedBox(width: 8),
                            _InfoChip(
                              icon: Icons.currency_rupee,
                              label: _formatMoney(mistake.financialCost!),
                              color: AppColors.amber,
                            ),
                          ],
                          const Spacer(),
                          if (mistake.repeatCount > 0)
                            _RepeatBadge(count: mistake.repeatCount),
                          const SizedBox(width: 8),
                          Text(
                            _formatDate(mistake.incidentDate),
                            style: GoogleFonts.spaceGrotesk(
                              fontSize: 11,
                              color: isDark
                                  ? AppColors.textTertiary
                                  : AppColors.textSecondaryLight,
                            ),
                          ),
                        ],
                      ),
                      if (mistake.tags.isNotEmpty) ...[
                        const SizedBox(height: 10),
                        Wrap(
                          spacing: 6,
                          runSpacing: 4,
                          children: mistake.tags
                              .take(3)
                              .map((t) => _TagChip(tag: t))
                              .toList(),
                        ),
                      ],
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  String _formatMoney(double amount) {
    if (amount >= 100000) return '₹${(amount / 100000).toStringAsFixed(1)}L';
    if (amount >= 1000) return '₹${(amount / 1000).toStringAsFixed(1)}K';
    return '₹${amount.toStringAsFixed(0)}';
  }

  String _formatDate(DateTime d) {
    final months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    return '${d.day} ${months[d.month - 1]} ${d.year}';
  }
}

class _InfoChip extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;

  const _InfoChip({required this.icon, required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 11, color: color),
          const SizedBox(width: 4),
          Text(
            label,
            style: GoogleFonts.spaceGrotesk(
              fontSize: 11, fontWeight: FontWeight.w600, color: color,
            ),
          ),
        ],
      ),
    );
  }
}

class _TagChip extends StatelessWidget {
  final String tag;
  const _TagChip({required this.tag});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: AppColors.textMuted.withOpacity(0.3),
        borderRadius: BorderRadius.circular(4),
      ),
      child: Text(
        '#$tag',
        style: GoogleFonts.dmSans(
          fontSize: 11,
          color: AppColors.textSecondary,
        ),
      ),
    );
  }
}

class _RepeatBadge extends StatelessWidget {
  final int count;
  const _RepeatBadge({required this.count});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
      decoration: BoxDecoration(
        color: AppColors.crimsonDim,
        borderRadius: BorderRadius.circular(5),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.loop, size: 10, color: AppColors.crimsonLight),
          const SizedBox(width: 3),
          Text(
            '×${count + 1}',
            style: GoogleFonts.spaceGrotesk(
              fontSize: 10,
              fontWeight: FontWeight.w700,
              color: AppColors.crimsonLight,
            ),
          ),
        ],
      ),
    );
  }
}

class _DeleteConfirmDialog extends StatelessWidget {
  final String title;
  const _DeleteConfirmDialog({required this.title});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Delete Entry?'),
      content: Text('Delete "$title"? This cannot be undone.'),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context, false),
          child: const Text('Cancel'),
        ),
        TextButton(
          onPressed: () => Navigator.pop(context, true),
          style: TextButton.styleFrom(foregroundColor: AppColors.highImpact),
          child: const Text('Delete'),
        ),
      ],
    );
  }
}

// ── EMOTIONAL SCALE SLIDER ────────────────────────────────────
class EmotionalScaleSlider extends StatelessWidget {
  final int value;
  final ValueChanged<int> onChanged;

  const EmotionalScaleSlider({
    super.key,
    required this.value,
    required this.onChanged,
  });

  Color _trackColor(int v) {
    if (v >= 7) return AppColors.highImpact;
    if (v >= 4) return AppColors.mediumImpact;
    return AppColors.lowImpact;
  }

  String _emoji(int v) {
    if (v >= 8) return '🔥';
    if (v >= 6) return '😤';
    if (v >= 4) return '😞';
    if (v >= 2) return '😐';
    return '🙂';
  }

  @override
  Widget build(BuildContext context) {
    final color = _trackColor(value);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(
              'Emotional Impact',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            const Spacer(),
            Text(_emoji(value), style: const TextStyle(fontSize: 20)),
            const SizedBox(width: 8),
            Container(
              width: 36,
              height: 36,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: color.withOpacity(0.15),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: color.withOpacity(0.4)),
              ),
              child: Text(
                '$value',
                style: GoogleFonts.spaceGrotesk(
                  fontSize: 16,
                  fontWeight: FontWeight.w800,
                  color: color,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        SliderTheme(
          data: SliderThemeData(
            trackHeight: 8,
            thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 12),
            overlayShape: const RoundSliderOverlayShape(overlayRadius: 20),
            activeTrackColor: color,
            inactiveTrackColor: color.withOpacity(0.15),
            thumbColor: color,
            overlayColor: color.withOpacity(0.15),
          ),
          child: Slider(
            value: value.toDouble(),
            min: 1,
            max: 10,
            divisions: 9,
            onChanged: (v) => onChanged(v.round()),
          ),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('Low', style: Theme.of(context).textTheme.bodySmall),
            Text('Devastating', style: Theme.of(context).textTheme.bodySmall),
          ],
        ),
      ],
    );
  }
}

// ── STAT CARD ─────────────────────────────────────────────────
class StatCard extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color color;
  final String? subtitle;

  const StatCard({
    super.key,
    required this.label,
    required this.value,
    required this.icon,
    required this.color,
    this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: color.withOpacity(0.06),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: color, size: 22),
          const SizedBox(height: 12),
          Text(
            value,
            style: GoogleFonts.spaceGrotesk(
              fontSize: 24,
              fontWeight: FontWeight.w800,
              color: color,
              letterSpacing: -0.5,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            label,
            style: Theme.of(context).textTheme.labelMedium,
          ),
          if (subtitle != null)
            Text(
              subtitle!,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    fontSize: 10,
                  ),
            ),
        ],
      ),
    );
  }
}

// ── SECTION HEADER ────────────────────────────────────────────
class SectionHeader extends StatelessWidget {
  final String title;
  final Widget? trailing;

  const SectionHeader({super.key, required this.title, this.trailing});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Text(title, style: Theme.of(context).textTheme.headlineSmall),
        ),
        if (trailing != null) trailing!,
      ],
    );
  }
}

// ── EMPTY STATE ───────────────────────────────────────────────
class EmptyState extends StatelessWidget {
  final String title;
  final String subtitle;
  final String emoji;
  final Widget? action;

  const EmptyState({
    super.key,
    required this.title,
    required this.subtitle,
    this.emoji = '📭',
    this.action,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(40),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(emoji, style: const TextStyle(fontSize: 56)),
            const SizedBox(height: 20),
            Text(
              title,
              style: Theme.of(context).textTheme.headlineSmall,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(
              subtitle,
              style: Theme.of(context).textTheme.bodyMedium,
              textAlign: TextAlign.center,
            ),
            if (action != null) ...[
              const SizedBox(height: 24),
              action!,
            ],
          ],
        ),
      ),
    ).animate().fadeIn(duration: 400.ms);
  }
}

// ── SIMILAR MISTAKE ALERT ─────────────────────────────────────
class SimilarMistakeAlert extends StatelessWidget {
  final int count;
  final VoidCallback onDismiss;

  const SimilarMistakeAlert({
    super.key,
    required this.count,
    required this.onDismiss,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.amber.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.amber.withOpacity(0.4)),
      ),
      child: Row(
        children: [
          const Text('⚠️', style: TextStyle(fontSize: 24)),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Pattern Detected!',
                  style: GoogleFonts.spaceGrotesk(
                    fontWeight: FontWeight.w700,
                    color: AppColors.amberLight,
                  ),
                ),
                Text(
                  'You\'ve made a similar mistake $count time${count > 1 ? 's' : ''} before.',
                  style: GoogleFonts.dmSans(
                    fontSize: 13,
                    color: AppColors.amber,
                  ),
                ),
              ],
            ),
          ),
          IconButton(
            icon: const Icon(Icons.close, color: AppColors.amber, size: 18),
            onPressed: onDismiss,
          ),
        ],
      ),
    ).animate().shake(duration: 400.ms, hz: 3);
  }
}
