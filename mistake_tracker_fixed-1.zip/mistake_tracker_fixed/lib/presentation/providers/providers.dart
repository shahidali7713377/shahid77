// lib/presentation/providers/mistake_provider.dart

import 'package:flutter/foundation.dart';
import '../../domain/entities/entities.dart';
import '../../data/repositories/repositories.dart';

enum ViewState { idle, loading, loaded, error }

class MistakeProvider extends ChangeNotifier {
  final MistakeRepository _repo = MistakeRepository();

  ViewState _state = ViewState.idle;
  List<MistakeEntity> _mistakes = [];
  List<MistakeEntity> _searchResults = [];
  List<MistakeEntity>? _similarMistakes; // null = no check done, [] = no matches
  String? _errorMessage;
  bool _isSearching = false;

  // Filters
  String? _filterCategory;
  String _sortBy = 'logged_date';
  bool _sortDescending = true;
  DateTime? _filterStartDate;
  DateTime? _filterEndDate;
  int? _filterMinEmotional;
  int? _filterMaxEmotional;

  // Getters
  ViewState get state => _state;
  List<MistakeEntity> get mistakes => _isSearching ? _searchResults : _mistakes;
  List<MistakeEntity>? get similarMistakes => _similarMistakes;
  String? get errorMessage => _errorMessage;
  bool get isSearching => _isSearching;
  String? get filterCategory => _filterCategory;
  String get sortBy => _sortBy;
  bool get sortDescending => _sortDescending;

  Future<void> loadMistakes() async {
    _state = ViewState.loading;
    notifyListeners();
    try {
      _mistakes = await _repo.getAllMistakes(
        category: _filterCategory,
        startDate: _filterStartDate,
        endDate: _filterEndDate,
        minEmotional: _filterMinEmotional,
        maxEmotional: _filterMaxEmotional,
        sortBy: _sortBy,
        descending: _sortDescending,
      );
      _state = ViewState.loaded;
    } catch (e) {
      _state = ViewState.error;
      _errorMessage = e.toString();
    }
    notifyListeners();
  }

  Future<void> search(String query) async {
    if (query.trim().isEmpty) {
      _isSearching = false;
      _searchResults = [];
      notifyListeners();
      return;
    }
    _isSearching = true;
    _searchResults = await _repo.searchMistakes(query);
    notifyListeners();
  }

  void clearSearch() {
    _isSearching = false;
    _searchResults = [];
    notifyListeners();
  }

  Future<bool> addMistake(MistakeEntity entity) async {
    try {
      // Check similarity before insert
      final similar = await _repo.findSimilarMistakes(entity.title, entity.description);
      _similarMistakes = similar;

      await _repo.insertMistake(entity);
      await loadMistakes();
      return true;
    } catch (e) {
      _errorMessage = e.toString();
      notifyListeners();
      return false;
    }
  }

  Future<bool> updateMistake(MistakeEntity entity) async {
    try {
      await _repo.updateMistake(entity);
      await loadMistakes();
      return true;
    } catch (e) {
      _errorMessage = e.toString();
      notifyListeners();
      return false;
    }
  }

  Future<bool> deleteMistake(int id) async {
    try {
      await _repo.deleteMistake(id);
      await loadMistakes();
      return true;
    } catch (e) {
      _errorMessage = e.toString();
      notifyListeners();
      return false;
    }
  }

  Future<List<MistakeEntity>> checkSimilarity(String title, String desc) async {
    return await _repo.findSimilarMistakes(title, desc);
  }

  void clearSimilarityResult() {
    _similarMistakes = null;
    notifyListeners();
  }

  // Filters
  void setFilter({
    String? category,
    DateTime? startDate,
    DateTime? endDate,
    int? minEmotional,
    int? maxEmotional,
  }) {
    _filterCategory = category;
    _filterStartDate = startDate;
    _filterEndDate = endDate;
    _filterMinEmotional = minEmotional;
    _filterMaxEmotional = maxEmotional;
    loadMistakes();
  }

  void setSorting(String field, bool descending) {
    _sortBy = field;
    _sortDescending = descending;
    loadMistakes();
  }

  void clearFilters() {
    _filterCategory = null;
    _filterStartDate = null;
    _filterEndDate = null;
    _filterMinEmotional = null;
    _filterMaxEmotional = null;
    loadMistakes();
  }

  Future<String> exportCSV() => _repo.exportToCSV();
}

// lib/presentation/providers/analytics_provider.dart
class AnalyticsProvider extends ChangeNotifier {
  final MistakeRepository _repo = MistakeRepository();

  ViewState _state = ViewState.idle;
  AnalyticsEntity? _analytics;

  ViewState get state => _state;
  AnalyticsEntity? get analytics => _analytics;

  Future<void> loadAnalytics() async {
    _state = ViewState.loading;
    notifyListeners();
    try {
      _analytics = await _repo.getAnalytics();
      _state = ViewState.loaded;
    } catch (e) {
      _state = ViewState.error;
    }
    notifyListeners();
  }
}

// lib/presentation/providers/category_provider.dart
class CategoryProvider extends ChangeNotifier {
  final CategoryRepository _repo = CategoryRepository();

  List<CategoryEntity> _categories = [];
  List<CategoryEntity> get categories => _categories;
  List<String> get categoryNames => _categories.map((c) => c.name).toList();

  Future<void> loadCategories() async {
    _categories = await _repo.getAllCategories();
    notifyListeners();
  }

  Future<void> addCategory(String name) async {
    await _repo.insertCategory(name);
    await loadCategories();
  }

  Future<void> updateCategory(int id, String newName) async {
    await _repo.updateCategory(id, newName);
    await loadCategories();
  }

  Future<void> deleteCategory(int id) async {
    await _repo.deleteCategory(id);
    await loadCategories();
  }

  Future<void> mergeCategories(String from, String to) async {
    await _repo.mergeCategories(from, to);
    await loadCategories();
  }
}

// lib/presentation/providers/never_again_provider.dart
class NeverAgainProvider extends ChangeNotifier {
  final NeverAgainRepository _repo = NeverAgainRepository();

  List<NeverAgainRuleEntity> _rules = [];
  List<NeverAgainRuleEntity> get rules => _rules;
  List<NeverAgainRuleEntity> get activeRules => _rules.where((r) => r.isActive).toList();

  Future<void> loadRules() async {
    _rules = await _repo.getAllRules();
    notifyListeners();
  }

  Future<void> addRule(String rule, {String? context}) async {
    await _repo.insertRule(NeverAgainRuleEntity(
      rule: rule,
      context: context,
      createdAt: DateTime.now(),
    ));
    await loadRules();
  }

  Future<void> deleteRule(int id) async {
    await _repo.deleteRule(id);
    await loadRules();
  }

  Future<void> toggleRule(int id, bool isActive) async {
    await _repo.toggleRule(id, isActive);
    await loadRules();
  }
}

// lib/presentation/providers/theme_provider.dart
class ThemeProvider extends ChangeNotifier {
  bool _isDark = true;
  bool get isDark => _isDark;

  void toggleTheme() {
    _isDark = !_isDark;
    notifyListeners();
  }

  void setDark(bool dark) {
    _isDark = dark;
    notifyListeners();
  }
}

// lib/presentation/providers/overlay_provider.dart

import 'package:flutter/services.dart';

class OverlayProvider extends ChangeNotifier {
  bool _hasPermission = false;
  bool _isOverlayShowing = false;
  String? _errorMessage;

  bool get hasPermission => _hasPermission;
  bool get isOverlayShowing => _isOverlayShowing;
  String? get errorMessage => _errorMessage;

  static const _channel = MethodChannel('mistake_tracker/overlay');

  Future<void> checkPermission() async {
    try {
      final granted = await _channel.invokeMethod<bool>('checkOverlayPermission');
      _hasPermission = granted ?? false;
      _errorMessage = null;
    } on MissingPluginException {
      _hasPermission = false;
      _errorMessage = 'Overlay not supported on this platform.';
    } catch (e) {
      _hasPermission = false;
      _errorMessage = e.toString();
    }

    // Also sync overlay running state
    await _syncOverlayState();
    notifyListeners();
  }

  Future<void> _syncOverlayState() async {
    try {
      final showing = await _channel.invokeMethod<bool>('isOverlayShowing');
      _isOverlayShowing = showing ?? false;
    } catch (_) {
      _isOverlayShowing = false;
    }
  }

  Future<void> requestPermission() async {
    try {
      final granted = await _channel.invokeMethod<bool>('requestOverlayPermission');
      _hasPermission = granted ?? false;
      _errorMessage = null;
    } on MissingPluginException {
      _errorMessage = 'Overlay not supported on this platform.';
    } catch (e) {
      _errorMessage = e.toString();
    }
    notifyListeners();
  }

  Future<void> showOverlay() async {
    if (!_hasPermission) {
      await requestPermission();
      if (!_hasPermission) return;
    }
    try {
      await _channel.invokeMethod('showOverlay');
      _isOverlayShowing = true;
      _errorMessage = null;
    } on PlatformException catch (e) {
      _errorMessage = e.message;
    } catch (e) {
      _errorMessage = e.toString();
    }
    notifyListeners();
  }

  Future<void> hideOverlay() async {
    try {
      await _channel.invokeMethod('hideOverlay');
      _isOverlayShowing = false;
      _errorMessage = null;
    } catch (_) {}
    notifyListeners();
  }
}
