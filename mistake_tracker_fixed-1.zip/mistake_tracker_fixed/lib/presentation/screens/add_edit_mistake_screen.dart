// lib/presentation/screens/add_edit_mistake_screen.dart

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_theme.dart';
import '../../domain/entities/entities.dart';
import '../providers/providers.dart';
import '../widgets/app_widgets.dart';

class AddEditMistakeScreen extends StatefulWidget {
  final MistakeEntity? mistake;

  const AddEditMistakeScreen({super.key, this.mistake});

  @override
  State<AddEditMistakeScreen> createState() => _AddEditMistakeScreenState();
}

class _AddEditMistakeScreenState extends State<AddEditMistakeScreen> {
  final _formKey = GlobalKey<FormState>();
  final _scrollController = ScrollController();

  late TextEditingController _titleCtrl;
  late TextEditingController _descCtrl;
  late TextEditingController _lessonCtrl;
  late TextEditingController _preventCtrl;
  late TextEditingController _financialCtrl;
  late TextEditingController _timeCtrl;
  late TextEditingController _tagCtrl;

  String _selectedCategory = 'Personal Discipline';
  int _emotionalScore = 5;
  DateTime _incidentDate = DateTime.now();
  List<String> _tags = [];
  List<MistakeEntity> _similarMistakes = [];
  bool _showSimilarAlert = false;
  bool _isSaving = false;
  Timer? _debounceTimer; // perf: debounce similarity checks

  bool get isEditing => widget.mistake != null;

  @override
  void initState() {
    super.initState();
    final m = widget.mistake;
    _titleCtrl = TextEditingController(text: m?.title ?? '');
    _descCtrl = TextEditingController(text: m?.description ?? '');
    _lessonCtrl = TextEditingController(text: m?.lessonLearned ?? '');
    _preventCtrl = TextEditingController(text: m?.preventiveStrategy ?? '');
    _financialCtrl = TextEditingController(
        text: m?.financialCost?.toStringAsFixed(0) ?? '');
    _timeCtrl = TextEditingController(
        text: m?.timeCostHours?.toStringAsFixed(1) ?? '');
    _tagCtrl = TextEditingController();

    if (m != null) {
      _selectedCategory = m.category;
      _emotionalScore = m.emotionalScore;
      _incidentDate = m.incidentDate;
      _tags = List.from(m.tags);
    }

    // Similarity check on title/desc change
    _titleCtrl.addListener(_checkSimilarity);
    _descCtrl.addListener(_checkSimilarity);
  }

  @override
  void dispose() {
    _debounceTimer?.cancel();
    _titleCtrl.dispose();
    _descCtrl.dispose();
    _lessonCtrl.dispose();
    _preventCtrl.dispose();
    _financialCtrl.dispose();
    _timeCtrl.dispose();
    _tagCtrl.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _checkSimilarity() {
    if (isEditing) return;
    if (_titleCtrl.text.length < 5) return;

    // Debounce: only run the (potentially slow) similarity query after
    // the user pauses typing for 600 ms, keeping the UI thread smooth.
    _debounceTimer?.cancel();
    _debounceTimer = Timer(const Duration(milliseconds: 600), () async {
      final provider = context.read<MistakeProvider>();
      final similar = await provider.checkSimilarity(
          _titleCtrl.text, _descCtrl.text);
      if (mounted) {
        setState(() {
          _similarMistakes = similar;
          _showSimilarAlert = similar.isNotEmpty;
        });
      }
    });
  }

  Future<void> _pickDate() async {
    final d = await showDatePicker(
      context: context,
      initialDate: _incidentDate,
      firstDate: DateTime(2000),
      lastDate: DateTime.now(),
      builder: (ctx, child) => Theme(
        data: Theme.of(ctx).copyWith(
          colorScheme: Theme.of(ctx).colorScheme.copyWith(
            primary: AppColors.crimson,
          ),
        ),
        child: child!,
      ),
    );
    if (d != null) setState(() => _incidentDate = d);
  }

  void _addTag() {
    final tag = _tagCtrl.text.trim().toLowerCase();
    if (tag.isEmpty || _tags.contains(tag)) return;
    setState(() {
      _tags.add(tag);
      _tagCtrl.clear();
    });
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isSaving = true);

    final entity = MistakeEntity(
      id: widget.mistake?.id,
      title: _titleCtrl.text.trim(),
      description: _descCtrl.text.trim(),
      category: _selectedCategory,
      financialCost: double.tryParse(_financialCtrl.text),
      timeCostHours: double.tryParse(_timeCtrl.text),
      emotionalScore: _emotionalScore,
      lessonLearned: _lessonCtrl.text.trim(),
      preventiveStrategy: _preventCtrl.text.trim(),
      tags: _tags,
      incidentDate: _incidentDate,
      loggedDate: widget.mistake?.loggedDate ?? DateTime.now(),
      repeatCount: widget.mistake?.repeatCount ?? 0,
    );

    final provider = context.read<MistakeProvider>();
    final success = isEditing
        ? await provider.updateMistake(entity)
        : await provider.addMistake(entity);

    if (mounted) {
      setState(() => _isSaving = false);
      if (success) {
        HapticFeedback.lightImpact();
        Navigator.pop(context, true);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(provider.errorMessage ?? 'Error saving')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final categories = context.watch<CategoryProvider>().categoryNames;

    return Scaffold(
      backgroundColor:
          isDark ? AppColors.bg : AppColors.bgLight,
      body: CustomScrollView(
        controller: _scrollController,
        slivers: [
          // App bar
          SliverAppBar(
            pinned: true,
            expandedHeight: 100,
            backgroundColor: isDark ? AppColors.bg : AppColors.bgLight,
            leading: IconButton(
              icon: const Icon(Icons.arrow_back_ios_new, size: 20),
              onPressed: () => Navigator.pop(context),
            ),
            flexibleSpace: FlexibleSpaceBar(
              titlePadding: const EdgeInsets.only(left: 60, bottom: 16),
              title: Text(
                isEditing ? 'Edit Entry' : 'Log Mistake',
                style: GoogleFonts.spaceGrotesk(
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            actions: [
              if (_isSaving)
                const Padding(
                  padding: EdgeInsets.all(16),
                  child: SizedBox(
                    width: 20, height: 20,
                    child: CircularProgressIndicator(
                      strokeWidth: 2, color: AppColors.crimson,
                    ),
                  ),
                )
              else
                TextButton(
                  onPressed: _save,
                  child: Text(
                    isEditing ? 'Update' : 'Save',
                    style: GoogleFonts.spaceGrotesk(
                      color: AppColors.crimson,
                      fontWeight: FontWeight.w700,
                      fontSize: 15,
                    ),
                  ),
                ),
            ],
          ),

          // Form
          SliverPadding(
            padding: const EdgeInsets.all(20),
            sliver: SliverList(
              delegate: SliverChildListDelegate([
                Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Similarity alert
                      if (_showSimilarAlert) ...[
                        SimilarMistakeAlert(
                          count: _similarMistakes.length,
                          onDismiss: () =>
                              setState(() => _showSimilarAlert = false),
                        ),
                        const SizedBox(height: 16),
                      ],

                      // Title
                      _FormSection(
                        label: 'TITLE',
                        child: TextFormField(
                          controller: _titleCtrl,
                          style: GoogleFonts.spaceGrotesk(
                            fontSize: 16, fontWeight: FontWeight.w600,
                          ),
                          decoration: const InputDecoration(
                            hintText: 'What happened?',
                          ),
                          validator: (v) => v == null || v.trim().isEmpty
                              ? 'Title is required'
                              : null,
                          textCapitalization: TextCapitalization.sentences,
                        ),
                      ),

                      const SizedBox(height: 20),

                      // Description
                      _FormSection(
                        label: 'DESCRIPTION',
                        child: TextFormField(
                          controller: _descCtrl,
                          maxLines: 4,
                          style: GoogleFonts.dmSans(fontSize: 15),
                          decoration: const InputDecoration(
                            hintText: 'Describe what happened in detail...',
                            alignLabelWithHint: true,
                          ),
                          validator: (v) => v == null || v.trim().isEmpty
                              ? 'Description is required'
                              : null,
                          textCapitalization: TextCapitalization.sentences,
                        ),
                      ),

                      const SizedBox(height: 20),

                      // Category & Date Row
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: _FormSection(
                              label: 'CATEGORY',
                              child: _CategoryDropdown(
                                value: _selectedCategory,
                                categories: categories,
                                onChanged: (v) =>
                                    setState(() => _selectedCategory = v!),
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: _FormSection(
                              label: 'DATE',
                              child: GestureDetector(
                                onTap: _pickDate,
                                child: Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 16, vertical: 15),
                                  decoration: BoxDecoration(
                                    color: isDark
                                        ? AppColors.bgSurface
                                        : AppColors.bgSurfaceLight,
                                    borderRadius: BorderRadius.circular(12),
                                    border: Border.all(
                                      color: isDark
                                          ? AppColors.border
                                          : AppColors.borderLight2,
                                    ),
                                  ),
                                  child: Row(
                                    children: [
                                      const Icon(Icons.calendar_today_outlined,
                                          size: 16, color: AppColors.crimson),
                                      const SizedBox(width: 8),
                                      Expanded(
                                        child: Text(
                                          _formatDate(_incidentDate),
                                          style: GoogleFonts.spaceGrotesk(
                                            fontSize: 13,
                                            fontWeight: FontWeight.w600,
                                          ),
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 20),

                      // Emotional Score
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: isDark ? AppColors.bgCard : AppColors.bgCardLight,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: isDark
                                ? AppColors.border
                                : AppColors.borderLight2,
                          ),
                        ),
                        child: EmotionalScaleSlider(
                          value: _emotionalScore,
                          onChanged: (v) =>
                              setState(() => _emotionalScore = v),
                        ),
                      ),

                      const SizedBox(height: 20),

                      // Cost section
                      Row(
                        children: [
                          Expanded(
                            child: _FormSection(
                              label: 'FINANCIAL COST (₹)',
                              child: TextFormField(
                                controller: _financialCtrl,
                                keyboardType: TextInputType.number,
                                decoration: const InputDecoration(
                                  hintText: '0.00',
                                  prefixText: '₹ ',
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: _FormSection(
                              label: 'TIME COST (HOURS)',
                              child: TextFormField(
                                controller: _timeCtrl,
                                keyboardType: TextInputType.number,
                                decoration: const InputDecoration(
                                  hintText: '0.0',
                                  suffixText: 'hrs',
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 20),

                      // Lesson Learned
                      _FormSection(
                        label: '💡 LESSON LEARNED',
                        child: TextFormField(
                          controller: _lessonCtrl,
                          maxLines: 3,
                          style: GoogleFonts.dmSans(fontSize: 15),
                          decoration: const InputDecoration(
                            hintText: 'What did you learn from this?',
                          ),
                          textCapitalization: TextCapitalization.sentences,
                        ),
                      ),

                      const SizedBox(height: 20),

                      // Preventive Strategy
                      _FormSection(
                        label: '🛡️ WHAT I SHOULD HAVE DONE',
                        child: TextFormField(
                          controller: _preventCtrl,
                          maxLines: 3,
                          style: GoogleFonts.dmSans(fontSize: 15),
                          decoration: const InputDecoration(
                            hintText: 'What preventive action would help?',
                          ),
                          textCapitalization: TextCapitalization.sentences,
                        ),
                      ),

                      const SizedBox(height: 20),

                      // Tags
                      _FormSection(
                        label: 'TAGS',
                        child: Column(
                          children: [
                            Row(
                              children: [
                                Expanded(
                                  child: TextFormField(
                                    controller: _tagCtrl,
                                    decoration: const InputDecoration(
                                      hintText: 'Add tag...',
                                      prefixText: '# ',
                                    ),
                                    onFieldSubmitted: (_) => _addTag(),
                                    textCapitalization: TextCapitalization.none,
                                  ),
                                ),
                                const SizedBox(width: 8),
                                IconButton.filled(
                                  onPressed: _addTag,
                                  icon: const Icon(Icons.add),
                                  style: IconButton.styleFrom(
                                    backgroundColor: AppColors.crimson,
                                    foregroundColor: Colors.white,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            if (_tags.isNotEmpty) ...[
                              const SizedBox(height: 10),
                              Wrap(
                                spacing: 8,
                                runSpacing: 8,
                                children: _tags
                                    .map((t) => Chip(
                                          label: Text('#$t',
                                              style: const TextStyle(
                                                  fontSize: 12)),
                                          deleteIcon: const Icon(Icons.close,
                                              size: 14),
                                          onDeleted: () => setState(
                                              () => _tags.remove(t)),
                                          side: BorderSide.none,
                                          backgroundColor:
                                              AppColors.bgSurface,
                                        ))
                                    .toList(),
                              ),
                            ],
                          ],
                        ),
                      ),

                      const SizedBox(height: 32),

                      // Save button
                      SizedBox(
                        width: double.infinity,
                        height: 52,
                        child: ElevatedButton(
                          onPressed: _isSaving ? null : _save,
                          child: Text(
                            isEditing ? 'Update Entry' : 'Save to Database',
                          ),
                        ),
                      ),

                      const SizedBox(height: 40),
                    ],
                  ),
                ),
              ]),
            ),
          ),
        ],
      ),
    );
  }

  String _formatDate(DateTime d) {
    final months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    return '${d.day} ${months[d.month-1]} ${d.year}';
  }
}

class _FormSection extends StatelessWidget {
  final String label;
  final Widget child;

  const _FormSection({required this.label, required this.child});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: GoogleFonts.spaceGrotesk(
            fontSize: 10,
            fontWeight: FontWeight.w700,
            color: AppColors.textTertiary,
            letterSpacing: 1.2,
          ),
        ),
        const SizedBox(height: 8),
        child,
      ],
    );
  }
}

class _CategoryDropdown extends StatelessWidget {
  final String value;
  final List<String> categories;
  final ValueChanged<String?> onChanged;

  const _CategoryDropdown({
    required this.value,
    required this.categories,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final effective = categories.contains(value) ? value : (categories.isNotEmpty ? categories.first : value);

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(
        color: isDark ? AppColors.bgSurface : AppColors.bgSurfaceLight,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isDark ? AppColors.border : AppColors.borderLight2,
        ),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: effective,
          isExpanded: true,
          dropdownColor: isDark ? AppColors.bgElevated : Colors.white,
          items: categories
              .map((c) => DropdownMenuItem(value: c, child: Text(c, overflow: TextOverflow.ellipsis)))
              .toList(),
          onChanged: onChanged,
          style: GoogleFonts.spaceGrotesk(
            fontSize: 13,
            fontWeight: FontWeight.w600,
            color: isDark ? AppColors.textPrimary : AppColors.textPrimaryLight,
          ),
        ),
      ),
    );
  }
}
