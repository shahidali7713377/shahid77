// lib/presentation/screens/mistake_detail_screen.dart

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_theme.dart';
import '../../domain/entities/entities.dart';
import '../providers/providers.dart';
import '../widgets/app_widgets.dart';
import 'add_edit_mistake_screen.dart';

class MistakeDetailScreen extends StatelessWidget {
  final MistakeEntity mistake;

  const MistakeDetailScreen({super.key, required this.mistake});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final color = switch (mistake.impactLevel) {
      ImpactLevel.high => AppColors.highImpact,
      ImpactLevel.medium => AppColors.mediumImpact,
      ImpactLevel.low => AppColors.lowImpact,
    };

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 200,
            pinned: true,
            leading: IconButton(
              icon: const Icon(Icons.arrow_back_ios_new, size: 20),
              onPressed: () => Navigator.pop(context),
            ),
            actions: [
              IconButton(
                icon: const Icon(Icons.edit_outlined),
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => AddEditMistakeScreen(mistake: mistake),
                  ),
                ),
              ),
              IconButton(
                icon: const Icon(Icons.delete_outline, color: AppColors.crimson),
                onPressed: () async {
                  final confirmed = await showDialog<bool>(
                    context: context,
                    builder: (_) =>
                        AlertDialog(
                          title: const Text('Delete Entry?'),
                          content: const Text(
                              'This cannot be undone.'),
                          actions: [
                            TextButton(
                                onPressed: () =>
                                    Navigator.pop(context, false),
                                child: const Text('Cancel')),
                            TextButton(
                              onPressed: () =>
                                  Navigator.pop(context, true),
                              style: TextButton.styleFrom(
                                  foregroundColor: AppColors.crimson),
                              child: const Text('Delete'),
                            ),
                          ],
                        ),
                  );
                  if (confirmed == true && context.mounted) {
                    await context
                        .read<MistakeProvider>()
                        .deleteMistake(mistake.id!);
                    if (context.mounted) Navigator.pop(context);
                  }
                },
              ),
            ],
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      color.withOpacity(0.15),
                      isDark ? AppColors.bg : AppColors.bgLight,
                    ],
                  ),
                ),
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 100, 20, 20),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      ImpactBadge(
                          level: mistake.impactLevel,
                          score: mistake.emotionalScore),
                      const SizedBox(height: 8),
                      Text(
                        mistake.title,
                        style: GoogleFonts.spaceGrotesk(
                          fontSize: 24,
                          fontWeight: FontWeight.w800,
                          letterSpacing: -0.5,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),

          SliverPadding(
            padding: const EdgeInsets.all(20),
            sliver: SliverList(
              delegate: SliverChildListDelegate([
                // Meta info
                _MetaRow(mistake: mistake),
                const SizedBox(height: 24),

                // Description
                if (mistake.description.isNotEmpty) ...[
                  _DetailSection(
                    emoji: '📝',
                    title: 'What Happened',
                    content: mistake.description,
                  ),
                  const SizedBox(height: 16),
                ],

                // Lesson
                if (mistake.lessonLearned.isNotEmpty) ...[
                  _DetailSection(
                    emoji: '💡',
                    title: 'Lesson Learned',
                    content: mistake.lessonLearned,
                    highlight: true,
                  ),
                  const SizedBox(height: 16),
                ],

                // Preventive
                if (mistake.preventiveStrategy.isNotEmpty) ...[
                  _DetailSection(
                    emoji: '🛡️',
                    title: 'Preventive Strategy',
                    content: mistake.preventiveStrategy,
                  ),
                  const SizedBox(height: 16),
                ],

                // Cost Breakdown
                _CostBreakdown(mistake: mistake),
                const SizedBox(height: 16),

                // Tags
                if (mistake.tags.isNotEmpty) ...[
                  Text('Tags', style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 6,
                    children: mistake.tags
                        .map((t) => Chip(
                              label: Text('#$t'),
                              side: BorderSide.none,
                              backgroundColor:
                                  isDark ? AppColors.bgSurface : AppColors.bgSurfaceLight,
                            ))
                        .toList(),
                  ),
                  const SizedBox(height: 16),
                ],

                // Repeat info
                if (mistake.repeatCount > 0)
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: AppColors.crimsonDim.withOpacity(0.3),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                          color: AppColors.crimson.withOpacity(0.3)),
                    ),
                    child: Row(
                      children: [
                        const Text('🔁',
                            style: TextStyle(fontSize: 24)),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Recurring Pattern',
                                style: GoogleFonts.spaceGrotesk(
                                  fontWeight: FontWeight.w700,
                                  color: AppColors.crimsonLight,
                                ),
                              ),
                              Text(
                                'This pattern has appeared ${mistake.repeatCount + 1} times total.',
                                style: GoogleFonts.dmSans(
                                  fontSize: 13,
                                  color: AppColors.crimson,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                const SizedBox(height: 40),
              ]),
            ),
          ),
        ],
      ),
    );
  }
}

class _MetaRow extends StatelessWidget {
  final MistakeEntity mistake;

  const _MetaRow({required this.mistake});

  @override
  Widget build(BuildContext context) {
    final months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    final date = '${mistake.incidentDate.day} ${months[mistake.incidentDate.month-1]} ${mistake.incidentDate.year}';
    final logged = '${mistake.loggedDate.day} ${months[mistake.loggedDate.month-1]}';

    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        _MetaChip(icon: Icons.folder_outlined, label: mistake.category),
        _MetaChip(icon: Icons.event, label: date),
        _MetaChip(icon: Icons.edit_calendar, label: 'Logged $logged'),
        if (mistake.repeatCount > 0)
          _MetaChip(
            icon: Icons.loop,
            label: '×${mistake.repeatCount + 1}',
            color: AppColors.crimson,
          ),
      ],
    );
  }
}

class _MetaChip extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color? color;

  const _MetaChip({required this.icon, required this.label, this.color});

  @override
  Widget build(BuildContext context) {
    final c = color ?? AppColors.textSecondary;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: c.withOpacity(0.08),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: c.withOpacity(0.2)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 13, color: c),
          const SizedBox(width: 5),
          Text(
            label,
            style: GoogleFonts.spaceGrotesk(
              fontSize: 12,
              fontWeight: FontWeight.w600,
              color: c,
            ),
          ),
        ],
      ),
    );
  }
}

class _DetailSection extends StatelessWidget {
  final String emoji;
  final String title;
  final String content;
  final bool highlight;

  const _DetailSection({
    required this.emoji,
    required this.title,
    required this.content,
    this.highlight = false,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: highlight
            ? AppColors.emerald.withOpacity(0.06)
            : (isDark ? AppColors.bgCard : AppColors.bgCardLight),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: highlight
              ? AppColors.emerald.withOpacity(0.25)
              : (isDark ? AppColors.border : AppColors.borderLight2),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(emoji, style: const TextStyle(fontSize: 18)),
              const SizedBox(width: 8),
              Text(title, style: Theme.of(context).textTheme.titleMedium),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            content,
            style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                  color: highlight ? AppColors.emeraldLight : null,
                  height: 1.6,
                ),
          ),
        ],
      ),
    );
  }
}

class _CostBreakdown extends StatelessWidget {
  final MistakeEntity mistake;

  const _CostBreakdown({required this.mistake});

  @override
  Widget build(BuildContext context) {
    if (!mistake.hasFinancialCost && !mistake.hasTimeCost) {
      return const SizedBox.shrink();
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Cost Breakdown', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 10),
        Row(
          children: [
            if (mistake.hasFinancialCost)
              Expanded(
                child: StatCard(
                  label: 'Financial',
                  value: '₹${mistake.financialCost!.toStringAsFixed(0)}',
                  icon: Icons.currency_rupee,
                  color: AppColors.amber,
                ),
              ),
            if (mistake.hasFinancialCost && mistake.hasTimeCost)
              const SizedBox(width: 12),
            if (mistake.hasTimeCost)
              Expanded(
                child: StatCard(
                  label: 'Time Lost',
                  value: '${mistake.timeCostHours!.toStringAsFixed(1)}h',
                  icon: Icons.access_time,
                  color: AppColors.lowImpact,
                ),
              ),
          ],
        ),
      ],
    );
  }
}
