// lib/presentation/screens/home_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_theme.dart';
import '../../domain/entities/entities.dart';
import '../providers/providers.dart';
import '../widgets/app_widgets.dart';
import 'add_edit_mistake_screen.dart';
import 'mistake_detail_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _searchCtrl = TextEditingController();
  bool _showSearch = false;
  String _selectedSort = 'logged_date';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<MistakeProvider>().loadMistakes();
    });
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          // Custom App Bar
          SliverAppBar(
            pinned: true,
            expandedHeight: 120,
            backgroundColor: isDark ? AppColors.bg : AppColors.bgLight,
            flexibleSpace: FlexibleSpaceBar(
              titlePadding: const EdgeInsets.only(left: 20, bottom: 16, right: 20),
              title: _showSearch
                  ? _SearchField(
                      controller: _searchCtrl,
                      onSearch: (q) =>
                          context.read<MistakeProvider>().search(q),
                      onClose: () {
                        setState(() => _showSearch = false);
                        _searchCtrl.clear();
                        context.read<MistakeProvider>().clearSearch();
                      },
                    )
                  : Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '⚠ ErrorLog',
                          style: GoogleFonts.spaceGrotesk(
                            fontSize: 22,
                            fontWeight: FontWeight.w800,
                            color: AppColors.crimson,
                            letterSpacing: -0.5,
                          ),
                        ),
                        Text(
                          'Mistakes are data.',
                          style: GoogleFonts.dmSans(
                            fontSize: 12,
                            color: isDark
                                ? AppColors.textTertiary
                                : AppColors.textSecondaryLight,
                          ),
                        ),
                      ],
                    ),
            ),
            actions: [
              if (!_showSearch)
                IconButton(
                  icon: const Icon(Icons.search),
                  onPressed: () => setState(() => _showSearch = true),
                ),
              IconButton(
                icon: const Icon(Icons.sort),
                onPressed: () => _showSortSheet(context),
              ),
              IconButton(
                icon: const Icon(Icons.filter_alt_outlined),
                onPressed: () => _showFilterSheet(context),
              ),
            ],
          ),

          // Content
          Consumer<MistakeProvider>(
            builder: (context, provider, _) {
              if (provider.state == ViewState.loading) {
                return const SliverFillRemaining(
                  child: Center(
                    child: CircularProgressIndicator(color: AppColors.crimson),
                  ),
                );
              }

              final mistakes = provider.mistakes;

              if (mistakes.isEmpty) {
                return SliverFillRemaining(
                  child: EmptyState(
                    title: provider.isSearching
                        ? 'No results found'
                        : 'Your database is empty',
                    subtitle: provider.isSearching
                        ? 'Try different keywords'
                        : 'Start logging mistakes to build your\nLife Lessons Database',
                    emoji: provider.isSearching ? '🔍' : '📓',
                    action: provider.isSearching
                        ? null
                        : ElevatedButton.icon(
                            onPressed: () => _openAddScreen(context),
                            icon: const Icon(Icons.add),
                            label: const Text('Log First Mistake'),
                          ),
                  ),
                );
              }

              return SliverPadding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
                sliver: SliverList(
                  delegate: SliverChildBuilderDelegate(
                    (context, index) {
                      final mistake = mistakes[index];
                      return MistakeCard(
                        mistake: mistake,
                        index: index,
                        onTap: () => _openDetail(context, mistake),
                        onEdit: () => _openEditScreen(context, mistake),
                        onDelete: () => context
                            .read<MistakeProvider>()
                            .deleteMistake(mistake.id!),
                      );
                    },
                    childCount: mistakes.length,
                  ),
                ),
              );
            },
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openAddScreen(context),
        backgroundColor: AppColors.crimson,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add),
        label: Text(
          'Log Mistake',
          style: GoogleFonts.spaceGrotesk(fontWeight: FontWeight.w700),
        ),
      ).animate().scale(delay: 300.ms, duration: 300.ms, curve: Curves.elasticOut),
    );
  }

  Future<void> _openAddScreen(BuildContext context) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const AddEditMistakeScreen()),
    );
    if (result == true && mounted) {
      HapticFeedback.lightImpact();
    }
  }

  Future<void> _openEditScreen(BuildContext context, MistakeEntity m) async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => AddEditMistakeScreen(mistake: m)),
    );
  }

  Future<void> _openDetail(BuildContext context, MistakeEntity m) async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => MistakeDetailScreen(mistake: m)),
    );
  }

  void _showSortSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (_) => _SortSheet(
        current: _selectedSort,
        onSelect: (sort, desc) {
          setState(() => _selectedSort = sort);
          context.read<MistakeProvider>().setSorting(sort, desc);
        },
      ),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
    );
  }

  void _showFilterSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => _FilterSheet(),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
    );
  }
}

class _SearchField extends StatelessWidget {
  final TextEditingController controller;
  final ValueChanged<String> onSearch;
  final VoidCallback onClose;

  const _SearchField({
    required this.controller,
    required this.onSearch,
    required this.onClose,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: TextField(
            controller: controller,
            autofocus: true,
            onChanged: onSearch,
            style: GoogleFonts.dmSans(fontSize: 15),
            decoration: InputDecoration(
              hintText: 'Search lessons, titles, tags...',
              hintStyle: GoogleFonts.dmSans(fontSize: 14),
              border: InputBorder.none,
              isDense: true,
              contentPadding: EdgeInsets.zero,
            ),
          ),
        ),
        IconButton(
          icon: const Icon(Icons.close, size: 20),
          onPressed: onClose,
        ),
      ],
    );
  }
}

class _SortSheet extends StatelessWidget {
  final String current;
  final Function(String, bool) onSelect;

  const _SortSheet({required this.current, required this.onSelect});

  @override
  Widget build(BuildContext context) {
    final options = [
      ('logged_date', 'Most Recent', true),
      ('incident_date', 'By Incident Date', true),
      ('emotional_score', 'Most Emotional', true),
      ('financial_cost', 'Most Expensive', true),
      ('repeat_count', 'Most Repeated', true),
    ];

    return Container(
      padding: const EdgeInsets.all(20),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Sort By', style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 16),
          ...options.map((o) => ListTile(
                title: Text(o.$2),
                leading: Radio<String>(
                  value: o.$1,
                  groupValue: current,
                  activeColor: AppColors.crimson,
                  onChanged: (_) {
                    onSelect(o.$1, o.$3);
                    Navigator.pop(context);
                  },
                ),
                onTap: () {
                  onSelect(o.$1, o.$3);
                  Navigator.pop(context);
                },
              )),
        ],
      ),
    );
  }
}

class _FilterSheet extends StatefulWidget {
  @override
  State<_FilterSheet> createState() => _FilterSheetState();
}

class _FilterSheetState extends State<_FilterSheet> {
  String? _category;
  RangeValues _emotionalRange = const RangeValues(1, 10);

  @override
  Widget build(BuildContext context) {
    final cats = context.read<CategoryProvider>().categoryNames;

    return Container(
      padding: EdgeInsets.only(
        left: 20, right: 20, top: 20,
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Filter', style: Theme.of(context).textTheme.headlineSmall),
              TextButton(
                onPressed: () {
                  context.read<MistakeProvider>().clearFilters();
                  Navigator.pop(context);
                },
                child: const Text('Clear All',
                    style: TextStyle(color: AppColors.crimson)),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Text('Category', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            children: [
              FilterChip(
                label: const Text('All'),
                selected: _category == null,
                onSelected: (_) => setState(() => _category = null),
                selectedColor: AppColors.crimsonDim,
              ),
              ...cats.map((c) => FilterChip(
                    label: Text(c),
                    selected: _category == c,
                    onSelected: (_) => setState(() => _category = c),
                    selectedColor: AppColors.crimsonDim,
                  )),
            ],
          ),
          const SizedBox(height: 16),
          Text('Emotional Score Range',
              style: Theme.of(context).textTheme.titleMedium),
          RangeSlider(
            values: _emotionalRange,
            min: 1,
            max: 10,
            divisions: 9,
            activeColor: AppColors.crimson,
            labels: RangeLabels(
                '${_emotionalRange.start.round()}',
                '${_emotionalRange.end.round()}'),
            onChanged: (v) => setState(() => _emotionalRange = v),
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {
                context.read<MistakeProvider>().setFilter(
                  category: _category,
                  minEmotional: _emotionalRange.start.round(),
                  maxEmotional: _emotionalRange.end.round(),
                );
                Navigator.pop(context);
              },
              child: const Text('Apply Filters'),
            ),
          ),
        ],
      ),
    );
  }
}
