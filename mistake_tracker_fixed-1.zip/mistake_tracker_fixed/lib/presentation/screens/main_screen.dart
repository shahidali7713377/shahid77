// lib/presentation/screens/main_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_theme.dart';
import '../providers/providers.dart';
import 'home_screen.dart';
import 'analytics_screen.dart';
import 'regret_reduction_screen.dart';
import 'categories_settings_screen.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _currentIndex = 0;

  final _pages = const [
    HomeScreen(),
    AnalyticsScreen(),
    RegretReductionScreen(),
    CategoriesScreen(),
    SettingsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: isDark
          ? SystemUiOverlayStyle.light
          : SystemUiOverlayStyle.dark,
      child: Scaffold(
        body: IndexedStack(
          index: _currentIndex,
          children: _pages,
        ),
        bottomNavigationBar: NavigationBar(
          selectedIndex: _currentIndex,
          onDestinationSelected: (i) {
            HapticFeedback.selectionClick();
            setState(() => _currentIndex = i);
          },
          height: 70,
          labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
          destinations: [
            _navDest(Icons.home_outlined, Icons.home, 'Home'),
            _navDest(Icons.bar_chart_outlined, Icons.bar_chart, 'Analytics'),
            _navDest(Icons.shield_outlined, Icons.shield, 'Rules'),
            _navDest(Icons.folder_outlined, Icons.folder, 'Categories'),
            _navDest(Icons.settings_outlined, Icons.settings, 'Settings'),
          ],
        ),
      ),
    );
  }

  NavigationDestination _navDest(
      IconData icon, IconData activeIcon, String label) {
    return NavigationDestination(
      icon: Icon(icon),
      selectedIcon: Icon(activeIcon, color: AppColors.crimson),
      label: label,
    );
  }
}
