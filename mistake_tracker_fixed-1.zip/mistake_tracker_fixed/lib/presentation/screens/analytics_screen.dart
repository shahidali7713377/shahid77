// lib/presentation/screens/analytics_screen.dart

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_theme.dart';
import '../../domain/entities/entities.dart';
import '../providers/providers.dart';
import '../widgets/app_widgets.dart';

class AnalyticsScreen extends StatefulWidget {
  const AnalyticsScreen({super.key});

  @override
  State<AnalyticsScreen> createState() => _AnalyticsScreenState();
}

class _AnalyticsScreenState extends State<AnalyticsScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<AnalyticsProvider>().loadAnalytics();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Analytics'),
      ),
      body: Consumer<AnalyticsProvider>(
        builder: (context, provider, _) {
          if (provider.state == ViewState.loading) {
            return const Center(
              child: CircularProgressIndicator(color: AppColors.crimson),
            );
          }

          final data = provider.analytics;
          if (data == null || data.totalMistakes == 0) {
            return const EmptyState(
              title: 'No data yet',
              subtitle: 'Log mistakes to see analytics',
              emoji: '📊',
            );
          }

          return RefreshIndicator(
            onRefresh: provider.loadAnalytics,
            color: AppColors.crimson,
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                // Header stats
                _StatsGrid(data: data),
                const SizedBox(height: 24),

                // Recurring patterns
                if (data.recurringPatterns.isNotEmpty) ...[
                  const SectionHeader(title: '🔁 Recurring Patterns'),
                  const SizedBox(height: 12),
                  _PatternsCard(patterns: data.recurringPatterns),
                  const SizedBox(height: 24),
                ],

                // Monthly trend chart
                if (data.monthlyTrend.isNotEmpty) ...[
                  const SectionHeader(title: '📅 Monthly Trend'),
                  const SizedBox(height: 12),
                  _MonthlyChart(data: data.monthlyTrend),
                  const SizedBox(height: 24),
                ],

                // Category breakdown
                if (data.categoryBreakdown.isNotEmpty) ...[
                  const SectionHeader(title: '📂 Category Breakdown'),
                  const SizedBox(height: 12),
                  _CategoryChart(data: data.categoryBreakdown),
                  const SizedBox(height: 24),
                ],

                // Emotional trend
                if (data.emotionalTrend.isNotEmpty) ...[
                  const SectionHeader(title: '😤 Emotional Trend'),
                  const SizedBox(height: 12),
                  _EmotionalChart(data: data.emotionalTrend),
                  const SizedBox(height: 24),
                ],

                // Top costly
                if (data.topCostlyMistakes.isNotEmpty) ...[
                  const SectionHeader(title: '💸 Top Costly Mistakes'),
                  const SizedBox(height: 12),
                  ...data.topCostlyMistakes.asMap().entries.map(
                    (e) => _RankedItem(
                      rank: e.key + 1,
                      title: e.value.title,
                      value: '₹${e.value.financialCost?.toStringAsFixed(0) ?? '0'}',
                      color: AppColors.chartPalette[e.key % AppColors.chartPalette.length],
                    ),
                  ),
                ],
                const SizedBox(height: 32),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _StatsGrid extends StatelessWidget {
  final AnalyticsEntity data;

  const _StatsGrid({required this.data});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          children: [
            Expanded(
              child: StatCard(
                label: 'Total Mistakes',
                value: '${data.totalMistakes}',
                icon: Icons.error_outline,
                color: AppColors.crimson,
                subtitle: 'Logged',
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: StatCard(
                label: 'Financial Loss',
                value: _formatMoney(data.totalFinancialLoss),
                icon: Icons.currency_rupee,
                color: AppColors.amber,
                subtitle: 'Total',
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: StatCard(
                label: 'Time Lost',
                value: '${data.totalTimeLost.toStringAsFixed(0)}h',
                icon: Icons.access_time,
                color: AppColors.lowImpact,
                subtitle: 'Hours',
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: StatCard(
                label: 'Avg Impact',
                value: data.averageEmotionalImpact.toStringAsFixed(1),
                icon: Icons.sentiment_dissatisfied,
                color: AppColors.crimsonLight,
                subtitle: 'out of 10',
              ),
            ),
          ],
        ),
        if (data.mostCommonCategory != null) ...[
          const SizedBox(height: 12),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  AppColors.crimson.withOpacity(0.1),
                  AppColors.amber.withOpacity(0.05),
                ],
              ),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppColors.crimson.withOpacity(0.2)),
            ),
            child: Row(
              children: [
                const Text('🎯', style: TextStyle(fontSize: 24)),
                const SizedBox(width: 12),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Most Common Pattern',
                      style: GoogleFonts.spaceGrotesk(
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        color: AppColors.textSecondary,
                        letterSpacing: 0.5,
                      ),
                    ),
                    Text(
                      data.mostCommonCategory!,
                      style: GoogleFonts.spaceGrotesk(
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                        color: AppColors.crimsonLight,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ).animate().fadeIn(delay: 200.ms),
        ],
      ],
    );
  }

  String _formatMoney(double amount) {
    if (amount >= 10000000) return '₹${(amount / 10000000).toStringAsFixed(1)}Cr';
    if (amount >= 100000) return '₹${(amount / 100000).toStringAsFixed(1)}L';
    if (amount >= 1000) return '₹${(amount / 1000).toStringAsFixed(1)}K';
    return '₹${amount.toStringAsFixed(0)}';
  }
}

class _PatternsCard extends StatelessWidget {
  final List<String> patterns;

  const _PatternsCard({required this.patterns});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.amber.withOpacity(0.06),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.amber.withOpacity(0.2)),
      ),
      child: Column(
        children: patterns.asMap().entries.map((e) {
          return Padding(
            padding: EdgeInsets.only(bottom: e.key < patterns.length - 1 ? 12 : 0),
            child: Row(
              children: [
                Container(
                  width: 24, height: 24,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: AppColors.amber.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    '${e.key + 1}',
                    style: GoogleFonts.spaceGrotesk(
                      fontSize: 12, fontWeight: FontWeight.w700,
                      color: AppColors.amberLight,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    e.value,
                    style: GoogleFonts.dmSans(
                      fontSize: 14, color: AppColors.amberLight,
                    ),
                  ),
                ),
              ],
            ),
          );
        }).toList(),
      ),
    ).animate().fadeIn(delay: 100.ms);
  }
}

class _MonthlyChart extends StatelessWidget {
  final List<MonthlyCount> data;

  const _MonthlyChart({required this.data});

  @override
  Widget build(BuildContext context) {
    final maxY = data.map((d) => d.count).reduce((a, b) => a > b ? a : b).toDouble();

    return Container(
      height: 200,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: BarChart(
        BarChartData(
          alignment: BarChartAlignment.spaceAround,
          maxY: maxY + 1,
          barTouchData: BarTouchData(
            enabled: true,
            touchTooltipData: BarTouchTooltipData(
              tooltipBgColor: AppColors.bgElevated,
            ),
          ),
          titlesData: FlTitlesData(
            show: true,
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                getTitlesWidget: (value, meta) {
                  final idx = value.toInt();
                  if (idx < 0 || idx >= data.length) return const SizedBox();
                  final month = data[idx].month.split('-')[1];
                  return Text(
                    _monthAbbr(int.parse(month)),
                    style: GoogleFonts.spaceGrotesk(fontSize: 10),
                  );
                },
              ),
            ),
            leftTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 28,
                getTitlesWidget: (value, meta) => Text(
                  '${value.toInt()}',
                  style: GoogleFonts.spaceGrotesk(
                    fontSize: 10, color: AppColors.textTertiary,
                  ),
                ),
              ),
            ),
            topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          ),
          gridData: FlGridData(
            show: true,
            drawVerticalLine: false,
            getDrawingHorizontalLine: (value) => FlLine(
              color: AppColors.border,
              strokeWidth: 1,
            ),
          ),
          borderData: FlBorderData(show: false),
          barGroups: data.asMap().entries.map((e) {
            final count = e.value.count.toDouble();
            final color = count == 0
                ? AppColors.textMuted
                : count >= 5
                    ? AppColors.crimson
                    : count >= 3
                        ? AppColors.amber
                        : AppColors.emerald;

            return BarChartGroupData(
              x: e.key,
              barRods: [
                BarChartRodData(
                  toY: count,
                  color: color,
                  width: 20,
                  borderRadius: BorderRadius.circular(4),
                ),
              ],
            );
          }).toList(),
        ),
      ),
    ).animate().fadeIn(delay: 200.ms);
  }

  String _monthAbbr(int m) =>
      ['J','F','M','A','M','J','J','A','S','O','N','D'][m - 1];
}

class _CategoryChart extends StatelessWidget {
  final List<CategoryCount> data;

  const _CategoryChart({required this.data});

  @override
  Widget build(BuildContext context) {
    final total = data.fold(0, (s, d) => s + d.count);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        children: data.take(6).toList().asMap().entries.map((e) {
          final pct = total == 0 ? 0.0 : e.value.count / total;
          final color = AppColors.chartPalette[e.key % AppColors.chartPalette.length];

          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 5),
            child: Column(
              children: [
                Row(
                  children: [
                    SizedBox(
                      width: 100,
                      child: Text(
                        e.value.category,
                        style: GoogleFonts.spaceGrotesk(fontSize: 12),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(4),
                        child: LinearProgressIndicator(
                          value: pct,
                          backgroundColor: color.withOpacity(0.12),
                          valueColor: AlwaysStoppedAnimation(color),
                          minHeight: 8,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      '${e.value.count}',
                      style: GoogleFonts.spaceGrotesk(
                        fontSize: 13, fontWeight: FontWeight.w700, color: color,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          );
        }).toList(),
      ),
    ).animate().fadeIn(delay: 300.ms);
  }
}

class _EmotionalChart extends StatelessWidget {
  final List<EmotionalPoint> data;

  const _EmotionalChart({required this.data});

  @override
  Widget build(BuildContext context) {
    final maxY = data.map((d) => d.avgScore).reduce((a, b) => a > b ? a : b);

    return Container(
      height: 180,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: LineChart(
        LineChartData(
          maxY: 10,
          minY: 0,
          gridData: FlGridData(
            show: true,
            drawVerticalLine: false,
            getDrawingHorizontalLine: (_) => const FlLine(
              color: AppColors.border,
              strokeWidth: 1,
            ),
          ),
          borderData: FlBorderData(show: false),
          titlesData: FlTitlesData(
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                getTitlesWidget: (value, _) {
                  final idx = value.toInt();
                  if (idx < 0 || idx >= data.length) return const SizedBox();
                  final month = data[idx].date.split('-')[1];
                  return Text(
                    ['J','F','M','A','M','J','J','A','S','O','N','D'][int.parse(month)-1],
                    style: GoogleFonts.spaceGrotesk(fontSize: 10),
                  );
                },
              ),
            ),
            leftTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 28,
                getTitlesWidget: (value, _) => Text(
                  '${value.toInt()}',
                  style: GoogleFonts.spaceGrotesk(
                    fontSize: 10, color: AppColors.textTertiary,
                  ),
                ),
              ),
            ),
            topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          ),
          lineBarsData: [
            LineChartBarData(
              spots: data.asMap().entries.map((e) =>
                FlSpot(e.key.toDouble(), e.value.avgScore)).toList(),
              isCurved: true,
              color: AppColors.crimson,
              barWidth: 2.5,
              dotData: const FlDotData(show: true),
              belowBarData: BarAreaData(
                show: true,
                color: AppColors.crimson.withOpacity(0.08),
              ),
            ),
          ],
        ),
      ),
    ).animate().fadeIn(delay: 350.ms);
  }
}

class _RankedItem extends StatelessWidget {
  final int rank;
  final String title;
  final String value;
  final Color color;

  const _RankedItem({
    required this.rank,
    required this.title,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withOpacity(0.06),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.15)),
      ),
      child: Row(
        children: [
          Text(
            '#$rank',
            style: GoogleFonts.spaceGrotesk(
              fontSize: 18, fontWeight: FontWeight.w800, color: color,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Text(
              title,
              style: Theme.of(context).textTheme.titleMedium,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          Text(
            value,
            style: GoogleFonts.spaceGrotesk(
              fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.amberLight,
            ),
          ),
        ],
      ),
    ).animate().slideX(begin: 0.1, end: 0, delay: Duration(milliseconds: 50 * rank), duration: 300.ms);
  }
}
