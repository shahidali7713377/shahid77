// lib/presentation/screens/categories_settings_screen.dart

import 'dart:io';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import '../../core/constants/app_theme.dart';
import '../../domain/entities/entities.dart';
import '../providers/providers.dart';
import '../widgets/app_widgets.dart';

class CategoriesScreen extends StatefulWidget {
  const CategoriesScreen({super.key});

  @override
  State<CategoriesScreen> createState() => _CategoriesScreenState();
}

class _CategoriesScreenState extends State<CategoriesScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<CategoryProvider>().loadCategories();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Categories')),
      body: Consumer<CategoryProvider>(
        builder: (context, provider, _) {
          final categories = provider.categories;

          if (categories.isEmpty) {
            return const EmptyState(
              title: 'No categories',
              subtitle: 'Add custom categories',
              emoji: '📁',
            );
          }

          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              ...categories.map((cat) => _CategoryCard(
                    category: cat,
                    onEdit: cat.isDefault
                        ? null
                        : () => _showEditDialog(context, cat),
                    onDelete: cat.isDefault
                        ? null
                        : () => _confirmDelete(context, cat),
                    onMerge: () => _showMergeDialog(context, cat, categories),
                  )),
              const SizedBox(height: 80),
            ],
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showAddDialog(context),
        backgroundColor: AppColors.crimson,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add),
        label: Text(
          'Add Category',
          style: GoogleFonts.spaceGrotesk(fontWeight: FontWeight.w700),
        ),
      ),
    );
  }

  Future<void> _showAddDialog(BuildContext context) async {
    final ctrl = TextEditingController();
    // Capture provider before async gap so we don't use context after pop.
    final categoryProvider = context.read<CategoryProvider>();

    await showDialog<void>(
      context: context,
      builder: (dialogCtx) => AlertDialog(
        title: const Text('New Category'),
        content: TextField(
          controller: ctrl,
          decoration: const InputDecoration(labelText: 'Category name'),
          autofocus: true,
          textCapitalization: TextCapitalization.words,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogCtx),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              final name = ctrl.text.trim();
              if (name.isNotEmpty) {
                categoryProvider.addCategory(name);
                Navigator.pop(dialogCtx);
              }
            },
            style: TextButton.styleFrom(foregroundColor: AppColors.crimson),
            child: const Text('Add'),
          ),
        ],
      ),
    );
    ctrl.dispose();
  }

  Future<void> _showEditDialog(BuildContext context, CategoryEntity cat) async {
    final ctrl = TextEditingController(text: cat.name);
    final categoryProvider = context.read<CategoryProvider>();

    await showDialog<void>(
      context: context,
      builder: (dialogCtx) => AlertDialog(
        title: const Text('Rename Category'),
        content: TextField(
          controller: ctrl,
          decoration: const InputDecoration(labelText: 'Category name'),
          autofocus: true,
          textCapitalization: TextCapitalization.words,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogCtx),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              final name = ctrl.text.trim();
              if (name.isNotEmpty) {
                categoryProvider.updateCategory(cat.id!, name);
                Navigator.pop(dialogCtx);
              }
            },
            style: TextButton.styleFrom(foregroundColor: AppColors.crimson),
            child: const Text('Save'),
          ),
        ],
      ),
    );
    ctrl.dispose();
  }

  Future<void> _showMergeDialog(
    BuildContext context,
    CategoryEntity from,
    List<CategoryEntity> all,
  ) async {
    final others = all.where((c) => c.name != from.name).toList();
    if (others.isEmpty) return;

    String? selected = others.first.name;
    final categoryProvider = context.read<CategoryProvider>();

    await showDialog<void>(
      context: context,
      builder: (dialogCtx) => StatefulBuilder(
        builder: (ctx, setState) => AlertDialog(
          title: Text('Merge "${from.name}"'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('Merge into:'),
              ...others.map((c) => RadioListTile<String>(
                    title: Text(c.name),
                    value: c.name,
                    groupValue: selected,
                    activeColor: AppColors.crimson,
                    onChanged: (v) => setState(() => selected = v),
                  )),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogCtx),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                if (selected != null) {
                  categoryProvider.mergeCategories(from.name, selected!);
                  Navigator.pop(dialogCtx);
                }
              },
              style: TextButton.styleFrom(foregroundColor: AppColors.crimson),
              child: const Text('Merge'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _confirmDelete(BuildContext context, CategoryEntity cat) async {
    final categoryProvider = context.read<CategoryProvider>();

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogCtx) => AlertDialog(
        title: const Text('Delete Category?'),
        content: Text(
            'Delete "${cat.name}"? Mistakes in this category will need to be reassigned.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogCtx, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(dialogCtx, true),
            style: TextButton.styleFrom(foregroundColor: AppColors.crimson),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (confirmed == true) {
      categoryProvider.deleteCategory(cat.id!);
    }
  }
}

class _CategoryCard extends StatelessWidget {
  final CategoryEntity category;
  final VoidCallback? onEdit;
  final VoidCallback? onDelete;
  final VoidCallback? onMerge;

  const _CategoryCard({
    required this.category,
    this.onEdit,
    this.onDelete,
    this.onMerge,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: Container(
          width: 40,
          height: 40,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: AppColors.crimson.withOpacity(0.12),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Text(
            _categoryEmoji(category.name),
            style: const TextStyle(fontSize: 18),
          ),
        ),
        title: Text(
          category.name,
          style: GoogleFonts.spaceGrotesk(fontWeight: FontWeight.w600),
        ),
        subtitle: Row(
          children: [
            Text(
              '${category.mistakeCount} mistake${category.mistakeCount != 1 ? 's' : ''}',
              style: Theme.of(context).textTheme.bodySmall,
            ),
            if (category.isDefault) ...[
              const SizedBox(width: 8),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: AppColors.textMuted.withOpacity(0.3),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Text(
                  'DEFAULT',
                  style: GoogleFonts.spaceGrotesk(
                    fontSize: 9,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textSecondary,
                    letterSpacing: 0.5,
                  ),
                ),
              ),
            ],
          ],
        ),
        trailing: PopupMenuButton<String>(
          icon: const Icon(Icons.more_vert, size: 20),
          itemBuilder: (_) => [
            if (onEdit != null)
              const PopupMenuItem(value: 'edit', child: Text('Rename')),
            if (onMerge != null)
              const PopupMenuItem(value: 'merge', child: Text('Merge Into...')),
            if (onDelete != null)
              const PopupMenuItem(
                value: 'delete',
                child:
                    Text('Delete', style: TextStyle(color: AppColors.crimson)),
              ),
          ],
          onSelected: (v) {
            switch (v) {
              case 'edit':
                onEdit?.call();
                break;
              case 'merge':
                onMerge?.call();
                break;
              case 'delete':
                onDelete?.call();
                break;
            }
          },
        ),
      ),
    );
  }

  String _categoryEmoji(String name) {
    const map = {
      'Financial': '💰',
      'Career': '💼',
      'Relationship': '❤️',
      'Health': '🏥',
      'Education': '📚',
      'Business': '🏢',
      'Personal Discipline': '🧠',
    };
    return map[name] ?? '📁';
  }
}

// ── SETTINGS SCREEN ───────────────────────────────────────────
class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Appearance
          _SettingsSection(
            title: 'Appearance',
            children: [
              Consumer<ThemeProvider>(
                builder: (_, provider, __) => SwitchListTile(
                  title: const Text('Dark Mode'),
                  subtitle: const Text('Default recommended'),
                  value: provider.isDark,
                  activeColor: AppColors.crimson,
                  onChanged: (v) => provider.setDark(v),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),

          // Overlay
          _SettingsSection(
            title: 'Overlay',
            children: [
              Consumer<OverlayProvider>(
                builder: (_, provider, __) {
                  return Column(
                    children: [
                      ListTile(
                        title: const Text('Display Over Other Apps'),
                        subtitle: Text(
                          provider.hasPermission
                              ? 'Permission granted'
                              : 'Required for the quick-log floating button',
                        ),
                        trailing: provider.hasPermission
                            ? const Icon(Icons.check_circle,
                                color: AppColors.emerald)
                            : ElevatedButton(
                                onPressed: () => provider.requestPermission(),
                                style: ElevatedButton.styleFrom(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 12, vertical: 8),
                                ),
                                child: const Text('Enable'),
                              ),
                      ),
                      if (provider.hasPermission) ...[
                        const Divider(height: 1, indent: 16),
                        SwitchListTile(
                          title: const Text('Show Floating Button'),
                          subtitle: Text(
                            provider.isOverlayShowing
                                ? 'Quick-log button is visible'
                                : 'Tap to show the quick-log button',
                          ),
                          value: provider.isOverlayShowing,
                          activeColor: AppColors.crimson,
                          onChanged: (v) => v
                              ? provider.showOverlay()
                              : provider.hideOverlay(),
                        ),
                      ],
                      if (provider.errorMessage != null) ...[
                        const Divider(height: 1, indent: 16),
                        Padding(
                          padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
                          child: Row(
                            children: [
                              const Icon(Icons.error_outline,
                                  color: AppColors.crimson, size: 16),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  provider.errorMessage!,
                                  style: const TextStyle(
                                    color: AppColors.crimson,
                                    fontSize: 12,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ],
                  );
                },
              ),
            ],
          ),
          const SizedBox(height: 16),

          // Data & Privacy
          _SettingsSection(
            title: 'Data & Privacy',
            children: [
              ListTile(
                leading: const Icon(Icons.download_outlined),
                title: const Text('Export Data (CSV)'),
                subtitle: const Text('Save & share as CSV file'),
                onTap: () => _exportData(context),
              ),
              const Divider(height: 1, indent: 16),
              ListTile(
                leading: const Icon(Icons.lock_outline),
                title: const Text('Privacy'),
                subtitle:
                    const Text('100% offline · No cloud · No tracking'),
                onTap: () => _showPrivacyInfo(context),
              ),
            ],
          ),
          const SizedBox(height: 16),

          // About
          _SettingsSection(
            title: 'About',
            children: [
              const ListTile(
                title: Text('ErrorLog'),
                subtitle: Text('v1.0.0 · Life Lessons Database'),
                leading: Text('⚠', style: TextStyle(fontSize: 24)),
              ),
            ],
          ),
        ],
      ),
    );
  }

  /// Generates the CSV, writes it to the cache directory, then
  /// opens the system share sheet so the user can save it anywhere.
  Future<void> _exportData(BuildContext context) async {
    final messenger = ScaffoldMessenger.of(context);
    try {
      // 1. Generate CSV content
      final csv =
          await context.read<MistakeProvider>().exportCSV();

      // 2. Write to a temporary file
      final dir = await getTemporaryDirectory();
      final now = DateTime.now();
      final stamp =
          '${now.year}${now.month.toString().padLeft(2, '0')}${now.day.toString().padLeft(2, '0')}'
          '_${now.hour.toString().padLeft(2, '0')}${now.minute.toString().padLeft(2, '0')}';
      final file = File('${dir.path}/errorlog_export_$stamp.csv');
      await file.writeAsString(csv);

      // 3. Share / save via the OS sheet
      await Share.shareXFiles(
        [XFile(file.path, mimeType: 'text/csv')],
        subject: 'ErrorLog Mistakes Export',
      );
    } catch (e) {
      messenger.showSnackBar(
        SnackBar(content: Text('Export failed: $e')),
      );
    }
  }

  void _showPrivacyInfo(BuildContext context) {
    showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.lock_outline, color: AppColors.emerald),
            SizedBox(width: 8),
            Text('Privacy First'),
          ],
        ),
        content: const Text(
          '✅ No internet permission\n'
          '✅ No cloud sync\n'
          '✅ No analytics\n'
          '✅ No account needed\n'
          '✅ Data stays on device\n'
          '✅ Export is local-only\n\n'
          'Your mistakes are yours. No one else sees them.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Got it'),
          ),
        ],
      ),
    );
  }
}

class _SettingsSection extends StatelessWidget {
  final String title;
  final List<Widget> children;

  const _SettingsSection({required this.title, required this.children});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(bottom: 8, left: 4),
          child: Text(
            title.toUpperCase(),
            style: GoogleFonts.spaceGrotesk(
              fontSize: 10,
              fontWeight: FontWeight.w700,
              color: AppColors.textTertiary,
              letterSpacing: 1.2,
            ),
          ),
        ),
        Container(
          decoration: BoxDecoration(
            color: Theme.of(context).cardTheme.color,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.border),
          ),
          child: Column(
            children: children
                .asMap()
                .entries
                .map((e) => Column(
                      children: [
                        e.value,
                        if (e.key < children.length - 1)
                          const Divider(height: 1, indent: 16),
                      ],
                    ))
                .toList(),
          ),
        ),
      ],
    );
  }
}
