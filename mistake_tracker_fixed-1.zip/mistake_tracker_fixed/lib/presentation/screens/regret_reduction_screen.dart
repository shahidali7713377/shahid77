// lib/presentation/screens/regret_reduction_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_theme.dart';
import '../../domain/entities/entities.dart';
import '../providers/providers.dart';
import '../widgets/app_widgets.dart';

class RegretReductionScreen extends StatefulWidget {
  const RegretReductionScreen({super.key});

  @override
  State<RegretReductionScreen> createState() => _RegretReductionScreenState();
}

class _RegretReductionScreenState extends State<RegretReductionScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<NeverAgainProvider>().loadRules();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Never Again Rules'),
      ),
      body: Consumer<NeverAgainProvider>(
        builder: (context, provider, _) {
          final rules = provider.rules;

          if (rules.isEmpty) {
            return EmptyState(
              title: 'No rules yet',
              subtitle: 'Create rules to prevent repeating costly mistakes',
              emoji: '🛡️',
              action: ElevatedButton.icon(
                onPressed: () => _showAddDialog(context),
                icon: const Icon(Icons.add),
                label: const Text('Add First Rule'),
              ),
            );
          }

          return CustomScrollView(
            slivers: [
              // Active rules header
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                sliver: SliverToBoxAdapter(
                  child: _MantraHeader(activeCount: provider.activeRules.length),
                ),
              ),

              // Rules list
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 100),
                sliver: SliverList(
                  delegate: SliverChildBuilderDelegate(
                    (context, index) {
                      final rule = rules[index];
                      return _NeverAgainCard(
                        rule: rule,
                        index: index,
                        onToggle: (v) =>
                            provider.toggleRule(rule.id!, v),
                        onDelete: () => _confirmDelete(context, rule),
                      );
                    },
                    childCount: rules.length,
                  ),
                ),
              ),
            ],
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showAddDialog(context),
        backgroundColor: AppColors.crimson,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add),
        label: Text(
          'New Rule',
          style: GoogleFonts.spaceGrotesk(fontWeight: FontWeight.w700),
        ),
      ),
    );
  }

  Future<void> _showAddDialog(BuildContext context) async {
    final ruleCtrl = TextEditingController();
    final contextCtrl = TextEditingController();
    // Capture provider here — before the async gap — to avoid using
    // BuildContext across async boundaries inside the bottom sheet.
    final provider = context.read<NeverAgainProvider>();

    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      // Use a Builder so the sheet has its own context for Navigator.pop.
      builder: (sheetCtx) => Padding(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(sheetCtx).viewInsets.bottom,
        ),
        child: Container(
          padding: const EdgeInsets.fromLTRB(20, 24, 20, 24),
          decoration: BoxDecoration(
            color: Theme.of(context).brightness == Brightness.dark
                ? AppColors.bgCard
                : Colors.white,
            borderRadius:
                const BorderRadius.vertical(top: Radius.circular(24)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '🛡️ Never Again Rule',
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              const SizedBox(height: 4),
              Text(
                'Set a rule you will never break again',
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              const SizedBox(height: 20),
              TextField(
                controller: ruleCtrl,
                decoration: const InputDecoration(
                  labelText: 'The Rule',
                  hintText: 'e.g. Never invest without research',
                  prefixText: '⚠️  ',
                ),
                textCapitalization: TextCapitalization.sentences,
                autofocus: true,
              ),
              const SizedBox(height: 12),
              TextField(
                controller: contextCtrl,
                decoration: const InputDecoration(
                  labelText: 'Context (optional)',
                  hintText: 'Why this rule matters...',
                ),
                maxLines: 2,
                textCapitalization: TextCapitalization.sentences,
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    final rule = ruleCtrl.text.trim();
                    if (rule.isEmpty) return;
                    final ctx = contextCtrl.text.trim();
                    provider.addRule(rule, context: ctx.isEmpty ? null : ctx);
                    HapticFeedback.lightImpact();
                    Navigator.pop(sheetCtx); // use sheet context, not screen's
                  },
                  child: const Text('Add Rule'),
                ),
              ),
            ],
          ),
        ),
      ),
    );

    ruleCtrl.dispose();
    contextCtrl.dispose();
  }

  Future<void> _confirmDelete(
      BuildContext context, NeverAgainRuleEntity rule) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Delete Rule?'),
        content: Text('Delete "${rule.rule}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            style:
                TextButton.styleFrom(foregroundColor: AppColors.crimson),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (confirmed == true && context.mounted) {
      context.read<NeverAgainProvider>().deleteRule(rule.id!);
    }
  }
}

class _MantraHeader extends StatelessWidget {
  final int activeCount;

  const _MantraHeader({required this.activeCount});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            AppColors.crimsonDim,
            AppColors.crimsonDim.withOpacity(0.5),
          ],
        ),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '"Mistakes are data.\nData improves decisions."',
            style: GoogleFonts.dmSans(
              fontSize: 16,
              fontStyle: FontStyle.italic,
              color: Colors.white.withOpacity(0.9),
              height: 1.5,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  '$activeCount Active Rules',
                  style: GoogleFonts.spaceGrotesk(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    ).animate().fadeIn(duration: 400.ms);
  }
}

class _NeverAgainCard extends StatelessWidget {
  final NeverAgainRuleEntity rule;
  final int index;
  final ValueChanged<bool> onToggle;
  final VoidCallback onDelete;

  const _NeverAgainCard({
    required this.rule,
    required this.index,
    required this.onToggle,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Animate(
      effects: [
        FadeEffect(
            delay: Duration(milliseconds: index * 50), duration: 300.ms),
        SlideEffect(
          begin: const Offset(0, 0.05),
          end: Offset.zero,
          delay: Duration(milliseconds: index * 50),
          duration: 300.ms,
        ),
      ],
      child: Dismissible(
        key: Key('rule_${rule.id}'),
        direction: DismissDirection.endToStart,
        background: Container(
          alignment: Alignment.centerRight,
          padding: const EdgeInsets.only(right: 20),
          margin: const EdgeInsets.symmetric(vertical: 5),
          decoration: BoxDecoration(
            color: AppColors.crimson.withOpacity(0.1),
            borderRadius: BorderRadius.circular(14),
          ),
          child: const Icon(Icons.delete_outline, color: AppColors.crimson),
        ),
        onDismissed: (_) => onDelete(),
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 5),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: isDark ? AppColors.bgCard : AppColors.bgCardLight,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: rule.isActive
                  ? AppColors.crimson.withOpacity(0.25)
                  : (isDark ? AppColors.border : AppColors.borderLight2),
            ),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Rule icon
              Container(
                width: 40, height: 40,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: rule.isActive
                      ? AppColors.crimsonDim
                      : AppColors.bgSurface,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  rule.isActive ? '⚠️' : '💤',
                  style: const TextStyle(fontSize: 18),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      rule.rule,
                      style: GoogleFonts.spaceGrotesk(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: rule.isActive
                            ? (isDark
                                ? AppColors.textPrimary
                                : AppColors.textPrimaryLight)
                            : AppColors.textSecondary,
                        decoration: rule.isActive
                            ? null
                            : TextDecoration.lineThrough,
                      ),
                    ),
                    if (rule.context != null &&
                        rule.context!.isNotEmpty) ...[
                      const SizedBox(height: 4),
                      Text(
                        rule.context!,
                        style: Theme.of(context).textTheme.bodySmall,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                    const SizedBox(height: 6),
                    Text(
                      _formatDate(rule.createdAt),
                      style: GoogleFonts.spaceGrotesk(
                        fontSize: 10,
                        color: AppColors.textTertiary,
                      ),
                    ),
                  ],
                ),
              ),
              Switch(
                value: rule.isActive,
                onChanged: onToggle,
                activeColor: AppColors.crimson,
                materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _formatDate(DateTime d) {
    final months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    return '${d.day} ${months[d.month-1]} ${d.year}';
  }
}
