// lib/data/models/mistake_model.dart

import 'dart:convert';
import '../../domain/entities/entities.dart';

class MistakeModel {
  final int? id;
  final String title;
  final String description;
  final String category;
  final double? financialCost;
  final double? timeCostHours;
  final int emotionalScore;
  final String lessonLearned;
  final String preventiveStrategy;
  final List<String> tags;
  final DateTime incidentDate;
  final DateTime loggedDate;
  final int repeatCount;

  const MistakeModel({
    this.id,
    required this.title,
    required this.description,
    required this.category,
    this.financialCost,
    this.timeCostHours,
    required this.emotionalScore,
    required this.lessonLearned,
    required this.preventiveStrategy,
    required this.tags,
    required this.incidentDate,
    required this.loggedDate,
    this.repeatCount = 0,
  });

  factory MistakeModel.fromMap(Map<String, dynamic> map) {
    List<String> parsedTags = [];
    try {
      final raw = map['tags'];
      if (raw is String && raw.isNotEmpty) {
        parsedTags = List<String>.from(jsonDecode(raw));
      }
    } catch (_) {}

    return MistakeModel(
      id: map['id'] as int?,
      title: map['title'] as String,
      description: map['description'] as String,
      category: map['category'] as String,
      financialCost: map['financial_cost'] != null
          ? (map['financial_cost'] as num).toDouble()
          : null,
      timeCostHours: map['time_cost_hours'] != null
          ? (map['time_cost_hours'] as num).toDouble()
          : null,
      emotionalScore: map['emotional_score'] as int,
      lessonLearned: map['lesson_learned'] as String? ?? '',
      preventiveStrategy: map['preventive_strategy'] as String? ?? '',
      tags: parsedTags,
      incidentDate: DateTime.parse(map['incident_date'] as String),
      loggedDate: DateTime.parse(map['logged_date'] as String),
      repeatCount: map['repeat_count'] as int? ?? 0,
    );
  }

  Map<String, dynamic> toMap() => {
    if (id != null) 'id': id,
    'title': title,
    'description': description,
    'category': category,
    'financial_cost': financialCost,
    'time_cost_hours': timeCostHours,
    'emotional_score': emotionalScore,
    'lesson_learned': lessonLearned,
    'preventive_strategy': preventiveStrategy,
    'tags': jsonEncode(tags),
    'incident_date': incidentDate.toIso8601String(),
    'logged_date': loggedDate.toIso8601String(),
    'repeat_count': repeatCount,
  };

  MistakeEntity toEntity() => MistakeEntity(
    id: id,
    title: title,
    description: description,
    category: category,
    financialCost: financialCost,
    timeCostHours: timeCostHours,
    emotionalScore: emotionalScore,
    lessonLearned: lessonLearned,
    preventiveStrategy: preventiveStrategy,
    tags: tags,
    incidentDate: incidentDate,
    loggedDate: loggedDate,
    repeatCount: repeatCount,
  );

  factory MistakeModel.fromEntity(MistakeEntity entity) => MistakeModel(
    id: entity.id,
    title: entity.title,
    description: entity.description,
    category: entity.category,
    financialCost: entity.financialCost,
    timeCostHours: entity.timeCostHours,
    emotionalScore: entity.emotionalScore,
    lessonLearned: entity.lessonLearned,
    preventiveStrategy: entity.preventiveStrategy,
    tags: entity.tags,
    incidentDate: entity.incidentDate,
    loggedDate: entity.loggedDate,
    repeatCount: entity.repeatCount,
  );
}

// CategoryModel
class CategoryModel {
  final int? id;
  final String name;
  final bool isDefault;
  final DateTime createdAt;

  const CategoryModel({
    this.id,
    required this.name,
    this.isDefault = false,
    required this.createdAt,
  });

  factory CategoryModel.fromMap(Map<String, dynamic> map) => CategoryModel(
    id: map['id'] as int?,
    name: map['name'] as String,
    isDefault: (map['is_default'] as int) == 1,
    createdAt: DateTime.parse(map['created_at'] as String),
  );

  Map<String, dynamic> toMap() => {
    if (id != null) 'id': id,
    'name': name,
    'is_default': isDefault ? 1 : 0,
    'created_at': createdAt.toIso8601String(),
  };

  CategoryEntity toEntity({int mistakeCount = 0}) => CategoryEntity(
    id: id,
    name: name,
    isDefault: isDefault,
    mistakeCount: mistakeCount,
  );
}

// NeverAgainRuleModel
class NeverAgainRuleModel {
  final int? id;
  final String rule;
  final String? context;
  final DateTime createdAt;
  final bool isActive;

  const NeverAgainRuleModel({
    this.id,
    required this.rule,
    this.context,
    required this.createdAt,
    this.isActive = true,
  });

  factory NeverAgainRuleModel.fromMap(Map<String, dynamic> map) =>
      NeverAgainRuleModel(
        id: map['id'] as int?,
        rule: map['rule'] as String,
        context: map['context'] as String?,
        createdAt: DateTime.parse(map['created_at'] as String),
        isActive: (map['is_active'] as int) == 1,
      );

  Map<String, dynamic> toMap() => {
    if (id != null) 'id': id,
    'rule': rule,
    'context': context,
    'created_at': createdAt.toIso8601String(),
    'is_active': isActive ? 1 : 0,
  };

  NeverAgainRuleEntity toEntity() => NeverAgainRuleEntity(
    id: id,
    rule: rule,
    context: context,
    createdAt: createdAt,
    isActive: isActive,
  );
}
