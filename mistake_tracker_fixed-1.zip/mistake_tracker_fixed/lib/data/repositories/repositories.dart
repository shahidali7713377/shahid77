// lib/data/repositories/mistake_repository_impl.dart

import 'dart:math';
import 'package:flutter/foundation.dart'; // for compute()
import '../../core/constants/app_constants.dart';
import '../../domain/entities/entities.dart';
import '../datasources/database_helper.dart';
import '../models/models.dart';

class MistakeRepository {
  final DatabaseHelper _db = DatabaseHelper.instance;

  // ── CRUD ──────────────────────────────────────────────────

  Future<int> insertMistake(MistakeEntity entity) async {
    // Auto-increment repeat count if similar exists
    final similar = await findSimilarMistakes(entity.title, entity.description);
    final count = similar.length;

    final model = MistakeModel.fromEntity(entity.copyWith(repeatCount: count));
    final id = await _db.insert(AppConstants.mistakeTable, model.toMap());

    // Update repeat_count on similar past entries
    if (count > 0) {
      for (final s in similar) {
        await _db.update(
          AppConstants.mistakeTable,
          {'repeat_count': s.repeatCount + 1},
          'id = ?',
          [s.id],
        );
      }
    }

    return id;
  }

  Future<void> updateMistake(MistakeEntity entity) async {
    final model = MistakeModel.fromEntity(entity);
    await _db.update(
      AppConstants.mistakeTable,
      model.toMap(),
      'id = ?',
      [entity.id],
    );
  }

  Future<void> deleteMistake(int id) async {
    await _db.delete(AppConstants.mistakeTable, 'id = ?', [id]);
  }

  Future<MistakeEntity?> getMistakeById(int id) async {
    final rows = await _db.query(
      AppConstants.mistakeTable,
      where: 'id = ?',
      whereArgs: [id],
    );
    if (rows.isEmpty) return null;
    return MistakeModel.fromMap(rows.first).toEntity();
  }

  // ── QUERIES ───────────────────────────────────────────────

  Future<List<MistakeEntity>> getAllMistakes({
    String? category,
    DateTime? startDate,
    DateTime? endDate,
    int? minEmotional,
    int? maxEmotional,
    double? minFinancial,
    double? maxFinancial,
    String sortBy = 'logged_date',
    bool descending = true,
    int? limit,
    int? offset,
  }) async {
    final conditions = <String>[];
    final args = <dynamic>[];

    if (category != null) {
      conditions.add('category = ?');
      args.add(category);
    }
    if (startDate != null) {
      conditions.add('incident_date >= ?');
      args.add(startDate.toIso8601String());
    }
    if (endDate != null) {
      conditions.add('incident_date <= ?');
      args.add(endDate.toIso8601String());
    }
    if (minEmotional != null) {
      conditions.add('emotional_score >= ?');
      args.add(minEmotional);
    }
    if (maxEmotional != null) {
      conditions.add('emotional_score <= ?');
      args.add(maxEmotional);
    }
    if (minFinancial != null) {
      conditions.add('financial_cost >= ?');
      args.add(minFinancial);
    }
    if (maxFinancial != null) {
      conditions.add('financial_cost <= ?');
      args.add(maxFinancial);
    }

    final where = conditions.isEmpty ? null : conditions.join(' AND ');
    final direction = descending ? 'DESC' : 'ASC';

    final rows = await _db.query(
      AppConstants.mistakeTable,
      where: where,
      whereArgs: args.isEmpty ? null : args,
      orderBy: '$sortBy $direction',
      limit: limit,
      offset: offset,
    );

    return rows.map((r) => MistakeModel.fromMap(r).toEntity()).toList();
  }

  Future<List<MistakeEntity>> searchMistakes(String query) async {
    if (query.trim().isEmpty) return getAllMistakes();
    // LIKE-based search only — FTS removed (caused INSERT crash on all builds).
    final q = '%$query%';
    final rows = await _db.rawQuery('
      SELECT * FROM ${AppConstants.mistakeTable}
      WHERE title LIKE ? OR description LIKE ? OR lesson_learned LIKE ? OR tags LIKE ?
      ORDER BY logged_date DESC
    ', [q, q, q, q]);
    return rows.map((r) => MistakeModel.fromMap(r).toEntity()).toList();
  }

  // ── SIMILARITY DETECTION ──────────────────────────────────

  Future<List<MistakeEntity>> findSimilarMistakes(
    String title,
    String description,
  ) async {
    final all = await getAllMistakes();
    if (all.isEmpty) return [];

    // Run the CPU-bound Jaccard scan in a background isolate so the
    // UI thread stays responsive even with large datasets.
    final input = '${title.toLowerCase()} ${description.toLowerCase()}';
    final existing = all.map((m) {
      return {
        'text': '${m.title.toLowerCase()} ${m.description.toLowerCase()}',
        'index': all.indexOf(m),
      };
    }).toList();

    final similarIndices = await compute(
      _jaccardFilter,
      _JaccardParams(
        input: input,
        corpus: existing,
        threshold: AppConstants.similarityThreshold,
      ),
    );

    return similarIndices.map((i) => all[i]).toList();
  }

  /// Top-level function required by compute().
  static List<int> _jaccardFilter(_JaccardParams params) {
    final wordsA = _tokenizeStatic(params.input);
    final result = <int>[];
    for (final entry in params.corpus) {
      final wordsB = _tokenizeStatic(entry['text'] as String);
      if (wordsA.isEmpty || wordsB.isEmpty) continue;
      final intersection = wordsA.intersection(wordsB).length;
      final union = wordsA.union(wordsB).length;
      final similarity = union == 0 ? 0.0 : intersection / union;
      if (similarity >= params.threshold) {
        result.add(entry['index'] as int);
      }
    }
    return result;
  }

  static Set<String> _tokenizeStatic(String text) {
    return text
        .toLowerCase()
        .replaceAll(RegExp(r'[^\w\s]'), '')
        .split(RegExp(r'\s+'))
        .where((w) => w.length > 2)
        .toSet();
  }

  // ── ANALYTICS ─────────────────────────────────────────────

  Future<AnalyticsEntity> getAnalytics() async {
    final all = await getAllMistakes();

    if (all.isEmpty) {
      return AnalyticsEntity(
        totalMistakes: 0,
        totalFinancialLoss: 0,
        totalTimeLost: 0,
        averageEmotionalImpact: 0,
        categoryBreakdown: [],
        monthlyTrend: [],
        emotionalTrend: [],
        recurringPatterns: [],
        topCostlyMistakes: [],
      );
    }

    // Category breakdown
    final catMap = <String, int>{};
    for (final m in all) {
      catMap[m.category] = (catMap[m.category] ?? 0) + 1;
    }
    final sorted = catMap.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    final breakdown = sorted
        .map((e) => CategoryCount(category: e.key, count: e.value))
        .toList();

    // Monthly trend (last 6 months)
    final monthMap = <String, int>{};
    final now = DateTime.now();
    for (var i = 5; i >= 0; i--) {
      final month = DateTime(now.year, now.month - i, 1);
      final key = '${month.year}-${month.month.toString().padLeft(2, '0')}';
      monthMap[key] = 0;
    }
    for (final m in all) {
      final key =
          '${m.incidentDate.year}-${m.incidentDate.month.toString().padLeft(2, '0')}';
      if (monthMap.containsKey(key)) {
        monthMap[key] = (monthMap[key] ?? 0) + 1;
      }
    }
    final monthly = monthMap.entries
        .map((e) => MonthlyCount(month: e.key, count: e.value))
        .toList();

    // Emotional trend
    final emotionByMonth = <String, List<int>>{};
    for (final m in all) {
      final key =
          '${m.incidentDate.year}-${m.incidentDate.month.toString().padLeft(2, '0')}';
      emotionByMonth.putIfAbsent(key, () => []).add(m.emotionalScore);
    }
    final emotionalTrend = emotionByMonth.entries
        .map((e) => EmotionalPoint(
              date: e.key,
              avgScore: e.value.reduce((a, b) => a + b) / e.value.length,
            ))
        .toList()
      ..sort((a, b) => a.date.compareTo(b.date));

    // Recurring patterns (categories with repeats)
    final patterns = breakdown
        .where((c) => c.count >= 2)
        .take(3)
        .map((c) => '${c.category} mistakes (${c.count}x)')
        .toList();

    // Top costly
    final withFinancial = all.where((m) => m.hasFinancialCost).toList()
      ..sort((a, b) => (b.financialCost ?? 0).compareTo(a.financialCost ?? 0));

    return AnalyticsEntity(
      totalMistakes: all.length,
      mostCommonCategory: breakdown.isNotEmpty ? breakdown.first.category : null,
      totalFinancialLoss: all.fold(0, (s, m) => s + (m.financialCost ?? 0)),
      totalTimeLost: all.fold(0, (s, m) => s + (m.timeCostHours ?? 0)),
      averageEmotionalImpact: all.fold(0, (s, m) => s + m.emotionalScore) / all.length,
      categoryBreakdown: breakdown,
      monthlyTrend: monthly,
      emotionalTrend: emotionalTrend,
      recurringPatterns: patterns,
      topCostlyMistakes: withFinancial.take(5).toList(),
    );
  }

  // ── EXPORT ────────────────────────────────────────────────
  Future<String> exportToCSV() async {
    final all = await getAllMistakes();
    final header =
        'ID,Title,Description,Category,Financial Cost,Time Cost (hrs),Emotional Score,Lesson,Preventive Strategy,Tags,Incident Date,Logged Date,Repeat Count\n';
    final rows = all.map((m) {
      return '${m.id},"${m.title}","${m.description}","${m.category}",${m.financialCost ?? ''},${m.timeCostHours ?? ''},${m.emotionalScore},"${m.lessonLearned}","${m.preventiveStrategy}","${m.tags.join(';')}","${m.incidentDate.toIso8601String()}","${m.loggedDate.toIso8601String()}",${m.repeatCount}';
    }).join('\n');
    return header + rows;
  }
}

// Category Repository
class CategoryRepository {
  final DatabaseHelper _db = DatabaseHelper.instance;

  Future<List<CategoryEntity>> getAllCategories() async {
    final rows = await _db.query(
      AppConstants.categoryTable,
      orderBy: 'is_default DESC, name ASC',
    );

    // Get mistake counts
    final counts = await _db.rawQuery('''
      SELECT category, COUNT(*) as cnt FROM ${AppConstants.mistakeTable}
      GROUP BY category
    ''');
    final countMap = {for (final r in counts) r['category'] as String: r['cnt'] as int};

    return rows.map((r) {
      final model = CategoryModel.fromMap(r);
      return model.toEntity(mistakeCount: countMap[model.name] ?? 0);
    }).toList();
  }

  Future<int> insertCategory(String name) async {
    return await _db.insert(AppConstants.categoryTable, {
      'name': name,
      'is_default': 0,
      'created_at': DateTime.now().toIso8601String(),
    });
  }

  Future<void> updateCategory(int id, String newName) async {
    await _db.update(
        AppConstants.categoryTable, {'name': newName}, 'id = ?', [id]);
  }

  Future<void> deleteCategory(int id) async {
    await _db.delete(AppConstants.categoryTable, 'id = ?', [id]);
  }

  Future<void> mergeCategories(String fromCat, String toCat) async {
    await _db.update(
      AppConstants.mistakeTable,
      {'category': toCat},
      'category = ?',
      [fromCat],
    );
    await _db.delete(AppConstants.categoryTable, 'name = ?', [fromCat]);
  }
}

// Never Again Rules Repository
class NeverAgainRepository {
  final DatabaseHelper _db = DatabaseHelper.instance;

  Future<List<NeverAgainRuleEntity>> getAllRules() async {
    final rows = await _db.query(
      AppConstants.neverAgainTable,
      orderBy: 'created_at DESC',
    );
    return rows
        .map((r) => NeverAgainRuleModel.fromMap(r).toEntity())
        .toList();
  }

  Future<int> insertRule(NeverAgainRuleEntity entity) async {
    return await _db.insert(
        AppConstants.neverAgainTable,
        NeverAgainRuleModel(
          rule: entity.rule,
          context: entity.context,
          createdAt: entity.createdAt,
          isActive: entity.isActive,
        ).toMap());
  }

  Future<void> deleteRule(int id) async {
    await _db.delete(AppConstants.neverAgainTable, 'id = ?', [id]);
  }

  Future<void> toggleRule(int id, bool isActive) async {
    await _db.update(
        AppConstants.neverAgainTable, {'is_active': isActive ? 1 : 0}, 'id = ?', [id]);
  }
}


// ── HELPER for compute() ──────────────────────────────────
class _JaccardParams {
  final String input;
  final List<Map<String, dynamic>> corpus;
  final double threshold;
  const _JaccardParams({
    required this.input,
    required this.corpus,
    required this.threshold,
  });
}
