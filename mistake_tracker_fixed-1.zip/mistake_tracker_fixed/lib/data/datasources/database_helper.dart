// lib/data/datasources/database_helper.dart
//
// FTS (full-text search) has been intentionally removed.
// Reason: On many Android SQLite builds the FTS5/FTS4 *content-table* triggers
// fail at INSERT compile-time with "no such module: fts5" even when the
// CREATE VIRTUAL TABLE statement doesn't throw. Removing triggers entirely
// prevents the DatabaseException that crashed the Log Mistake screen.
// All search is handled via fast LIKE queries in the repository layer.

import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../../core/constants/app_constants.dart';

class DatabaseHelper {
  DatabaseHelper._();
  static final DatabaseHelper instance = DatabaseHelper._();

  static Database? _database;

  Future<Database> get database async {
    _database ??= await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, AppConstants.dbName);

    return await openDatabase(
      path,
      version: AppConstants.dbVersion, // v3 — forces clean migration
      onCreate: _createTables,
      onUpgrade: _onUpgrade,
      onConfigure: (db) async =>
          await db.execute('PRAGMA foreign_keys = ON'),
    );
  }

  /// Drop everything and rebuild from scratch on any version bump.
  /// Safe here because v1/v2 databases may be corrupt (partial FTS setup).
  Future<void> _onUpgrade(
      Database db, int oldVersion, int newVersion) async {
    await db.execute('PRAGMA foreign_keys = OFF');

    // Drop all triggers first (they may reference broken FTS tables)
    final triggers = await db.rawQuery(
        "SELECT name FROM sqlite_master WHERE type='trigger'");
    for (final row in triggers) {
      await db.execute('DROP TRIGGER IF EXISTS "${row['name']}"');
    }

    // Drop all virtual tables (FTS remnants)
    final vtables = await db.rawQuery(
        "SELECT name FROM sqlite_master WHERE type='table' AND sql LIKE '%VIRTUAL%'");
    for (final row in vtables) {
      await db.execute('DROP TABLE IF EXISTS "${row['name']}"');
    }

    // Drop all regular user tables
    final tables = await db.rawQuery(
        "SELECT name FROM sqlite_master WHERE type='table' "
        "AND name NOT LIKE 'sqlite_%' AND name NOT LIKE 'android_%'");
    for (final row in tables) {
      await db.execute('DROP TABLE IF EXISTS "${row['name']}"');
    }

    await db.execute('PRAGMA foreign_keys = ON');
    await _createTables(db, newVersion);
  }

  Future<void> _createTables(Database db, int version) async {
    // ── Categories ──────────────────────────────────────────
    await db.execute('''
      CREATE TABLE IF NOT EXISTS ${AppConstants.categoryTable} (
        id       INTEGER PRIMARY KEY AUTOINCREMENT,
        name     TEXT    NOT NULL UNIQUE,
        is_default INTEGER NOT NULL DEFAULT 0,
        created_at TEXT  NOT NULL
      )
    ''');

    // ── Mistakes ────────────────────────────────────────────
    await db.execute('''
      CREATE TABLE IF NOT EXISTS ${AppConstants.mistakeTable} (
        id                INTEGER PRIMARY KEY AUTOINCREMENT,
        title             TEXT    NOT NULL,
        description       TEXT    NOT NULL,
        category          TEXT    NOT NULL,
        financial_cost    REAL,
        time_cost_hours   REAL,
        emotional_score   INTEGER NOT NULL DEFAULT 5,
        lesson_learned    TEXT    NOT NULL DEFAULT '',
        preventive_strategy TEXT  NOT NULL DEFAULT '',
        tags              TEXT    NOT NULL DEFAULT '[]',
        incident_date     TEXT    NOT NULL,
        logged_date       TEXT    NOT NULL,
        repeat_count      INTEGER NOT NULL DEFAULT 0,
        FOREIGN KEY (category)
          REFERENCES ${AppConstants.categoryTable}(name)
          ON UPDATE CASCADE
      )
    ''');

    // ── Performance index on category + date ────────────────
    await db.execute('''
      CREATE INDEX IF NOT EXISTS idx_mistakes_category
        ON ${AppConstants.mistakeTable}(category)
    ''');
    await db.execute('''
      CREATE INDEX IF NOT EXISTS idx_mistakes_incident_date
        ON ${AppConstants.mistakeTable}(incident_date)
    ''');

    // ── Never Again Rules ───────────────────────────────────
    await db.execute('''
      CREATE TABLE IF NOT EXISTS ${AppConstants.neverAgainTable} (
        id         INTEGER PRIMARY KEY AUTOINCREMENT,
        rule       TEXT    NOT NULL,
        context    TEXT,
        created_at TEXT    NOT NULL,
        is_active  INTEGER NOT NULL DEFAULT 1
      )
    ''');

    // ── Seed default categories ─────────────────────────────
    final now = DateTime.now().toIso8601String();
    final batch = db.batch();
    for (final cat in AppConstants.defaultCategories) {
      batch.insert(
        AppConstants.categoryTable,
        {'name': cat, 'is_default': 1, 'created_at': now},
        conflictAlgorithm: ConflictAlgorithm.ignore,
      );
    }
    await batch.commit(noResult: true);
  }

  // ── GENERIC CRUD helpers ───────────────────────────────────

  Future<int> insert(String table, Map<String, dynamic> values) async {
    final db = await database;
    return db.insert(table, values,
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<int> update(
    String table,
    Map<String, dynamic> values,
    String where,
    List<dynamic> whereArgs,
  ) async {
    final db = await database;
    return db.update(table, values, where: where, whereArgs: whereArgs);
  }

  Future<int> delete(
    String table,
    String where,
    List<dynamic> whereArgs,
  ) async {
    final db = await database;
    return db.delete(table, where: where, whereArgs: whereArgs);
  }

  Future<List<Map<String, dynamic>>> query(
    String table, {
    String? where,
    List<dynamic>? whereArgs,
    String? orderBy,
    int? limit,
    int? offset,
    List<String>? columns,
  }) async {
    final db = await database;
    return db.query(
      table,
      columns: columns,
      where: where,
      whereArgs: whereArgs,
      orderBy: orderBy,
      limit: limit,
      offset: offset,
    );
  }

  Future<List<Map<String, dynamic>>> rawQuery(
    String sql, [
    List<dynamic>? args,
  ]) async {
    final db = await database;
    return db.rawQuery(sql, args);
  }

  Future<void> close() async {
    if (_database != null) {
      await _database!.close();
      _database = null;
    }
  }
}
