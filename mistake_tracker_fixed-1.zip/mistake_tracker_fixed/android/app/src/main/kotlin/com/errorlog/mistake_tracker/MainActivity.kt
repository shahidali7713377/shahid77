// android/app/src/main/kotlin/com/errorlog/mistake_tracker/MainActivity.kt

package com.errorlog.mistake_tracker

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {

    private val CHANNEL = "mistake_tracker/overlay"

    // Modern replacement for deprecated onActivityResult
    private lateinit var overlayPermissionLauncher: ActivityResultLauncher<Intent>
    private var pendingPermissionResult: MethodChannel.Result? = null

    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)

        // Register the launcher BEFORE onStart / configureFlutterEngine
        overlayPermissionLauncher = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { _ ->
            // Called when the user returns from the system Settings screen
            val granted = hasOverlayPermission()
            pendingPermissionResult?.success(granted)
            pendingPermissionResult = null
        }
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            CHANNEL
        ).setMethodCallHandler { call, result ->
            when (call.method) {

                // ── Permission check ───────────────────────────────────────
                "checkOverlayPermission" -> {
                    result.success(hasOverlayPermission())
                }

                // ── Permission request ─────────────────────────────────────
                "requestOverlayPermission" -> {
                    if (hasOverlayPermission()) {
                        result.success(true)
                    } else {
                        // Store the result callback; it is resolved when the
                        // user returns from system Settings (via the launcher).
                        pendingPermissionResult = result
                        val intent = Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")
                        )
                        overlayPermissionLauncher.launch(intent)
                    }
                }

                // ── Show overlay ───────────────────────────────────────────
                "showOverlay" -> {
                    if (!hasOverlayPermission()) {
                        result.error(
                            "NO_PERMISSION",
                            "SYSTEM_ALERT_WINDOW permission not granted. " +
                            "Call requestOverlayPermission first.",
                            null
                        )
                        return@setMethodCallHandler
                    }
                    if (OverlayService.isRunning) {
                        result.success(true)        // already showing
                        return@setMethodCallHandler
                    }
                    val intent = Intent(this, OverlayService::class.java)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        startForegroundService(intent)
                    } else {
                        startService(intent)
                    }
                    result.success(true)
                }

                // ── Hide overlay ───────────────────────────────────────────
                "hideOverlay" -> {
                    stopService(Intent(this, OverlayService::class.java))
                    result.success(true)
                }

                // ── Running state ──────────────────────────────────────────
                "isOverlayShowing" -> {
                    result.success(OverlayService.isRunning)
                }

                else -> result.notImplemented()
            }
        }
    }

    // ── Helpers ────────────────────────────────────────────────────────────

    private fun hasOverlayPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else {
            true // Pre-M: permission granted at install time
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        // Cleanup: if user force-kills the app the service keeps running,
        // which is the desired behaviour for an overlay app.
    }
}
