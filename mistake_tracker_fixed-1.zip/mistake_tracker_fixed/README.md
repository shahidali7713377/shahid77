# ⚠ ErrorLog — Life Lessons Database

> *"Mistakes are data. Data improves decisions."*

A fully offline, privacy-focused Flutter app that turns your failures into a structured, searchable database of life lessons.

---

## 🏗 Architecture: MVVM + Clean Architecture

```
lib/
├── core/
│   └── constants/
│       ├── app_constants.dart      # App-wide constants
│       └── app_theme.dart          # Colors, typography, themes
│
├── data/
│   ├── datasources/
│   │   └── database_helper.dart   # SQLite + FTS5
│   ├── models/
│   │   └── models.dart            # Data transfer objects
│   └── repositories/
│       └── repositories.dart      # MistakeRepo, CategoryRepo, NeverAgainRepo
│
├── domain/
│   └── entities/
│       └── entities.dart          # Pure business entities
│
└── presentation/
    ├── providers/                  # ViewModels (ChangeNotifier)
    │   └── providers.dart         # MistakeProvider, AnalyticsProvider, etc.
    ├── screens/
    │   ├── main_screen.dart       # Bottom nav host
    │   ├── home_screen.dart       # List + search
    │   ├── add_edit_mistake_screen.dart
    │   ├── mistake_detail_screen.dart
    │   ├── analytics_screen.dart
    │   ├── regret_reduction_screen.dart
    │   └── categories_settings_screen.dart
    └── widgets/
        └── app_widgets.dart       # Reusable components
```

---

## ✅ Features Implemented

| # | Feature | Status |
|---|---------|--------|
| 1 | Mistake Entry (title, desc, category, costs, emotion, lesson) | ✅ |
| 2 | Categorization + CRUD + Merge | ✅ |
| 3 | Smart Analytics Dashboard (charts, trends) | ✅ |
| 4 | FTS5 Full-Text Search + Advanced Filters | ✅ |
| 5 | Repeat Mistake Detection (Jaccard similarity) | ✅ |
| 6 | Growth Insights & Monthly Patterns | ✅ |
| 7 | Never Again Rules (Regret Reduction Mode) | ✅ |
| 8 | Display Over Other Apps (Android overlay) | ✅ |
| 9 | 100% Offline + No internet permission | ✅ |
| 10 | Dark/Light Theme | ✅ |
| 11 | CSV Export | ✅ |
| 12 | Swipe to delete, sort, filter | ✅ |

---

## 🔐 Privacy Architecture

- **Zero internet permission** — `INTERNET` not in manifest
- **Local SQLite** — data never leaves device
- **No analytics** — no Firebase, no Crashlytics
- **No account** — works without login
- **Export local** — CSV saved to device storage only

---

## 🖥 Display Over Other Apps

Implementation uses Android's `SYSTEM_ALERT_WINDOW` permission:

1. User grants permission via Settings > Apps > Special App Access
2. Floating "⚠ Log Mistake" button appears over any app
3. Tapping opens ErrorLog directly
4. Native Kotlin implementation via `MethodChannel("mistake_tracker/overlay")`

---

## 🧠 Similarity Detection Algorithm

Uses **Jaccard similarity** on tokenized word sets:
- Tokenize both titles & descriptions (words > 2 chars)
- Compare intersection / union of word sets  
- Threshold: 0.45 (configurable in AppConstants)
- Alert shown: "You made a similar mistake N times before"

---

## 📊 Database Schema

```sql
mistakes (
  id, title, description, category,
  financial_cost, time_cost_hours, emotional_score,
  lesson_learned, preventive_strategy, tags,
  incident_date, logged_date, repeat_count
)

categories (id, name, is_default, created_at)

never_again_rules (id, rule, context, created_at, is_active)

-- FTS5 virtual table for full-text search
mistakes_fts USING fts5(title, description, lesson_learned, tags)
```

---

## 🚀 Setup

```bash
# Install
flutter pub get

# Run
flutter run

# Build release APK
flutter build apk --release --target-platform android-arm64

# Build app bundle
flutter build appbundle --release
```

### Android Requirements
- minSdkVersion: 21 (Android 5+)
- targetSdkVersion: 34
- Add to `android/app/build.gradle`:
  ```gradle
  minSdkVersion 21
  targetSdkVersion 34
  ```

---

## 📦 Dependencies

| Package | Purpose |
|---------|---------|
| `provider ^6.1.2` | MVVM state management |
| `sqflite ^2.3.3` | Local SQLite database |
| `fl_chart ^0.69.0` | Analytics charts |
| `flutter_animate ^4.5.0` | Smooth animations |
| `flutter_slidable ^3.1.1` | Swipe actions |
| `google_fonts ^6.2.1` | Space Grotesk + DM Sans |
| `share_plus ^9.0.0` | CSV export sharing |
| `permission_handler ^11.3.1` | Overlay permissions |
| `uuid ^4.4.0` | Unique identifiers |

---

## 🎨 Design System

**Font Pair:** Space Grotesk (headers) + DM Sans (body)  
**Primary:** `#DC2626` Crimson — error, urgency, impact  
**Theme:** Deep obsidian dark (`#0A0A0F`) + clean light (`#F8F8FC`)

**Color Coding:**
- 🔴 `#DC2626` — High impact (emotional ≥ 7)  
- 🟠 `#D97706` — Medium impact (emotional ≥ 4)  
- 🟢 `#059669` — Low impact (emotional < 4)
