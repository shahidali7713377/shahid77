// lib/presentation/screens/outfit_planner_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../core/theme/app_theme.dart';
import '../../core/constants/app_constants.dart';
import '../../providers/providers.dart';
import '../widgets/app_widgets.dart';

class OutfitPlannerScreen extends ConsumerWidget {
  const OutfitPlannerScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final outfits = ref.watch(outfitProvider);
    final suggestion = ref.watch(outfitSuggestionProvider);
    final profile = ref.watch(userProfileProvider);

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Outfit Planner 👗'),
        backgroundColor: AppColors.background,
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () => _showAddOutfitDialog(context, ref),
          ),
        ],
      ),
      body: outfits.isEmpty
          ? EmptyStateWidget(
              emoji: '👚',
              title: 'No outfits in your wardrobe',
              subtitle: 'Add clothing items to get AI outfit suggestions',
              actionLabel: 'Add First Item',
              onAction: () => _showAddOutfitDialog(context, ref),
            )
          : SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Today's Suggestion
                  if (suggestion != null) ...[
                    _SuggestionCard(
                      suggestion: suggestion,
                      onAccept: () {
                        for (final item in suggestion.items) {
                          ref.read(outfitProvider.notifier).markWorn(item.id);
                        }
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: const Text('✅ Outfit logged as worn!'),
                            backgroundColor: AppColors.success,
                            behavior: SnackBarBehavior.floating,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12)),
                          ),
                        );
                      },
                    ).animate().fadeIn(delay: 100.ms),
                    const SizedBox(height: 24),
                  ] else
                    Container(
                      padding: const EdgeInsets.all(16),
                      margin: const EdgeInsets.only(bottom: 24),
                      decoration: BoxDecoration(
                        color: AppColors.warning.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(16),
                        border:
                            Border.all(color: AppColors.warning.withOpacity(0.3)),
                      ),
                      child: const Row(
                        children: [
                          Icon(Icons.info_outline, color: AppColors.warning),
                          SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              'All items were worn recently. Add more to your wardrobe!',
                              style: TextStyle(
                                  color: AppColors.warning, fontSize: 13),
                            ),
                          ),
                        ],
                      ),
                    ),

                  // Rotation Days Config
                  _RotationConfig(
                    days: profile.outfitRotationDays,
                    onChanged: (days) async {
                      final updated = profile;
                      updated.outfitRotationDays = days;
                      await ref
                          .read(userProfileProvider.notifier)
                          .updateProfile(updated);
                    },
                  ).animate().fadeIn(delay: 200.ms),

                  const SizedBox(height: 24),

                  // Wardrobe by Category
                  const SectionHeader(title: 'Your Wardrobe'),
                  const SizedBox(height: 12),

                  ...ClothingCategory.values.map((cat) {
                    final items = outfits
                        .where((o) => o.category == cat)
                        .toList();
                    if (items.isEmpty) return const SizedBox.shrink();
                    return _CategorySection(
                      category: cat,
                      items: items,
                      rotationDays: profile.outfitRotationDays,
                      onDelete: (id) =>
                          ref.read(outfitProvider.notifier).delete(id),
                      onMarkWorn: (id) =>
                          ref.read(outfitProvider.notifier).markWorn(id),
                    );
                  }),

                  const SizedBox(height: 80),
                ],
              ),
            ),
      floatingActionButton: outfits.isNotEmpty
          ? FloatingActionButton.extended(
              onPressed: () => _showAddOutfitDialog(context, ref),
              backgroundColor: AppColors.primary,
              icon: const Icon(Icons.add, color: Colors.white),
              label: const Text('Add Item',
                  style: TextStyle(color: Colors.white)),
            )
          : null,
    );
  }
}

class _SuggestionCard extends StatelessWidget {
  final OutfitSuggestion suggestion;
  final VoidCallback onAccept;

  const _SuggestionCard(
      {required this.suggestion, required this.onAccept});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            const Color(0xFFFF6B9D).withOpacity(0.15),
            AppColors.primary.withOpacity(0.08),
          ],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFFF6B9D).withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: const Color(0xFFFF6B9D).withOpacity(0.2),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Text('✨', style: TextStyle(fontSize: 18)),
              ),
              const SizedBox(width: 12),
              const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Today\'s AI Outfit',
                    style: TextStyle(
                      color: AppColors.textSecondary,
                      fontSize: 12,
                    ),
                  ),
                  Text(
                    'Curated for you',
                    style: TextStyle(
                      color: AppColors.textPrimary,
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
              const Spacer(),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: AppColors.success.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  '${(suggestion.matchScore * 100).toInt()}% match',
                  style: const TextStyle(
                      color: AppColors.success,
                      fontSize: 11,
                      fontWeight: FontWeight.w600),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),

          // Outfit Items
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: suggestion.items
                .map((item) => _OutfitItemChip(item: item))
                .toList(),
          ),

          const SizedBox(height: 12),
          Text(
            suggestion.reasoning,
            style: const TextStyle(
              color: AppColors.textSecondary,
              fontSize: 12,
              height: 1.5,
            ),
          ),
          const SizedBox(height: 16),
          ElevatedButton.icon(
            onPressed: onAccept,
            icon: const Icon(Icons.check_circle_outline, size: 18),
            label: const Text('Wear This Today'),
            style: ElevatedButton.styleFrom(
              minimumSize: const Size(double.infinity, 46),
              backgroundColor: const Color(0xFFFF6B9D),
            ),
          ),
        ],
      ),
    );
  }
}

class _OutfitItemChip extends StatelessWidget {
  final OutfitItemModel item;
  const _OutfitItemChip({required this.item});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: AppColors.surfaceVariant,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: const Color(0xFF2A2A4A)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(item.category.emoji, style: const TextStyle(fontSize: 14)),
          const SizedBox(width: 6),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                item.name,
                style: const TextStyle(
                  color: AppColors.textPrimary,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
              Text(
                item.color,
                style: const TextStyle(
                  color: AppColors.textMuted,
                  fontSize: 10,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _RotationConfig extends StatelessWidget {
  final int days;
  final ValueChanged<int> onChanged;

  const _RotationConfig({required this.days, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.cardBackground,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF2A2A4A)),
      ),
      child: Row(
        children: [
          const Icon(Icons.rotate_right, color: AppColors.primary, size: 20),
          const SizedBox(width: 12),
          const Expanded(
            child: Text(
              'Rotation Period',
              style: TextStyle(
                color: AppColors.textPrimary,
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          Row(
            children: [
              GestureDetector(
                onTap: () => days > 1 ? onChanged(days - 1) : null,
                child: Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                    color: AppColors.surfaceVariant,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Icon(Icons.remove,
                      size: 16, color: AppColors.textSecondary),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: Text(
                  '$days days',
                  style: const TextStyle(
                    color: AppColors.primary,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              GestureDetector(
                onTap: () => onChanged(days + 1),
                child: Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                    color: AppColors.surfaceVariant,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Icon(Icons.add,
                      size: 16, color: AppColors.textSecondary),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _CategorySection extends StatelessWidget {
  final ClothingCategory category;
  final List<OutfitItemModel> items;
  final int rotationDays;
  final Function(String) onDelete;
  final Function(String) onMarkWorn;

  const _CategorySection({
    required this.category,
    required this.items,
    required this.rotationDays,
    required this.onDelete,
    required this.onMarkWorn,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 12),
          child: Row(
            children: [
              Text(category.emoji, style: const TextStyle(fontSize: 16)),
              const SizedBox(width: 8),
              Text(
                category.label,
                style: const TextStyle(
                  color: AppColors.textSecondary,
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: AppColors.surfaceVariant,
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(
                  '${items.length}',
                  style: const TextStyle(
                    color: AppColors.textMuted,
                    fontSize: 11,
                  ),
                ),
              ),
            ],
          ),
        ),
        ...items.map((item) => _OutfitItemTile(
              item: item,
              rotationDays: rotationDays,
              onDelete: () => onDelete(item.id),
              onMarkWorn: () => onMarkWorn(item.id),
            )),
      ],
    );
  }
}

class _OutfitItemTile extends StatelessWidget {
  final OutfitItemModel item;
  final int rotationDays;
  final VoidCallback onDelete;
  final VoidCallback onMarkWorn;

  const _OutfitItemTile({
    required this.item,
    required this.rotationDays,
    required this.onDelete,
    required this.onMarkWorn,
  });

  @override
  Widget build(BuildContext context) {
    final recentlyWorn = item.wasWornWithinDays(rotationDays);
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.cardBackground,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: recentlyWorn
              ? AppColors.warning.withOpacity(0.3)
              : const Color(0xFF2A2A4A),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: AppColors.primary.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10),
            ),
            alignment: Alignment.center,
            child: Text(item.category.emoji,
                style: const TextStyle(fontSize: 18)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item.name,
                  style: const TextStyle(
                    color: AppColors.textPrimary,
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    _Tag(item.color),
                    const SizedBox(width: 4),
                    _Tag(item.formality.label),
                    if (recentlyWorn) ...[
                      const SizedBox(width: 4),
                      _Tag('Recently Worn',
                          color: AppColors.warning),
                    ],
                  ],
                ),
              ],
            ),
          ),
          PopupMenuButton<String>(
            icon: const Icon(Icons.more_vert,
                color: AppColors.textMuted, size: 18),
            color: AppColors.surfaceVariant,
            onSelected: (value) {
              if (value == 'worn') onMarkWorn();
              if (value == 'delete') onDelete();
            },
            itemBuilder: (_) => [
              const PopupMenuItem(
                value: 'worn',
                child: Text('Mark as Worn',
                    style: TextStyle(color: AppColors.textPrimary)),
              ),
              const PopupMenuItem(
                value: 'delete',
                child: Text('Remove',
                    style: TextStyle(color: AppColors.error)),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _Tag extends StatelessWidget {
  final String label;
  final Color? color;
  const _Tag(this.label, {this.color});

  @override
  Widget build(BuildContext context) {
    final c = color ?? AppColors.textMuted;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: c.withOpacity(0.1),
        borderRadius: BorderRadius.circular(4),
      ),
      child: Text(label, style: TextStyle(color: c, fontSize: 10)),
    );
  }
}

void _showAddOutfitDialog(BuildContext context, WidgetRef ref) {
  showModalBottomSheet(
    context: context,
    backgroundColor: AppColors.surface,
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
    ),
    builder: (_) => const _AddOutfitSheet(),
  );
}

class _AddOutfitSheet extends ConsumerStatefulWidget {
  const _AddOutfitSheet();

  @override
  ConsumerState<_AddOutfitSheet> createState() => _AddOutfitSheetState();
}

class _AddOutfitSheetState extends ConsumerState<_AddOutfitSheet> {
  final _nameController = TextEditingController();
  final _colorController = TextEditingController();
  ClothingCategory _category = ClothingCategory.top;
  FormailityLevel _formality = FormailityLevel.casual;
  final List<WeatherSuitability> _weather = [WeatherSuitability.allWeather];

  @override
  void dispose() {
    _nameController.dispose();
    _colorController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_nameController.text.trim().isEmpty ||
        _colorController.text.trim().isEmpty) return;

    await ref.read(outfitProvider.notifier).addItem(
          name: _nameController.text.trim(),
          category: _category,
          color: _colorController.text.trim(),
          formality: _formality,
          weather: _weather,
        );

    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 20,
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            const Center(
              child: Text(
                'Add Clothing Item',
                style: TextStyle(
                  color: AppColors.textPrimary,
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            const SizedBox(height: 20),

            TextField(
              controller: _nameController,
              style: const TextStyle(color: AppColors.textPrimary),
              decoration: const InputDecoration(labelText: 'Item Name'),
            ),
            const SizedBox(height: 12),

            TextField(
              controller: _colorController,
              style: const TextStyle(color: AppColors.textPrimary),
              decoration: const InputDecoration(labelText: 'Color'),
            ),
            const SizedBox(height: 16),

            const Text('Category',
                style: TextStyle(
                    color: AppColors.textSecondary, fontSize: 13)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: ClothingCategory.values
                  .map((cat) => GestureDetector(
                        onTap: () =>
                            setState(() => _category = cat),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: _category == cat
                                ? AppColors.primary.withOpacity(0.2)
                                : AppColors.surfaceVariant,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: _category == cat
                                  ? AppColors.primary
                                  : const Color(0xFF2A2A4A),
                            ),
                          ),
                          child: Text(
                            '${cat.emoji} ${cat.label}',
                            style: TextStyle(
                              color: _category == cat
                                  ? AppColors.primary
                                  : AppColors.textSecondary,
                              fontSize: 12,
                            ),
                          ),
                        ),
                      ))
                  .toList(),
            ),
            const SizedBox(height: 16),

            const Text('Formality',
                style: TextStyle(
                    color: AppColors.textSecondary, fontSize: 13)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: FormailityLevel.values
                  .map((f) => GestureDetector(
                        onTap: () =>
                            setState(() => _formality = f),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: _formality == f
                                ? AppColors.primary.withOpacity(0.2)
                                : AppColors.surfaceVariant,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: _formality == f
                                  ? AppColors.primary
                                  : const Color(0xFF2A2A4A),
                            ),
                          ),
                          child: Text(
                            f.label,
                            style: TextStyle(
                              color: _formality == f
                                  ? AppColors.primary
                                  : AppColors.textSecondary,
                              fontSize: 12,
                            ),
                          ),
                        ),
                      ))
                  .toList(),
            ),
            const SizedBox(height: 24),

            GradientButton(
              label: 'Add to Wardrobe',
              onPressed: _submit,
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }
}
