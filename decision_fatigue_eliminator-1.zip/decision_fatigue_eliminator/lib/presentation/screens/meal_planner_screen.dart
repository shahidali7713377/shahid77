// lib/presentation/screens/meal_planner_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../core/theme/app_theme.dart';
import '../../core/constants/app_constants.dart';
import '../../providers/providers.dart';
import '../../services/ai_decision_engine.dart';
import '../widgets/app_widgets.dart';

class MealPlannerScreen extends ConsumerStatefulWidget {
  const MealPlannerScreen({super.key});

  @override
  ConsumerState<MealPlannerScreen> createState() =>
      _MealPlannerScreenState();
}

class _MealPlannerScreenState extends ConsumerState<MealPlannerScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  MealType _selectedType = MealType.breakfast;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  MealSuggestion? _getSuggestion(WidgetRef ref, MealType type) {
    final meals = ref.read(mealProvider);
    final profile = ref.read(userProfileProvider);
    final engine = ref.read(aiEngineProvider);
    return engine.suggestMeal(
      availableMeals: meals,
      type: type,
      rotationDays: profile.mealRotationDays,
    );
  }

  @override
  Widget build(BuildContext context) {
    final meals = ref.watch(mealProvider);
    final profile = ref.watch(userProfileProvider);

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Meal Planner 🍽️'),
        backgroundColor: AppColors.background,
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () => _showAddMealDialog(context, ref),
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: AppColors.primary,
          labelColor: AppColors.primary,
          unselectedLabelColor: AppColors.textMuted,
          tabs: MealType.values
              .map((t) => Tab(text: t.emoji + t.label))
              .toList(),
          onTap: (index) =>
              setState(() => _selectedType = MealType.values[index]),
        ),
      ),
      body: meals.isEmpty
          ? EmptyStateWidget(
              emoji: '🥘',
              title: 'No meals in your library',
              subtitle:
                  'Add meals to get AI-powered meal suggestions and weekly plans',
              actionLabel: 'Add First Meal',
              onAction: () => _showAddMealDialog(context, ref),
            )
          : TabBarView(
              controller: _tabController,
              children: MealType.values.map((type) {
                final typeMeals = meals
                    .where((m) => m.mealType == type)
                    .toList();
                final suggestion = _getSuggestion(ref, type);

                return SingleChildScrollView(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // AI Suggestion
                      if (suggestion != null)
                        _MealSuggestionCard(
                          suggestion: suggestion,
                          onAccept: () {
                            ref
                                .read(mealProvider.notifier)
                                .markConsumed(suggestion.meal.id);
                            ref.read(decisionProvider.notifier).addDecision(
                                  title: suggestion.meal.name,
                                  category: DecisionCategory.food,
                                  effortLevel: EffortLevel.low,
                                  isAutomated: true,
                                  usedAI: true,
                                );
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text(
                                    '✅ ${suggestion.meal.name} logged!'),
                                backgroundColor: AppColors.success,
                                behavior: SnackBarBehavior.floating,
                                shape: RoundedRectangleBorder(
                                    borderRadius:
                                        BorderRadius.circular(12)),
                              ),
                            );
                          },
                        ).animate().fadeIn(delay: 100.ms)
                      else
                        _NoMealsWarning(type: type),

                      const SizedBox(height: 24),

                      // Meal Library for this type
                      if (typeMeals.isNotEmpty) ...[
                        SectionHeader(
                          title: '${type.emoji} ${type.label} Library',
                          action: 'Add',
                          onAction: () => _showAddMealDialog(context, ref),
                        ),
                        const SizedBox(height: 12),
                        ...typeMeals.asMap().entries.map(
                          (e) => _MealTile(
                            meal: e.value,
                            rotationDays: profile.mealRotationDays,
                            onDelete: () => ref
                                .read(mealProvider.notifier)
                                .delete(e.value.id),
                            onMarkConsumed: () => ref
                                .read(mealProvider.notifier)
                                .markConsumed(e.value.id),
                          ).animate().fadeIn(
                              delay:
                                  Duration(milliseconds: 150 + e.key * 50)),
                        ),
                      ] else
                        _EmptyTypeState(type: type),

                      const SizedBox(height: 80),
                    ],
                  ),
                );
              }).toList(),
            ),
      floatingActionButton: meals.isNotEmpty
          ? FloatingActionButton.extended(
              onPressed: () => _showAddMealDialog(context, ref),
              backgroundColor: const Color(0xFF4ECDC4),
              icon: const Icon(Icons.restaurant_menu, color: Colors.white),
              label:
                  const Text('Add Meal', style: TextStyle(color: Colors.white)),
            )
          : null,
    );
  }
}

class _MealSuggestionCard extends StatelessWidget {
  final MealSuggestion suggestion;
  final VoidCallback onAccept;

  const _MealSuggestionCard(
      {required this.suggestion, required this.onAccept});

  @override
  Widget build(BuildContext context) {
    final meal = suggestion.meal;
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            const Color(0xFF4ECDC4).withOpacity(0.15),
            AppColors.primary.withOpacity(0.08),
          ],
        ),
        borderRadius: BorderRadius.circular(20),
        border:
            Border.all(color: const Color(0xFF4ECDC4).withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: const Color(0xFF4ECDC4).withOpacity(0.2),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(meal.mealType.emoji,
                    style: const TextStyle(fontSize: 18)),
              ),
              const SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('AI Recommendation',
                      style: TextStyle(
                          color: AppColors.textSecondary, fontSize: 12)),
                  Text(meal.mealType.label,
                      style: const TextStyle(
                        color: AppColors.textPrimary,
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                      )),
                ],
              ),
              const Spacer(),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: AppColors.success.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  '${(suggestion.matchScore * 100).toInt()}% match',
                  style: const TextStyle(
                      color: AppColors.success,
                      fontSize: 11,
                      fontWeight: FontWeight.w600),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Text(
            meal.name,
            style: const TextStyle(
              color: AppColors.textPrimary,
              fontSize: 22,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              _MealStat('🔥 ${meal.calories} cal'),
              const SizedBox(width: 8),
              _MealStat('⏱ ${meal.prepTimeMinutes}m prep'),
              const SizedBox(width: 8),
              if (meal.dietTags.isNotEmpty)
                _MealStat(meal.dietTags.first.emoji),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            suggestion.reasoning,
            style: const TextStyle(
              color: AppColors.textSecondary,
              fontSize: 12,
              height: 1.5,
            ),
          ),
          const SizedBox(height: 16),
          ElevatedButton.icon(
            onPressed: onAccept,
            icon: const Icon(Icons.check_circle_outline, size: 18),
            label: const Text('Log This Meal'),
            style: ElevatedButton.styleFrom(
              minimumSize: const Size(double.infinity, 46),
              backgroundColor: const Color(0xFF4ECDC4),
              foregroundColor: Colors.white,
            ),
          ),
        ],
      ),
    );
  }
}

class _MealStat extends StatelessWidget {
  final String text;
  const _MealStat(this.text);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: AppColors.surfaceVariant,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(text,
          style: const TextStyle(color: AppColors.textSecondary, fontSize: 11)),
    );
  }
}

class _NoMealsWarning extends StatelessWidget {
  final MealType type;
  const _NoMealsWarning({required this.type});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.warning.withOpacity(0.1),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.warning.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          const Icon(Icons.info_outline, color: AppColors.warning, size: 18),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              'No ${type.label} suggestions right now. All recent meals eaten or none added yet.',
              style: const TextStyle(color: AppColors.warning, fontSize: 12),
            ),
          ),
        ],
      ),
    );
  }
}

class _EmptyTypeState extends StatelessWidget {
  final MealType type;
  const _EmptyTypeState({required this.type});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Text(
          'No ${type.label} meals yet. Tap + to add some!',
          style: const TextStyle(color: AppColors.textMuted, fontSize: 14),
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}

class _MealTile extends StatelessWidget {
  final MealModel meal;
  final int rotationDays;
  final VoidCallback onDelete;
  final VoidCallback onMarkConsumed;

  const _MealTile({
    required this.meal,
    required this.rotationDays,
    required this.onDelete,
    required this.onMarkConsumed,
  });

  @override
  Widget build(BuildContext context) {
    final recentlyEaten = meal.wasConsumedWithinDays(rotationDays);
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.cardBackground,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: recentlyEaten
              ? AppColors.warning.withOpacity(0.3)
              : const Color(0xFF2A2A4A),
        ),
      ),
      child: Row(
        children: [
          Text(meal.mealType.emoji, style: const TextStyle(fontSize: 24)),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  meal.name,
                  style: const TextStyle(
                    color: AppColors.textPrimary,
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    _Tag('${meal.calories} cal'),
                    const SizedBox(width: 4),
                    _Tag('${meal.prepTimeMinutes}m'),
                    if (meal.dietTags.isNotEmpty) ...[
                      const SizedBox(width: 4),
                      _Tag(meal.dietTags.first.label),
                    ],
                    if (recentlyEaten) ...[
                      const SizedBox(width: 4),
                      _Tag('Recent', color: AppColors.warning),
                    ],
                  ],
                ),
              ],
            ),
          ),
          Row(
            children: [
              Text(
                '⭐ ${meal.averageSatisfaction.toStringAsFixed(1)}',
                style: const TextStyle(
                    color: AppColors.textSecondary, fontSize: 12),
              ),
              PopupMenuButton<String>(
                icon: const Icon(Icons.more_vert,
                    color: AppColors.textMuted, size: 18),
                color: AppColors.surfaceVariant,
                onSelected: (value) {
                  if (value == 'eaten') onMarkConsumed();
                  if (value == 'delete') onDelete();
                },
                itemBuilder: (_) => [
                  const PopupMenuItem(
                    value: 'eaten',
                    child: Text('Mark as Eaten',
                        style: TextStyle(color: AppColors.textPrimary)),
                  ),
                  const PopupMenuItem(
                    value: 'delete',
                    child: Text('Remove',
                        style: TextStyle(color: AppColors.error)),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _Tag extends StatelessWidget {
  final String text;
  final Color? color;
  const _Tag(this.text, {this.color});

  @override
  Widget build(BuildContext context) {
    final c = color ?? AppColors.textMuted;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: c.withOpacity(0.1),
        borderRadius: BorderRadius.circular(4),
      ),
      child: Text(text, style: TextStyle(color: c, fontSize: 10)),
    );
  }
}

void _showAddMealDialog(BuildContext context, WidgetRef ref) {
  showModalBottomSheet(
    context: context,
    backgroundColor: AppColors.surface,
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
    ),
    builder: (_) => const _AddMealSheet(),
  );
}

class _AddMealSheet extends ConsumerStatefulWidget {
  const _AddMealSheet();

  @override
  ConsumerState<_AddMealSheet> createState() => _AddMealSheetState();
}

class _AddMealSheetState extends ConsumerState<_AddMealSheet> {
  final _nameController = TextEditingController();
  final _caloriesController = TextEditingController();
  final _prepTimeController = TextEditingController();
  final _ingredientsController = TextEditingController();
  MealType _type = MealType.breakfast;
  final Set<DietTag> _selectedTags = {};

  @override
  void dispose() {
    _nameController.dispose();
    _caloriesController.dispose();
    _prepTimeController.dispose();
    _ingredientsController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_nameController.text.trim().isEmpty) return;

    await ref.read(mealProvider.notifier).addMeal(
          name: _nameController.text.trim(),
          type: _type,
          calories: int.tryParse(_caloriesController.text) ?? 400,
          prepTimeMinutes: int.tryParse(_prepTimeController.text) ?? 15,
          dietTags: _selectedTags.toList(),
          ingredients: _ingredientsController.text
              .split(',')
              .map((s) => s.trim())
              .where((s) => s.isNotEmpty)
              .toList(),
        );

    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 20,
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            const Center(
              child: Text(
                'Add Meal',
                style: TextStyle(
                  color: AppColors.textPrimary,
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            const SizedBox(height: 20),

            TextField(
              controller: _nameController,
              style: const TextStyle(color: AppColors.textPrimary),
              decoration: const InputDecoration(labelText: 'Meal Name'),
            ),
            const SizedBox(height: 10),

            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _caloriesController,
                    keyboardType: TextInputType.number,
                    style: const TextStyle(color: AppColors.textPrimary),
                    decoration:
                        const InputDecoration(labelText: 'Calories'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: TextField(
                    controller: _prepTimeController,
                    keyboardType: TextInputType.number,
                    style: const TextStyle(color: AppColors.textPrimary),
                    decoration:
                        const InputDecoration(labelText: 'Prep (min)'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),

            TextField(
              controller: _ingredientsController,
              style: const TextStyle(color: AppColors.textPrimary),
              decoration: const InputDecoration(
                  labelText: 'Ingredients (comma separated)'),
            ),
            const SizedBox(height: 16),

            const Text('Meal Type',
                style: TextStyle(
                    color: AppColors.textSecondary, fontSize: 13)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: MealType.values
                  .map((t) => GestureDetector(
                        onTap: () => setState(() => _type = t),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: _type == t
                                ? AppColors.primary.withOpacity(0.2)
                                : AppColors.surfaceVariant,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: _type == t
                                  ? AppColors.primary
                                  : const Color(0xFF2A2A4A),
                            ),
                          ),
                          child: Text(
                            '${t.emoji} ${t.label}',
                            style: TextStyle(
                              color: _type == t
                                  ? AppColors.primary
                                  : AppColors.textSecondary,
                              fontSize: 12,
                            ),
                          ),
                        ),
                      ))
                  .toList(),
            ),
            const SizedBox(height: 16),

            const Text('Diet Tags',
                style: TextStyle(
                    color: AppColors.textSecondary, fontSize: 13)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: DietTag.values
                  .map((tag) => GestureDetector(
                        onTap: () => setState(() {
                          if (_selectedTags.contains(tag)) {
                            _selectedTags.remove(tag);
                          } else {
                            _selectedTags.add(tag);
                          }
                        }),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 5),
                          decoration: BoxDecoration(
                            color: _selectedTags.contains(tag)
                                ? AppColors.secondary.withOpacity(0.2)
                                : AppColors.surfaceVariant,
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(
                              color: _selectedTags.contains(tag)
                                  ? AppColors.secondary
                                  : const Color(0xFF2A2A4A),
                            ),
                          ),
                          child: Text(
                            '${tag.emoji} ${tag.label}',
                            style: TextStyle(
                              color: _selectedTags.contains(tag)
                                  ? AppColors.secondary
                                  : AppColors.textSecondary,
                              fontSize: 11,
                            ),
                          ),
                        ),
                      ))
                  .toList(),
            ),
            const SizedBox(height: 20),

            GradientButton(
              label: 'Add Meal',
              colors: const [Color(0xFF4ECDC4), Color(0xFF44A08D)],
              onPressed: _submit,
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }
}
