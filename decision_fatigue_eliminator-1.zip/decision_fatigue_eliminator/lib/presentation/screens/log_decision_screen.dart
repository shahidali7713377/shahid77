// lib/presentation/screens/log_decision_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../core/theme/app_theme.dart';
import '../../core/constants/app_constants.dart';
import '../../providers/providers.dart';
import '../widgets/app_widgets.dart';

class LogDecisionScreen extends ConsumerStatefulWidget {
  const LogDecisionScreen({super.key});

  @override
  ConsumerState<LogDecisionScreen> createState() => _LogDecisionScreenState();
}

class _LogDecisionScreenState extends ConsumerState<LogDecisionScreen> {
  final _titleController = TextEditingController();
  final _emotionalController = TextEditingController();
  DecisionCategory _selectedCategory = DecisionCategory.misc;
  EffortLevel _selectedEffort = EffortLevel.low;
  bool _isLoading = false;

  @override
  void dispose() {
    _titleController.dispose();
    _emotionalController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_titleController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a decision title')),
      );
      return;
    }

    setState(() => _isLoading = true);

    await ref.read(decisionProvider.notifier).addDecision(
          title: _titleController.text.trim(),
          category: _selectedCategory,
          effortLevel: _selectedEffort,
          emotionalImpact: _emotionalController.text.trim().isEmpty
              ? null
              : _emotionalController.text.trim(),
        );

    if (mounted) {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('✅ Decision logged!'),
          backgroundColor: AppColors.success,
          behavior: SnackBarBehavior.floating,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Log Decision'),
        backgroundColor: AppColors.background,
        leading: IconButton(
          icon: const Icon(Icons.close),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Title
            _FormLabel('Decision Title'),
            const SizedBox(height: 8),
            TextField(
              controller: _titleController,
              style: const TextStyle(color: AppColors.textPrimary),
              decoration: const InputDecoration(
                hintText: 'e.g. What to have for lunch...',
              ),
              textCapitalization: TextCapitalization.sentences,
            ).animate().fadeIn(delay: 100.ms),

            const SizedBox(height: 24),

            // Category
            _FormLabel('Category'),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: DecisionCategory.values
                  .map((cat) => CategoryBadge(
                        category: cat,
                        selected: _selectedCategory == cat,
                        onTap: () =>
                            setState(() => _selectedCategory = cat),
                      ))
                  .toList(),
            ).animate().fadeIn(delay: 200.ms),

            const SizedBox(height: 24),

            // Effort Level
            _FormLabel('Mental Effort Required'),
            const SizedBox(height: 12),
            EffortSelector(
              selected: _selectedEffort,
              onChanged: (level) =>
                  setState(() => _selectedEffort = level),
            ).animate().fadeIn(delay: 300.ms),

            const SizedBox(height: 24),

            // Emotional Impact (Optional)
            _FormLabel('Emotional Impact (Optional)'),
            const SizedBox(height: 8),
            TextField(
              controller: _emotionalController,
              style: const TextStyle(color: AppColors.textPrimary),
              decoration: const InputDecoration(
                hintText: 'How does this decision make you feel?',
              ),
              textCapitalization: TextCapitalization.sentences,
            ).animate().fadeIn(delay: 400.ms),

            const SizedBox(height: 32),

            // Cognitive Weight Preview
            _CognitiveWeightPreview(
              category: _selectedCategory,
              effort: _selectedEffort,
            ).animate().fadeIn(delay: 500.ms),

            const SizedBox(height: 24),

            // Submit Button
            GradientButton(
              label: _isLoading ? 'Logging...' : 'Log Decision',
              icon: Icons.add_circle_outline,
              onPressed: _isLoading ? null : _submit,
            ).animate().fadeIn(delay: 600.ms),

            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }
}

class _FormLabel extends StatelessWidget {
  final String text;
  const _FormLabel(this.text);

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: const TextStyle(
        color: AppColors.textSecondary,
        fontSize: 14,
        fontWeight: FontWeight.w600,
      ),
    );
  }
}

class _CognitiveWeightPreview extends StatelessWidget {
  final DecisionCategory category;
  final EffortLevel effort;

  const _CognitiveWeightPreview({
    required this.category,
    required this.effort,
  });

  double get _weight {
    double base = effort.value.toDouble();
    switch (category) {
      case DecisionCategory.work:
        return base * 1.5;
      case DecisionCategory.purchase:
        return base * 1.3;
      case DecisionCategory.social:
        return base * 1.2;
      case DecisionCategory.food:
      case DecisionCategory.outfit:
        return base * 0.8;
      default:
        return base * 1.0;
    }
  }

  bool get _isHighValue =>
      effort == EffortLevel.high ||
      ((category == DecisionCategory.work ||
              category == DecisionCategory.study) &&
          effort != EffortLevel.low);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surfaceVariant,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFF2A2A4A)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            '📊 Cognitive Impact Preview',
            style: TextStyle(
              color: AppColors.textSecondary,
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              _PreviewChip(
                label: 'Weight: ${_weight.toStringAsFixed(1)}',
                color: _weight > 3
                    ? AppColors.error
                    : _weight > 2
                        ? AppColors.warning
                        : AppColors.success,
              ),
              const SizedBox(width: 8),
              _PreviewChip(
                label: _isHighValue ? '⭐ High Value' : '🔄 Low Value',
                color: _isHighValue ? AppColors.primary : AppColors.textMuted,
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _PreviewChip extends StatelessWidget {
  final String label;
  final Color color;

  const _PreviewChip({required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: color,
          fontSize: 12,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}
