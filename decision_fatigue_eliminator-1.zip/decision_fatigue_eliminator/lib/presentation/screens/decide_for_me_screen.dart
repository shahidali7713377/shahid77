// lib/presentation/screens/decide_for_me_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../core/theme/app_theme.dart';
import '../../core/constants/app_constants.dart';
import '../../providers/providers.dart';
import '../widgets/app_widgets.dart';

class DecideForMeScreen extends ConsumerStatefulWidget {
  const DecideForMeScreen({super.key});

  @override
  ConsumerState<DecideForMeScreen> createState() =>
      _DecideForMeScreenState();
}

class _DecideForMeScreenState extends ConsumerState<DecideForMeScreen> {
  final _optionController = TextEditingController();
  final List<String> _options = [];
  DecisionCategory _category = DecisionCategory.misc;
  int _energyLevel = 3;
  bool _showResult = false;

  @override
  void dispose() {
    _optionController.dispose();
    super.dispose();
  }

  void _addOption() {
    final text = _optionController.text.trim();
    if (text.isEmpty || _options.contains(text)) return;
    setState(() {
      _options.add(text);
      _optionController.clear();
    });
  }

  void _removeOption(String option) {
    setState(() => _options.remove(option));
    ref.read(aiDecisionProvider.notifier).reset();
    setState(() => _showResult = false);
  }

  Future<void> _decide() async {
    if (_options.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Add at least one option!')),
      );
      return;
    }

    await ref.read(aiDecisionProvider.notifier).decide(
          options: _options,
          category: _category,
          energyLevel: _energyLevel,
        );

    setState(() => _showResult = true);
  }

  Future<void> _acceptDecision(String decision) async {
    await ref.read(decisionProvider.notifier).addDecision(
          title: decision,
          category: _category,
          effortLevel: EffortLevel.low,
          usedAI: true,
          aiRecommendation: decision,
        );

    if (mounted) {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('✅ "${decision}" accepted & logged!'),
          backgroundColor: AppColors.success,
          behavior: SnackBarBehavior.floating,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final aiState = ref.watch(aiDecisionProvider);
    final profile = ref.watch(userProfileProvider);

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Decide For Me 🤖'),
        backgroundColor: AppColors.background,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header Card
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    AppColors.primary.withOpacity(0.15),
                    AppColors.secondary.withOpacity(0.08),
                  ],
                ),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                    color: AppColors.primary.withOpacity(0.2)),
              ),
              child: Column(
                children: [
                  const Text(
                    '🧠',
                    style: TextStyle(fontSize: 48),
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    'Let AI decide for you',
                    style: TextStyle(
                      color: AppColors.textPrimary,
                      fontSize: 20,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Add your options below and tap Decide. AI will pick the best choice based on your history and cognitive state.',
                    style: TextStyle(
                      color: AppColors.textSecondary,
                      fontSize: 13,
                      height: 1.5,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ).animate().fadeIn(delay: 100.ms),

            const SizedBox(height: 24),

            // AI Mode Selector
            const Text(
              'AI Mode',
              style: TextStyle(
                color: AppColors.textSecondary,
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 10),
            Row(
              children: AIDecisionMode.values.map((mode) {
                final isSelected = profile.preferredAIMode == mode;
                return Expanded(
                  child: GestureDetector(
                    onTap: () => ref
                        .read(userProfileProvider.notifier)
                        .updateAIMode(mode),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      margin: const EdgeInsets.only(right: 8),
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      decoration: BoxDecoration(
                        color: isSelected
                            ? AppColors.primary.withOpacity(0.2)
                            : AppColors.surfaceVariant,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: isSelected
                              ? AppColors.primary
                              : const Color(0xFF2A2A4A),
                          width: isSelected ? 1.5 : 1,
                        ),
                      ),
                      child: Column(
                        children: [
                          Text(
                            mode.label,
                            style: TextStyle(
                              color: isSelected
                                  ? AppColors.primary
                                  : AppColors.textSecondary,
                              fontSize: 12,
                              fontWeight: isSelected
                                  ? FontWeight.w700
                                  : FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              }).toList(),
            ).animate().fadeIn(delay: 200.ms),

            const SizedBox(height: 24),

            // Category
            const Text(
              'Category',
              style: TextStyle(
                color: AppColors.textSecondary,
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 10),
            SizedBox(
              height: 40,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: DecisionCategory.values
                    .map((cat) => Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: CategoryBadge(
                            category: cat,
                            selected: _category == cat,
                            onTap: () =>
                                setState(() => _category = cat),
                          ),
                        ))
                    .toList(),
              ),
            ).animate().fadeIn(delay: 300.ms),

            const SizedBox(height: 24),

            // Energy Level
            const Text(
              'Current Energy Level',
              style: TextStyle(
                color: AppColors.textSecondary,
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                const Text('😴', style: TextStyle(fontSize: 20)),
                Expanded(
                  child: Slider(
                    value: _energyLevel.toDouble(),
                    min: 1,
                    max: 5,
                    divisions: 4,
                    onChanged: (v) =>
                        setState(() => _energyLevel = v.toInt()),
                  ),
                ),
                const Text('⚡', style: TextStyle(fontSize: 20)),
              ],
            ).animate().fadeIn(delay: 350.ms),

            const SizedBox(height: 24),

            // Options Input
            const Text(
              'Your Options',
              style: TextStyle(
                color: AppColors.textSecondary,
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 10),

            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _optionController,
                    style:
                        const TextStyle(color: AppColors.textPrimary),
                    decoration: const InputDecoration(
                      hintText: 'Add an option...',
                    ),
                    onSubmitted: (_) => _addOption(),
                  ),
                ),
                const SizedBox(width: 10),
                GestureDetector(
                  onTap: _addOption,
                  child: Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [
                          AppColors.gradientStart,
                          AppColors.gradientEnd
                        ],
                      ),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: const Icon(Icons.add,
                        color: Colors.white, size: 20),
                  ),
                ),
              ],
            ).animate().fadeIn(delay: 400.ms),

            const SizedBox(height: 12),

            // Options List
            ..._options.asMap().entries.map((entry) => Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.symmetric(
                      horizontal: 16, vertical: 12),
                  decoration: BoxDecoration(
                    color: AppColors.surfaceVariant,
                    borderRadius: BorderRadius.circular(12),
                    border:
                        Border.all(color: const Color(0xFF2A2A4A)),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 24,
                        height: 24,
                        decoration: BoxDecoration(
                          color: AppColors.primary.withOpacity(0.2),
                          shape: BoxShape.circle,
                        ),
                        alignment: Alignment.center,
                        child: Text(
                          '${entry.key + 1}',
                          style: const TextStyle(
                            color: AppColors.primary,
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          entry.value,
                          style: const TextStyle(
                            color: AppColors.textPrimary,
                            fontSize: 14,
                          ),
                        ),
                      ),
                      GestureDetector(
                        onTap: () => _removeOption(entry.value),
                        child: const Icon(Icons.close,
                            size: 16,
                            color: AppColors.textMuted),
                      ),
                    ],
                  ),
                ).animate().slideX(begin: 0.2).fadeIn()),

            if (_options.isEmpty)
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppColors.surfaceVariant,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                      color: const Color(0xFF2A2A4A),
                      style: BorderStyle.solid),
                ),
                child: const Center(
                  child: Text(
                    'Add at least 2 options for best results',
                    style: TextStyle(
                        color: AppColors.textMuted, fontSize: 13),
                  ),
                ),
              ),

            const SizedBox(height: 24),

            // Decide Button
            if (!aiState.isLoading && !_showResult)
              GradientButton(
                label: '🎯 Let AI Decide',
                height: 58,
                onPressed: _options.isEmpty ? null : _decide,
              ).animate().fadeIn(delay: 500.ms),

            // Loading State
            if (aiState.isLoading)
              Container(
                height: 58,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: AppColors.surfaceVariant,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        valueColor: AlwaysStoppedAnimation(AppColors.primary),
                      ),
                    ),
                    const SizedBox(width: 12),
                    const Text(
                      'AI is thinking...',
                      style: TextStyle(
                          color: AppColors.textSecondary, fontSize: 15),
                    ),
                  ],
                ),
              ).animate().fadeIn(),

            // AI Result
            if (_showResult && aiState.result != null) ...[
              const SizedBox(height: 16),
              AIResultCard(
                result: aiState.result!,
                onAccept: () =>
                    _acceptDecision(aiState.result!.decision),
                onRetry: () {
                  ref.read(aiDecisionProvider.notifier).reset();
                  setState(() => _showResult = false);
                  _decide();
                },
              ),
            ],

            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }
}
