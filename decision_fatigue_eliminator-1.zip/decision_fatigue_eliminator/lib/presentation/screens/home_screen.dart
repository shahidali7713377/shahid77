// lib/presentation/screens/home_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../core/theme/app_theme.dart';
import '../../core/constants/app_constants.dart';
import '../../providers/providers.dart';
import '../widgets/app_widgets.dart';
import 'decide_for_me_screen.dart';
import 'log_decision_screen.dart';
import 'outfit_planner_screen.dart';
import 'meal_planner_screen.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  String _greeting() {
    final hour = DateTime.now().hour;
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    return 'Good evening';
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final profile = ref.watch(userProfileProvider);
    final loadResult = ref.watch(cognitiveLoadProvider);
    final recommendations = ref.watch(aiRecommendationsProvider);
    final todayDecisions = ref.watch(decisionProvider);

    return Scaffold(
      backgroundColor: AppColors.background,
      body: CustomScrollView(
        slivers: [
          // ─── App Bar ────────────────────────────────────────────────────
          SliverAppBar(
            expandedHeight: 100,
            floating: true,
            pinned: false,
            backgroundColor: AppColors.background,
            flexibleSpace: FlexibleSpaceBar(
              titlePadding:
                  const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
              title: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '${_greeting()}, ${profile.name.split(' ').first} 👋',
                    style: const TextStyle(
                      color: AppColors.textSecondary,
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const Text(
                    'Clear Mind Dashboard',
                    style: TextStyle(
                      color: AppColors.textPrimary,
                      fontSize: 20,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ],
              ),
            ),
            actions: [
              // Minimalist Mode Toggle
              GestureDetector(
                onTap: () => ref
                    .read(userProfileProvider.notifier)
                    .toggleMinimalistMode(),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  margin: const EdgeInsets.only(right: 16, top: 12, bottom: 12),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: profile.minimalistModeEnabled
                        ? AppColors.primary.withOpacity(0.2)
                        : AppColors.surfaceVariant,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: profile.minimalistModeEnabled
                          ? AppColors.primary
                          : const Color(0xFF2A2A4A),
                    ),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        Icons.psychology,
                        size: 14,
                        color: profile.minimalistModeEnabled
                            ? AppColors.primary
                            : AppColors.textMuted,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        profile.minimalistModeEnabled ? 'Zen' : 'Normal',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: profile.minimalistModeEnabled
                              ? AppColors.primary
                              : AppColors.textMuted,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),

          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            sliver: SliverList(
              delegate: SliverChildListDelegate([
                // Minimalist Mode Banner
                if (profile.minimalistModeEnabled)
                  MinimalistModeBanner(
                    onDisable: () => ref
                        .read(userProfileProvider.notifier)
                        .toggleMinimalistMode(),
                  ),

                const SizedBox(height: 16),

                // ─── CLS Gauge ─────────────────────────────────────────────
                CognitiveLoadGauge(loadResult: loadResult),

                const SizedBox(height: 20),

                // ─── Decide For Me Button ──────────────────────────────────
                GradientButton(
                  label: '🤖 Decide For Me',
                  height: 60,
                  fontSize: 17,
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const DecideForMeScreen()),
                  ),
                ).animate().fadeIn(delay: 200.ms).slideY(begin: 0.15),

                const SizedBox(height: 8),

                // ─── Today's Decision Counter ─────────────────────────────
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 20, vertical: 14),
                  decoration: BoxDecoration(
                    color: AppColors.surfaceVariant,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: const Color(0xFF2A2A4A)),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _MiniStat(
                          '${loadResult.totalDecisions}', 'Decisions', '📊'),
                      _Divider(),
                      _MiniStat(
                          '${loadResult.highValueCount}', 'High Value', '⭐'),
                      _Divider(),
                      _MiniStat(
                          '${loadResult.lowValueCount}', 'Low Value', '🔄'),
                      _Divider(),
                      _MiniStat(
                          '${loadResult.automatedCount}', 'Automated', '🤖'),
                    ],
                  ),
                ).animate().fadeIn(delay: 300.ms),

                const SizedBox(height: 24),

                // ─── Quick Actions ─────────────────────────────────────────
                const SectionHeader(title: 'Quick Actions'),
                const SizedBox(height: 12),

                GridView.count(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  crossAxisCount: 2,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                  childAspectRatio: 1.2,
                  children: [
                    QuickActionCard(
                      emoji: '📝',
                      title: 'Log Decision',
                      subtitle: 'Track a new decision',
                      accentColor: AppColors.primary,
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => const LogDecisionScreen()),
                      ),
                    ),
                    QuickActionCard(
                      emoji: '👗',
                      title: "Today's Outfit",
                      subtitle: 'AI picks your look',
                      accentColor: const Color(0xFFFF6B9D),
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => const OutfitPlannerScreen()),
                      ),
                    ),
                    QuickActionCard(
                      emoji: '🍽️',
                      title: "Meal Plan",
                      subtitle: 'Auto-decide your meals',
                      accentColor: const Color(0xFF4ECDC4),
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => const MealPlannerScreen()),
                      ),
                    ),
                    QuickActionCard(
                      emoji: '⚡',
                      title: 'Smart Defaults',
                      subtitle: 'Configure automations',
                      accentColor: const Color(0xFFFFE66D),
                      onTap: () {},
                    ),
                  ],
                ).animate().fadeIn(delay: 400.ms),

                const SizedBox(height: 24),

                // ─── AI Recommendations ────────────────────────────────────
                const SectionHeader(title: '🧠 AI Insights'),
                const SizedBox(height: 12),

                ...recommendations.asMap().entries.map(
                  (entry) => _RecommendationTile(
                    text: entry.value,
                    delay: entry.key * 100,
                  ),
                ),

                const SizedBox(height: 24),

                // ─── Recent Decisions ──────────────────────────────────────
                SectionHeader(
                  title: 'Recent Decisions',
                  action: todayDecisions.isNotEmpty ? 'See all' : null,
                  onAction: () {},
                ),
                const SizedBox(height: 12),

                if (todayDecisions.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 16),
                    child: EmptyStateWidget(
                      emoji: '✨',
                      title: 'No decisions logged yet',
                      subtitle:
                          'Start tracking your decisions to see insights',
                    ),
                  )
                else
                  ...todayDecisions.take(5).map(
                    (d) => _DecisionListTile(decision: d),
                  ),

                const SizedBox(height: 100),
              ]),
            ),
          ),
        ],
      ),
    );
  }
}

class _MiniStat extends StatelessWidget {
  final String value;
  final String label;
  final String emoji;

  const _MiniStat(this.value, this.label, this.emoji);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(emoji, style: const TextStyle(fontSize: 16)),
        const SizedBox(height: 4),
        Text(
          value,
          style: const TextStyle(
            color: AppColors.textPrimary,
            fontSize: 18,
            fontWeight: FontWeight.w800,
          ),
        ),
        Text(
          label,
          style: const TextStyle(color: AppColors.textMuted, fontSize: 10),
        ),
      ],
    );
  }
}

class _Divider extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 30,
      width: 1,
      color: const Color(0xFF2A2A4A),
    );
  }
}

class _RecommendationTile extends StatelessWidget {
  final String text;
  final int delay;

  const _RecommendationTile({required this.text, required this.delay});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: AppColors.cardBackground,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFF2A2A4A)),
      ),
      child: Text(
        text,
        style: const TextStyle(
          color: AppColors.textSecondary,
          fontSize: 13,
          height: 1.4,
        ),
      ),
    ).animate().fadeIn(delay: Duration(milliseconds: delay + 500)).slideX(begin: 0.1);
  }
}

class _DecisionListTile extends ConsumerWidget {
  final decision;

  const _DecisionListTile({required this.decision});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final color = AppColors
        .categoryColors[decision.category.index % AppColors.categoryColors.length];

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: AppColors.cardBackground,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFF2A2A4A)),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: color.withOpacity(0.15),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Text(decision.category.emoji,
                style: const TextStyle(fontSize: 16)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  decision.title,
                  style: const TextStyle(
                    color: AppColors.textPrimary,
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 2),
                Row(
                  children: [
                    Text(
                      decision.category.label,
                      style: const TextStyle(
                        color: AppColors.textMuted,
                        fontSize: 11,
                      ),
                    ),
                    const SizedBox(width: 8),
                    if (decision.isAutomated)
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: AppColors.success.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: const Text('Auto',
                            style: TextStyle(
                                color: AppColors.success, fontSize: 10)),
                      ),
                    if (decision.usedAI) ...[
                      const SizedBox(width: 4),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: AppColors.primary.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: const Text('AI',
                            style: TextStyle(
                                color: AppColors.primary, fontSize: 10)),
                      ),
                    ],
                  ],
                ),
              ],
            ),
          ),
          Text(
            decision.isHighValue ? '⭐' : '🔄',
            style: const TextStyle(fontSize: 16),
          ),
        ],
      ),
    );
  }
}
