// lib/presentation/screens/settings_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../core/theme/app_theme.dart';
import '../../core/constants/app_constants.dart';
import '../../providers/providers.dart';
import '../widgets/app_widgets.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final profile = ref.watch(userProfileProvider);

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Settings ⚙️'),
        backgroundColor: AppColors.background,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Profile Section
            _SectionTitle('Profile'),
            _SettingsCard(
              children: [
                _TextSettingTile(
                  icon: Icons.person_outline,
                  label: 'Your Name',
                  value: profile.name,
                  onEdit: (value) async {
                    final updated = profile;
                    updated.name = value;
                    await ref
                        .read(userProfileProvider.notifier)
                        .updateProfile(updated);
                  },
                ),
                _DividerLine(),
                _NumberSettingTile(
                  icon: Icons.today,
                  label: 'Daily Decision Goal',
                  value: profile.dailyDecisionGoal,
                  min: 10,
                  max: 200,
                  onChanged: (v) async {
                    final updated = profile;
                    updated.dailyDecisionGoal = v;
                    await ref
                        .read(userProfileProvider.notifier)
                        .updateProfile(updated);
                  },
                ),
              ],
            ).animate().fadeIn(delay: 100.ms),

            _SectionTitle('AI Engine'),
            _SettingsCard(
              children: [
                _ToggleTile(
                  icon: Icons.psychology,
                  label: 'Minimalist Mode',
                  subtitle: 'Auto-apply defaults, hide choices',
                  value: profile.minimalistModeEnabled,
                  onChanged: (_) => ref
                      .read(userProfileProvider.notifier)
                      .toggleMinimalistMode(),
                ),
                _DividerLine(),
                _SelectionTile(
                  icon: Icons.auto_awesome,
                  label: 'Default AI Mode',
                  value: profile.preferredAIMode.label,
                  options: AIDecisionMode.values.map((m) => m.label).toList(),
                  onSelected: (label) {
                    final mode = AIDecisionMode.values
                        .firstWhere((m) => m.label == label);
                    ref
                        .read(userProfileProvider.notifier)
                        .updateAIMode(mode);
                  },
                ),
              ],
            ).animate().fadeIn(delay: 150.ms),

            _SectionTitle('Outfit Rotation'),
            _SettingsCard(
              children: [
                _NumberSettingTile(
                  icon: Icons.rotate_right,
                  label: 'Rotation Period',
                  value: profile.outfitRotationDays,
                  min: 1,
                  max: 30,
                  suffix: 'days',
                  onChanged: (v) async {
                    final updated = profile;
                    updated.outfitRotationDays = v;
                    await ref
                        .read(userProfileProvider.notifier)
                        .updateProfile(updated);
                  },
                ),
              ],
            ).animate().fadeIn(delay: 200.ms),

            _SectionTitle('Meal Planning'),
            _SettingsCard(
              children: [
                _NumberSettingTile(
                  icon: Icons.restaurant,
                  label: 'Meal Rotation Period',
                  value: profile.mealRotationDays,
                  min: 1,
                  max: 14,
                  suffix: 'days',
                  onChanged: (v) async {
                    final updated = profile;
                    updated.mealRotationDays = v;
                    await ref
                        .read(userProfileProvider.notifier)
                        .updateProfile(updated);
                  },
                ),
              ],
            ).animate().fadeIn(delay: 250.ms),

            _SectionTitle('Notifications'),
            _SettingsCard(
              children: [
                _ToggleTile(
                  icon: Icons.notifications_outlined,
                  label: 'Push Notifications',
                  subtitle: 'Fatigue alerts and daily summaries',
                  value: profile.notificationsEnabled,
                  onChanged: (v) async {
                    final updated = profile;
                    updated.notificationsEnabled = v;
                    await ref
                        .read(userProfileProvider.notifier)
                        .updateProfile(updated);
                  },
                ),
              ],
            ).animate().fadeIn(delay: 300.ms),

            _SectionTitle('Smart Defaults'),
            _SettingsCard(
              children: [
                _NavigationTile(
                  icon: Icons.bolt,
                  label: 'Manage Smart Defaults',
                  subtitle: 'Configure automatic decision rules',
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const SmartDefaultsScreen()),
                  ),
                ),
              ],
            ).animate().fadeIn(delay: 350.ms),

            _SectionTitle('Data'),
            _SettingsCard(
              children: [
                _NavigationTile(
                  icon: Icons.delete_outline,
                  label: 'Clear Today\'s Decisions',
                  subtitle: 'Remove all decisions logged today',
                  iconColor: AppColors.error,
                  onTap: () => _showClearConfirmDialog(context, ref),
                ),
              ],
            ).animate().fadeIn(delay: 400.ms),

            const SizedBox(height: 16),

            // App Info
            Center(
              child: Column(
                children: [
                  const Text(
                    'Decision Fatigue Eliminator',
                    style: TextStyle(
                      color: AppColors.textMuted,
                      fontSize: 12,
                    ),
                  ),
                  const Text(
                    'v1.0.0 — Built with ❤️ and Flutter',
                    style: TextStyle(
                      color: AppColors.textMuted,
                      fontSize: 11,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  Future<void> _showClearConfirmDialog(
      BuildContext context, WidgetRef ref) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.surface,
        title: const Text('Clear Today\'s Decisions',
            style: TextStyle(color: AppColors.textPrimary)),
        content: const Text(
          'This will remove all decisions logged today. This cannot be undone.',
          style: TextStyle(color: AppColors.textSecondary),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: TextButton.styleFrom(foregroundColor: AppColors.error),
            child: const Text('Clear'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      final decisions = ref.read(decisionProvider);
      for (final d in decisions) {
        await ref.read(decisionProvider.notifier).delete(d.id);
      }
    }
  }
}

class _SectionTitle extends StatelessWidget {
  final String text;
  const _SectionTitle(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 20, bottom: 8),
      child: Text(
        text.toUpperCase(),
        style: const TextStyle(
          color: AppColors.textMuted,
          fontSize: 11,
          fontWeight: FontWeight.w700,
          letterSpacing: 1.2,
        ),
      ),
    );
  }
}

class _SettingsCard extends StatelessWidget {
  final List<Widget> children;
  const _SettingsCard({required this.children});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.cardBackground,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF2A2A4A)),
      ),
      child: Column(children: children),
    );
  }
}

class _ToggleTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final String subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;

  const _ToggleTile({
    required this.icon,
    required this.label,
    required this.subtitle,
    required this.value,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon, color: AppColors.primary, size: 20),
      title: Text(label,
          style: const TextStyle(
              color: AppColors.textPrimary, fontSize: 14)),
      subtitle: Text(subtitle,
          style: const TextStyle(
              color: AppColors.textMuted, fontSize: 12)),
      trailing: Switch(
        value: value,
        onChanged: onChanged,
        activeColor: AppColors.primary,
      ),
      contentPadding:
          const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
    );
  }
}

class _NavigationTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final String subtitle;
  final VoidCallback onTap;
  final Color? iconColor;

  const _NavigationTile({
    required this.icon,
    required this.label,
    required this.subtitle,
    required this.onTap,
    this.iconColor,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: onTap,
      leading: Icon(icon, color: iconColor ?? AppColors.primary, size: 20),
      title: Text(label,
          style: const TextStyle(
              color: AppColors.textPrimary, fontSize: 14)),
      subtitle: Text(subtitle,
          style: const TextStyle(
              color: AppColors.textMuted, fontSize: 12)),
      trailing: const Icon(Icons.chevron_right, color: AppColors.textMuted),
      contentPadding:
          const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
    );
  }
}

class _TextSettingTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Function(String) onEdit;

  const _TextSettingTile({
    required this.icon,
    required this.label,
    required this.value,
    required this.onEdit,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon, color: AppColors.primary, size: 20),
      title: Text(label,
          style: const TextStyle(
              color: AppColors.textPrimary, fontSize: 14)),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(value,
              style: const TextStyle(
                  color: AppColors.textSecondary, fontSize: 14)),
          const SizedBox(width: 4),
          const Icon(Icons.edit_outlined,
              color: AppColors.textMuted, size: 16),
        ],
      ),
      onTap: () async {
        final controller = TextEditingController(text: value);
        final result = await showDialog<String>(
          context: context,
          builder: (ctx) => AlertDialog(
            backgroundColor: AppColors.surface,
            title: Text(label,
                style: const TextStyle(color: AppColors.textPrimary)),
            content: TextField(
              controller: controller,
              style: const TextStyle(color: AppColors.textPrimary),
              decoration: InputDecoration(hintText: label),
              autofocus: true,
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('Cancel'),
              ),
              TextButton(
                onPressed: () =>
                    Navigator.pop(ctx, controller.text),
                child: const Text('Save'),
              ),
            ],
          ),
        );
        if (result != null && result.isNotEmpty) onEdit(result);
      },
      contentPadding:
          const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
    );
  }
}

class _NumberSettingTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final int value;
  final int min;
  final int max;
  final String? suffix;
  final ValueChanged<int> onChanged;

  const _NumberSettingTile({
    required this.icon,
    required this.label,
    required this.value,
    required this.min,
    required this.max,
    required this.onChanged,
    this.suffix,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon, color: AppColors.primary, size: 20),
      title: Text(label,
          style: const TextStyle(
              color: AppColors.textPrimary, fontSize: 14)),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          GestureDetector(
            onTap: () => value > min ? onChanged(value - 1) : null,
            child: Container(
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                color: AppColors.surfaceVariant,
                borderRadius: BorderRadius.circular(6),
              ),
              child: const Icon(Icons.remove,
                  size: 14, color: AppColors.textSecondary),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Text(
              suffix != null ? '$value $suffix' : '$value',
              style: const TextStyle(
                color: AppColors.primary,
                fontWeight: FontWeight.w700,
                fontSize: 13,
              ),
            ),
          ),
          GestureDetector(
            onTap: () => value < max ? onChanged(value + 1) : null,
            child: Container(
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                color: AppColors.surfaceVariant,
                borderRadius: BorderRadius.circular(6),
              ),
              child: const Icon(Icons.add,
                  size: 14, color: AppColors.textSecondary),
            ),
          ),
        ],
      ),
      contentPadding:
          const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
    );
  }
}

class _SelectionTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final List<String> options;
  final ValueChanged<String> onSelected;

  const _SelectionTile({
    required this.icon,
    required this.label,
    required this.value,
    required this.options,
    required this.onSelected,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon, color: AppColors.primary, size: 20),
      title: Text(label,
          style: const TextStyle(
              color: AppColors.textPrimary, fontSize: 14)),
      trailing: PopupMenuButton<String>(
        color: AppColors.surfaceVariant,
        onSelected: onSelected,
        itemBuilder: (_) => options
            .map((o) => PopupMenuItem(
                  value: o,
                  child: Text(o,
                      style: TextStyle(
                        color: o == value
                            ? AppColors.primary
                            : AppColors.textPrimary,
                      )),
                ))
            .toList(),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(value,
                style: const TextStyle(
                    color: AppColors.primary,
                    fontWeight: FontWeight.w600,
                    fontSize: 13)),
            const Icon(Icons.arrow_drop_down, color: AppColors.textMuted),
          ],
        ),
      ),
      contentPadding:
          const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
    );
  }
}

class _DividerLine extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return const Divider(
      height: 1,
      color: Color(0xFF2A2A4A),
      indent: 52,
    );
  }
}

// ─── Smart Defaults Screen ────────────────────────────────────────────────

class SmartDefaultsScreen extends ConsumerWidget {
  const SmartDefaultsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final defaults = ref.watch(smartDefaultProvider);

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Smart Defaults ⚡'),
        backgroundColor: AppColors.background,
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () => _showAddDefaultDialog(context, ref),
          ),
        ],
      ),
      body: defaults.isEmpty
          ? EmptyStateWidget(
              emoji: '⚡',
              title: 'No Smart Defaults Yet',
              subtitle:
                  'Set up automatic rules so the app decides for you in specific situations',
              actionLabel: 'Add First Default',
              onAction: () => _showAddDefaultDialog(context, ref),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(20),
              itemCount: defaults.length,
              itemBuilder: (_, index) {
                final def = defaults[index];
                return Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppColors.cardBackground,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: const Color(0xFF2A2A4A)),
                  ),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: AppColors.primary.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Icon(Icons.bolt,
                            color: AppColors.primary, size: 18),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'When: ${def.triggerContext}',
                              style: const TextStyle(
                                color: AppColors.textSecondary,
                                fontSize: 11,
                              ),
                            ),
                            Text(
                              def.defaultChoice,
                              style: const TextStyle(
                                color: AppColors.textPrimary,
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Row(
                              children: [
                                _Tag(
                                    '${def.timesApplied}x applied'),
                                const SizedBox(width: 6),
                                _Tag(
                                    '${(def.successRate * 100).toInt()}% success'),
                              ],
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete_outline,
                            color: AppColors.error, size: 18),
                        onPressed: () => ref
                            .read(smartDefaultProvider.notifier)
                            .delete(def.id),
                      ),
                    ],
                  ),
                ).animate().fadeIn(delay: Duration(milliseconds: index * 80));
              },
            ),
    );
  }
}

void _showAddDefaultDialog(BuildContext context, WidgetRef ref) {
  final triggerController = TextEditingController();
  final choiceController = TextEditingController();
  var category = DecisionCategory.misc;

  showDialog(
    context: context,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setState) => AlertDialog(
        backgroundColor: AppColors.surface,
        title: const Text('Add Smart Default',
            style: TextStyle(color: AppColors.textPrimary)),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: triggerController,
                style: const TextStyle(color: AppColors.textPrimary),
                decoration: const InputDecoration(
                  labelText: 'Trigger Context',
                  hintText: 'e.g. Every weekday morning',
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: choiceController,
                style: const TextStyle(color: AppColors.textPrimary),
                decoration: const InputDecoration(
                  labelText: 'Default Choice',
                  hintText: 'e.g. Oatmeal for breakfast',
                ),
              ),
              const SizedBox(height: 16),
              const Text('Category',
                  style: TextStyle(
                      color: AppColors.textSecondary, fontSize: 12)),
              const SizedBox(height: 8),
              Wrap(
                spacing: 6,
                runSpacing: 6,
                children: DecisionCategory.values
                    .map((cat) => GestureDetector(
                          onTap: () => setState(() => category = cat),
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 5),
                            decoration: BoxDecoration(
                              color: category == cat
                                  ? AppColors.primary.withOpacity(0.2)
                                  : AppColors.surfaceVariant,
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(
                                color: category == cat
                                    ? AppColors.primary
                                    : const Color(0xFF2A2A4A),
                              ),
                            ),
                            child: Text(
                              '${cat.emoji} ${cat.label}',
                              style: TextStyle(
                                color: category == cat
                                    ? AppColors.primary
                                    : AppColors.textSecondary,
                                fontSize: 11,
                              ),
                            ),
                          ),
                        ))
                    .toList(),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              if (triggerController.text.isNotEmpty &&
                  choiceController.text.isNotEmpty) {
                await ref.read(smartDefaultProvider.notifier).addDefault(
                      triggerContext: triggerController.text.trim(),
                      defaultChoice: choiceController.text.trim(),
                      category: category,
                    );
                if (ctx.mounted) Navigator.pop(ctx);
              }
            },
            child: const Text('Add'),
          ),
        ],
      ),
    ),
  );
}

class _Tag extends StatelessWidget {
  final String text;
  const _Tag(this.text);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: AppColors.surfaceVariant,
        borderRadius: BorderRadius.circular(4),
      ),
      child: Text(text,
          style: const TextStyle(color: AppColors.textMuted, fontSize: 10)),
    );
  }
}
