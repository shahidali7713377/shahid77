// lib/presentation/screens/analytics_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:percent_indicator/linear_percent_indicator.dart';
import '../../core/theme/app_theme.dart';
import '../../core/constants/app_constants.dart';
import '../../providers/providers.dart';
import '../widgets/app_widgets.dart';

class AnalyticsScreen extends ConsumerWidget {
  const AnalyticsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final loadResult = ref.watch(cognitiveLoadProvider);
    final weeklyData = ref.watch(weeklyDecisionCountsProvider);
    final categoryBreakdown = ref.watch(categoryBreakdownProvider);
    final recommendations = ref.watch(aiRecommendationsProvider);
    final engine = ref.read(aiEngineProvider);

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Analytics 📊'),
        backgroundColor: AppColors.background,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ─── KPI Cards ─────────────────────────────────────────────────
            Row(
              children: [
                Expanded(
                  child: _KPICard(
                    emoji: '🧠',
                    label: 'Cognitive Load',
                    value: '${loadResult.score.toInt()}%',
                    subtitle: loadResult.risk.label,
                    color: _riskColor(loadResult.risk),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _KPICard(
                    emoji: '⚡',
                    label: 'Energy Saved',
                    value:
                        '${loadResult.mentalEnergyPreserved.toInt()}%',
                    subtitle: 'via automation',
                    color: AppColors.success,
                  ),
                ),
              ],
            ).animate().fadeIn(delay: 100.ms),

            const SizedBox(height: 12),

            Row(
              children: [
                Expanded(
                  child: _KPICard(
                    emoji: '🤖',
                    label: 'Auto-Decisions',
                    value: '${loadResult.automatedCount}',
                    subtitle: 'today',
                    color: AppColors.primary,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _KPICard(
                    emoji: '⏰',
                    label: 'Time Saved',
                    value: '${loadResult.timeSavedMinutes}m',
                    subtitle: 'today',
                    color: AppColors.secondary,
                  ),
                ),
              ],
            ).animate().fadeIn(delay: 150.ms),

            const SizedBox(height: 24),

            // ─── Decision Trend Chart ──────────────────────────────────────
            const SectionHeader(title: '📈 7-Day Decision Trend'),
            const SizedBox(height: 16),

            _WeeklyTrendChart(weeklyData: weeklyData)
                .animate()
                .fadeIn(delay: 200.ms),

            const SizedBox(height: 24),

            // ─── Fatigue Risk Indicator ────────────────────────────────────
            const SectionHeader(title: '⚠️ Burnout Risk Index'),
            const SizedBox(height: 16),

            _FatigueRiskBar(loadResult: loadResult)
                .animate()
                .fadeIn(delay: 300.ms),

            const SizedBox(height: 24),

            // ─── Category Breakdown ────────────────────────────────────────
            const SectionHeader(title: '🥧 Decision Categories'),
            const SizedBox(height: 16),

            categoryBreakdown.isEmpty
                ? const _NoDataPlaceholder()
                : _CategoryPieChart(breakdown: categoryBreakdown)
                    .animate()
                    .fadeIn(delay: 400.ms),

            const SizedBox(height: 24),

            // ─── High vs Low Value Breakdown ──────────────────────────────
            const SectionHeader(title: '🎯 Decision Quality'),
            const SizedBox(height: 16),

            _DecisionQualityBars(loadResult: loadResult)
                .animate()
                .fadeIn(delay: 500.ms),

            const SizedBox(height: 24),

            // ─── AI Fatigue Prediction ─────────────────────────────────────
            const SectionHeader(title: '🔮 Fatigue Prediction'),
            const SizedBox(height: 16),

            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.cardBackground,
                borderRadius: BorderRadius.circular(16),
                border:
                    Border.all(color: AppColors.primary.withOpacity(0.3)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Icon(Icons.auto_awesome,
                          color: AppColors.primary, size: 18),
                      const SizedBox(width: 8),
                      const Text(
                        'Predicted Peak Fatigue',
                        style: TextStyle(
                          color: AppColors.textPrimary,
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    engine.predictFatigueTime(weeklyData),
                    style: const TextStyle(
                      color: AppColors.primary,
                      fontSize: 20,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Based on your historical decision patterns and current load.',
                    style: TextStyle(
                      color: AppColors.textSecondary,
                      fontSize: 12,
                      height: 1.5,
                    ),
                  ),
                ],
              ),
            ).animate().fadeIn(delay: 600.ms),

            const SizedBox(height: 24),

            // ─── AI Insights ───────────────────────────────────────────────
            const SectionHeader(title: '💡 AI Recommendations'),
            const SizedBox(height: 12),

            ...recommendations.asMap().entries.map(
              (e) => Container(
                margin: const EdgeInsets.only(bottom: 8),
                padding: const EdgeInsets.symmetric(
                    horizontal: 16, vertical: 12),
                decoration: BoxDecoration(
                  color: AppColors.cardBackground,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: const Color(0xFF2A2A4A)),
                ),
                child: Text(
                  e.value,
                  style: const TextStyle(
                      color: AppColors.textSecondary, fontSize: 13),
                ),
              ).animate().fadeIn(
                  delay: Duration(milliseconds: 650 + e.key * 80)),
            ),

            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  Color _riskColor(FatigueRisk risk) {
    switch (risk) {
      case FatigueRisk.low:
        return AppColors.success;
      case FatigueRisk.moderate:
        return AppColors.warning;
      case FatigueRisk.high:
      case FatigueRisk.critical:
        return AppColors.error;
    }
  }
}

class _KPICard extends StatelessWidget {
  final String emoji;
  final String label;
  final String value;
  final String subtitle;
  final Color color;

  const _KPICard({
    required this.emoji,
    required this.label,
    required this.value,
    required this.subtitle,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.cardBackground,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(emoji, style: const TextStyle(fontSize: 18)),
              const Spacer(),
              Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  color: color,
                  shape: BoxShape.circle,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            value,
            style: TextStyle(
              color: color,
              fontSize: 24,
              fontWeight: FontWeight.w800,
            ),
          ),
          Text(
            label,
            style: const TextStyle(
              color: AppColors.textPrimary,
              fontSize: 13,
              fontWeight: FontWeight.w600,
            ),
          ),
          Text(
            subtitle,
            style: const TextStyle(
              color: AppColors.textMuted,
              fontSize: 11,
            ),
          ),
        ],
      ),
    );
  }
}

class _WeeklyTrendChart extends StatelessWidget {
  final List<MapEntry<DateTime, int>> weeklyData;

  const _WeeklyTrendChart({required this.weeklyData});

  @override
  Widget build(BuildContext context) {
    if (weeklyData.isEmpty) return const _NoDataPlaceholder();

    final spots = weeklyData
        .asMap()
        .entries
        .map((e) => FlSpot(e.key.toDouble(), e.value.value.toDouble()))
        .toList();

    final days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.cardBackground,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFF2A2A4A)),
      ),
      child: SizedBox(
        height: 180,
        child: LineChart(
          LineChartData(
            gridData: FlGridData(
              show: true,
              drawVerticalLine: false,
              horizontalInterval: 20,
              getDrawingHorizontalLine: (value) => FlLine(
                color: const Color(0xFF2A2A4A),
                strokeWidth: 1,
              ),
            ),
            titlesData: FlTitlesData(
              leftTitles: AxisTitles(
                sideTitles: SideTitles(
                  showTitles: true,
                  reservedSize: 32,
                  getTitlesWidget: (v, _) => Text(
                    v.toInt().toString(),
                    style: const TextStyle(
                        color: AppColors.textMuted, fontSize: 10),
                  ),
                ),
              ),
              bottomTitles: AxisTitles(
                sideTitles: SideTitles(
                  showTitles: true,
                  getTitlesWidget: (v, _) => Text(
                    days[v.toInt() % 7],
                    style: const TextStyle(
                        color: AppColors.textMuted, fontSize: 10),
                  ),
                ),
              ),
              rightTitles: const AxisTitles(
                  sideTitles: SideTitles(showTitles: false)),
              topTitles: const AxisTitles(
                  sideTitles: SideTitles(showTitles: false)),
            ),
            borderData: FlBorderData(show: false),
            lineBarsData: [
              LineChartBarData(
                spots: spots,
                isCurved: true,
                color: AppColors.primary,
                barWidth: 3,
                dotData: FlDotData(
                  show: true,
                  getDotPainter: (spot, percent, bar, index) =>
                      FlDotCirclePainter(
                    radius: 4,
                    color: AppColors.primary,
                    strokeWidth: 2,
                    strokeColor: AppColors.background,
                  ),
                ),
                belowBarData: BarAreaData(
                  show: true,
                  gradient: LinearGradient(
                    colors: [
                      AppColors.primary.withOpacity(0.3),
                      AppColors.primary.withOpacity(0.0),
                    ],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _FatigueRiskBar extends StatelessWidget {
  final CognitiveLoadResult loadResult;

  const _FatigueRiskBar({required this.loadResult});

  @override
  Widget build(BuildContext context) {
    final percent = (loadResult.score / 100).clamp(0.0, 1.0);
    final color = loadResult.score < 30
        ? AppColors.success
        : loadResult.score < 55
            ? AppColors.warning
            : AppColors.error;

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.cardBackground,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF2A2A4A)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                loadResult.risk.label,
                style: TextStyle(
                  color: color,
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                ),
              ),
              Text(
                '${loadResult.score.toInt()} / 100',
                style: const TextStyle(
                    color: AppColors.textSecondary, fontSize: 12),
              ),
            ],
          ),
          const SizedBox(height: 12),
          LinearPercentIndicator(
            lineHeight: 14,
            percent: percent,
            progressColor: color,
            backgroundColor: AppColors.surfaceVariant,
            barRadius: const Radius.circular(7),
            padding: EdgeInsets.zero,
            animation: true,
            animationDuration: 1000,
          ),
          const SizedBox(height: 12),
          Text(
            loadResult.risk.description,
            style: const TextStyle(
              color: AppColors.textSecondary,
              fontSize: 12,
              height: 1.5,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              _RiskZone('Safe', AppColors.success, percent < 0.3),
              _RiskZone('Caution', AppColors.warning,
                  percent >= 0.3 && percent < 0.55),
              _RiskZone('High', AppColors.error,
                  percent >= 0.55 && percent < 0.75),
              _RiskZone('Critical', const Color(0xFFFF2244),
                  percent >= 0.75),
            ],
          ),
        ],
      ),
    );
  }
}

class _RiskZone extends StatelessWidget {
  final String label;
  final Color color;
  final bool isActive;

  const _RiskZone(this.label, this.color, this.isActive);

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.only(right: 4),
        padding: const EdgeInsets.symmetric(vertical: 6),
        decoration: BoxDecoration(
          color: isActive ? color.withOpacity(0.2) : Colors.transparent,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: isActive ? color : const Color(0xFF2A2A4A),
          ),
        ),
        alignment: Alignment.center,
        child: Text(
          label,
          style: TextStyle(
            color: isActive ? color : AppColors.textMuted,
            fontSize: 10,
            fontWeight: isActive ? FontWeight.w700 : FontWeight.w500,
          ),
        ),
      ),
    );
  }
}

class _CategoryPieChart extends StatelessWidget {
  final Map<String, int> breakdown;

  const _CategoryPieChart({required this.breakdown});

  @override
  Widget build(BuildContext context) {
    final entries = breakdown.entries.toList();
    final total = entries.fold(0, (sum, e) => sum + e.value);

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.cardBackground,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFF2A2A4A)),
      ),
      child: Column(
        children: [
          SizedBox(
            height: 200,
            child: PieChart(
              PieChartData(
                sections: entries.asMap().entries.map((e) {
                  final color = AppColors.categoryColors[
                      e.key % AppColors.categoryColors.length];
                  final pct = e.value.value / total * 100;
                  return PieChartSectionData(
                    color: color,
                    value: e.value.value.toDouble(),
                    title: '${pct.toInt()}%',
                    radius: 70,
                    titleStyle: const TextStyle(
                      color: Colors.white,
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                    ),
                  );
                }).toList(),
                centerSpaceRadius: 40,
                sectionsSpace: 3,
              ),
            ),
          ),
          const SizedBox(height: 16),
          Wrap(
            spacing: 12,
            runSpacing: 8,
            alignment: WrapAlignment.center,
            children: entries.asMap().entries.map((e) {
              final color = AppColors.categoryColors[
                  e.key % AppColors.categoryColors.length];
              final cat = DecisionCategory.values
                  .firstWhere((c) => c.name == e.value.key,
                      orElse: () => DecisionCategory.misc);
              return Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 10,
                    height: 10,
                    decoration:
                        BoxDecoration(color: color, shape: BoxShape.circle),
                  ),
                  const SizedBox(width: 4),
                  Text(
                    '${cat.emoji} ${cat.label} (${e.value.value})',
                    style: const TextStyle(
                        color: AppColors.textSecondary, fontSize: 11),
                  ),
                ],
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
}

class _DecisionQualityBars extends StatelessWidget {
  final CognitiveLoadResult loadResult;

  const _DecisionQualityBars({required this.loadResult});

  @override
  Widget build(BuildContext context) {
    final total = loadResult.totalDecisions;
    if (total == 0) return const _NoDataPlaceholder();

    final highPct = total > 0 ? loadResult.highValueCount / total : 0.0;
    final lowPct = total > 0 ? loadResult.lowValueCount / total : 0.0;
    final autoPct = total > 0 ? loadResult.automatedCount / total : 0.0;

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.cardBackground,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF2A2A4A)),
      ),
      child: Column(
        children: [
          _QualityBar('⭐ High Value', loadResult.highValueCount,
              highPct, AppColors.primary),
          const SizedBox(height: 12),
          _QualityBar('🔄 Low Value', loadResult.lowValueCount,
              lowPct, AppColors.textMuted),
          const SizedBox(height: 12),
          _QualityBar('🤖 Automated', loadResult.automatedCount,
              autoPct, AppColors.success),
        ],
      ),
    );
  }
}

class _QualityBar extends StatelessWidget {
  final String label;
  final int count;
  final double percent;
  final Color color;

  const _QualityBar(this.label, this.count, this.percent, this.color);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label,
                style: const TextStyle(
                    color: AppColors.textSecondary, fontSize: 12)),
            Text('$count (${(percent * 100).toInt()}%)',
                style: TextStyle(
                    color: color,
                    fontSize: 12,
                    fontWeight: FontWeight.w600)),
          ],
        ),
        const SizedBox(height: 6),
        LinearPercentIndicator(
          lineHeight: 8,
          percent: percent.clamp(0.0, 1.0),
          progressColor: color,
          backgroundColor: AppColors.surfaceVariant,
          barRadius: const Radius.circular(4),
          padding: EdgeInsets.zero,
          animation: true,
          animationDuration: 800,
        ),
      ],
    );
  }
}

class _NoDataPlaceholder extends StatelessWidget {
  const _NoDataPlaceholder();

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 80,
      alignment: Alignment.center,
      child: const Text(
        'No data yet. Start logging decisions!',
        style: TextStyle(color: AppColors.textMuted, fontSize: 13),
      ),
    );
  }
}
