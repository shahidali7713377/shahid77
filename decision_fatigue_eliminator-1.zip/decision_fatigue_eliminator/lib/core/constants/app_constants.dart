// lib/core/constants/app_constants.dart

class AppConstants {
  static const appName = 'Decision Fatigue Eliminator';
  static const maxDailyDecisions = 200;
  static const fatigueThreshold = 70; // CLS score
  static const defaultOutfitRotationDays = 7;
  static const defaultMealRotationDays = 5;
  static const aiDecisionDelayMs = 400; // Simulated AI processing
  static const hiveDecisionBox = 'decisions';
  static const hiveOutfitBox = 'outfits';
  static const hiveMealBox = 'meals';
  static const hiveSettingsBox = 'settings';
  static const hiveSmartDefaultBox = 'smart_defaults';
  static const hiveUserProfileBox = 'user_profile';
}

enum DecisionCategory {
  food('Food', '🍕'),
  outfit('Outfit', '👗'),
  work('Work', '💼'),
  social('Social', '👥'),
  purchase('Purchase', '🛍️'),
  study('Study', '📚'),
  misc('Misc', '⚙️');

  final String label;
  final String emoji;
  const DecisionCategory(this.label, this.emoji);
}

enum EffortLevel {
  low('Low', 1),
  medium('Medium', 2),
  high('High', 3);

  final String label;
  final int value;
  const EffortLevel(this.label, this.value);
}

enum DecisionValue {
  low,
  high;
}

enum AIDecisionMode {
  quick('Quick', 'Instant decision based on your defaults'),
  balanced('Balanced', 'Optimized for your goals and history'),
  growth('Growth', 'Slightly challenging for personal development');

  final String label;
  final String description;
  const AIDecisionMode(this.label, this.description);
}

enum ClothingCategory {
  top('Top', '👕'),
  bottom('Bottom', '👖'),
  shoes('Shoes', '👟'),
  accessories('Accessories', '⌚'),
  outerwear('Outerwear', '🧥'),
  dress('Dress', '👗');

  final String label;
  final String emoji;
  const ClothingCategory(this.label, this.emoji);
}

enum FormailityLevel {
  casual('Casual'),
  business('Business Casual'),
  formal('Formal'),
  athletic('Athletic');

  final String label;
  const FormailityLevel(this.label);
}

enum WeatherSuitability {
  hot('Hot'),
  warm('Warm'),
  cool('Cool'),
  cold('Cold'),
  rainy('Rainy'),
  allWeather('All Weather');

  final String label;
  const WeatherSuitability(this.label);
}

enum MealType {
  breakfast('Breakfast', '🍳'),
  lunch('Lunch', '🥗'),
  dinner('Dinner', '🍽️'),
  snack('Snack', '🍎');

  final String label;
  final String emoji;
  const MealType(this.label, this.emoji);
}

enum DietTag {
  vegetarian('Vegetarian', '🥦'),
  vegan('Vegan', '🌱'),
  highProtein('High Protein', '💪'),
  keto('Keto', '🥑'),
  lowCarb('Low Carb', '🥩'),
  balanced('Balanced', '⚖️'),
  glutenFree('Gluten Free', '🌾');

  final String label;
  final String emoji;
  const DietTag(this.label, this.emoji);
}

enum FatigueRisk {
  low,
  moderate,
  high,
  critical;

  String get label {
    switch (this) {
      case FatigueRisk.low: return 'Low Risk';
      case FatigueRisk.moderate: return 'Moderate Risk';
      case FatigueRisk.high: return 'High Risk';
      case FatigueRisk.critical: return 'Critical';
    }
  }

  String get description {
    switch (this) {
      case FatigueRisk.low: return "You're in great mental shape today!";
      case FatigueRisk.moderate: return 'Consider delegating some decisions.';
      case FatigueRisk.high: return 'Activate Minimalist Mode now.';
      case FatigueRisk.critical: return 'Emergency: Let AI handle everything.';
    }
  }
}
