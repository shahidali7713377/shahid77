// lib/data/repositories/decision_repository.dart

import 'package:hive_flutter/hive_flutter.dart';
import '../models/decision_model.dart';
import '../../core/constants/app_constants.dart';

class DecisionRepository {
  Box<DecisionModel> get _box => Hive.box<DecisionModel>(AppConstants.hiveDecisionBox);

  List<DecisionModel> getAll() => _box.values.toList()
    ..sort((a, b) => b.timestamp.compareTo(a.timestamp));

  List<DecisionModel> getTodayDecisions() {
    final now = DateTime.now();
    final startOfDay = DateTime(now.year, now.month, now.day);
    return _box.values
        .where((d) => d.timestamp.isAfter(startOfDay))
        .toList()
      ..sort((a, b) => b.timestamp.compareTo(a.timestamp));
  }

  List<DecisionModel> getDecisionsForDateRange(DateTime start, DateTime end) {
    return _box.values
        .where((d) => d.timestamp.isAfter(start) && d.timestamp.isBefore(end))
        .toList()
      ..sort((a, b) => b.timestamp.compareTo(a.timestamp));
  }

  List<DecisionModel> getDecisionsForWeek() {
    final now = DateTime.now();
    final weekStart = now.subtract(Duration(days: now.weekday - 1));
    final start = DateTime(weekStart.year, weekStart.month, weekStart.day);
    return getDecisionsForDateRange(start, now.add(const Duration(days: 1)));
  }

  Future<void> save(DecisionModel decision) async {
    await _box.put(decision.id, decision);
  }

  Future<void> delete(String id) async {
    await _box.delete(id);
  }

  Future<void> updateSatisfaction(String id, int rating) async {
    final decision = _box.get(id);
    if (decision != null) {
      decision.satisfactionRating = rating;
      await decision.save();
    }
  }

  Map<String, int> getCategoryBreakdownToday() {
    final todayDecisions = getTodayDecisions();
    final map = <String, int>{};
    for (final d in todayDecisions) {
      map[d.categoryName] = (map[d.categoryName] ?? 0) + 1;
    }
    return map;
  }

  List<MapEntry<DateTime, int>> getDailyCountsForLast7Days() {
    final result = <MapEntry<DateTime, int>>[];
    final now = DateTime.now();
    for (int i = 6; i >= 0; i--) {
      final date = now.subtract(Duration(days: i));
      final start = DateTime(date.year, date.month, date.day);
      final end = start.add(const Duration(days: 1));
      final count = _box.values
          .where((d) => d.timestamp.isAfter(start) && d.timestamp.isBefore(end))
          .length;
      result.add(MapEntry(start, count));
    }
    return result;
  }
}

// lib/data/repositories/outfit_repository.dart

class OutfitRepository {
  Box<OutfitItemModel> get _box =>
      Hive.box<OutfitItemModel>(AppConstants.hiveOutfitBox);

  List<OutfitItemModel> getAll() =>
      _box.values.where((o) => o.isActive).toList();

  List<OutfitItemModel> getByCategory(ClothingCategory category) =>
      getAll().where((o) => o.category == category).toList();

  Future<void> save(OutfitItemModel item) async {
    await _box.put(item.id, item);
  }

  Future<void> delete(String id) async {
    final item = _box.get(id);
    if (item != null) {
      item.isActive = false;
      await item.save();
    }
  }

  Future<void> markWorn(String id) async {
    final item = _box.get(id);
    if (item != null) {
      item.wornDates.add(DateTime.now());
      await item.save();
    }
  }

  List<OutfitItemModel> getAvailableForRotation(int rotationDays) =>
      getAll().where((o) => !o.wasWornWithinDays(rotationDays)).toList();
}

// lib/data/repositories/meal_repository.dart

class MealRepository {
  Box<MealModel> get _box => Hive.box<MealModel>(AppConstants.hiveMealBox);

  List<MealModel> getAll() => _box.values.where((m) => m.isActive).toList();

  List<MealModel> getByType(MealType type) =>
      getAll().where((m) => m.mealType == type).toList();

  Future<void> save(MealModel meal) async {
    await _box.put(meal.id, meal);
  }

  Future<void> delete(String id) async {
    final meal = _box.get(id);
    if (meal != null) {
      meal.isActive = false;
      await meal.save();
    }
  }

  Future<void> markConsumed(String id) async {
    final meal = _box.get(id);
    if (meal != null) {
      meal.consumedDates.add(DateTime.now());
      await meal.save();
    }
  }

  Future<void> updateSatisfaction(String id, double rating) async {
    final meal = _box.get(id);
    if (meal != null) {
      final totalRatings = meal.consumedDates.length;
      meal.averageSatisfaction =
          ((meal.averageSatisfaction * (totalRatings - 1)) + rating) /
              totalRatings;
      await meal.save();
    }
  }

  List<MealModel> getAvailableForRotation(MealType type, int rotationDays) =>
      getByType(type).where((m) => !m.wasConsumedWithinDays(rotationDays)).toList();

  List<String> generateGroceryList(List<MealModel> meals) {
    final ingredients = <String>{};
    for (final meal in meals) {
      ingredients.addAll(meal.ingredients);
    }
    return ingredients.toList()..sort();
  }
}

// lib/data/repositories/smart_default_repository.dart

class SmartDefaultRepository {
  Box<SmartDefaultModel> get _box =>
      Hive.box<SmartDefaultModel>(AppConstants.hiveSmartDefaultBox);

  List<SmartDefaultModel> getAll() =>
      _box.values.where((s) => s.isActive).toList();

  Future<void> save(SmartDefaultModel model) async {
    await _box.put(model.id, model);
  }

  Future<void> delete(String id) async {
    await _box.delete(id);
  }

  Future<void> incrementApplied(String id, bool success) async {
    final model = _box.get(id);
    if (model != null) {
      model.timesApplied++;
      final totalSuccess = (model.successRate * (model.timesApplied - 1)) +
          (success ? 1 : 0);
      model.successRate = totalSuccess / model.timesApplied;
      await model.save();
    }
  }
}

// lib/data/repositories/user_profile_repository.dart

class UserProfileRepository {
  Box<UserProfileModel> get _box =>
      Hive.box<UserProfileModel>(AppConstants.hiveUserProfileBox);

  UserProfileModel get profile {
    if (_box.isEmpty) {
      final defaults = UserProfileModel.defaults();
      _box.put('profile', defaults);
      return defaults;
    }
    return _box.get('profile') ?? UserProfileModel.defaults();
  }

  Future<void> save(UserProfileModel profile) async {
    await _box.put('profile', profile);
  }

  Future<void> toggleMinimalistMode() async {
    final p = profile;
    p.minimalistModeEnabled = !p.minimalistModeEnabled;
    await p.save();
  }
}
