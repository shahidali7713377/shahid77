// lib/data/models/decision_model.dart

import 'package:hive/hive.dart';
import '../../core/constants/app_constants.dart';

part 'decision_model.g.dart';

@HiveType(typeId: 0)
class DecisionModel extends HiveObject {
  @HiveField(0)
  late String id;

  @HiveField(1)
  late String title;

  @HiveField(2)
  late String categoryName;

  @HiveField(3)
  late String effortLevelName;

  @HiveField(4)
  late DateTime timestamp;

  @HiveField(5)
  late bool isAutomated;

  @HiveField(6)
  late bool isHighValue;

  @HiveField(7)
  late double cognitiveWeight;

  @HiveField(8)
  String? emotionalImpact;

  @HiveField(9)
  int? satisfactionRating;

  @HiveField(10)
  late String? aiRecommendation;

  @HiveField(11)
  late bool usedAI;

  DecisionCategory get category =>
      DecisionCategory.values.firstWhere((e) => e.name == categoryName,
          orElse: () => DecisionCategory.misc);

  EffortLevel get effortLevel =>
      EffortLevel.values.firstWhere((e) => e.name == effortLevelName,
          orElse: () => EffortLevel.low);

  factory DecisionModel.create({
    required String id,
    required String title,
    required DecisionCategory category,
    required EffortLevel effortLevel,
    String? emotionalImpact,
    bool isAutomated = false,
    bool usedAI = false,
    String? aiRecommendation,
  }) {
    final model = DecisionModel();
    model.id = id;
    model.title = title;
    model.categoryName = category.name;
    model.effortLevelName = effortLevel.name;
    model.timestamp = DateTime.now();
    model.isAutomated = isAutomated;
    model.emotionalImpact = emotionalImpact;
    model.usedAI = usedAI;
    model.aiRecommendation = aiRecommendation;
    model.cognitiveWeight = _calculateCognitiveWeight(category, effortLevel);
    model.isHighValue = _determineHighValue(category, effortLevel);
    return model;
  }

  static double _calculateCognitiveWeight(
      DecisionCategory cat, EffortLevel effort) {
    double base = effort.value.toDouble();
    switch (cat) {
      case DecisionCategory.work:
        return base * 1.5;
      case DecisionCategory.purchase:
        return base * 1.3;
      case DecisionCategory.social:
        return base * 1.2;
      case DecisionCategory.food:
      case DecisionCategory.outfit:
        return base * 0.8;
      default:
        return base * 1.0;
    }
  }

  static bool _determineHighValue(DecisionCategory cat, EffortLevel effort) {
    if (effort == EffortLevel.high) return true;
    if (cat == DecisionCategory.work || cat == DecisionCategory.study) {
      return effort != EffortLevel.low;
    }
    return false;
  }
}

@HiveType(typeId: 1)
class OutfitItemModel extends HiveObject {
  @HiveField(0)
  late String id;

  @HiveField(1)
  late String name;

  @HiveField(2)
  late String categoryName;

  @HiveField(3)
  late String color;

  @HiveField(4)
  late String formalityName;

  @HiveField(5)
  late List<String> weatherNames;

  @HiveField(6)
  String? imagePath;

  @HiveField(7)
  late List<DateTime> wornDates;

  @HiveField(8)
  late bool isActive;

  ClothingCategory get category => ClothingCategory.values
      .firstWhere((e) => e.name == categoryName, orElse: () => ClothingCategory.top);

  FormailityLevel get formality => FormailityLevel.values
      .firstWhere((e) => e.name == formalityName, orElse: () => FormailityLevel.casual);

  List<WeatherSuitability> get weatherSuitability => weatherNames
      .map((n) => WeatherSuitability.values.firstWhere((e) => e.name == n,
          orElse: () => WeatherSuitability.allWeather))
      .toList();

  DateTime? get lastWorn => wornDates.isEmpty ? null : wornDates.last;

  bool wasWornWithinDays(int days) {
    if (lastWorn == null) return false;
    return DateTime.now().difference(lastWorn!).inDays < days;
  }
}

@HiveType(typeId: 2)
class MealModel extends HiveObject {
  @HiveField(0)
  late String id;

  @HiveField(1)
  late String name;

  @HiveField(2)
  late String mealTypeName;

  @HiveField(3)
  late int calories;

  @HiveField(4)
  late int prepTimeMinutes;

  @HiveField(5)
  late List<String> dietTagNames;

  @HiveField(6)
  late List<String> ingredients;

  @HiveField(7)
  late List<DateTime> consumedDates;

  @HiveField(8)
  late bool isActive;

  @HiveField(9)
  late double averageSatisfaction;

  MealType get mealType => MealType.values
      .firstWhere((e) => e.name == mealTypeName, orElse: () => MealType.lunch);

  List<DietTag> get dietTags => dietTagNames
      .map((n) => DietTag.values.firstWhere((e) => e.name == n,
          orElse: () => DietTag.balanced))
      .toList();

  DateTime? get lastConsumed => consumedDates.isEmpty ? null : consumedDates.last;

  bool wasConsumedWithinDays(int days) {
    if (lastConsumed == null) return false;
    return DateTime.now().difference(lastConsumed!).inDays < days;
  }
}

@HiveType(typeId: 3)
class SmartDefaultModel extends HiveObject {
  @HiveField(0)
  late String id;

  @HiveField(1)
  late String triggerContext;

  @HiveField(2)
  late String defaultChoice;

  @HiveField(3)
  late String categoryName;

  @HiveField(4)
  late int timesApplied;

  @HiveField(5)
  late double successRate;

  @HiveField(6)
  late bool isActive;

  @HiveField(7)
  late DateTime createdAt;
}

@HiveType(typeId: 4)
class UserProfileModel extends HiveObject {
  @HiveField(0)
  late String name;

  @HiveField(1)
  late bool minimalistModeEnabled;

  @HiveField(2)
  late int outfitRotationDays;

  @HiveField(3)
  late int mealRotationDays;

  @HiveField(4)
  late String preferredAIModeNmae;

  @HiveField(5)
  late List<String> healthGoals;

  @HiveField(6)
  late String defaultDietTagName;

  @HiveField(7)
  late bool notificationsEnabled;

  @HiveField(8)
  late int dailyDecisionGoal;

  AIDecisionMode get preferredAIMode => AIDecisionMode.values.firstWhere(
      (e) => e.name == preferredAIModeNmae,
      orElse: () => AIDecisionMode.balanced);

  factory UserProfileModel.defaults() {
    final p = UserProfileModel();
    p.name = 'User';
    p.minimalistModeEnabled = false;
    p.outfitRotationDays = 7;
    p.mealRotationDays = 5;
    p.preferredAIModeNmae = AIDecisionMode.balanced.name;
    p.healthGoals = [];
    p.defaultDietTagName = DietTag.balanced.name;
    p.notificationsEnabled = true;
    p.dailyDecisionGoal = 50;
    return p;
  }
}

@HiveType(typeId: 5)
class WeeklyOutfitPlanModel extends HiveObject {
  @HiveField(0)
  late String id;

  @HiveField(1)
  late DateTime weekStart;

  @HiveField(2)
  late Map<int, List<String>> dayOutfitItemIds; // day index -> outfit item ids

  @HiveField(3)
  late bool isAutoGenerated;
}

@HiveType(typeId: 6)
class WeeklyMealPlanModel extends HiveObject {
  @HiveField(0)
  late String id;

  @HiveField(1)
  late DateTime weekStart;

  @HiveField(2)
  late Map<int, Map<String, String>> dayMealIds; // day index -> mealType -> mealId

  @HiveField(3)
  late bool isAutoGenerated;
}
