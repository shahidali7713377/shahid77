// lib/providers/providers.dart

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uuid/uuid.dart';
import '../data/models/decision_model.dart';
import '../data/repositories/repositories.dart';
import '../services/ai_decision_engine.dart';
import '../core/constants/app_constants.dart';

// ─── Repository Providers ─────────────────────────────────────────────────

final decisionRepositoryProvider = Provider<DecisionRepository>(
  (_) => DecisionRepository(),
);

final outfitRepositoryProvider = Provider<OutfitRepository>(
  (_) => OutfitRepository(),
);

final mealRepositoryProvider = Provider<MealRepository>(
  (_) => MealRepository(),
);

final smartDefaultRepositoryProvider = Provider<SmartDefaultRepository>(
  (_) => SmartDefaultRepository(),
);

final userProfileRepositoryProvider = Provider<UserProfileRepository>(
  (_) => UserProfileRepository(),
);

final aiEngineProvider = Provider<AIDecisionEngine>(
  (_) => AIDecisionEngine(),
);

// ─── User Profile State ───────────────────────────────────────────────────

class UserProfileNotifier extends StateNotifier<UserProfileModel> {
  final UserProfileRepository _repo;

  UserProfileNotifier(this._repo) : super(_repo.profile);

  Future<void> toggleMinimalistMode() async {
    await _repo.toggleMinimalistMode();
    state = _repo.profile;
  }

  Future<void> updateProfile(UserProfileModel updated) async {
    await _repo.save(updated);
    state = updated;
  }

  Future<void> updateAIMode(AIDecisionMode mode) async {
    final updated = state;
    updated.preferredAIModeNmae = mode.name;
    await _repo.save(updated);
    state = _repo.profile;
  }
}

final userProfileProvider =
    StateNotifierProvider<UserProfileNotifier, UserProfileModel>(
  (ref) => UserProfileNotifier(ref.read(userProfileRepositoryProvider)),
);

// ─── Decision State ───────────────────────────────────────────────────────

class DecisionNotifier extends StateNotifier<List<DecisionModel>> {
  final DecisionRepository _repo;
  final Uuid _uuid = const Uuid();

  DecisionNotifier(this._repo) : super(_repo.getTodayDecisions());

  void refresh() => state = _repo.getTodayDecisions();

  Future<void> addDecision({
    required String title,
    required DecisionCategory category,
    required EffortLevel effortLevel,
    String? emotionalImpact,
    bool isAutomated = false,
    bool usedAI = false,
    String? aiRecommendation,
  }) async {
    final decision = DecisionModel.create(
      id: _uuid.v4(),
      title: title,
      category: category,
      effortLevel: effortLevel,
      emotionalImpact: emotionalImpact,
      isAutomated: isAutomated,
      usedAI: usedAI,
      aiRecommendation: aiRecommendation,
    );
    await _repo.save(decision);
    refresh();
  }

  Future<void> rateSatisfaction(String id, int rating) async {
    await _repo.updateSatisfaction(id, rating);
    refresh();
  }

  Future<void> delete(String id) async {
    await _repo.delete(id);
    refresh();
  }
}

final decisionProvider =
    StateNotifierProvider<DecisionNotifier, List<DecisionModel>>(
  (ref) => DecisionNotifier(ref.read(decisionRepositoryProvider)),
);

// ─── Cognitive Load Provider ──────────────────────────────────────────────

final cognitiveLoadProvider = Provider<CognitiveLoadResult>((ref) {
  final decisions = ref.watch(decisionProvider);
  final engine = ref.read(aiEngineProvider);
  return engine.calculateCognitiveLoad(decisions);
});

// ─── Outfit State ─────────────────────────────────────────────────────────

class OutfitNotifier extends StateNotifier<List<OutfitItemModel>> {
  final OutfitRepository _repo;
  final Uuid _uuid = const Uuid();

  OutfitNotifier(this._repo) : super(_repo.getAll());

  void refresh() => state = _repo.getAll();

  Future<void> addItem({
    required String name,
    required ClothingCategory category,
    required String color,
    required FormailityLevel formality,
    required List<WeatherSuitability> weather,
    String? imagePath,
  }) async {
    final item = OutfitItemModel()
      ..id = _uuid.v4()
      ..name = name
      ..categoryName = category.name
      ..color = color
      ..formalityName = formality.name
      ..weatherNames = weather.map((w) => w.name).toList()
      ..imagePath = imagePath
      ..wornDates = []
      ..isActive = true;
    await _repo.save(item);
    refresh();
  }

  Future<void> markWorn(String id) async {
    await _repo.markWorn(id);
    refresh();
  }

  Future<void> delete(String id) async {
    await _repo.delete(id);
    refresh();
  }
}

final outfitProvider =
    StateNotifierProvider<OutfitNotifier, List<OutfitItemModel>>(
  (ref) => OutfitNotifier(ref.read(outfitRepositoryProvider)),
);

final outfitSuggestionProvider = Provider<OutfitSuggestion?>((ref) {
  final outfits = ref.watch(outfitProvider);
  final profile = ref.watch(userProfileProvider);
  final engine = ref.read(aiEngineProvider);
  return engine.suggestOutfit(
    availableItems: outfits,
    rotationDays: profile.outfitRotationDays,
  );
});

// ─── Meal State ───────────────────────────────────────────────────────────

class MealNotifier extends StateNotifier<List<MealModel>> {
  final MealRepository _repo;
  final Uuid _uuid = const Uuid();

  MealNotifier(this._repo) : super(_repo.getAll());

  void refresh() => state = _repo.getAll();

  Future<void> addMeal({
    required String name,
    required MealType type,
    required int calories,
    required int prepTimeMinutes,
    required List<DietTag> dietTags,
    required List<String> ingredients,
  }) async {
    final meal = MealModel()
      ..id = _uuid.v4()
      ..name = name
      ..mealTypeName = type.name
      ..calories = calories
      ..prepTimeMinutes = prepTimeMinutes
      ..dietTagNames = dietTags.map((t) => t.name).toList()
      ..ingredients = ingredients
      ..consumedDates = []
      ..isActive = true
      ..averageSatisfaction = 3.5;
    await _repo.save(meal);
    refresh();
  }

  Future<void> markConsumed(String id) async {
    await _repo.markConsumed(id);
    refresh();
  }

  Future<void> delete(String id) async {
    await _repo.delete(id);
    refresh();
  }
}

final mealProvider = StateNotifierProvider<MealNotifier, List<MealModel>>(
  (ref) => MealNotifier(ref.read(mealRepositoryProvider)),
);

// ─── Smart Defaults State ─────────────────────────────────────────────────

class SmartDefaultNotifier extends StateNotifier<List<SmartDefaultModel>> {
  final SmartDefaultRepository _repo;
  final Uuid _uuid = const Uuid();

  SmartDefaultNotifier(this._repo) : super(_repo.getAll());

  void refresh() => state = _repo.getAll();

  Future<void> addDefault({
    required String triggerContext,
    required String defaultChoice,
    required DecisionCategory category,
  }) async {
    final model = SmartDefaultModel()
      ..id = _uuid.v4()
      ..triggerContext = triggerContext
      ..defaultChoice = defaultChoice
      ..categoryName = category.name
      ..timesApplied = 0
      ..successRate = 0
      ..isActive = true
      ..createdAt = DateTime.now();
    await _repo.save(model);
    refresh();
  }

  Future<void> delete(String id) async {
    await _repo.delete(id);
    refresh();
  }
}

final smartDefaultProvider =
    StateNotifierProvider<SmartDefaultNotifier, List<SmartDefaultModel>>(
  (ref) => SmartDefaultNotifier(ref.read(smartDefaultRepositoryProvider)),
);

// ─── Analytics Provider ───────────────────────────────────────────────────

final weeklyDecisionCountsProvider =
    Provider<List<MapEntry<DateTime, int>>>((ref) {
  final repo = ref.read(decisionRepositoryProvider);
  return repo.getDailyCountsForLast7Days();
});

final categoryBreakdownProvider = Provider<Map<String, int>>((ref) {
  final repo = ref.read(decisionRepositoryProvider);
  return repo.getCategoryBreakdownToday();
});

final aiRecommendationsProvider = Provider<List<String>>((ref) {
  final load = ref.watch(cognitiveLoadProvider);
  final engine = ref.read(aiEngineProvider);
  return engine.generateCognitiveRecommendations(load);
});

// ─── AI Decision State ────────────────────────────────────────────────────

class AIDecisionState {
  final bool isLoading;
  final AIDecisionResult? result;
  final String? error;

  const AIDecisionState({
    this.isLoading = false,
    this.result,
    this.error,
  });

  AIDecisionState copyWith({
    bool? isLoading,
    AIDecisionResult? result,
    String? error,
  }) =>
      AIDecisionState(
        isLoading: isLoading ?? this.isLoading,
        result: result ?? this.result,
        error: error ?? this.error,
      );
}

class AIDecisionNotifier extends StateNotifier<AIDecisionState> {
  final AIDecisionEngine _engine;
  final DecisionRepository _decisionRepo;
  final UserProfileRepository _profileRepo;

  AIDecisionNotifier(this._engine, this._decisionRepo, this._profileRepo)
      : super(const AIDecisionState());

  Future<void> decide({
    required List<String> options,
    required DecisionCategory category,
    int? energyLevel,
  }) async {
    state = state.copyWith(isLoading: true, error: null);
    try {
      final profile = _profileRepo.profile;
      final recentDecisions = _decisionRepo.getDecisionsForDateRange(
        DateTime.now().subtract(const Duration(days: 7)),
        DateTime.now(),
      );
      final todayDecisions = _decisionRepo.getTodayDecisions();
      final engine = AIDecisionEngine();
      final load = engine.calculateCognitiveLoad(todayDecisions);

      final result = await _engine.decideForMe(
        options: options,
        mode: profile.preferredAIMode,
        currentCognitiveLoad: load.score,
        recentDecisions: recentDecisions,
        category: category,
        energyLevel: energyLevel,
      );

      state = state.copyWith(isLoading: false, result: result);
    } catch (e) {
      state = state.copyWith(isLoading: false, error: e.toString());
    }
  }

  void reset() => state = const AIDecisionState();
}

final aiDecisionProvider =
    StateNotifierProvider<AIDecisionNotifier, AIDecisionState>(
  (ref) => AIDecisionNotifier(
    ref.read(aiEngineProvider),
    ref.read(decisionRepositoryProvider),
    ref.read(userProfileRepositoryProvider),
  ),
);
