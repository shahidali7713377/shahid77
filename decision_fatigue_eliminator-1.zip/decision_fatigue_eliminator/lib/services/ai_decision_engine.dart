// lib/services/ai_decision_engine.dart

import 'dart:math';
import '../core/constants/app_constants.dart';
import '../data/models/decision_model.dart';

class CognitiveLoadResult {
  final double score; // 0-100
  final FatigueRisk risk;
  final int totalDecisions;
  final int highValueCount;
  final int lowValueCount;
  final int automatedCount;
  final double mentalEnergyPreserved; // percentage
  final int timeSavedMinutes;

  const CognitiveLoadResult({
    required this.score,
    required this.risk,
    required this.totalDecisions,
    required this.highValueCount,
    required this.lowValueCount,
    required this.automatedCount,
    required this.mentalEnergyPreserved,
    required this.timeSavedMinutes,
  });
}

class AIDecisionResult {
  final String decision;
  final String reasoning;
  final double confidenceScore;
  final AIDecisionMode mode;
  final List<String> alternatives;

  const AIDecisionResult({
    required this.decision,
    required this.reasoning,
    required this.confidenceScore,
    required this.mode,
    required this.alternatives,
  });
}

class OutfitSuggestion {
  final List<OutfitItemModel> items;
  final String reasoning;
  final double matchScore;

  const OutfitSuggestion({
    required this.items,
    required this.reasoning,
    required this.matchScore,
  });
}

class MealSuggestion {
  final MealModel meal;
  final String reasoning;
  final double matchScore;

  const MealSuggestion({
    required this.meal,
    required this.reasoning,
    required this.matchScore,
  });
}

class AIDecisionEngine {
  final Random _random = Random();

  // ─── Cognitive Load Scoring ───────────────────────────────────────────────

  CognitiveLoadResult calculateCognitiveLoad(List<DecisionModel> todayDecisions) {
    if (todayDecisions.isEmpty) {
      return const CognitiveLoadResult(
        score: 0,
        risk: FatigueRisk.low,
        totalDecisions: 0,
        highValueCount: 0,
        lowValueCount: 0,
        automatedCount: 0,
        mentalEnergyPreserved: 100,
        timeSavedMinutes: 0,
      );
    }

    final highValue = todayDecisions.where((d) => d.isHighValue).length;
    final lowValue = todayDecisions.where((d) => !d.isHighValue).length;
    final automated = todayDecisions.where((d) => d.isAutomated).length;

    // Cognitive Load Score formula:
    // Each decision contributes weighted by cognitiveWeight
    // Automated decisions reduce load by 60%
    double rawScore = 0;
    for (final d in todayDecisions) {
      rawScore += d.isAutomated ? d.cognitiveWeight * 0.4 : d.cognitiveWeight;
    }

    // Normalize to 0-100 scale (max expected: 150 weighted units per day)
    final score = (rawScore / 150 * 100).clamp(0.0, 100.0);

    final risk = _calculateRisk(score);
    final energyPreserved = automated > 0
        ? (automated / todayDecisions.length * 100).clamp(0.0, 100.0)
        : 0.0;
    final timeSaved = automated * 3; // ~3 mins avg per automated decision

    return CognitiveLoadResult(
      score: score,
      risk: risk,
      totalDecisions: todayDecisions.length,
      highValueCount: highValue,
      lowValueCount: lowValue,
      automatedCount: automated,
      mentalEnergyPreserved: energyPreserved,
      timeSavedMinutes: timeSaved,
    );
  }

  FatigueRisk _calculateRisk(double score) {
    if (score < 30) return FatigueRisk.low;
    if (score < 55) return FatigueRisk.moderate;
    if (score < 75) return FatigueRisk.high;
    return FatigueRisk.critical;
  }

  // ─── AI "Decide For Me" Engine ────────────────────────────────────────────

  Future<AIDecisionResult> decideForMe({
    required List<String> options,
    required AIDecisionMode mode,
    required double currentCognitiveLoad,
    required List<DecisionModel> recentDecisions,
    required DecisionCategory category,
    int? energyLevel, // 1-5
  }) async {
    // Simulate AI processing time
    await Future.delayed(
        const Duration(milliseconds: AppConstants.aiDecisionDelayMs));

    if (options.isEmpty) {
      return const AIDecisionResult(
        decision: 'No options available',
        reasoning: 'Please add some options first.',
        confidenceScore: 0,
        mode: AIDecisionMode.balanced,
        alternatives: [],
      );
    }

    String chosen;
    String reasoning;
    List<String> alternatives;
    double confidence;

    switch (mode) {
      case AIDecisionMode.quick:
        // Fast: pick highest satisfaction from history or random
        chosen = _quickDecide(options, recentDecisions, category);
        reasoning = 'Selected based on your historical preferences for quick decision-making.';
        confidence = 0.75 + _random.nextDouble() * 0.2;
        alternatives = options.where((o) => o != chosen).take(2).toList();
        break;

      case AIDecisionMode.balanced:
        // Balanced: consider energy, load, and history
        chosen = _balancedDecide(
            options, recentDecisions, currentCognitiveLoad, energyLevel ?? 3);
        reasoning = _generateBalancedReasoning(category, currentCognitiveLoad);
        confidence = 0.80 + _random.nextDouble() * 0.15;
        alternatives = options.where((o) => o != chosen).take(2).toList();
        break;

      case AIDecisionMode.growth:
        // Growth: choose a less-used option to expand comfort zone
        chosen = _growthDecide(options, recentDecisions, category);
        reasoning = 'Selected a less frequent choice to expand your experience and support personal growth.';
        confidence = 0.65 + _random.nextDouble() * 0.2;
        alternatives = options.where((o) => o != chosen).take(2).toList();
        break;
    }

    return AIDecisionResult(
      decision: chosen,
      reasoning: reasoning,
      confidenceScore: confidence,
      mode: mode,
      alternatives: alternatives,
    );
  }

  String _quickDecide(List<String> options, List<DecisionModel> history,
      DecisionCategory category) {
    // Find most frequently satisfied decision in this category
    final categoryHistory = history
        .where((d) =>
            d.categoryName == category.name && d.satisfactionRating != null)
        .toList();

    if (categoryHistory.isEmpty) {
      return options[_random.nextInt(options.length)];
    }

    // Find option names that appear in history with high satisfaction
    for (final option in options) {
      final matching = categoryHistory.where((d) =>
          d.title.toLowerCase().contains(option.toLowerCase()) &&
          (d.satisfactionRating ?? 0) >= 4);
      if (matching.isNotEmpty) return option;
    }

    return options[_random.nextInt(options.length)];
  }

  String _balancedDecide(List<String> options, List<DecisionModel> history,
      double cognitiveLoad, int energyLevel) {
    // High cognitive load: prefer familiar, low-effort options
    if (cognitiveLoad > 60 || energyLevel <= 2) {
      return _quickDecide(options, history, DecisionCategory.misc);
    }
    // Normal load: prefer variety but with good track record
    return options[_random.nextInt(options.length)];
  }

  String _growthDecide(List<String> options, List<DecisionModel> history,
      DecisionCategory category) {
    // Prefer options not recently chosen
    final recentTitles =
        history.take(20).map((d) => d.title.toLowerCase()).toSet();
    final fresh = options
        .where((o) => !recentTitles.any(
            (t) => t.contains(o.toLowerCase())))
        .toList();
    if (fresh.isNotEmpty) {
      return fresh[_random.nextInt(fresh.length)];
    }
    return options[_random.nextInt(options.length)];
  }

  String _generateBalancedReasoning(
      DecisionCategory category, double cognitiveLoad) {
    if (cognitiveLoad > 70) {
      return 'Your cognitive load is high (${cognitiveLoad.toInt()}%). Selected the most familiar option to preserve mental energy.';
    } else if (cognitiveLoad > 40) {
      return 'Moderate load detected. Selected an option balancing familiarity and variety for optimal satisfaction.';
    } else {
      return 'You\'re in great mental shape! Selected an option aligned with your patterns and goals.';
    }
  }

  // ─── Outfit Intelligence ──────────────────────────────────────────────────

  OutfitSuggestion? suggestOutfit({
    required List<OutfitItemModel> availableItems,
    required int rotationDays,
    FormailityLevel? requiredFormality,
    WeatherSuitability? weather,
  }) {
    final filtered = availableItems.where((item) {
      if (item.wasWornWithinDays(rotationDays)) return false;
      if (requiredFormality != null && item.formality != requiredFormality) {
        return false;
      }
      if (weather != null &&
          !item.weatherSuitability.contains(weather) &&
          !item.weatherSuitability.contains(WeatherSuitability.allWeather)) {
        return false;
      }
      return true;
    }).toList();

    final tops = filtered.where((i) => i.category == ClothingCategory.top).toList();
    final bottoms = filtered.where((i) => i.category == ClothingCategory.bottom).toList();
    final shoes = filtered.where((i) => i.category == ClothingCategory.shoes).toList();

    if (tops.isEmpty || bottoms.isEmpty) return null;

    final chosen = <OutfitItemModel>[];
    tops.shuffle(_random);
    bottoms.shuffle(_random);
    shoes.shuffle(_random);

    chosen.add(tops.first);
    chosen.add(bottoms.first);
    if (shoes.isNotEmpty) chosen.add(shoes.first);

    // Add accessories occasionally
    final accessories = filtered.where((i) => i.category == ClothingCategory.accessories).toList();
    if (accessories.isNotEmpty && _random.nextBool()) {
      accessories.shuffle(_random);
      chosen.add(accessories.first);
    }

    final score = _calculateOutfitScore(chosen);
    return OutfitSuggestion(
      items: chosen,
      reasoning: _generateOutfitReasoning(chosen, rotationDays),
      matchScore: score,
    );
  }

  double _calculateOutfitScore(List<OutfitItemModel> items) {
    // Higher score for fresh items and compatible formality
    double score = 0.7;
    final formalityLevels = items.map((i) => i.formalityName).toSet();
    if (formalityLevels.length == 1) score += 0.2; // Consistent formality
    if (items.any((i) => i.lastWorn == null)) score += 0.1; // Never-worn item
    return score.clamp(0.0, 1.0);
  }

  String _generateOutfitReasoning(List<OutfitItemModel> items, int rotationDays) {
    final neverWorn = items.where((i) => i.lastWorn == null).toList();
    if (neverWorn.isNotEmpty) {
      return 'Great combo! Includes ${neverWorn.first.name} which you haven\'t worn yet. Fresh rotation maintained.';
    }
    return 'Perfect combination! These items haven\'t been worn for $rotationDays+ days, keeping your wardrobe fresh.';
  }

  Map<int, List<OutfitItemModel>> generateWeeklyOutfitPlan({
    required List<OutfitItemModel> allItems,
    required int rotationDays,
  }) {
    final plan = <int, List<OutfitItemModel>>{};
    final usedIds = <String>{};

    for (int day = 0; day < 7; day++) {
      final availableForDay = allItems.where((item) {
        if (usedIds.contains(item.id)) return false;
        if (item.wasWornWithinDays(rotationDays)) return false;
        return true;
      }).toList();

      final suggestion = suggestOutfit(
        availableItems: availableForDay,
        rotationDays: rotationDays,
      );

      if (suggestion != null) {
        plan[day] = suggestion.items;
        usedIds.addAll(suggestion.items.map((i) => i.id));
      } else {
        plan[day] = [];
      }
    }

    return plan;
  }

  // ─── Meal Intelligence ────────────────────────────────────────────────────

  MealSuggestion? suggestMeal({
    required List<MealModel> availableMeals,
    required MealType type,
    required int rotationDays,
    int? prepTimeAvailable,
    int? energyLevel,
    DietTag? preferredDiet,
  }) {
    var candidates = availableMeals.where((m) {
      if (m.mealType != type) return false;
      if (m.wasConsumedWithinDays(rotationDays)) return false;
      if (prepTimeAvailable != null && m.prepTimeMinutes > prepTimeAvailable) {
        return false;
      }
      return true;
    }).toList();

    if (candidates.isEmpty) {
      // Relax rotation constraint
      candidates = availableMeals.where((m) => m.mealType == type).toList();
    }

    if (candidates.isEmpty) return null;

    // Score each meal
    candidates.sort((a, b) => _mealScore(b, preferredDiet, energyLevel)
        .compareTo(_mealScore(a, preferredDiet, energyLevel)));

    final chosen = candidates.first;
    return MealSuggestion(
      meal: chosen,
      reasoning: _generateMealReasoning(chosen, energyLevel),
      matchScore: _mealScore(chosen, preferredDiet, energyLevel),
    );
  }

  double _mealScore(MealModel meal, DietTag? preferred, int? energy) {
    double score = meal.averageSatisfaction / 5;
    if (preferred != null && meal.dietTags.contains(preferred)) score += 0.2;
    if (energy != null && energy <= 2 && meal.prepTimeMinutes <= 10) score += 0.15;
    if (!meal.wasConsumedWithinDays(3)) score += 0.1;
    return score.clamp(0.0, 1.0);
  }

  String _generateMealReasoning(MealModel meal, int? energyLevel) {
    if (energyLevel != null && energyLevel <= 2) {
      return '${meal.name} is quick (${meal.prepTimeMinutes} min) and suits your low energy right now. Great nutrition, minimal effort.';
    }
    if (meal.averageSatisfaction >= 4) {
      return 'You\'ve rated ${meal.name} highly in the past. It\'s been a while since you had it — perfect timing!';
    }
    return '${meal.name} matches your goals and keeps your meal rotation fresh.';
  }

  Map<int, Map<String, MealModel>> generateWeeklyMealPlan({
    required List<MealModel> allMeals,
    required int rotationDays,
  }) {
    final plan = <int, Map<String, MealModel>>{};

    for (int day = 0; day < 7; day++) {
      plan[day] = {};
      for (final type in [MealType.breakfast, MealType.lunch, MealType.dinner]) {
        final suggestion = suggestMeal(
          availableMeals: allMeals,
          type: type,
          rotationDays: rotationDays,
        );
        if (suggestion != null) {
          plan[day]![type.name] = suggestion.meal;
        }
      }
    }

    return plan;
  }

  // ─── Fatigue Prediction ───────────────────────────────────────────────────

  String predictFatigueTime(List<MapEntry<DateTime, int>> weeklyData) {
    if (weeklyData.isEmpty) return 'Not enough data yet';

    final avgDecisions = weeklyData.fold(0, (sum, e) => sum + e.value) /
        weeklyData.length;

    if (avgDecisions > 80) {
      return 'High risk: Typically around 2:00 PM';
    } else if (avgDecisions > 50) {
      return 'Moderate risk: Around 4:00 PM';
    } else {
      return 'Low risk today';
    }
  }

  List<String> generateCognitiveRecommendations(CognitiveLoadResult load) {
    final recs = <String>[];

    if (load.risk == FatigueRisk.critical || load.risk == FatigueRisk.high) {
      recs.add('🔴 Activate Minimalist Mode immediately');
      recs.add('🤖 Use AI Decide for all remaining decisions today');
      recs.add('📋 Switch to pre-planned meals and outfits');
    } else if (load.risk == FatigueRisk.moderate) {
      recs.add('🟡 Consider automating food & outfit decisions');
      recs.add('⏰ Take a 10-min break before important decisions');
      recs.add('✅ Focus remaining energy on high-value work decisions');
    } else {
      recs.add('🟢 Great energy! Tackle high-value decisions now');
      recs.add('📈 Good time for creative problem-solving');
      recs.add('🎯 Focus on complex work tasks while sharp');
    }

    if (load.automatedCount == 0) {
      recs.add('💡 Set up Smart Defaults to automate low-value decisions');
    }

    return recs;
  }
}
