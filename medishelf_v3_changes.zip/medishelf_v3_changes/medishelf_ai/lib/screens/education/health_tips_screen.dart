// lib/screens/education/health_tips_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../core/app_theme.dart';
import '../../core/constants.dart';
import '../../blocs/settings/settings_bloc.dart';

class HealthTipsScreen extends StatefulWidget {
  const HealthTipsScreen({super.key});

  @override
  State<HealthTipsScreen> createState() => _HealthTipsScreenState();
}

class _HealthTipsScreenState extends State<HealthTipsScreen> {
  int _expandedIndex = 0;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final lang =
        context.watch<SettingsBloc>().state.languageCode == 'ur' ? 'ur' : 'en';

    return Scaffold(
      appBar: AppBar(
        title: const Text('Health Education'),
        actions: [
          IconButton(
            icon: const Icon(Icons.translate),
            tooltip: 'Switch Language',
            onPressed: () {
              final current =
                  context.read<SettingsBloc>().state.languageCode;
              context
                  .read<SettingsBloc>()
                  .add(ChangeLanguage(current == 'ur' ? 'en' : 'ur'));
            },
          ),
        ],
      ),
      body: CustomScrollView(
        slivers: [
          // Hero banner
          SliverToBoxAdapter(
            child: Container(
              margin: const EdgeInsets.fromLTRB(16, 16, 16, 8),
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [AppColors.primary, AppColors.secondary],
                ),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('🏥', style: TextStyle(fontSize: 36)),
                  const SizedBox(height: 10),
                  Text(
                    lang == 'ur'
                        ? 'صحت سے متعلق رہنما اصول'
                        : 'Health Education Tips',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    lang == 'ur'
                        ? '100٪ آف لائن • اردو اور انگریزی'
                        : '100% Offline • English & Urdu',
                    style: const TextStyle(
                        color: Colors.white70, fontSize: 12),
                  ),
                ],
              ),
            ).animate().fadeIn(duration: 400.ms).slideY(begin: -0.1),
          ),

          // Language toggle row
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
              child: Row(
                children: [
                  _LangChip(
                    label: '🇬🇧 English',
                    isSelected: lang == 'en',
                    onTap: () => context
                        .read<SettingsBloc>()
                        .add(const ChangeLanguage('en')),
                  ),
                  const SizedBox(width: 10),
                  _LangChip(
                    label: '🇵🇰 اردو',
                    isSelected: lang == 'ur',
                    onTap: () => context
                        .read<SettingsBloc>()
                        .add(const ChangeLanguage('ur')),
                  ),
                ],
              ),
            ),
          ),

          // Tips list
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 100),
            sliver: SliverList(
              delegate: SliverChildBuilderDelegate(
                (context, i) {
                  final tip = AppConstants.healthTips[i];
                  final isExpanded = _expandedIndex == i;
                  final title = lang == 'ur'
                      ? tip['titleUr']!
                      : tip['titleEn']!;
                  final body =
                      lang == 'ur' ? tip['tipUr']! : tip['tipEn']!;

                  return Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: _TipCard(
                      emoji: tip['emoji']!,
                      title: title,
                      body: body,
                      isExpanded: isExpanded,
                      isRtl: lang == 'ur',
                      onTap: () => setState(() =>
                          _expandedIndex = isExpanded ? -1 : i),
                    ).animate(delay: (i * 50).ms).fadeIn().slideX(begin: 0.05),
                  );
                },
                childCount: AppConstants.healthTips.length,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Tip card ──────────────────────────────────────────────────────────────────

class _TipCard extends StatelessWidget {
  final String emoji;
  final String title;
  final String body;
  final bool isExpanded;
  final bool isRtl;
  final VoidCallback onTap;

  const _TipCard({
    required this.emoji,
    required this.title,
    required this.body,
    required this.isExpanded,
    required this.isRtl,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeInOut,
        decoration: BoxDecoration(
          color: isExpanded
              ? AppColors.primary.withOpacity(0.05)
              : theme.colorScheme.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isExpanded
                ? AppColors.primary.withOpacity(0.35)
                : theme.colorScheme.outline,
            width: isExpanded ? 1.5 : 1,
          ),
          boxShadow: isExpanded
              ? [
                  BoxShadow(
                    color: AppColors.primary.withOpacity(0.08),
                    blurRadius: 12,
                    offset: const Offset(0, 4),
                  )
                ]
              : null,
        ),
        child: Directionality(
          textDirection: isRtl ? TextDirection.rtl : TextDirection.ltr,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(emoji, style: const TextStyle(fontSize: 26)),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        title,
                        style: theme.textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.w700,
                          color: isExpanded ? AppColors.primary : null,
                        ),
                      ),
                    ),
                    AnimatedRotation(
                      turns: isExpanded ? 0.5 : 0,
                      duration: const Duration(milliseconds: 200),
                      child: Icon(
                        Icons.keyboard_arrow_down,
                        color: isExpanded
                            ? AppColors.primary
                            : AppColors.textMuted,
                      ),
                    ),
                  ],
                ),
                AnimatedCrossFade(
                  firstChild: const SizedBox.shrink(),
                  secondChild: Padding(
                    padding: const EdgeInsets.only(top: 12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Divider(height: 1),
                        const SizedBox(height: 12),
                        Text(
                          body,
                          style: theme.textTheme.bodyMedium?.copyWith(
                            height: 1.6,
                            color: theme.colorScheme.onSurface
                                .withOpacity(0.85),
                          ),
                        ),
                      ],
                    ),
                  ),
                  crossFadeState: isExpanded
                      ? CrossFadeState.showSecond
                      : CrossFadeState.showFirst,
                  duration: const Duration(milliseconds: 250),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ── Language chip ─────────────────────────────────────────────────────────────

class _LangChip extends StatelessWidget {
  final String label;
  final bool isSelected;
  final VoidCallback onTap;

  const _LangChip(
      {required this.label,
      required this.isSelected,
      required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected
              ? AppColors.primary.withOpacity(0.12)
              : AppColors.surfaceVariant,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isSelected ? AppColors.primary : AppColors.border,
            width: isSelected ? 1.5 : 1,
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: isSelected ? AppColors.primary : AppColors.textSecondary,
            fontWeight:
                isSelected ? FontWeight.w700 : FontWeight.w400,
            fontSize: 13,
          ),
        ),
      ),
    );
  }
}
