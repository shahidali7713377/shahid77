// lib/screens/archive/archive_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:intl/intl.dart';
import '../../core/app_theme.dart';
import '../../data/models/medicine_model.dart';
import '../../data/repositories/medicine_repository.dart';

class ArchiveScreen extends StatefulWidget {
  const ArchiveScreen({super.key});

  @override
  State<ArchiveScreen> createState() => _ArchiveScreenState();
}

class _ArchiveScreenState extends State<ArchiveScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final _repo = MedicineRepository();

  List<Medicine> _disposed = [];
  List<Medicine> _expired = [];
  bool _loading = true;

  // Simple stats derived from archive
  Map<String, int> _typeCount = {};
  Map<String, int> _monthlyExpiry = {};

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _load();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final all =
        await _repo.getMedicines(includeDisposed: true);
    final disposed = all.where((m) => m.isDisposed).toList();
    final expired = all.where((m) => m.isExpired && !m.isDisposed).toList();

    // Compute type breakdown from disposed + expired
    final typeCount = <String, int>{};
    for (final m in [...disposed, ...expired]) {
      typeCount[m.type] = (typeCount[m.type] ?? 0) + 1;
    }

    // Monthly expiry pattern (last 12 months)
    final monthly = <String, int>{};
    for (final m in [...disposed, ...expired]) {
      final key = DateFormat('MMM yy').format(m.expiryDate);
      monthly[key] = (monthly[key] ?? 0) + 1;
    }

    setState(() {
      _disposed = disposed..sort((a, b) => b.expiryDate.compareTo(a.expiryDate));
      _expired = expired..sort((a, b) => a.daysUntilExpiry.compareTo(b.daysUntilExpiry));
      _typeCount = typeCount;
      _monthlyExpiry = monthly;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Archive & History'),
        bottom: TabBar(
          controller: _tabController,
          tabs: [
            Tab(
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.archive_outlined, size: 16),
                  const SizedBox(width: 6),
                  Text('Disposed (${_disposed.length})'),
                ],
              ),
            ),
            Tab(
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.cancel_outlined, size: 16),
                  const SizedBox(width: 6),
                  Text('Expired (${_expired.length})'),
                ],
              ),
            ),
            const Tab(
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.bar_chart, size: 16),
                  SizedBox(width: 6),
                  Text('Patterns'),
                ],
              ),
            ),
          ],
          indicatorColor: AppColors.primary,
          labelColor: AppColors.primary,
          unselectedLabelColor: AppColors.textSecondary,
          dividerColor: Colors.transparent,
          isScrollable: true,
          tabAlignment: TabAlignment.start,
        ),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : TabBarView(
              controller: _tabController,
              children: [
                _buildDisposedList(),
                _buildExpiredList(),
                _buildPatterns(),
              ],
            ),
    );
  }

  // ── Disposed tab ───────────────────────────────────────────────────────────

  Widget _buildDisposedList() {
    if (_disposed.isEmpty) {
      return _buildEmpty(
        '🗂️',
        'No Disposed Medicines',
        'Medicines you mark as disposed will appear here for reference.',
      );
    }
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: _disposed.length,
        separatorBuilder: (_, __) => const SizedBox(height: 10),
        itemBuilder: (context, i) => _ArchiveCard(
          medicine: _disposed[i],
          badge: 'Disposed',
          badgeColor: AppColors.textMuted,
          onRestore: () => _restoreDialog(_disposed[i]),
        ).animate(delay: (i * 40).ms).fadeIn().slideY(begin: 0.1),
      ),
    );
  }

  // ── Expired tab ────────────────────────────────────────────────────────────

  Widget _buildExpiredList() {
    if (_expired.isEmpty) {
      return _buildEmpty(
        '✅',
        'No Expired Medicines',
        'All your active medicines are within date. Well done!',
      );
    }
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: _expired.length,
        separatorBuilder: (_, __) => const SizedBox(height: 10),
        itemBuilder: (context, i) => _ArchiveCard(
          medicine: _expired[i],
          badge: 'Expired',
          badgeColor: AppColors.expired,
          onRestore: null,
          onDispose: () => _disposeNow(_expired[i]),
        ).animate(delay: (i * 40).ms).fadeIn().slideY(begin: 0.1),
      ),
    );
  }

  // ── Patterns tab ───────────────────────────────────────────────────────────

  Widget _buildPatterns() {
    final total = _disposed.length + _expired.length;
    if (total == 0) {
      return _buildEmpty('📊', 'No Data Yet',
          'Usage patterns will appear here once medicines are archived.');
    }

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        // Summary cards
        Row(
          children: [
            _StatBubble(
              label: 'Total Archived',
              value: '$total',
              color: AppColors.primary,
            ),
            const SizedBox(width: 10),
            _StatBubble(
              label: 'Disposed Safely',
              value: '${_disposed.length}',
              color: AppColors.safe,
            ),
            const SizedBox(width: 10),
            _StatBubble(
              label: 'Still Expired',
              value: '${_expired.length}',
              color: AppColors.expired,
            ),
          ],
        ),
        const SizedBox(height: 20),

        // Medicine type breakdown
        Text('Medicine Type Breakdown',
            style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 12),
        ..._typeCount.entries.map((e) {
          final pct = e.value / total;
          return Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('${e.key}',
                        style: const TextStyle(
                            fontSize: 13, fontWeight: FontWeight.w500)),
                    Text('${e.value} (${(pct * 100).toStringAsFixed(0)}%)',
                        style: const TextStyle(
                            fontSize: 12, color: AppColors.textSecondary)),
                  ],
                ),
                const SizedBox(height: 4),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                    value: pct,
                    minHeight: 8,
                    backgroundColor: AppColors.border,
                    valueColor: const AlwaysStoppedAnimation(AppColors.primary),
                  ),
                ),
              ],
            ),
          );
        }),

        const SizedBox(height: 20),

        // Tips based on pattern
        if (_expired.length > 2)
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.warningLight,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: AppColors.warning.withOpacity(0.3)),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('💡', style: TextStyle(fontSize: 22)),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Pattern Insight',
                          style: TextStyle(
                              fontWeight: FontWeight.w700, fontSize: 13)),
                      const SizedBox(height: 4),
                      Text(
                        'You have ${_expired.length} medicines that expired without being disposed. '
                        'Consider enabling weekly summary notifications to stay ahead.',
                        style: const TextStyle(fontSize: 12, height: 1.5),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
      ],
    );
  }

  Widget _buildEmpty(String emoji, String title, String subtitle) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(emoji, style: const TextStyle(fontSize: 64)),
          const SizedBox(height: 16),
          Text(title,
              style: const TextStyle(
                  fontSize: 18, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 40),
            child: Text(subtitle,
                textAlign: TextAlign.center,
                style: const TextStyle(color: AppColors.textSecondary)),
          ),
        ],
      ).animate().fadeIn(),
    );
  }

  Future<void> _restoreDialog(Medicine medicine) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Restore Medicine?'),
        content: Text(
            'Move "${medicine.name}" back to your active medicines?'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel')),
          ElevatedButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Restore')),
        ],
      ),
    );
    if (confirm == true) {
      final restored = medicine.copyWith(isDisposed: false);
      await _repo.updateMedicine(restored);
      await _load();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('✅ Medicine restored to active list.')),
        );
      }
    }
  }

  Future<void> _disposeNow(Medicine medicine) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Mark as Disposed?'),
        content: Text(
            'Move "${medicine.name}" to disposed history? This confirms safe disposal.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel')),
          ElevatedButton(
              onPressed: () => Navigator.pop(context, true),
              style: ElevatedButton.styleFrom(backgroundColor: AppColors.safe),
              child: const Text('Mark Disposed')),
        ],
      ),
    );
    if (confirm == true) {
      final updated = medicine.copyWith(isDisposed: true);
      await _repo.updateMedicine(updated);
      await _load();
    }
  }
}

// ── Archive card ──────────────────────────────────────────────────────────────

class _ArchiveCard extends StatelessWidget {
  final Medicine medicine;
  final String badge;
  final Color badgeColor;
  final VoidCallback? onRestore;
  final VoidCallback? onDispose;

  const _ArchiveCard({
    required this.medicine,
    required this.badge,
    required this.badgeColor,
    this.onRestore,
    this.onDispose,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: theme.colorScheme.outline),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: badgeColor.withOpacity(0.10),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Center(
              child: Text(medicine.typeEmoji,
                  style: const TextStyle(fontSize: 20)),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(medicine.name,
                          style: const TextStyle(
                              fontWeight: FontWeight.w700, fontSize: 14),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 7, vertical: 3),
                      decoration: BoxDecoration(
                        color: badgeColor.withOpacity(0.10),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(badge,
                          style: TextStyle(
                              color: badgeColor,
                              fontSize: 10,
                              fontWeight: FontWeight.w700)),
                    ),
                  ],
                ),
                const SizedBox(height: 3),
                Text(
                  '${medicine.type}  •  Exp: ${DateFormat('dd/MM/yyyy').format(medicine.expiryDate)}',
                  style: const TextStyle(
                      color: AppColors.textSecondary, fontSize: 12),
                ),
                if (medicine.doctorName != null)
                  Text('Dr. ${medicine.doctorName}',
                      style: const TextStyle(
                          color: AppColors.textMuted, fontSize: 11)),
              ],
            ),
          ),
          if (onRestore != null)
            IconButton(
              icon: const Icon(Icons.restore,
                  color: AppColors.primary, size: 20),
              tooltip: 'Restore',
              onPressed: onRestore,
            ),
          if (onDispose != null)
            IconButton(
              icon: const Icon(Icons.delete_sweep_outlined,
                  color: AppColors.safe, size: 20),
              tooltip: 'Dispose',
              onPressed: onDispose,
            ),
        ],
      ),
    );
  }
}

// ── Stat bubble ───────────────────────────────────────────────────────────────

class _StatBubble extends StatelessWidget {
  final String label;
  final String value;
  final Color color;

  const _StatBubble(
      {required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: color.withOpacity(0.08),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: color.withOpacity(0.2)),
        ),
        child: Column(
          children: [
            Text(value,
                style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w800,
                    color: color)),
            const SizedBox(height: 2),
            Text(label,
                textAlign: TextAlign.center,
                style: const TextStyle(
                    fontSize: 11, color: AppColors.textSecondary)),
          ],
        ),
      ),
    );
  }
}
