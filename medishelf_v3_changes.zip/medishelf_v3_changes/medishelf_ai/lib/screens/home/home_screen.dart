// lib/screens/home/home_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../core/app_routes.dart';
import '../../core/app_theme.dart';
import '../../blocs/medicine/medicine_bloc.dart';
import '../../blocs/dashboard/dashboard_bloc.dart';
import 'dashboard_screen.dart';
import '../medicine/medicine_list_screen.dart';
import '../profiles/profiles_screen.dart';
import '../settings/settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;

  final _screens = const [
    DashboardScreen(),
    MedicineListScreen(),
    ProfilesScreen(embedded: true),
    SettingsScreen(embedded: true),
  ];

  @override
  void initState() {
    super.initState();
    context.read<MedicineBloc>().add(const LoadMedicines());
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: _screens,
      ),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          border: Border(
            top: BorderSide(
              color: isDark ? AppColors.darkBorder : AppColors.border,
              width: 1,
            ),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.04),
              blurRadius: 20,
              offset: const Offset(0, -5),
            ),
          ],
        ),
        child: NavigationBar(
          selectedIndex: _currentIndex,
          onDestinationSelected: (index) {
            setState(() => _currentIndex = index);
            if (index == 0) {
              context.read<DashboardBloc>().add(const RefreshDashboard());
            }
          },
          backgroundColor:
              isDark ? AppColors.darkSurface : AppColors.surface,
          indicatorColor: AppColors.primary.withOpacity(0.12),
          labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
          destinations: [
            NavigationDestination(
              icon: Icon(Icons.dashboard_outlined,
                  color: _currentIndex == 0
                      ? AppColors.primary
                      : AppColors.textMuted),
              selectedIcon:
                  const Icon(Icons.dashboard, color: AppColors.primary),
              label: 'Dashboard',
            ),
            _buildMedicineBadge(),
            const NavigationDestination(
              icon: Icon(Icons.people_outline),
              selectedIcon: Icon(Icons.people),
              label: 'Family',
            ),
            const NavigationDestination(
              icon: Icon(Icons.settings_outlined),
              selectedIcon: Icon(Icons.settings),
              label: 'Settings',
            ),
          ],
        ),
      ),
      // Quick-access FAB row on Dashboard for new features
      floatingActionButton: _currentIndex == 0 ? _buildQuickAccessRow() : null,
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
    );
  }

  NavigationDestination _buildMedicineBadge() {
    return NavigationDestination(
      icon: BlocBuilder<MedicineBloc, MedicineState>(
        builder: (context, state) {
          int count = 0;
          if (state is MedicinesLoaded) {
            count = state.expired.length + state.critical.length;
          }
          return count > 0
              ? Badge(
                  label: Text('$count',
                      style: const TextStyle(fontSize: 10)),
                  backgroundColor: AppColors.expired,
                  child: Icon(Icons.medication_outlined,
                      color: _currentIndex == 1
                          ? AppColors.primary
                          : AppColors.textMuted),
                )
              : Icon(Icons.medication_outlined,
                  color: _currentIndex == 1
                      ? AppColors.primary
                      : AppColors.textMuted);
        },
      ),
      selectedIcon: const Icon(Icons.medication, color: AppColors.primary),
      label: 'Medicines',
    );
  }

  Widget _buildQuickAccessRow() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        // Health Tips
        _MiniActionButton(
          icon: '🏥',
          label: 'Health Tips',
          onTap: () => Navigator.pushNamed(context, AppRoutes.healthTips),
        ),
        const SizedBox(height: 8),
        // Archive
        _MiniActionButton(
          icon: '🗂️',
          label: 'Archive',
          onTap: () => Navigator.pushNamed(context, AppRoutes.archive),
        ),
        const SizedBox(height: 8),
        // Emergency
        _MiniActionButton(
          icon: '🆘',
          label: 'Emergency',
          onTap: () => Navigator.pushNamed(context, AppRoutes.emergency),
          color: AppColors.expired,
        ),
      ],
    );
  }
}

class _MiniActionButton extends StatelessWidget {
  final String icon;
  final String label;
  final VoidCallback onTap;
  final Color color;

  const _MiniActionButton({
    required this.icon,
    required this.label,
    required this.onTap,
    this.color = AppColors.primary,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(24),
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(0.35),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(icon, style: const TextStyle(fontSize: 16)),
            const SizedBox(width: 8),
            Text(label,
                style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                    fontSize: 13)),
          ],
        ),
      ),
    );
  }
}
