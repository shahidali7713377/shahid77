// lib/screens/medicine/add_medicine_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';
import '../../core/app_theme.dart';
import '../../core/app_routes.dart';
import '../../core/constants.dart';
import '../../blocs/medicine/medicine_bloc.dart';
import '../../blocs/profile/profile_bloc.dart';
import '../../data/models/medicine_model.dart';
import '../../data/models/family_member_model.dart';
import '../../widgets/voice_entry_sheet.dart';

class AddMedicineScreen extends StatefulWidget {
  final Map<String, dynamic>? initialData;

  const AddMedicineScreen({super.key, this.initialData});

  @override
  State<AddMedicineScreen> createState() => _AddMedicineScreenState();
}

class _AddMedicineScreenState extends State<AddMedicineScreen> {
  final _formKey = GlobalKey<FormState>();
  final _uuid = const Uuid();

  // Controllers
  late TextEditingController _nameCtrl;
  late TextEditingController _quantityCtrl;
  late TextEditingController _notesCtrl;
  late TextEditingController _doctorCtrl;

  // State
  String _selectedType = AppConstants.medicineTypes.first;
  DateTime? _mfgDate;
  DateTime? _expiryDate;
  final Set<String> _selectedMemberIds = {};   // ← multi-select set
  bool _isSaving = false;
  Medicine? _editingMedicine;

  @override
  void initState() {
    super.initState();

    final data = widget.initialData;
    _editingMedicine = data?['medicine'] as Medicine?;

    _nameCtrl = TextEditingController(
      text: (_editingMedicine?.name ?? data?['name'] ?? '') as String,
    );
    _quantityCtrl = TextEditingController(
      text: (_editingMedicine?.quantity ?? 1).toString(),
    );
    _notesCtrl = TextEditingController(text: _editingMedicine?.notes ?? '');
    _doctorCtrl = TextEditingController(text: _editingMedicine?.doctorName ?? '');

    if (_editingMedicine != null) {
      _selectedType = _editingMedicine!.type;
      _mfgDate = _editingMedicine!.mfgDate;
      _expiryDate = _editingMedicine!.expiryDate;
      _selectedMemberIds.addAll(_editingMedicine!.familyMemberIds);
    } else if (data != null) {
      if (data['mfgDate'] is DateTime) _mfgDate = data['mfgDate'] as DateTime;
      if (data['expiryDate'] is DateTime) _expiryDate = data['expiryDate'] as DateTime;
    }
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _quantityCtrl.dispose();
    _notesCtrl.dispose();
    _doctorCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isEditing = _editingMedicine != null;

    return Scaffold(
      appBar: AppBar(
        title: Text(isEditing ? 'Edit Medicine' : 'Add Medicine'),
        actions: [
          TextButton(
            onPressed: _isSaving ? null : _save,
            child: _isSaving
                ? const SizedBox(
                    width: 16, height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : Text(isEditing ? 'Update' : 'Save',
                    style: const TextStyle(
                      color: AppColors.primary,
                      fontWeight: FontWeight.w700,
                    )),
          ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            // Entry method banners (Camera + Voice)
            if (!isEditing)
              Column(
                children: [
                  // Camera scan
                  GestureDetector(
                    onTap: () async {
                      final result = await Navigator.pushNamed(
                          context, AppRoutes.cameraScan);
                      if (result is Map<String, dynamic>) {
                        setState(() {
                          if (result['name'] != null)
                            _nameCtrl.text = result['name'];
                          if (result['mfgDate'] != null)
                            _mfgDate = result['mfgDate'];
                          if (result['expiryDate'] != null)
                            _expiryDate = result['expiryDate'];
                        });
                      }
                    },
                    child: Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            AppColors.primary.withOpacity(0.08),
                            AppColors.secondary.withOpacity(0.08)
                          ],
                        ),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                            color: AppColors.primary.withOpacity(0.2)),
                      ),
                      child: Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: AppColors.primary.withOpacity(0.12),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(Icons.camera_alt,
                                color: AppColors.primary, size: 20),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('📷 Scan Medicine Label',
                                    style: Theme.of(context)
                                        .textTheme
                                        .titleSmall
                                        ?.copyWith(
                                            color: AppColors.primary,
                                            fontWeight: FontWeight.w700)),
                                Text('AI reads name, MFG & expiry dates',
                                    style: Theme.of(context)
                                        .textTheme
                                        .bodySmall),
                              ],
                            ),
                          ),
                          const Icon(Icons.arrow_forward_ios,
                              size: 14, color: AppColors.primary),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 10),

                  // Voice entry (for illiterate users)
                  GestureDetector(
                    onTap: () async {
                      final result = await showVoiceEntrySheet(context);
                      if (result != null) {
                        setState(() {
                          if (result.name != null &&
                              result.name!.isNotEmpty) {
                            _nameCtrl.text = result.name!;
                          }
                          if (result.expiryDate != null) {
                            _expiryDate = result.expiryDate;
                          }
                          if (result.type != null) {
                            _selectedType = result.type!;
                          }
                          if (result.quantity != null) {
                            _quantityCtrl.text =
                                result.quantity.toString();
                          }
                        });
                        if (mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content:
                                  Text('✅ Voice details applied — review & save'),
                              backgroundColor: AppColors.safe,
                            ),
                          );
                        }
                      }
                    },
                    child: Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            AppColors.safe.withOpacity(0.08),
                            AppColors.safe.withOpacity(0.04)
                          ],
                        ),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                            color: AppColors.safe.withOpacity(0.25)),
                      ),
                      child: Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: AppColors.safe.withOpacity(0.12),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(Icons.mic,
                                color: AppColors.safe, size: 20),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('🎤 Voice Entry (بولیں)',
                                    style: Theme.of(context)
                                        .textTheme
                                        .titleSmall
                                        ?.copyWith(
                                            color: AppColors.safe,
                                            fontWeight: FontWeight.w700)),
                                Text(
                                    'Speak: "Paracetamol, expiry 2027"',
                                    style: Theme.of(context)
                                        .textTheme
                                        .bodySmall),
                              ],
                            ),
                          ),
                          const Icon(Icons.arrow_forward_ios,
                              size: 14, color: AppColors.safe),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 20),
                  Row(
                    children: [
                      Expanded(child: Divider(color: AppColors.border)),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        child: Text('or fill manually',
                            style: Theme.of(context)
                                .textTheme
                                .bodySmall
                                ?.copyWith(color: AppColors.textMuted)),
                      ),
                      Expanded(child: Divider(color: AppColors.border)),
                    ],
                  ),
                  const SizedBox(height: 20),
                ],
              ),

            // Medicine Name
            _buildFieldLabel('Medicine Name *'),
            TextFormField(
              controller: _nameCtrl,
              textCapitalization: TextCapitalization.words,
              decoration: const InputDecoration(
                hintText: 'e.g., Paracetamol 500mg',
                prefixIcon: Icon(Icons.medication),
              ),
              validator: (v) => v?.trim().isEmpty == true ? 'Medicine name is required' : null,
            ),
            const SizedBox(height: 20),

            // Medicine Type
            _buildFieldLabel('Medicine Type *'),
            _buildTypeSelector(),
            const SizedBox(height: 20),

            // Dates Row
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildFieldLabel('Mfg. Date'),
                      _buildDateField(
                        date: _mfgDate,
                        hint: 'MM/YYYY',
                        icon: Icons.factory_outlined,
                        onTap: () => _pickDate(isMfg: true),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildFieldLabel('Expiry Date *'),
                      _buildDateField(
                        date: _expiryDate,
                        hint: 'MM/YYYY',
                        icon: Icons.event_outlined,
                        onTap: () => _pickDate(isMfg: false),
                        isRequired: true,
                      ),
                    ],
                  ),
                ),
              ],
            ),
            if (_expiryDate == null)
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Text(
                  '⚠️ Expiry date is required',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: AppColors.warning,
                  ),
                ),
              ),
            const SizedBox(height: 20),

            // Quantity
            _buildFieldLabel('Quantity'),
            TextFormField(
              controller: _quantityCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                hintText: '1',
                prefixIcon: Icon(Icons.inventory_2_outlined),
                suffixText: 'units',
              ),
              validator: (v) {
                if (v?.trim().isEmpty == true) return null;
                final n = int.tryParse(v!.trim());
                if (n == null || n < 1) return 'Enter a valid quantity';
                return null;
              },
            ),
            const SizedBox(height: 20),

            // Family Members — multi-select
            _buildFieldLabel('Assign to Family Member(s)'),
            _buildFamilyMemberPicker(),
            const SizedBox(height: 20),

            // Doctor Name
            _buildFieldLabel('Doctor Name (Optional)'),
            TextFormField(
              controller: _doctorCtrl,
              textCapitalization: TextCapitalization.words,
              decoration: const InputDecoration(
                hintText: 'Dr. Ahmed Khan',
                prefixIcon: Icon(Icons.local_hospital_outlined),
              ),
            ),
            const SizedBox(height: 20),

            // Notes
            _buildFieldLabel('Notes (Optional)'),
            TextFormField(
              controller: _notesCtrl,
              maxLines: 3,
              decoration: const InputDecoration(
                hintText: 'Dosage instructions, purpose, etc.',
                prefixIcon: Icon(Icons.notes),
                alignLabelWithHint: true,
              ),
            ),
            const SizedBox(height: 40),

            // Save Button
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton.icon(
                onPressed: _isSaving ? null : _save,
                icon: Icon(isEditing ? Icons.check : Icons.save),
                label: Text(isEditing ? 'Update Medicine' : 'Save Medicine'),
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildFieldLabel(String label) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Text(
        label,
        style: Theme.of(context).textTheme.titleSmall?.copyWith(
              color: AppColors.textSecondary,
              fontSize: 13,
            ),
      ),
    );
  }

  Widget _buildTypeSelector() {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: AppConstants.medicineTypes.map((type) {
        final isSelected = _selectedType == type;
        return GestureDetector(
          onTap: () => setState(() => _selectedType = type),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: isSelected ? AppColors.primary.withOpacity(0.12) : AppColors.surfaceVariant,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: isSelected ? AppColors.primary : AppColors.border,
                width: isSelected ? 1.5 : 1,
              ),
            ),
            child: Text(
              '${AppConstants.medicineTypeEmojis[type]} $type',
              style: TextStyle(
                fontSize: 13,
                color: isSelected ? AppColors.primary : AppColors.textPrimary,
                fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
              ),
            ),
          ),
        );
      }).toList(),
    );
  }

  /// Multi-select family member picker with checkboxes.
  Widget _buildFamilyMemberPicker() {
    return BlocBuilder<ProfileBloc, ProfileState>(
      builder: (context, state) {
        final members =
            state is ProfilesLoaded ? state.members : <FamilyMember>[];

        if (members.isEmpty) {
          return GestureDetector(
            onTap: () => Navigator.pushNamed(context, AppRoutes.profiles),
            child: Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppColors.surfaceVariant,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.border),
              ),
              child: Row(
                children: [
                  const Icon(Icons.people_outline,
                      color: AppColors.textMuted, size: 18),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'No family profiles yet — tap to add',
                      style: TextStyle(
                          color: AppColors.textMuted, fontSize: 13),
                    ),
                  ),
                  const Icon(Icons.arrow_forward_ios,
                      size: 12, color: AppColors.textMuted),
                ],
              ),
            ),
          );
        }

        // Summary chip row when members are selected
        final selectedNames = members
            .where((m) => _selectedMemberIds.contains(m.id))
            .map((m) => '${m.emoji} ${m.name}')
            .toList();

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Hint row
            Row(
              children: [
                const Icon(Icons.info_outline,
                    size: 13, color: AppColors.textMuted),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    'Select one or more. Leave blank for general / shared medicines.',
                    style: Theme.of(context)
                        .textTheme
                        .bodySmall
                        ?.copyWith(color: AppColors.textMuted),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),

            // Checkbox list
            Container(
              decoration: BoxDecoration(
                color: AppColors.surfaceVariant,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.border),
              ),
              child: Column(
                children: members.asMap().entries.map((entry) {
                  final idx = entry.key;
                  final member = entry.value;
                  final isChecked =
                      _selectedMemberIds.contains(member.id);
                  final isLast = idx == members.length - 1;

                  return Column(
                    children: [
                      InkWell(
                        onTap: () => setState(() {
                          if (isChecked) {
                            _selectedMemberIds.remove(member.id);
                          } else {
                            _selectedMemberIds.add(member.id);
                          }
                        }),
                        borderRadius: BorderRadius.vertical(
                          top: idx == 0
                              ? const Radius.circular(12)
                              : Radius.zero,
                          bottom: isLast
                              ? const Radius.circular(12)
                              : Radius.zero,
                        ),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 14, vertical: 10),
                          child: Row(
                            children: [
                              Text(member.emoji,
                                  style: const TextStyle(fontSize: 22)),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                  children: [
                                    Text(member.name,
                                        style: const TextStyle(
                                            fontSize: 14,
                                            fontWeight: FontWeight.w600)),
                                    Text(member.relation,
                                        style: const TextStyle(
                                            fontSize: 12,
                                            color: AppColors.textSecondary)),
                                  ],
                                ),
                              ),
                              Checkbox(
                                value: isChecked,
                                activeColor: AppColors.primary,
                                shape: RoundedRectangleBorder(
                                    borderRadius:
                                        BorderRadius.circular(4)),
                                onChanged: (_) => setState(() {
                                  if (isChecked) {
                                    _selectedMemberIds.remove(member.id);
                                  } else {
                                    _selectedMemberIds.add(member.id);
                                  }
                                }),
                              ),
                            ],
                          ),
                        ),
                      ),
                      if (!isLast)
                        const Divider(height: 1, indent: 56, endIndent: 16),
                    ],
                  );
                }).toList(),
              ),
            ),

            // Selected summary chips
            if (selectedNames.isNotEmpty) ...[
              const SizedBox(height: 10),
              Wrap(
                spacing: 6,
                runSpacing: 6,
                children: selectedNames
                    .map((name) => Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 5),
                          decoration: BoxDecoration(
                            color: AppColors.primary.withOpacity(0.10),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                                color:
                                    AppColors.primary.withOpacity(0.25)),
                          ),
                          child: Text(
                            name,
                            style: const TextStyle(
                                color: AppColors.primary,
                                fontSize: 12,
                                fontWeight: FontWeight.w600),
                          ),
                        ))
                    .toList(),
              ),
            ],
          ],
        );
      },
    );
  }

  Widget _buildDateField({
    required DateTime? date,
    required String hint,
    required IconData icon,
    required VoidCallback onTap,
    bool isRequired = false,
  }) {
    final hasDate = date != null;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        decoration: BoxDecoration(
          color: AppColors.surfaceVariant,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isRequired && !hasDate ? AppColors.warning.withOpacity(0.5) : AppColors.border,
          ),
        ),
        child: Row(
          children: [
            Icon(icon, size: 16, color: hasDate ? AppColors.primary : AppColors.textMuted),
            const SizedBox(width: 8),
            Text(
              hasDate ? DateFormat('MM/yyyy').format(date!) : hint,
              style: TextStyle(
                color: hasDate ? AppColors.textPrimary : AppColors.textMuted,
                fontSize: 14,
                fontWeight: hasDate ? FontWeight.w500 : FontWeight.w400,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _pickDate({required bool isMfg}) async {
    final now = DateTime.now();
    final initial = isMfg
        ? (_mfgDate ?? now.subtract(const Duration(days: 365)))
        : (_expiryDate ?? now.add(const Duration(days: 365)));

    final picked = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: DateTime(2000),
      lastDate: DateTime(2040),
      initialDatePickerMode: DatePickerMode.year,
      helpText: isMfg ? 'Select Manufacturing Date' : 'Select Expiry Date',
    );

    if (picked != null) {
      setState(() {
        if (isMfg) {
          _mfgDate = DateTime(picked.year, picked.month, 1);
          // Auto-predict expiry if not set
          if (_expiryDate == null) {
            final shelfMonths = AppConstants.typicalShelfLife[_selectedType] ?? 24;
            _expiryDate = DateTime(picked.year, picked.month + shelfMonths, 1);
          }
        } else {
          _expiryDate = DateTime(picked.year, picked.month, picked.day);
        }
      });
    }
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    if (_expiryDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select an expiry date'), backgroundColor: AppColors.warning),
      );
      return;
    }

    setState(() => _isSaving = true);

    final medicine = Medicine(
      id: _editingMedicine?.id ?? _uuid.v4(),
      name: _nameCtrl.text.trim(),
      type: _selectedType,
      mfgDate: _mfgDate,
      expiryDate: _expiryDate!,
      quantity: int.tryParse(_quantityCtrl.text.trim()) ?? 1,
      notes: _notesCtrl.text.trim().isEmpty ? null : _notesCtrl.text.trim(),
      doctorName: _doctorCtrl.text.trim().isEmpty ? null : _doctorCtrl.text.trim(),
      familyMemberIds: _selectedMemberIds.toList(),
      addedAt: _editingMedicine?.addedAt ?? DateTime.now(),
    );

    if (_editingMedicine != null) {
      context.read<MedicineBloc>().add(UpdateMedicine(medicine));
    } else {
      context.read<MedicineBloc>().add(AddMedicine(medicine));
    }

    setState(() => _isSaving = false);
    if (mounted) Navigator.pop(context);
  }
}
