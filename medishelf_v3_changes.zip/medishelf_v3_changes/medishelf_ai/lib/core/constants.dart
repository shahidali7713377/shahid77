// lib/core/constants.dart
class AppConstants {
  static const String appName = 'MediShelf AI';
  static const String appVersion = '1.0.0';
  static const String dbName = 'medishelf.db';
  static const int dbVersion = 1;

  // Table names
  static const String medicinesTable = 'medicines';
  static const String familyMembersTable = 'family_members';
  static const String notificationSettingsTable = 'notification_settings';
  static const String usageLogsTable = 'usage_logs';
  static const String emergencyContactsTable = 'emergency_contacts';

  // Expiry thresholds (days)
  static const int criticalThreshold = 15;
  static const int warningThreshold = 30;

  // Default notification days before expiry
  static const List<int> defaultNotificationDays = [60, 30, 15, 7, 3];

  // Medicine types
  static const List<String> medicineTypes = [
    'Tablet',
    'Capsule',
    'Syrup',
    'Suspension',
    'Injection',
    'Cream',
    'Drops',
    'Inhaler',
    'Patch',
    'Suppository',
    'Powder',
    'Ointment',
    'Gel',
    'Other',
  ];

  // Medicine type icons (Material icon codepoints)
  static const Map<String, String> medicineTypeEmojis = {
    'Tablet': '💊',
    'Capsule': '🔴',
    'Syrup': '🍶',
    'Suspension': '🧪',
    'Injection': '💉',
    'Cream': '🧴',
    'Drops': '💧',
    'Inhaler': '🫁',
    'Patch': '🩹',
    'Suppository': '⬛',
    'Powder': '🌿',
    'Ointment': '🧴',
    'Gel': '💙',
    'Other': '💊',
  };

  // Typical shelf life database (months) for AI prediction
  static const Map<String, int> typicalShelfLife = {
    'Tablet': 24,
    'Capsule': 24,
    'Syrup': 12,
    'Suspension': 14,
    'Injection': 24,
    'Cream': 24,
    'Drops': 12,
    'Inhaler': 24,
    'Patch': 24,
    'Suppository': 12,
    'Powder': 24,
    'Ointment': 24,
    'Gel': 18,
    'Other': 18,
  };

  // Languages
  static const List<Map<String, String>> supportedLanguages = [
    {'code': 'en', 'name': 'English'},
    {'code': 'ur', 'name': 'اردو'},
  ];

  // Notification channel
  static const String notifChannelId = 'medishelf_expiry_channel';
  static const String notifChannelName = 'Medicine Expiry Alerts';
  static const String notifChannelDesc = 'Alerts for medicine expiry dates';
  static const int weeklySummaryNotifId = 888888;

  // Prefs keys
  static const String prefThemeMode = 'theme_mode';
  static const String prefLanguage = 'language';
  static const String prefFontSize = 'font_size';
  static const String prefAppLock = 'app_lock';
  static const String prefAppPin = 'app_pin';
  static const String prefNotifEnabled = 'notif_enabled';
  static const String prefNotifDays = 'notif_days';
  static const String prefOnboarded = 'onboarded';
  static const String prefSelectedProfile = 'selected_profile';

  // ── Health Education Tips (offline, bilingual) ───────────────────────────
  static const List<Map<String, String>> healthTips = [
    {
      'emoji': '🌡️',
      'titleEn': 'Store Medicines Correctly',
      'tipEn':
          'Keep medicines in a cool, dry place away from direct sunlight. Most medicines should be stored below 25°C. Never store in the bathroom — humidity damages them.',
      'titleUr': 'دوائیں صحیح جگہ رکھیں',
      'tipUr':
          'دوائیں ٹھنڈی، خشک اور سورج کی روشنی سے دور جگہ پر رکھیں۔ باتھ روم میں نمی سے دوائیں خراب ہو جاتی ہیں۔',
    },
    {
      'emoji': '🚫',
      'titleEn': 'Never Use Expired Medicine',
      'tipEn':
          'Expired medicines can lose effectiveness or become harmful. Check expiry dates before every dose. When in doubt, throw it out.',
      'titleUr': 'میعاد ختم دوا استعمال نہ کریں',
      'tipUr':
          'میعاد ختم دوائیں بے اثر یا نقصاندہ ہو سکتی ہیں۔ ہر بار لینے سے پہلے تاریخ ضرور چیک کریں۔',
    },
    {
      'emoji': '👶',
      'titleEn': 'Keep Away from Children',
      'tipEn':
          'Store all medicines in locked or high cabinets away from children\'s reach. Child-proof caps do not replace safe storage. Even vitamins can be dangerous in overdose.',
      'titleUr': 'بچوں سے دور رکھیں',
      'tipUr':
          'تمام دوائیں بچوں کی پہنچ سے دور تالے والی الماری میں رکھیں۔ وٹامن بھی زیادہ مقدار میں نقصاندہ ہو سکتے ہیں۔',
    },
    {
      'emoji': '💧',
      'titleEn': 'Dispose Medicines Safely',
      'tipEn':
          'Never flush medicines down the toilet or throw them in open trash. Mix with dirt or coffee grounds in a sealed bag before disposal. Return to a pharmacy if possible.',
      'titleUr': 'دوائیں محفوظ طریقے سے پھینکیں',
      'tipUr':
          'دوائیں کبھی بھی نالے یا کھلے کوڑے میں نہ پھینکیں۔ مٹی میں ملا کر بند تھیلے میں ڈالیں یا فارمیسی واپس کریں۔',
    },
    {
      'emoji': '📋',
      'titleEn': 'Follow Prescription Exactly',
      'tipEn':
          'Always complete the full course of antibiotics even if you feel better. Stopping early can cause bacteria to become resistant and harder to treat.',
      'titleUr': 'نسخہ مکمل کریں',
      'tipUr':
          'اینٹی بائیوٹک کا پورا کورس مکمل کریں چاہے آپ بہتر محسوس کریں۔ ادھورا کورس جراثیم کو مزاحم بنا دیتا ہے۔',
    },
    {
      'emoji': '🌿',
      'titleEn': 'Refrigerated Medicines',
      'tipEn':
          'Some medicines like insulin, eye drops, and certain syrups must be refrigerated (2–8°C). Do not freeze them unless instructed. Keep them away from the freezer compartment.',
      'titleUr': 'فریج میں رکھنے والی دوائیں',
      'tipUr':
          'انسولین، آنکھوں کے قطرے اور بعض شربت فریج میں (2–8°C) رکھنے ضروری ہیں۔ انہیں فریزر میں مت رکھیں۔',
    },
    {
      'emoji': '☀️',
      'titleEn': 'Light-Sensitive Medicines',
      'tipEn':
          'Some medicines degrade when exposed to light. Keep them in their original dark packaging. Brown glass bottles are designed for light protection.',
      'titleUr': 'روشنی سے حساس دوائیں',
      'tipUr':
          'کچھ دوائیں روشنی سے خراب ہو جاتی ہیں۔ انہیں اصل گہرے رنگ کی پیکنگ میں رکھیں۔',
    },
    {
      'emoji': '🍶',
      'titleEn': 'Liquid Medicine After Opening',
      'tipEn':
          'Most liquid medicines (syrups, suspensions) expire within 7–14 days after opening, even if the printed date is far away. Write the opening date on the bottle.',
      'titleUr': 'شربت کھولنے کے بعد',
      'tipUr':
          'زیادہ تر شربت کھولنے کے 7–14 دن بعد خراب ہو جاتے ہیں چاہے چھپی تاریخ دور ہو۔ بوتل پر کھولنے کی تاریخ لکھیں۔',
    },
    {
      'emoji': '🤝',
      'titleEn': 'Do Not Share Prescriptions',
      'tipEn':
          'Never give your prescription medicine to someone else, even for the same symptoms. Each person\'s condition and safe dosage is different.',
      'titleUr': 'نسخہ شیئر نہ کریں',
      'tipUr':
          'اپنی نسخے والی دوا کسی اور کو نہ دیں چاہے علامات ایک جیسی ہوں۔ ہر شخص کی خوراک الگ ہوتی ہے۔',
    },
    {
      'emoji': '🏥',
      'titleEn': 'When to Seek Immediate Help',
      'tipEn':
          'Go to a hospital immediately if you experience: difficulty breathing, sudden severe pain, unconsciousness, seizures, or allergic reaction after taking medicine.',
      'titleUr': 'فوری مدد کب لیں',
      'tipUr':
          'اگر دوا لینے کے بعد سانس لینے میں تکلیف، شدید درد، بے ہوشی، یا الرجی ہو تو فوری ہسپتال جائیں۔',
    },
  ];
}
