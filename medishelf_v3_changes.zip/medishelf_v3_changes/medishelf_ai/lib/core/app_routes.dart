// lib/core/app_routes.dart
import 'package:flutter/material.dart';
import '../screens/splash/splash_screen.dart';
import '../screens/home/home_screen.dart';
import '../screens/medicine/add_medicine_screen.dart';
import '../screens/medicine/medicine_detail_screen.dart';
import '../screens/camera/camera_scan_screen.dart';
import '../screens/profiles/profiles_screen.dart';
import '../screens/settings/settings_screen.dart';
import '../screens/emergency/emergency_screen.dart';
import '../screens/archive/archive_screen.dart';
import '../screens/education/health_tips_screen.dart';
import '../data/models/medicine_model.dart';

class AppRoutes {
  static const String splash        = '/';
  static const String home          = '/home';
  static const String addMedicine   = '/add-medicine';
  static const String medicineDetail= '/medicine-detail';
  static const String cameraScan    = '/camera-scan';
  static const String profiles      = '/profiles';
  static const String settings      = '/settings';
  static const String emergency     = '/emergency';
  static const String archive       = '/archive';
  static const String healthTips    = '/health-tips';

  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case splash:
        return _fadeRoute(const SplashScreen(), settings);
      case home:
        return _fadeRoute(const HomeScreen(), settings);
      case addMedicine:
        final args = settings.arguments as Map<String, dynamic>?;
        return _slideRoute(AddMedicineScreen(initialData: args), settings);
      case medicineDetail:
        final medicine = settings.arguments as Medicine;
        return _slideRoute(MedicineDetailScreen(medicine: medicine), settings);
      case cameraScan:
        return _slideRoute(const CameraScanScreen(), settings);
      case profiles:
        return _slideRoute(const ProfilesScreen(), settings);
      case AppRoutes.settings:
        return _slideRoute(const SettingsScreen(), settings);
      case emergency:
        return _slideRoute(const EmergencyScreen(), settings);
      case archive:
        return _slideRoute(const ArchiveScreen(), settings);
      case healthTips:
        return _slideRoute(const HealthTipsScreen(), settings);
      default:
        return _fadeRoute(const HomeScreen(), settings);
    }
  }

  static PageRouteBuilder _fadeRoute(Widget page, RouteSettings s) =>
      PageRouteBuilder(
        settings: s,
        pageBuilder: (_, __, ___) => page,
        transitionsBuilder: (_, anim, __, child) =>
            FadeTransition(opacity: anim, child: child),
        transitionDuration: const Duration(milliseconds: 300),
      );

  static PageRouteBuilder _slideRoute(Widget page, RouteSettings s) =>
      PageRouteBuilder(
        settings: s,
        pageBuilder: (_, __, ___) => page,
        transitionsBuilder: (_, anim, __, child) {
          final tween = Tween(begin: const Offset(1, 0), end: Offset.zero)
              .chain(CurveTween(curve: Curves.easeOutCubic));
          return SlideTransition(
              position: anim.drive(tween), child: child);
        },
        transitionDuration: const Duration(milliseconds: 320),
      );
}
