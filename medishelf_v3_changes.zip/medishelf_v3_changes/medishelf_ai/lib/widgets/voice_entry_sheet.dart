// lib/widgets/voice_entry_sheet.dart
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../core/app_theme.dart';
import '../services/voice_entry_service.dart';

/// Call this to open the voice entry sheet.
/// Returns a [VoiceParseResult] if the user confirms, or null if dismissed.
Future<VoiceParseResult?> showVoiceEntrySheet(BuildContext context) {
  return showModalBottomSheet<VoiceParseResult>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (_) => const _VoiceEntrySheet(),
  );
}

class _VoiceEntrySheet extends StatefulWidget {
  const _VoiceEntrySheet();

  @override
  State<_VoiceEntrySheet> createState() => _VoiceEntrySheetState();
}

class _VoiceEntrySheetState extends State<_VoiceEntrySheet>
    with SingleTickerProviderStateMixin {
  final _service = VoiceEntryService.instance;

  _VoiceState _state = _VoiceState.idle;
  String _liveText = '';
  String _finalText = '';
  VoiceParseResult? _result;
  bool _available = false;
  String? _errorMsg;
  late AnimationController _pulseCtrl;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat(reverse: true);
    _init();
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _service.cancelListening();
    super.dispose();
  }

  Future<void> _init() async {
    final ok = await _service.initialize();
    setState(() => _available = ok);
    if (!ok) {
      setState(() =>
          _errorMsg = 'Microphone not available on this device.');
    }
  }

  Future<void> _startListening() async {
    setState(() {
      _state = _VoiceState.listening;
      _liveText = '';
      _finalText = '';
      _result = null;
      _errorMsg = null;
    });

    await _service.startListening(
      onResult: (text) => setState(() => _liveText = text),
      onFinalResult: (text) {
        if (text.isNotEmpty) {
          setState(() {
            _finalText = text;
            _liveText = text;
            _state = _VoiceState.processing;
          });
          _processResult(text);
        }
      },
    );

    // Auto-stop after 10s silence
    await Future.delayed(const Duration(seconds: 12));
    if (_state == _VoiceState.listening) {
      await _service.stopListening();
      if (_liveText.isNotEmpty && _state == _VoiceState.listening) {
        _processResult(_liveText);
      }
    }
  }

  void _processResult(String text) {
    final parsed = VoiceEntryService.parseSpokenText(text);
    setState(() {
      _result = parsed;
      _state = parsed.hasAnyData ? _VoiceState.done : _VoiceState.error;
      if (!parsed.hasAnyData) {
        _errorMsg = 'Could not detect medicine info. Please try again.';
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Container(
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
      ),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 20, 24, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Handle
              Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: AppColors.border,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(height: 20),

              // Title
              const Text(
                '🎤 Voice Medicine Entry',
                style:
                    TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 6),
              Text(
                'Say: "Paracetamol, expiry January 2027"',
                style: TextStyle(
                    color: AppColors.textSecondary, fontSize: 13),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 28),

              // Mic button / animation
              _buildMicArea(),
              const SizedBox(height: 24),

              // Live transcript
              if (_liveText.isNotEmpty) _buildTranscript(),

              // Parsed result
              if (_state == _VoiceState.done && _result != null)
                _buildParsedResult(),

              // Error
              if (_state == _VoiceState.error && _errorMsg != null)
                _buildError(),

              // Action buttons
              _buildActions(),
              const SizedBox(height: 8),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMicArea() {
    switch (_state) {
      case _VoiceState.idle:
        return GestureDetector(
          onTap: _available ? _startListening : null,
          child: Container(
            width: 90,
            height: 90,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: _available
                    ? [AppColors.primary, AppColors.secondary]
                    : [AppColors.border, AppColors.border],
              ),
              shape: BoxShape.circle,
              boxShadow: _available
                  ? [
                      BoxShadow(
                        color: AppColors.primary.withOpacity(0.35),
                        blurRadius: 24,
                        spreadRadius: 4,
                      )
                    ]
                  : null,
            ),
            child: const Icon(Icons.mic, color: Colors.white, size: 40),
          ),
        )
            .animate(onPlay: (c) => c.reset())
            .scale(duration: 300.ms, curve: Curves.elasticOut);

      case _VoiceState.listening:
        return AnimatedBuilder(
          animation: _pulseCtrl,
          builder: (_, child) => Stack(
            alignment: Alignment.center,
            children: [
              // Pulse rings
              Container(
                width: 90 + 30 * _pulseCtrl.value,
                height: 90 + 30 * _pulseCtrl.value,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: AppColors.expired.withOpacity(
                      0.15 * (1 - _pulseCtrl.value)),
                ),
              ),
              Container(
                width: 90 + 15 * _pulseCtrl.value,
                height: 90 + 15 * _pulseCtrl.value,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: AppColors.expired.withOpacity(
                      0.25 * (1 - _pulseCtrl.value)),
                ),
              ),
              child!,
            ],
          ),
          child: GestureDetector(
            onTap: () async {
              await _service.stopListening();
              if (_liveText.isNotEmpty) {
                _processResult(_liveText);
              } else {
                setState(() => _state = _VoiceState.idle);
              }
            },
            child: Container(
              width: 90,
              height: 90,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                    colors: [AppColors.expired, Color(0xFFDC2626)]),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.stop, color: Colors.white, size: 36),
            ),
          ),
        );

      case _VoiceState.processing:
        return Container(
          width: 90,
          height: 90,
          decoration: BoxDecoration(
            color: AppColors.warning.withOpacity(0.15),
            shape: BoxShape.circle,
          ),
          child: const Center(
            child: CircularProgressIndicator(
                color: AppColors.warning, strokeWidth: 3),
          ),
        );

      case _VoiceState.done:
        return Container(
          width: 90,
          height: 90,
          decoration: BoxDecoration(
            color: AppColors.safe.withOpacity(0.15),
            shape: BoxShape.circle,
          ),
          child: const Icon(Icons.check_circle,
              color: AppColors.safe, size: 48),
        )
            .animate()
            .scale(duration: 300.ms, curve: Curves.elasticOut);

      case _VoiceState.error:
        return GestureDetector(
          onTap: _startListening,
          child: Container(
            width: 90,
            height: 90,
            decoration: BoxDecoration(
              color: AppColors.expired.withOpacity(0.15),
              shape: BoxShape.circle,
            ),
            child:
                const Icon(Icons.refresh, color: AppColors.expired, size: 40),
          ),
        );
    }
  }

  Widget _buildTranscript() {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.primary.withOpacity(0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.primary.withOpacity(0.2)),
      ),
      child: Text(
        '"$_liveText"',
        style: const TextStyle(
          fontStyle: FontStyle.italic,
          fontSize: 14,
          height: 1.5,
          color: AppColors.primary,
        ),
        textAlign: TextAlign.center,
      ),
    ).animate().fadeIn();
  }

  Widget _buildParsedResult() {
    final r = _result!;
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.safeLight,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.safe.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(Icons.auto_awesome, color: AppColors.safe, size: 16),
              SizedBox(width: 6),
              Text('Detected Fields',
                  style: TextStyle(
                      color: AppColors.safe,
                      fontWeight: FontWeight.w700,
                      fontSize: 13)),
            ],
          ),
          const SizedBox(height: 10),
          if (r.name != null)
            _ResultRow(icon: '💊', label: 'Name', value: r.name!),
          if (r.type != null)
            _ResultRow(icon: '🏷️', label: 'Type', value: r.type!),
          if (r.expiryDate != null)
            _ResultRow(
              icon: '📅',
              label: 'Expiry',
              value:
                  '${r.expiryDate!.month.toString().padLeft(2, '0')}/${r.expiryDate!.year}',
            ),
          if (r.quantity != null)
            _ResultRow(
                icon: '📦', label: 'Quantity', value: '${r.quantity}'),
        ],
      ),
    ).animate().fadeIn().slideY(begin: 0.1);
  }

  Widget _buildError() {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.expiredLight,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.expired.withOpacity(0.3)),
      ),
      child: Text(
        _errorMsg!,
        style: const TextStyle(color: AppColors.expired, fontSize: 13),
        textAlign: TextAlign.center,
      ),
    ).animate().shakeX();
  }

  Widget _buildActions() {
    if (_state == _VoiceState.done && _result != null) {
      return Column(
        children: [
          SizedBox(
            width: double.infinity,
            height: 50,
            child: ElevatedButton.icon(
              onPressed: () => Navigator.pop(context, _result),
              icon: const Icon(Icons.check),
              label: const Text('Use These Details'),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.safe,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14)),
              ),
            ),
          ),
          const SizedBox(height: 10),
          TextButton.icon(
            onPressed: _startListening,
            icon: const Icon(Icons.refresh, size: 16),
            label: const Text('Try Again'),
          ),
        ],
      );
    }

    if (_state == _VoiceState.idle) {
      return Column(
        children: [
          if (!_available)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Text(
                _errorMsg ?? 'Checking microphone…',
                style: const TextStyle(
                    color: AppColors.textSecondary, fontSize: 12),
                textAlign: TextAlign.center,
              ),
            ),
          SizedBox(
            width: double.infinity,
            height: 50,
            child: ElevatedButton.icon(
              onPressed: _available ? _startListening : null,
              icon: const Icon(Icons.mic),
              label: const Text('Tap to Speak'),
              style: ElevatedButton.styleFrom(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14)),
              ),
            ),
          ),
          const SizedBox(height: 10),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
        ],
      );
    }

    if (_state == _VoiceState.error) {
      return Column(
        children: [
          SizedBox(
            width: double.infinity,
            height: 50,
            child: ElevatedButton.icon(
              onPressed: _startListening,
              icon: const Icon(Icons.mic),
              label: const Text('Try Again'),
              style: ElevatedButton.styleFrom(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14)),
              ),
            ),
          ),
          const SizedBox(height: 10),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
        ],
      );
    }

    // Listening or processing — show stop/wait
    return const SizedBox.shrink();
  }
}

class _ResultRow extends StatelessWidget {
  final String icon;
  final String label;
  final String value;

  const _ResultRow(
      {required this.icon, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(
        children: [
          Text(icon, style: const TextStyle(fontSize: 14)),
          const SizedBox(width: 8),
          Text('$label: ',
              style: const TextStyle(
                  color: AppColors.textSecondary, fontSize: 13)),
          Expanded(
            child: Text(value,
                style: const TextStyle(
                    fontWeight: FontWeight.w600, fontSize: 13)),
          ),
        ],
      ),
    );
  }
}

enum _VoiceState { idle, listening, processing, done, error }
