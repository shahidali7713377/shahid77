// lib/services/voice_entry_service.dart
import 'package:speech_to_text/speech_to_text.dart';
import 'package:speech_to_text/speech_recognition_result.dart';
import '../core/constants.dart';

/// Parses spoken text into structured medicine data — fully offline.
class VoiceEntryService {
  static VoiceEntryService? _instance;
  VoiceEntryService._internal();
  static VoiceEntryService get instance {
    _instance ??= VoiceEntryService._internal();
    return _instance!;
  }

  final SpeechToText _speech = SpeechToText();
  bool _initialized = false;

  Future<bool> initialize() async {
    if (_initialized) return true;
    _initialized = await _speech.initialize(
      onError: (e) {},
      onStatus: (s) {},
    );
    return _initialized;
  }

  bool get isAvailable => _initialized && _speech.isAvailable;
  bool get isListening => _speech.isListening;

  /// Start listening. [onResult] called with live transcription.
  /// [onFinalResult] called once the user stops speaking.
  Future<void> startListening({
    required void Function(String text) onResult,
    required void Function(String text) onFinalResult,
    String localeId = 'en_US',
  }) async {
    if (!_initialized) await initialize();
    if (!_initialized) return;

    await _speech.listen(
      onResult: (SpeechRecognitionResult result) {
        onResult(result.recognizedWords);
        if (result.finalResult) {
          onFinalResult(result.recognizedWords);
        }
      },
      localeId: localeId,
      listenMode: ListenMode.dictation,
      cancelOnError: false,
      partialResults: true,
    );
  }

  Future<void> stopListening() async {
    await _speech.stop();
  }

  Future<void> cancelListening() async {
    await _speech.cancel();
  }

  // ── AI parser: spoken text → medicine fields ──────────────────────────────

  /// Parses a spoken phrase like:
  ///   "Paracetamol, expiry January 2027"
  ///   "Syrup Amoxicillin expires March 2026 quantity 2"
  ///   "Panadol tablet 2025"
  ///
  /// Returns a map with any fields it could detect.
  static VoiceParseResult parseSpokenText(String raw) {
    final text = raw.toLowerCase().trim();
    String? name;
    DateTime? expiryDate;
    String? type;
    int? quantity;

    // ── Medicine type detection ─────────────────────────────────────────────
    for (final t in AppConstants.medicineTypes) {
      if (text.contains(t.toLowerCase())) {
        type = t;
        break;
      }
    }

    // ── Expiry date detection ───────────────────────────────────────────────
    // Pattern: "expiry MONTH YEAR" or "expires in YEAR" or "MONTH YEAR"
    final monthMap = {
      'january': 1, 'jan': 1,
      'february': 2, 'feb': 2,
      'march': 3, 'mar': 3,
      'april': 4, 'apr': 4,
      'may': 5,
      'june': 6, 'jun': 6,
      'july': 7, 'jul': 7,
      'august': 8, 'aug': 8,
      'september': 9, 'sep': 9, 'sept': 9,
      'october': 10, 'oct': 10,
      'november': 11, 'nov': 11,
      'december': 12, 'dec': 12,
    };

    // Try "MONTH YEAR" (e.g. "january 2027")
    final monthYearRe = RegExp(
        r'(january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sep|sept|oct|nov|dec)\s+(\d{4})',
        caseSensitive: false);
    final myMatch = monthYearRe.firstMatch(text);
    if (myMatch != null) {
      final month = monthMap[myMatch.group(1)!.toLowerCase()]!;
      final year = int.parse(myMatch.group(2)!);
      // Use last day of that month as expiry
      final lastDay = DateTime(year, month + 1, 0).day;
      expiryDate = DateTime(year, month, lastDay);
    }

    // Try bare 4-digit year (e.g. "expiry 2027")
    if (expiryDate == null) {
      final yearRe =
          RegExp(r'expir[esy]+\s+(?:in\s+)?(\d{4})', caseSensitive: false);
      final yMatch = yearRe.firstMatch(text);
      if (yMatch != null) {
        final year = int.parse(yMatch.group(1)!);
        expiryDate = DateTime(year, 12, 31);
      }
    }

    // Try plain 4-digit year anywhere as fallback
    if (expiryDate == null) {
      final yearRe = RegExp(r'\b(202[4-9]|203\d)\b');
      final yMatch = yearRe.firstMatch(text);
      if (yMatch != null) {
        final year = int.parse(yMatch.group(1)!);
        expiryDate = DateTime(year, 12, 31);
      }
    }

    // ── Quantity detection ──────────────────────────────────────────────────
    final qtyRe = RegExp(
        r'(?:quantity|qty|pack|tablets?|capsules?|pieces?|pcs?)?\s*(\d+)\s*(?:quantity|qty|pack|tablets?|capsules?|pieces?|pcs?)',
        caseSensitive: false);
    final qMatch = qtyRe.firstMatch(text);
    if (qMatch != null) {
      quantity = int.tryParse(qMatch.group(1) ?? '');
    }

    // ── Name extraction ─────────────────────────────────────────────────────
    // Remove known keywords and extract the medicine name
    String nameText = raw.trim();
    // Strip trigger words
    nameText = nameText.replaceAllMapped(
        RegExp(
            r'\b(expir[esy]+|in|quantity|qty|tablets?|capsules?|syrup|suspension|injection|cream|drops|inhaler|patch|powder|ointment|gel)\b',
            caseSensitive: false),
        (_) => '');
    // Strip month/year
    nameText = nameText
        .replaceAll(monthYearRe, '')
        .replaceAll(RegExp(r'\b\d{4}\b'), '')
        .replaceAll(RegExp(r'\b\d+\b'), '');
    // Strip type if detected
    if (type != null) {
      nameText =
          nameText.replaceAll(RegExp(type, caseSensitive: false), '');
    }
    // Clean commas, extra spaces
    nameText = nameText
        .replaceAll(RegExp(r'[,.\-]'), ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();

    if (nameText.isNotEmpty) {
      // Title-case the name
      name = nameText
          .split(' ')
          .where((w) => w.isNotEmpty)
          .map((w) => w[0].toUpperCase() + w.substring(1).toLowerCase())
          .join(' ');
    }

    return VoiceParseResult(
      rawText: raw,
      name: name,
      expiryDate: expiryDate,
      type: type,
      quantity: quantity,
    );
  }
}

class VoiceParseResult {
  final String rawText;
  final String? name;
  final DateTime? expiryDate;
  final String? type;
  final int? quantity;

  const VoiceParseResult({
    required this.rawText,
    this.name,
    this.expiryDate,
    this.type,
    this.quantity,
  });

  bool get hasAnyData =>
      name != null || expiryDate != null || type != null || quantity != null;

  @override
  String toString() =>
      'VoiceParseResult(name: $name, expiry: $expiryDate, type: $type, qty: $quantity)';
}
