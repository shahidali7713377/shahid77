// lib/services/notification_service.dart
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest.dart' as tz_data;
import '../core/constants.dart';
import '../data/models/medicine_model.dart';

class NotificationService {
  static NotificationService? _instance;
  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();

  NotificationService._internal();
  static NotificationService get instance {
    _instance ??= NotificationService._internal();
    return _instance!;
  }

  Future<void> initialize() async {
    tz_data.initializeTimeZones();
    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosInit = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );
    const initSettings =
        InitializationSettings(android: androidInit, iOS: iosInit);

    await _plugin.initialize(
      initSettings,
      onDidReceiveNotificationResponse: _onNotificationTapped,
    );
    await _plugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.requestNotificationsPermission();
  }

  void _onNotificationTapped(NotificationResponse response) {}

  // ── Notification detail builders ──────────────────────────────────────────

  NotificationDetails _buildDetails({bool critical = false}) {
    return NotificationDetails(
      android: AndroidNotificationDetails(
        critical
            ? '${AppConstants.notifChannelId}_critical'
            : AppConstants.notifChannelId,
        critical ? 'Critical Medicine Alerts' : AppConstants.notifChannelName,
        channelDescription: critical
            ? 'Urgent alerts for expired / nearly-expired medicines'
            : AppConstants.notifChannelDesc,
        importance: critical ? Importance.max : Importance.high,
        priority: critical ? Priority.max : Priority.high,
        enableVibration: true,
        playSound: true,
        fullScreenIntent: critical,
        color: critical ? const Color(0xFFEF4444) : const Color(0xFF2563EB),
        largeIcon: const DrawableResourceAndroidBitmap('@mipmap/ic_launcher'),
        styleInformation: const BigTextStyleInformation(''),
      ),
      iOS: DarwinNotificationDetails(
        presentAlert: true,
        presentBadge: true,
        presentSound: true,
        interruptionLevel:
            critical ? InterruptionLevel.critical : InterruptionLevel.active,
      ),
    );
  }

  // ── Schedule expiry notifications ─────────────────────────────────────────

  Future<void> scheduleExpiryNotifications(
      Medicine medicine, List<int> daysBefore) async {
    await cancelMedicineNotifications(medicine.id);

    final now = tz.TZDateTime.now(tz.local);

    for (final days in daysBefore) {
      // Compute the exact calendar date X days before expiry
      final rawTarget = medicine.expiryDate.subtract(Duration(days: days));
      final fireDate = tz.TZDateTime(
        tz.local,
        rawTarget.year,
        rawTarget.month,
        rawTarget.day,
        9, // 9:00 AM
        0,
      );

      // ──────────────────────────────────────────────────────────────────────
      // BUG FIX: Do NOT set matchDateTimeComponents.
      // Setting DateTimeComponents.time made every notification repeat DAILY
      // at 9 AM regardless of the scheduled date — causing false alerts.
      // With no matchDateTimeComponents, each notification fires ONCE only.
      // ──────────────────────────────────────────────────────────────────────
      if (fireDate.isAfter(now)) {
        final isCritical = days <= 3;
        await _plugin.zonedSchedule(
          _notifId(medicine.id, days),
          '💊 ${medicine.name} expiring in $days day${days == 1 ? '' : 's'}',
          isCritical
              ? '🚨 Replace immediately — expires on ${_fmtDate(medicine.expiryDate)}.'
              : 'Stock up before it expires on ${_fmtDate(medicine.expiryDate)}.',
          fireDate,
          _buildDetails(critical: isCritical),
          androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
          uiLocalNotificationDateInterpretation:
              UILocalNotificationDateInterpretation.absoluteTime,
          payload: medicine.id,
          // NO matchDateTimeComponents — fires once only ✅
        );
      }
    }

    // One-shot notification on the expiry day itself
    final expiryFire = tz.TZDateTime(
      tz.local,
      medicine.expiryDate.year,
      medicine.expiryDate.month,
      medicine.expiryDate.day,
      9,
      0,
    );
    if (expiryFire.isAfter(now)) {
      await _plugin.zonedSchedule(
        _notifId(medicine.id, 0),
        '🚨 ${medicine.name} EXPIRES TODAY!',
        'This medicine expires today. Please dispose safely.',
        expiryFire,
        _buildDetails(critical: true),
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
        payload: medicine.id,
      );
    }
  }

  // ── Weekly summary notification ───────────────────────────────────────────

  /// Schedules a single weekly summary for next Monday at 9 AM.
  /// Groups all expiry info into ONE intelligent notification instead of
  /// individual alerts per medicine.
  Future<void> scheduleWeeklySummary({
    required int expiringIn7,
    required int expiringIn30,
    required int expired,
  }) async {
    await _plugin.cancel(AppConstants.weeklySummaryNotifId);
    if (expiringIn7 == 0 && expiringIn30 == 0 && expired == 0) return;

    // Target: next Monday 9 AM
    final now = tz.TZDateTime.now(tz.local);
    var target = now.add(const Duration(days: 1));
    while (target.weekday != DateTime.monday) {
      target = target.add(const Duration(days: 1));
    }
    final fireDate =
        tz.TZDateTime(tz.local, target.year, target.month, target.day, 9, 0);

    final parts = <String>[];
    if (expired > 0) parts.add('$expired expired medicine${expired > 1 ? 's' : ''}');
    if (expiringIn7 > 0) parts.add('$expiringIn7 expiring within 7 days');
    if (expiringIn30 > 0) parts.add('$expiringIn30 expiring within 30 days');

    await _plugin.zonedSchedule(
      AppConstants.weeklySummaryNotifId,
      '📋 Weekly Medicine Summary',
      parts.join(' · '),
      fireDate,
      _buildDetails(critical: expired > 0),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
    );
  }

  /// Show an instant summary notification (e.g., on app startup).
  Future<void> showImmediateSummary({
    required int expiringIn7,
    required int expiringIn30,
    required int expired,
  }) async {
    if (expiringIn7 == 0 && expiringIn30 == 0 && expired == 0) return;
    final parts = <String>[];
    if (expired > 0) parts.add('$expired expired');
    if (expiringIn7 > 0) parts.add('$expiringIn7 expiring in 7 days');
    if (expiringIn30 > 0) parts.add('$expiringIn30 expiring in 30 days');
    await _plugin.show(
      AppConstants.weeklySummaryNotifId,
      '📋 MediShelf Weekly Check',
      parts.join(' · '),
      _buildDetails(critical: expired > 0),
    );
  }

  // ── Low stock ─────────────────────────────────────────────────────────────

  Future<void> showLowStockNotification(Medicine medicine) async {
    await _plugin.show(
      _notifId(medicine.id, -2),
      '📦 Low Stock: ${medicine.name}',
      'Only ${medicine.remainingQuantity} unit${medicine.remainingQuantity == 1 ? '' : 's'} remaining.',
      _buildDetails(),
      payload: medicine.id,
    );
  }

  // ── Cancel ────────────────────────────────────────────────────────────────

  Future<void> cancelMedicineNotifications(String medicineId) async {
    for (final d in [...AppConstants.defaultNotificationDays, 0, -1, -2]) {
      await _plugin.cancel(_notifId(medicineId, d));
    }
  }

  Future<void> cancelAll() => _plugin.cancelAll();

  // ── Helpers ───────────────────────────────────────────────────────────────

  int _notifId(String medicineId, int days) =>
      '${medicineId}_$days'.hashCode.abs() % 2147483647;

  String _fmtDate(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';
}
