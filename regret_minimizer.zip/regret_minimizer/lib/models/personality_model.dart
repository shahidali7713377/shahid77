// Personality model is defined in user_profile_model.dart
// This file exports it for convenience
export 'user_profile_model.dart' show PersonalityProfile, PersonalityProfileAdapter;
