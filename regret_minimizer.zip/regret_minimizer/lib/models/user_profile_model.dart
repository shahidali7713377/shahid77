import 'package:hive/hive.dart';

part 'user_profile_model.g.dart';

@HiveType(typeId: 0)
class UserProfile extends HiveObject {
  @HiveField(0)
  String id;

  @HiveField(1)
  String name;

  @HiveField(2)
  String email;

  @HiveField(3)
  PersonalityProfile personality;

  @HiveField(4)
  double riskTolerance; // 0-100

  @HiveField(5)
  String decisionStyle; // analytical, intuitive, consultative, spontaneous

  @HiveField(6)
  List<String> primaryRegretTriggers;

  @HiveField(7)
  double emotionalVolatility; // 0-100

  @HiveField(8)
  DateTime createdAt;

  @HiveField(9)
  int totalDecisions;

  @HiveField(10)
  int totalRegrets;

  @HiveField(11)
  double avgRegretScore;

  @HiveField(12)
  String? avatarPath;

  UserProfile({
    required this.id,
    required this.name,
    this.email = '',
    required this.personality,
    this.riskTolerance = 50,
    this.decisionStyle = 'analytical',
    this.primaryRegretTriggers = const [],
    this.emotionalVolatility = 50,
    required this.createdAt,
    this.totalDecisions = 0,
    this.totalRegrets = 0,
    this.avgRegretScore = 0,
    this.avatarPath,
  });

  UserProfile copyWith({
    String? id,
    String? name,
    String? email,
    PersonalityProfile? personality,
    double? riskTolerance,
    String? decisionStyle,
    List<String>? primaryRegretTriggers,
    double? emotionalVolatility,
    DateTime? createdAt,
    int? totalDecisions,
    int? totalRegrets,
    double? avgRegretScore,
    String? avatarPath,
  }) {
    return UserProfile(
      id: id ?? this.id,
      name: name ?? this.name,
      email: email ?? this.email,
      personality: personality ?? this.personality,
      riskTolerance: riskTolerance ?? this.riskTolerance,
      decisionStyle: decisionStyle ?? this.decisionStyle,
      primaryRegretTriggers: primaryRegretTriggers ?? this.primaryRegretTriggers,
      emotionalVolatility: emotionalVolatility ?? this.emotionalVolatility,
      createdAt: createdAt ?? this.createdAt,
      totalDecisions: totalDecisions ?? this.totalDecisions,
      totalRegrets: totalRegrets ?? this.totalRegrets,
      avgRegretScore: avgRegretScore ?? this.avgRegretScore,
      avatarPath: avatarPath ?? this.avatarPath,
    );
  }

  // Compute regret rate
  double get regretRate {
    if (totalDecisions == 0) return 0;
    return (totalRegrets / totalDecisions) * 100;
  }

  // Get dominant personality trait
  String get dominantTrait => personality.dominantTrait;
}

@HiveType(typeId: 1)
class PersonalityProfile extends HiveObject {
  @HiveField(0)
  double openness; // 0-100

  @HiveField(1)
  double conscientiousness; // 0-100

  @HiveField(2)
  double extraversion; // 0-100

  @HiveField(3)
  double agreeableness; // 0-100

  @HiveField(4)
  double neuroticism; // 0-100

  PersonalityProfile({
    this.openness = 50,
    this.conscientiousness = 50,
    this.extraversion = 50,
    this.agreeableness = 50,
    this.neuroticism = 50,
  });

  // Get dominant trait name
  String get dominantTrait {
    final traits = {
      'Openness': openness,
      'Conscientiousness': conscientiousness,
      'Extraversion': extraversion,
      'Agreeableness': agreeableness,
      'Neuroticism': neuroticism,
    };
    return traits.entries.reduce((a, b) => a.value > b.value ? a : b).key;
  }

  // Compute regret susceptibility based on personality
  double get regretSusceptibility {
    // High neuroticism + low conscientiousness = high regret susceptibility
    return (neuroticism * 0.4 + (100 - conscientiousness) * 0.3 +
        (100 - agreeableness) * 0.15 + (100 - openness) * 0.15);
  }

  List<double> get vector => [
        openness / 100,
        conscientiousness / 100,
        extraversion / 100,
        agreeableness / 100,
        neuroticism / 100,
      ];

  PersonalityProfile copyWith({
    double? openness,
    double? conscientiousness,
    double? extraversion,
    double? agreeableness,
    double? neuroticism,
  }) {
    return PersonalityProfile(
      openness: openness ?? this.openness,
      conscientiousness: conscientiousness ?? this.conscientiousness,
      extraversion: extraversion ?? this.extraversion,
      agreeableness: agreeableness ?? this.agreeableness,
      neuroticism: neuroticism ?? this.neuroticism,
    );
  }
}

// Hive Adapters (normally generated via build_runner)
class UserProfileAdapter extends TypeAdapter<UserProfile> {
  @override
  final int typeId = 0;

  @override
  UserProfile read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return UserProfile(
      id: fields[0] as String,
      name: fields[1] as String,
      email: fields[2] as String? ?? '',
      personality: fields[3] as PersonalityProfile,
      riskTolerance: fields[4] as double? ?? 50,
      decisionStyle: fields[5] as String? ?? 'analytical',
      primaryRegretTriggers: (fields[6] as List?)?.cast<String>() ?? [],
      emotionalVolatility: fields[7] as double? ?? 50,
      createdAt: fields[8] as DateTime? ?? DateTime.now(),
      totalDecisions: fields[9] as int? ?? 0,
      totalRegrets: fields[10] as int? ?? 0,
      avgRegretScore: fields[11] as double? ?? 0,
      avatarPath: fields[12] as String?,
    );
  }

  @override
  void write(BinaryWriter writer, UserProfile obj) {
    writer
      ..writeByte(13)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.name)
      ..writeByte(2)
      ..write(obj.email)
      ..writeByte(3)
      ..write(obj.personality)
      ..writeByte(4)
      ..write(obj.riskTolerance)
      ..writeByte(5)
      ..write(obj.decisionStyle)
      ..writeByte(6)
      ..write(obj.primaryRegretTriggers)
      ..writeByte(7)
      ..write(obj.emotionalVolatility)
      ..writeByte(8)
      ..write(obj.createdAt)
      ..writeByte(9)
      ..write(obj.totalDecisions)
      ..writeByte(10)
      ..write(obj.totalRegrets)
      ..writeByte(11)
      ..write(obj.avgRegretScore)
      ..writeByte(12)
      ..write(obj.avatarPath);
  }
}

class PersonalityProfileAdapter extends TypeAdapter<PersonalityProfile> {
  @override
  final int typeId = 1;

  @override
  PersonalityProfile read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return PersonalityProfile(
      openness: fields[0] as double? ?? 50,
      conscientiousness: fields[1] as double? ?? 50,
      extraversion: fields[2] as double? ?? 50,
      agreeableness: fields[3] as double? ?? 50,
      neuroticism: fields[4] as double? ?? 50,
    );
  }

  @override
  void write(BinaryWriter writer, PersonalityProfile obj) {
    writer
      ..writeByte(5)
      ..writeByte(0)
      ..write(obj.openness)
      ..writeByte(1)
      ..write(obj.conscientiousness)
      ..writeByte(2)
      ..write(obj.extraversion)
      ..writeByte(3)
      ..write(obj.agreeableness)
      ..writeByte(4)
      ..write(obj.neuroticism);
  }
}
