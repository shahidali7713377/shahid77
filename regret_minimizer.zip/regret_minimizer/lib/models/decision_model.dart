import 'package:hive/hive.dart';

part 'decision_model.g.dart';

// Enums
@HiveType(typeId: 5)
enum TimeHorizon {
  @HiveField(0)
  shortTerm, // < 6 months

  @HiveField(1)
  midTerm, // 6 months - 2 years

  @HiveField(2)
  longTerm, // > 2 years
}

@HiveType(typeId: 6)
enum RiskLevel {
  @HiveField(0)
  low,

  @HiveField(1)
  moderate,

  @HiveField(2)
  high,

  @HiveField(3)
  extreme,
}

@HiveType(typeId: 7)
enum EmotionalState {
  @HiveField(0)
  calm,

  @HiveField(1)
  anxious,

  @HiveField(2)
  excited,

  @HiveField(3)
  stressed,

  @HiveField(4)
  confident,

  @HiveField(5)
  uncertain,

  @HiveField(6)
  hopeful,

  @HiveField(7)
  fearful,
}

// Prediction result for a single option
@HiveType(typeId: 4)
class RegretPrediction extends HiveObject {
  @HiveField(0)
  String optionId;

  @HiveField(1)
  double regretProbability6Months; // 0-100

  @HiveField(2)
  double regretProbability1Year; // 0-100

  @HiveField(3)
  double regretProbability5Years; // 0-100

  @HiveField(4)
  double confidenceLevel; // 0-100

  @HiveField(5)
  double emotionalImpactScore; // -100 to 100 (negative = bad, positive = good)

  @HiveField(6)
  double longTermSatisfactionScore; // 0-100

  @HiveField(7)
  String bestCaseScenario;

  @HiveField(8)
  String worstCaseScenario;

  @HiveField(9)
  String mostLikelyScenario;

  @HiveField(10)
  String aiAdvice;

  @HiveField(11)
  List<String> keyRiskFactors;

  @HiveField(12)
  List<String> mitigationStrategies;

  @HiveField(13)
  DateTime calculatedAt;

  RegretPrediction({
    required this.optionId,
    required this.regretProbability6Months,
    required this.regretProbability1Year,
    required this.regretProbability5Years,
    required this.confidenceLevel,
    required this.emotionalImpactScore,
    required this.longTermSatisfactionScore,
    required this.bestCaseScenario,
    required this.worstCaseScenario,
    required this.mostLikelyScenario,
    required this.aiAdvice,
    required this.keyRiskFactors,
    required this.mitigationStrategies,
    required this.calculatedAt,
  });

  double get overallRegretScore {
    return (regretProbability6Months * 0.2 +
            regretProbability1Year * 0.35 +
            regretProbability5Years * 0.45)
        .clamp(0, 100);
  }
}

// Individual option within a decision
@HiveType(typeId: 3)
class DecisionOption extends HiveObject {
  @HiveField(0)
  String id;

  @HiveField(1)
  String title;

  @HiveField(2)
  String description;

  @HiveField(3)
  List<String> pros;

  @HiveField(4)
  List<String> cons;

  @HiveField(5)
  double perceivedRisk; // 0-100

  @HiveField(6)
  double expectedOutcomeScore; // 0-100

  @HiveField(7)
  RegretPrediction? prediction;

  @HiveField(8)
  bool? wasRegretted; // null = not yet evaluated, true/false = user reported

  DecisionOption({
    required this.id,
    required this.title,
    this.description = '',
    this.pros = const [],
    this.cons = const [],
    this.perceivedRisk = 50,
    this.expectedOutcomeScore = 50,
    this.prediction,
    this.wasRegretted,
  });

  DecisionOption copyWith({
    String? id,
    String? title,
    String? description,
    List<String>? pros,
    List<String>? cons,
    double? perceivedRisk,
    double? expectedOutcomeScore,
    RegretPrediction? prediction,
    bool? wasRegretted,
  }) {
    return DecisionOption(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      pros: pros ?? this.pros,
      cons: cons ?? this.cons,
      perceivedRisk: perceivedRisk ?? this.perceivedRisk,
      expectedOutcomeScore: expectedOutcomeScore ?? this.expectedOutcomeScore,
      prediction: prediction ?? this.prediction,
      wasRegretted: wasRegretted ?? this.wasRegretted,
    );
  }
}

// Main decision model
@HiveType(typeId: 2)
class DecisionModel extends HiveObject {
  @HiveField(0)
  String id;

  @HiveField(1)
  String title;

  @HiveField(2)
  String category; // career, relationships, finance, education, health, lifestyle

  @HiveField(3)
  List<DecisionOption> options;

  @HiveField(4)
  TimeHorizon timeHorizon;

  @HiveField(5)
  EmotionalState emotionalStateAtInput;

  @HiveField(6)
  RiskLevel perceivedRiskLevel;

  @HiveField(7)
  DateTime createdAt;

  @HiveField(8)
  DateTime? decisionMadeAt;

  @HiveField(9)
  String? chosenOptionId;

  @HiveField(10)
  String? notes;

  @HiveField(11)
  bool isAnalyzed;

  @HiveField(12)
  DateTime? reflectionDueAt;

  @HiveField(13)
  bool reflectionCompleted;

  @HiveField(14)
  String userId;

  @HiveField(15)
  List<String> tags;

  DecisionModel({
    required this.id,
    required this.title,
    required this.category,
    required this.options,
    required this.timeHorizon,
    required this.emotionalStateAtInput,
    required this.perceivedRiskLevel,
    required this.createdAt,
    this.decisionMadeAt,
    this.chosenOptionId,
    this.notes,
    this.isAnalyzed = false,
    this.reflectionDueAt,
    this.reflectionCompleted = false,
    required this.userId,
    this.tags = const [],
  });

  DecisionOption? get chosenOption {
    if (chosenOptionId == null) return null;
    try {
      return options.firstWhere((o) => o.id == chosenOptionId);
    } catch (_) {
      return null;
    }
  }

  DecisionOption? get lowestRegretOption {
    if (!isAnalyzed) return null;
    DecisionOption? best;
    double bestScore = double.infinity;
    for (final option in options) {
      final score = option.prediction?.overallRegretScore ?? double.infinity;
      if (score < bestScore) {
        bestScore = score;
        best = option;
      }
    }
    return best;
  }

  String get timeHorizonLabel {
    switch (timeHorizon) {
      case TimeHorizon.shortTerm:
        return 'Short Term (< 6 months)';
      case TimeHorizon.midTerm:
        return 'Mid Term (6 months – 2 years)';
      case TimeHorizon.longTerm:
        return 'Long Term (> 2 years)';
    }
  }

  DecisionModel copyWith({
    String? id,
    String? title,
    String? category,
    List<DecisionOption>? options,
    TimeHorizon? timeHorizon,
    EmotionalState? emotionalStateAtInput,
    RiskLevel? perceivedRiskLevel,
    DateTime? createdAt,
    DateTime? decisionMadeAt,
    String? chosenOptionId,
    String? notes,
    bool? isAnalyzed,
    DateTime? reflectionDueAt,
    bool? reflectionCompleted,
    String? userId,
    List<String>? tags,
  }) {
    return DecisionModel(
      id: id ?? this.id,
      title: title ?? this.title,
      category: category ?? this.category,
      options: options ?? this.options,
      timeHorizon: timeHorizon ?? this.timeHorizon,
      emotionalStateAtInput: emotionalStateAtInput ?? this.emotionalStateAtInput,
      perceivedRiskLevel: perceivedRiskLevel ?? this.perceivedRiskLevel,
      createdAt: createdAt ?? this.createdAt,
      decisionMadeAt: decisionMadeAt ?? this.decisionMadeAt,
      chosenOptionId: chosenOptionId ?? this.chosenOptionId,
      notes: notes ?? this.notes,
      isAnalyzed: isAnalyzed ?? this.isAnalyzed,
      reflectionDueAt: reflectionDueAt ?? this.reflectionDueAt,
      reflectionCompleted: reflectionCompleted ?? this.reflectionCompleted,
      userId: userId ?? this.userId,
      tags: tags ?? this.tags,
    );
  }
}

// Hive Adapters
class TimeHorizonAdapter extends TypeAdapter<TimeHorizon> {
  @override
  final int typeId = 5;

  @override
  TimeHorizon read(BinaryReader reader) =>
      TimeHorizon.values[reader.readByte()];

  @override
  void write(BinaryWriter writer, TimeHorizon obj) =>
      writer.writeByte(obj.index);
}

class RiskLevelAdapter extends TypeAdapter<RiskLevel> {
  @override
  final int typeId = 6;

  @override
  RiskLevel read(BinaryReader reader) => RiskLevel.values[reader.readByte()];

  @override
  void write(BinaryWriter writer, RiskLevel obj) => writer.writeByte(obj.index);
}

class EmotionalStateAdapter extends TypeAdapter<EmotionalState> {
  @override
  final int typeId = 7;

  @override
  EmotionalState read(BinaryReader reader) =>
      EmotionalState.values[reader.readByte()];

  @override
  void write(BinaryWriter writer, EmotionalState obj) =>
      writer.writeByte(obj.index);
}

class RegretPredictionAdapter extends TypeAdapter<RegretPrediction> {
  @override
  final int typeId = 4;

  @override
  RegretPrediction read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return RegretPrediction(
      optionId: fields[0] as String,
      regretProbability6Months: fields[1] as double,
      regretProbability1Year: fields[2] as double,
      regretProbability5Years: fields[3] as double,
      confidenceLevel: fields[4] as double,
      emotionalImpactScore: fields[5] as double,
      longTermSatisfactionScore: fields[6] as double,
      bestCaseScenario: fields[7] as String,
      worstCaseScenario: fields[8] as String,
      mostLikelyScenario: fields[9] as String,
      aiAdvice: fields[10] as String,
      keyRiskFactors: (fields[11] as List).cast<String>(),
      mitigationStrategies: (fields[12] as List).cast<String>(),
      calculatedAt: fields[13] as DateTime,
    );
  }

  @override
  void write(BinaryWriter writer, RegretPrediction obj) {
    writer
      ..writeByte(14)
      ..writeByte(0)
      ..write(obj.optionId)
      ..writeByte(1)
      ..write(obj.regretProbability6Months)
      ..writeByte(2)
      ..write(obj.regretProbability1Year)
      ..writeByte(3)
      ..write(obj.regretProbability5Years)
      ..writeByte(4)
      ..write(obj.confidenceLevel)
      ..writeByte(5)
      ..write(obj.emotionalImpactScore)
      ..writeByte(6)
      ..write(obj.longTermSatisfactionScore)
      ..writeByte(7)
      ..write(obj.bestCaseScenario)
      ..writeByte(8)
      ..write(obj.worstCaseScenario)
      ..writeByte(9)
      ..write(obj.mostLikelyScenario)
      ..writeByte(10)
      ..write(obj.aiAdvice)
      ..writeByte(11)
      ..write(obj.keyRiskFactors)
      ..writeByte(12)
      ..write(obj.mitigationStrategies)
      ..writeByte(13)
      ..write(obj.calculatedAt);
  }
}

class DecisionOptionAdapter extends TypeAdapter<DecisionOption> {
  @override
  final int typeId = 3;

  @override
  DecisionOption read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return DecisionOption(
      id: fields[0] as String,
      title: fields[1] as String,
      description: fields[2] as String? ?? '',
      pros: (fields[3] as List?)?.cast<String>() ?? [],
      cons: (fields[4] as List?)?.cast<String>() ?? [],
      perceivedRisk: fields[5] as double? ?? 50,
      expectedOutcomeScore: fields[6] as double? ?? 50,
      prediction: fields[7] as RegretPrediction?,
      wasRegretted: fields[8] as bool?,
    );
  }

  @override
  void write(BinaryWriter writer, DecisionOption obj) {
    writer
      ..writeByte(9)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.title)
      ..writeByte(2)
      ..write(obj.description)
      ..writeByte(3)
      ..write(obj.pros)
      ..writeByte(4)
      ..write(obj.cons)
      ..writeByte(5)
      ..write(obj.perceivedRisk)
      ..writeByte(6)
      ..write(obj.expectedOutcomeScore)
      ..writeByte(7)
      ..write(obj.prediction)
      ..writeByte(8)
      ..write(obj.wasRegretted);
  }
}

class DecisionModelAdapter extends TypeAdapter<DecisionModel> {
  @override
  final int typeId = 2;

  @override
  DecisionModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return DecisionModel(
      id: fields[0] as String,
      title: fields[1] as String,
      category: fields[2] as String,
      options: (fields[3] as List).cast<DecisionOption>(),
      timeHorizon: fields[4] as TimeHorizon,
      emotionalStateAtInput: fields[5] as EmotionalState,
      perceivedRiskLevel: fields[6] as RiskLevel,
      createdAt: fields[7] as DateTime,
      decisionMadeAt: fields[8] as DateTime?,
      chosenOptionId: fields[9] as String?,
      notes: fields[10] as String?,
      isAnalyzed: fields[11] as bool? ?? false,
      reflectionDueAt: fields[12] as DateTime?,
      reflectionCompleted: fields[13] as bool? ?? false,
      userId: fields[14] as String,
      tags: (fields[15] as List?)?.cast<String>() ?? [],
    );
  }

  @override
  void write(BinaryWriter writer, DecisionModel obj) {
    writer
      ..writeByte(16)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.title)
      ..writeByte(2)
      ..write(obj.category)
      ..writeByte(3)
      ..write(obj.options)
      ..writeByte(4)
      ..write(obj.timeHorizon)
      ..writeByte(5)
      ..write(obj.emotionalStateAtInput)
      ..writeByte(6)
      ..write(obj.perceivedRiskLevel)
      ..writeByte(7)
      ..write(obj.createdAt)
      ..writeByte(8)
      ..write(obj.decisionMadeAt)
      ..writeByte(9)
      ..write(obj.chosenOptionId)
      ..writeByte(10)
      ..write(obj.notes)
      ..writeByte(11)
      ..write(obj.isAnalyzed)
      ..writeByte(12)
      ..write(obj.reflectionDueAt)
      ..writeByte(13)
      ..write(obj.reflectionCompleted)
      ..writeByte(14)
      ..write(obj.userId)
      ..writeByte(15)
      ..write(obj.tags);
  }
}
