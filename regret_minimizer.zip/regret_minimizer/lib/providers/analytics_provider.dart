import 'package:flutter/foundation.dart';
import '../models/decision_model.dart';

class RegretTriggerInsight {
  final String category;
  final int count;
  final double avgRegretScore;
  final String emoji;

  const RegretTriggerInsight({
    required this.category,
    required this.count,
    required this.avgRegretScore,
    required this.emoji,
  });
}

class MonthlyRegretPoint {
  final DateTime month;
  final double avgRegretScore;
  final int decisionsCount;

  const MonthlyRegretPoint({
    required this.month,
    required this.avgRegretScore,
    required this.decisionsCount,
  });
}

class AnalyticsProvider extends ChangeNotifier {
  List<DecisionModel> _decisions = [];

  void updateDecisions(List<DecisionModel> decisions) {
    _decisions = decisions;
    notifyListeners();
  }

  int get totalDecisions => _decisions.length;
  int get analyzedDecisions => _decisions.where((d) => d.isAnalyzed).length;
  int get reflectedDecisions =>
      _decisions.where((d) => d.reflectionCompleted).length;

  int get totalRegrets {
    int count = 0;
    for (final d in _decisions) {
      for (final o in d.options) {
        if (o.wasRegretted == true) count++;
      }
    }
    return count;
  }

  double get overallRegretRate {
    if (reflectedDecisions == 0) return 0;
    return (totalRegrets / reflectedDecisions) * 100;
  }

  double get avgPredictedRegret {
    final analyzed = _decisions.where((d) => d.isAnalyzed).toList();
    if (analyzed.isEmpty) return 0;

    double total = 0;
    int count = 0;
    for (final d in analyzed) {
      for (final o in d.options) {
        if (o.prediction != null) {
          total += o.prediction!.overallRegretScore;
          count++;
        }
      }
    }
    return count > 0 ? total / count : 0;
  }

  List<RegretTriggerInsight> get categoryInsights {
    final Map<String, List<double>> categoryScores = {};
    final Map<String, String> categoryEmojis = {
      'career': '💼',
      'relationships': '❤️',
      'finance': '💰',
      'education': '📚',
      'health': '🏥',
      'lifestyle': '🌿',
      'other': '🎯',
    };

    for (final d in _decisions.where((d) => d.isAnalyzed)) {
      final cat = d.category.toLowerCase();
      categoryScores[cat] ??= [];
      for (final o in d.options) {
        if (o.prediction != null) {
          categoryScores[cat]!.add(o.prediction!.overallRegretScore);
        }
      }
    }

    return categoryScores.entries.map((entry) {
      final scores = entry.value;
      final avg = scores.reduce((a, b) => a + b) / scores.length;
      return RegretTriggerInsight(
        category: entry.key,
        count: scores.length,
        avgRegretScore: avg,
        emoji: categoryEmojis[entry.key] ?? '🎯',
      );
    }).toList()
      ..sort((a, b) => b.avgRegretScore.compareTo(a.avgRegretScore));
  }

  List<MonthlyRegretPoint> get monthlyTrend {
    final Map<String, List<double>> byMonth = {};

    for (final d in _decisions.where((d) => d.isAnalyzed)) {
      final key =
          '${d.createdAt.year}-${d.createdAt.month.toString().padLeft(2, '0')}';
      byMonth[key] ??= [];
      for (final o in d.options) {
        if (o.prediction != null) {
          byMonth[key]!.add(o.prediction!.overallRegretScore);
        }
      }
    }

    final sortedKeys = byMonth.keys.toList()..sort();
    return sortedKeys.map((key) {
      final parts = key.split('-');
      final month = DateTime(int.parse(parts[0]), int.parse(parts[1]));
      final scores = byMonth[key]!;
      return MonthlyRegretPoint(
        month: month,
        avgRegretScore: scores.reduce((a, b) => a + b) / scores.length,
        decisionsCount: scores.length,
      );
    }).toList();
  }

  // Most common emotional state when making high-regret decisions
  Map<String, int> get emotionalStateFrequency {
    final Map<String, int> freq = {};
    for (final d in _decisions) {
      final state = d.emotionalStateAtInput.name;
      freq[state] = (freq[state] ?? 0) + 1;
    }
    return freq;
  }

  String get highestRegretCategory {
    final insights = categoryInsights;
    if (insights.isEmpty) return 'N/A';
    return insights.first.category;
  }

  String get lowestRegretCategory {
    final insights = categoryInsights;
    if (insights.isEmpty) return 'N/A';
    return insights.last.category;
  }

  // Prediction accuracy (only for reflected decisions)
  double get predictionAccuracy {
    int correct = 0;
    int total = 0;

    for (final d in _decisions.where((d) => d.reflectionCompleted)) {
      for (final o in d.options) {
        if (o.prediction != null && o.wasRegretted != null) {
          total++;
          final predicted = o.prediction!.overallRegretScore > 50;
          if (predicted == o.wasRegretted) correct++;
        }
      }
    }
    return total > 0 ? (correct / total) * 100 : 0;
  }

  String get personalityInsight {
    final avgRegret = avgPredictedRegret;
    if (avgRegret < 30) {
      return 'You are a low-regret decision maker. Your analytical approach aligns well with long-term satisfaction.';
    } else if (avgRegret < 50) {
      return 'You experience moderate regret risk. Consider slowing down high-stakes decisions and consulting others.';
    } else {
      return 'Your decision patterns show elevated regret risk. Emotional state at decision time seems to be a key factor.';
    }
  }

  String get bestTimeToDecide {
    final byState = <String, double>{};
    final stateCount = <String, int>{};

    for (final d in _decisions.where((d) => d.isAnalyzed)) {
      final state = d.emotionalStateAtInput.name;
      for (final o in d.options) {
        if (o.prediction != null) {
          byState[state] =
              (byState[state] ?? 0) + o.prediction!.overallRegretScore;
          stateCount[state] = (stateCount[state] ?? 0) + 1;
        }
      }
    }

    if (byState.isEmpty) return 'calm or confident';

    String bestState = 'calm';
    double bestAvg = double.infinity;
    for (final entry in byState.entries) {
      final avg = entry.value / (stateCount[entry.key] ?? 1);
      if (avg < bestAvg) {
        bestAvg = avg;
        bestState = entry.key;
      }
    }
    return bestState;
  }
}
