import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';
import '../models/decision_model.dart';
import '../models/user_profile_model.dart';
import '../core/storage/hive_storage.dart';
import '../core/engine/regret_prediction_engine.dart';

enum DecisionStatus { idle, loading, analyzing, error, success }

class DecisionProvider extends ChangeNotifier {
  List<DecisionModel> _decisions = [];
  DecisionModel? _currentDecision;
  DecisionStatus _status = DecisionStatus.idle;
  String? _error;
  bool _initialized = false;

  List<DecisionModel> get decisions => _decisions;
  DecisionModel? get currentDecision => _currentDecision;
  DecisionStatus get status => _status;
  String? get error => _error;
  bool get isLoading => _status == DecisionStatus.loading;
  bool get isAnalyzing => _status == DecisionStatus.analyzing;

  void initialize() {
    if (_initialized) return;
    _loadDecisions();
    _initialized = true;
  }

  void _loadDecisions() {
    _decisions = HiveStorage.getAllDecisions();
    notifyListeners();
  }

  // Create and save a new decision
  Future<String> createDecision({
    required String title,
    required String category,
    required List<DecisionOption> options,
    required TimeHorizon timeHorizon,
    required EmotionalState emotionalState,
    required RiskLevel riskLevel,
    String? notes,
    List<String> tags = const [],
    required String userId,
  }) async {
    _status = DecisionStatus.loading;
    notifyListeners();

    try {
      final decisionId = const Uuid().v4();

      // Give each option a fresh UUID
      final stampedOptions = options.map((o) {
        return DecisionOption(
          id: const Uuid().v4(),
          title: o.title,
          description: o.description,
          pros: o.pros,
          cons: o.cons,
          perceivedRisk: o.perceivedRisk,
          expectedOutcomeScore: o.expectedOutcomeScore,
        );
      }).toList();

      final decision = DecisionModel(
        id: decisionId,
        title: title,
        category: category,
        options: stampedOptions,
        timeHorizon: timeHorizon,
        emotionalStateAtInput: emotionalState,
        perceivedRiskLevel: riskLevel,
        createdAt: DateTime.now(),
        isAnalyzed: false,
        userId: userId,
        notes: notes,
        tags: tags,
        reflectionDueAt: _computeReflectionDate(timeHorizon),
      );

      await HiveStorage.saveDecision(decision);
      _decisions.insert(0, decision);
      _currentDecision = decision;
      _status = DecisionStatus.success;
      notifyListeners();
      return decisionId;
    } catch (e) {
      _error = 'Failed to create decision: $e';
      _status = DecisionStatus.error;
      notifyListeners();
      return '';
    }
  }

  // Run AI analysis on a decision
  Future<void> analyzeDecision(String decisionId, UserProfile profile) async {
    _status = DecisionStatus.analyzing;
    notifyListeners();

    try {
      // Simulate processing time for UX
      await Future.delayed(const Duration(seconds: 2));

      final decision = HiveStorage.getDecision(decisionId);
      if (decision == null) {
        _error = 'Decision not found';
        _status = DecisionStatus.error;
        notifyListeners();
        return;
      }

      // Run prediction engine
      final predictions = RegretPredictionEngine.analyzeDecision(
        decision: decision,
        userProfile: profile,
      );

      // Attach predictions to options
      final updatedOptions = decision.options.map((option) {
        final pred = predictions.firstWhere(
          (p) => p.optionId == option.id,
          orElse: () => predictions.first,
        );
        return DecisionOption(
          id: option.id,
          title: option.title,
          description: option.description,
          pros: option.pros,
          cons: option.cons,
          perceivedRisk: option.perceivedRisk,
          expectedOutcomeScore: option.expectedOutcomeScore,
          prediction: pred,
        );
      }).toList();

      final analyzedDecision = decision.copyWith(
        options: updatedOptions,
        isAnalyzed: true,
      );

      await HiveStorage.saveDecision(analyzedDecision);

      // Update in-memory list
      final idx = _decisions.indexWhere((d) => d.id == decisionId);
      if (idx != -1) _decisions[idx] = analyzedDecision;
      _currentDecision = analyzedDecision;

      _status = DecisionStatus.success;
      notifyListeners();
    } catch (e) {
      _error = 'Analysis failed: $e';
      _status = DecisionStatus.error;
      notifyListeners();
    }
  }

  // Set chosen option
  Future<void> chooseOption(String decisionId, String optionId) async {
    final decision = HiveStorage.getDecision(decisionId);
    if (decision == null) return;

    final updated = decision.copyWith(
      chosenOptionId: optionId,
      decisionMadeAt: DateTime.now(),
    );
    await HiveStorage.saveDecision(updated);

    final idx = _decisions.indexWhere((d) => d.id == decisionId);
    if (idx != -1) _decisions[idx] = updated;
    if (_currentDecision?.id == decisionId) _currentDecision = updated;

    notifyListeners();
  }

  // Submit reflection
  Future<void> submitReflection(
    String decisionId,
    String optionId,
    bool wasRegretted,
  ) async {
    final decision = HiveStorage.getDecision(decisionId);
    if (decision == null) return;

    final updatedOptions = decision.options.map((o) {
      if (o.id == optionId) {
        return DecisionOption(
          id: o.id,
          title: o.title,
          description: o.description,
          pros: o.pros,
          cons: o.cons,
          perceivedRisk: o.perceivedRisk,
          expectedOutcomeScore: o.expectedOutcomeScore,
          prediction: o.prediction,
          wasRegretted: wasRegretted,
        );
      }
      return o;
    }).toList();

    final updated = decision.copyWith(
      options: updatedOptions,
      reflectionCompleted: true,
    );
    await HiveStorage.saveDecision(updated);

    final idx = _decisions.indexWhere((d) => d.id == decisionId);
    if (idx != -1) _decisions[idx] = updated;
    if (_currentDecision?.id == decisionId) _currentDecision = updated;

    notifyListeners();
  }

  // Delete decision
  Future<void> deleteDecision(String decisionId) async {
    await HiveStorage.deleteDecision(decisionId);
    _decisions.removeWhere((d) => d.id == decisionId);
    if (_currentDecision?.id == decisionId) _currentDecision = null;
    notifyListeners();
  }

  void setCurrentDecision(String decisionId) {
    _currentDecision = _decisions.firstWhere(
      (d) => d.id == decisionId,
      orElse: () => HiveStorage.getDecision(decisionId)!,
    );
    notifyListeners();
  }

  void clearError() {
    _error = null;
    _status = DecisionStatus.idle;
    notifyListeners();
  }

  DateTime _computeReflectionDate(TimeHorizon horizon) {
    final now = DateTime.now();
    switch (horizon) {
      case TimeHorizon.shortTerm:
        return now.add(const Duration(days: 90)); // 3 months
      case TimeHorizon.midTerm:
        return now.add(const Duration(days: 365)); // 1 year
      case TimeHorizon.longTerm:
        return now.add(const Duration(days: 365 * 2)); // 2 years
    }
  }

  // Filtered views
  List<DecisionModel> get analyzedDecisions =>
      _decisions.where((d) => d.isAnalyzed).toList();

  List<DecisionModel> get pendingDecisions =>
      _decisions.where((d) => !d.isAnalyzed).toList();

  List<DecisionModel> get recentDecisions =>
      _decisions.take(5).toList();

  List<DecisionModel> pendingReflections() {
    final now = DateTime.now();
    return _decisions.where((d) {
      return d.isAnalyzed &&
          !d.reflectionCompleted &&
          d.reflectionDueAt != null &&
          d.reflectionDueAt!.isBefore(now.add(const Duration(days: 7)));
    }).toList();
  }
}
