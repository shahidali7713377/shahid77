import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';
import '../models/user_profile_model.dart';
import '../core/storage/hive_storage.dart';

class UserProvider extends ChangeNotifier {
  UserProfile? _userProfile;
  bool _isLoading = false;
  String? _error;

  UserProfile? get userProfile => _userProfile;
  bool get isLoading => _isLoading;
  String? get error => _error;
  bool get hasProfile => _userProfile != null;

  UserProvider() {
    _loadProfile();
  }

  void _loadProfile() {
    _userProfile = HiveStorage.getUserProfile();
    notifyListeners();
  }

  Future<void> createProfile({
    required String name,
    required PersonalityProfile personality,
    required double riskTolerance,
    required String decisionStyle,
    required double emotionalVolatility,
    required List<String> primaryRegretTriggers,
    String email = '',
  }) async {
    _isLoading = true;
    notifyListeners();

    try {
      final profile = UserProfile(
        id: const Uuid().v4(),
        name: name,
        email: email,
        personality: personality,
        riskTolerance: riskTolerance,
        decisionStyle: decisionStyle,
        emotionalVolatility: emotionalVolatility,
        primaryRegretTriggers: primaryRegretTriggers,
        createdAt: DateTime.now(),
      );

      await HiveStorage.saveUserProfile(profile);
      _userProfile = profile;
      _error = null;
    } catch (e) {
      _error = 'Failed to create profile: $e';
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> updateProfile(UserProfile updatedProfile) async {
    _isLoading = true;
    notifyListeners();

    try {
      await HiveStorage.saveUserProfile(updatedProfile);
      _userProfile = updatedProfile;
      _error = null;
    } catch (e) {
      _error = 'Failed to update profile: $e';
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> incrementDecisionCount({bool wasRegretted = false}) async {
    if (_userProfile == null) return;

    final updated = _userProfile!.copyWith(
      totalDecisions: _userProfile!.totalDecisions + 1,
      totalRegrets: wasRegretted
          ? _userProfile!.totalRegrets + 1
          : _userProfile!.totalRegrets,
    );
    await updateProfile(updated);
  }

  Future<void> clearProfile() async {
    await HiveStorage.clearUserProfile();
    await HiveStorage.setOnboardingComplete(false);
    _userProfile = null;
    notifyListeners();
  }

  bool get isOnboardingComplete => HiveStorage.isOnboardingComplete();
}
