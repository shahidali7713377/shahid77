import 'package:flutter/foundation.dart';
import '../models/user_profile_model.dart';
import '../core/engine/regret_prediction_engine.dart';

class OnboardingProvider extends ChangeNotifier {
  int _currentStep = 0;
  bool _isProcessing = false;

  // Step 1: Personal info
  String name = '';

  // Step 2: Personality Quiz (25 questions)
  final Map<int, double> _quizAnswers = {};
  PersonalityProfile? _computedPersonality;

  // Step 3: Behavioral baseline
  double _riskTolerance = 50.0;
  String _decisionStyle = 'analytical';
  double _emotionalVolatility = 50.0;
  List<String> _primaryRegretTriggers = [];

  // Step 4: Review

  int get currentStep => _currentStep;
  bool get isProcessing => _isProcessing;
  Map<int, double> get quizAnswers => Map.unmodifiable(_quizAnswers);
  PersonalityProfile? get computedPersonality => _computedPersonality;
  double get riskTolerance => _riskTolerance;
  String get decisionStyle => _decisionStyle;
  double get emotionalVolatility => _emotionalVolatility;
  List<String> get primaryRegretTriggers => List.unmodifiable(_primaryRegretTriggers);

  int get totalSteps => 4;

  void nextStep() {
    if (_currentStep < totalSteps - 1) {
      _currentStep++;
      notifyListeners();
    }
  }

  void previousStep() {
    if (_currentStep > 0) {
      _currentStep--;
      notifyListeners();
    }
  }

  void setName(String value) {
    name = value;
    notifyListeners();
  }

  void setQuizAnswer(int questionIndex, double value) {
    _quizAnswers[questionIndex] = value;
    notifyListeners();
  }

  void computePersonality() {
    _isProcessing = true;
    notifyListeners();

    Future.delayed(const Duration(milliseconds: 800), () {
      _computedPersonality =
          RegretPredictionEngine.scorePersonalityQuiz(_quizAnswers);
      _isProcessing = false;
      notifyListeners();
    });
  }

  void setRiskTolerance(double value) {
    _riskTolerance = value;
    notifyListeners();
  }

  void setDecisionStyle(String value) {
    _decisionStyle = value;
    notifyListeners();
  }

  void setEmotionalVolatility(double value) {
    _emotionalVolatility = value;
    notifyListeners();
  }

  void toggleRegretTrigger(String trigger) {
    if (_primaryRegretTriggers.contains(trigger)) {
      _primaryRegretTriggers = List.from(_primaryRegretTriggers)
        ..remove(trigger);
    } else {
      _primaryRegretTriggers = List.from(_primaryRegretTriggers)..add(trigger);
    }
    notifyListeners();
  }

  bool isTriggerSelected(String trigger) =>
      _primaryRegretTriggers.contains(trigger);

  void reset() {
    _currentStep = 0;
    name = '';
    _quizAnswers.clear();
    _computedPersonality = null;
    _riskTolerance = 50.0;
    _decisionStyle = 'analytical';
    _emotionalVolatility = 50.0;
    _primaryRegretTriggers = [];
    notifyListeners();
  }

  double get completionPercent => (_currentStep + 1) / totalSteps;
}

// Onboarding quiz questions
const List<Map<String, dynamic>> personalityQuestions = [
  // Openness (0-4)
  {
    'index': 0,
    'text': 'I enjoy exploring new ideas and unconventional approaches',
    'trait': 'Openness',
    'emoji': '🔭'
  },
  {
    'index': 1,
    'text': 'I find abstract concepts and theories fascinating',
    'trait': 'Openness',
    'emoji': '💡'
  },
  {
    'index': 2,
    'text': 'I love experiencing new cultures, art, and creative expression',
    'trait': 'Openness',
    'emoji': '🎨'
  },
  {
    'index': 3,
    'text': 'I often challenge conventional thinking',
    'trait': 'Openness',
    'emoji': '🌀'
  },
  {
    'index': 4,
    'text': 'I prefer novelty over routine in my daily life',
    'trait': 'Openness',
    'emoji': '✨'
  },
  // Conscientiousness (5-9)
  {
    'index': 5,
    'text': 'I always complete tasks and follow through on commitments',
    'trait': 'Conscientiousness',
    'emoji': '✅'
  },
  {
    'index': 6,
    'text': 'I plan carefully before taking action',
    'trait': 'Conscientiousness',
    'emoji': '📋'
  },
  {
    'index': 7,
    'text': 'I keep my environment organized and structured',
    'trait': 'Conscientiousness',
    'emoji': '🗂️'
  },
  {
    'index': 8,
    'text': 'I set clear goals and work systematically toward them',
    'trait': 'Conscientiousness',
    'emoji': '🎯'
  },
  {
    'index': 9,
    'text': 'I research decisions thoroughly before committing',
    'trait': 'Conscientiousness',
    'emoji': '🔍'
  },
  // Extraversion (10-14)
  {
    'index': 10,
    'text': 'I feel energized by social interactions',
    'trait': 'Extraversion',
    'emoji': '🎉'
  },
  {
    'index': 11,
    'text': 'I prefer talking things through with others',
    'trait': 'Extraversion',
    'emoji': '💬'
  },
  {
    'index': 12,
    'text': 'I enjoy being the center of attention',
    'trait': 'Extraversion',
    'emoji': '⭐'
  },
  {
    'index': 13,
    'text': 'I take initiative in social situations',
    'trait': 'Extraversion',
    'emoji': '🚀'
  },
  {
    'index': 14,
    'text': 'I have a wide network of friends and acquaintances',
    'trait': 'Extraversion',
    'emoji': '🤝'
  },
  // Agreeableness (15-19)
  {
    'index': 15,
    'text': 'I prioritize harmony and avoid conflict',
    'trait': 'Agreeableness',
    'emoji': '🕊️'
  },
  {
    'index': 16,
    'text': 'I make decisions considering how they affect others',
    'trait': 'Agreeableness',
    'emoji': '❤️'
  },
  {
    'index': 17,
    'text': 'I trust people easily and give benefit of the doubt',
    'trait': 'Agreeableness',
    'emoji': '🌱'
  },
  {
    'index': 18,
    'text': 'I feel genuine empathy for people in difficult situations',
    'trait': 'Agreeableness',
    'emoji': '🫂'
  },
  {
    'index': 19,
    'text': 'I prefer cooperation over competition',
    'trait': 'Agreeableness',
    'emoji': '🤲'
  },
  // Neuroticism (20-24)
  {
    'index': 20,
    'text': 'I often worry about what could go wrong',
    'trait': 'Neuroticism',
    'emoji': '😰'
  },
  {
    'index': 21,
    'text': 'I experience strong emotional reactions to setbacks',
    'trait': 'Neuroticism',
    'emoji': '🌊'
  },
  {
    'index': 22,
    'text': 'I second-guess my decisions after making them',
    'trait': 'Neuroticism',
    'emoji': '🔄'
  },
  {
    'index': 23,
    'text': 'I feel stressed easily in uncertain situations',
    'trait': 'Neuroticism',
    'emoji': '⚡'
  },
  {
    'index': 24,
    'text': 'My mood fluctuates depending on circumstances',
    'trait': 'Neuroticism',
    'emoji': '🎭'
  },
];

const List<String> regretTriggerOptions = [
  '💸 Financial losses',
  '💔 Relationship decisions',
  '💼 Career choices not taken',
  '🎓 Education paths',
  '⏰ Missed opportunities',
  '🏥 Health neglect',
  '👨‍👩‍👧 Family decisions',
  '🌍 Travel not taken',
  '🎯 Goals abandoned',
  '🤝 Trust betrayed',
];

const List<Map<String, String>> decisionStyles = [
  {
    'value': 'analytical',
    'label': 'Analytical',
    'desc': 'I research thoroughly and rely on data'
  },
  {
    'value': 'intuitive',
    'label': 'Intuitive',
    'desc': 'I trust my gut feeling'
  },
  {
    'value': 'consultative',
    'label': 'Consultative',
    'desc': 'I seek advice from others'
  },
  {
    'value': 'spontaneous',
    'label': 'Spontaneous',
    'desc': 'I decide quickly in the moment'
  },
];
