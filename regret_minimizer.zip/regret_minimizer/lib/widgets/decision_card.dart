import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../core/theme/app_theme.dart';
import '../models/decision_model.dart';

class DecisionCard extends StatelessWidget {
  final DecisionModel decision;
  final VoidCallback onTap;
  final bool showReflectButton;
  final VoidCallback? onReflect;
  final VoidCallback? onDelete;

  const DecisionCard({
    super.key,
    required this.decision,
    required this.onTap,
    this.showReflectButton = false,
    this.onReflect,
    this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    final lowestOption = decision.lowestRegretOption;
    final overallScore = lowestOption?.prediction?.overallRegretScore;
    final color = overallScore != null ? regretScoreColor(overallScore) : AppTheme.textMuted;
    final categoryEmojis = {
      'career': '💼', 'relationships': '❤️', 'finance': '💰',
      'education': '📚', 'health': '🏥', 'lifestyle': '🌿', 'other': '🎯',
    };
    final emoji = categoryEmojis[decision.category.toLowerCase()] ?? '🎯';

    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        decoration: BoxDecoration(
          color: AppTheme.bgCard,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: decision.isAnalyzed ? color.withOpacity(0.2) : Colors.white.withOpacity(0.06),
          ),
        ),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                // Category emoji + indicator
                Column(children: [
                  Container(
                    width: 44, height: 44,
                    decoration: BoxDecoration(
                      color: AppTheme.bgSurface,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Center(child: Text(emoji, style: const TextStyle(fontSize: 22))),
                  ),
                  if (decision.isAnalyzed && overallScore != null) ...[
                    const SizedBox(height: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: color.withOpacity(0.15), borderRadius: BorderRadius.circular(6)),
                      child: Text('${overallScore.round()}%', style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.w700)),
                    ),
                  ],
                ]),

                const SizedBox(width: 14),

                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      Expanded(
                        child: Text(
                          decision.title,
                          style: Theme.of(context).textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.w600),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      if (onDelete != null)
                        GestureDetector(
                          onTap: onDelete,
                          child: const Icon(Icons.more_vert, color: AppTheme.textMuted, size: 18),
                        ),
                    ]),
                    const SizedBox(height: 6),
                    Row(children: [
                      _Chip(label: decision.category, color: AppTheme.primaryPurple),
                      const SizedBox(width: 6),
                      _Chip(label: _horizonLabel(decision.timeHorizon), color: AppTheme.accentCyan),
                      if (decision.isAnalyzed) ...[
                        const SizedBox(width: 6),
                        _Chip(label: '${decision.options.length} options', color: AppTheme.accentEmerald),
                      ],
                    ]),
                    const SizedBox(height: 8),
                    Row(children: [
                      Icon(Icons.access_time, size: 12, color: AppTheme.textMuted),
                      const SizedBox(width: 4),
                      Text(DateFormat('MMM d, y').format(decision.createdAt),
                          style: Theme.of(context).textTheme.bodySmall?.copyWith(color: AppTheme.textMuted)),
                      const Spacer(),
                      if (!decision.isAnalyzed)
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(color: AppTheme.accentAmber.withOpacity(0.1), borderRadius: BorderRadius.circular(6)),
                          child: Text('Pending', style: Theme.of(context).textTheme.bodySmall?.copyWith(color: AppTheme.accentAmber, fontWeight: FontWeight.w600)),
                        )
                      else if (decision.chosenOptionId != null)
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(color: AppTheme.accentEmerald.withOpacity(0.1), borderRadius: BorderRadius.circular(6)),
                          child: Row(children: [
                            const Icon(Icons.check, color: AppTheme.accentEmerald, size: 12),
                            const SizedBox(width: 4),
                            Text('Decided', style: Theme.of(context).textTheme.bodySmall?.copyWith(color: AppTheme.accentEmerald, fontWeight: FontWeight.w600)),
                          ]),
                        ),
                    ]),
                  ]),
                ),
              ]),
            ),

            // Reflect button
            if (showReflectButton && onReflect != null)
              GestureDetector(
                onTap: onReflect,
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  decoration: BoxDecoration(
                    color: AppTheme.accentAmber.withOpacity(0.1),
                    borderRadius: const BorderRadius.vertical(bottom: Radius.circular(16)),
                    border: Border(top: BorderSide(color: AppTheme.accentAmber.withOpacity(0.2))),
                  ),
                  child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                    const Icon(Icons.rate_review_outlined, color: AppTheme.accentAmber, size: 16),
                    const SizedBox(width: 6),
                    Text('Reflection Due – Tap to reflect', style: Theme.of(context).textTheme.bodySmall?.copyWith(color: AppTheme.accentAmber, fontWeight: FontWeight.w600)),
                  ]),
                ),
              ),
          ],
        ),
      ),
    );
  }

  String _horizonLabel(TimeHorizon h) {
    switch (h) {
      case TimeHorizon.shortTerm: return 'Short Term';
      case TimeHorizon.midTerm: return 'Mid Term';
      case TimeHorizon.longTerm: return 'Long Term';
    }
  }
}

class _Chip extends StatelessWidget {
  final String label;
  final Color color;
  const _Chip({required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(6)),
      child: Text(label, style: Theme.of(context).textTheme.bodySmall?.copyWith(color: color, fontSize: 11, fontWeight: FontWeight.w500)),
    );
  }
}
