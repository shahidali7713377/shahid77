import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'core/theme/app_theme.dart';
import 'providers/user_provider.dart';
import 'screens/splash/splash_screen.dart';
import 'screens/onboarding/onboarding_screen.dart';
import 'screens/home/home_screen.dart';
import 'screens/decision/decision_input_screen.dart';
import 'screens/decision/decision_analysis_screen.dart';
import 'screens/history/history_screen.dart';
import 'screens/analytics/analytics_screen.dart';
import 'screens/settings/settings_screen.dart';

class RegretMinimizerApp extends StatelessWidget {
  const RegretMinimizerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Regret Minimizer',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.darkTheme,
      initialRoute: '/splash',
      routes: {
        '/splash': (_) => const SplashScreen(),
        '/onboarding': (_) => const OnboardingScreen(),
        '/home': (_) => const HomeScreen(),
        '/decision/new': (_) => const DecisionInputScreen(),
        '/history': (_) => const HistoryScreen(),
        '/analytics': (_) => const AnalyticsScreen(),
        '/settings': (_) => const SettingsScreen(),
      },
      onGenerateRoute: (settings) {
        if (settings.name == '/decision/analysis') {
          final decisionId = settings.arguments as String;
          return MaterialPageRoute(
            builder: (_) => DecisionAnalysisScreen(decisionId: decisionId),
          );
        }
        return null;
      },
    );
  }
}
