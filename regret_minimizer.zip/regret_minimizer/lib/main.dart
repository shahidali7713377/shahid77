import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:provider/provider.dart';

import 'core/storage/hive_storage.dart';
import 'models/decision_model.dart';
import 'models/personality_model.dart';
import 'models/user_profile_model.dart';
import 'providers/analytics_provider.dart';
import 'providers/decision_provider.dart';
import 'providers/onboarding_provider.dart';
import 'providers/user_provider.dart';
import 'app.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Lock to portrait orientation
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
  ));

  // Initialize Hive
  await Hive.initFlutter();

  // Register Adapters
  Hive.registerAdapter(UserProfileAdapter());
  Hive.registerAdapter(PersonalityProfileAdapter());
  Hive.registerAdapter(DecisionModelAdapter());
  Hive.registerAdapter(DecisionOptionAdapter());
  Hive.registerAdapter(RegretPredictionAdapter());
  Hive.registerAdapter(EmotionalStateAdapter());
  Hive.registerAdapter(TimeHorizonAdapter());
  Hive.registerAdapter(RiskLevelAdapter());

  // Open Hive boxes
  await HiveStorage.init();

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => UserProvider()),
        ChangeNotifierProvider(create: (_) => OnboardingProvider()),
        ChangeNotifierProvider(create: (_) => DecisionProvider()),
        ChangeNotifierProvider(create: (_) => AnalyticsProvider()),
      ],
      child: const RegretMinimizerApp(),
    ),
  );
}
