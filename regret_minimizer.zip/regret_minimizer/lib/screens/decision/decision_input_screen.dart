import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';
import '../../core/theme/app_theme.dart';
import '../../models/decision_model.dart';
import '../../providers/decision_provider.dart';
import '../../providers/user_provider.dart';

class DecisionInputScreen extends StatefulWidget {
  const DecisionInputScreen({super.key});

  @override
  State<DecisionInputScreen> createState() => _DecisionInputScreenState();
}

class _DecisionInputScreenState extends State<DecisionInputScreen> {
  final _pageController = PageController();
  int _step = 0;
  final _totalSteps = 3;

  // Step 1: Decision basics
  final _titleController = TextEditingController();
  String _category = 'career';
  TimeHorizon _timeHorizon = TimeHorizon.midTerm;
  EmotionalState _emotionalState = EmotionalState.calm;
  RiskLevel _riskLevel = RiskLevel.moderate;

  // Step 2: Options
  final List<_OptionDraft> _options = [
    _OptionDraft(id: const Uuid().v4()),
    _OptionDraft(id: const Uuid().v4()),
  ];

  // Step 3: Notes and review
  final _notesController = TextEditingController();

  @override
  void dispose() {
    _pageController.dispose();
    _titleController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  void _nextStep() {
    if (_step == 0 && _titleController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a decision title')),
      );
      return;
    }
    if (_step == 1) {
      final hasEmpty = _options.any((o) => o.title.trim().isEmpty);
      if (hasEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Please fill in all option titles')),
        );
        return;
      }
    }
    setState(() => _step++);
    _pageController.nextPage(
      duration: const Duration(milliseconds: 350),
      curve: Curves.easeInOutCubic,
    );
  }

  void _prevStep() {
    setState(() => _step--);
    _pageController.previousPage(
      duration: const Duration(milliseconds: 350),
      curve: Curves.easeInOutCubic,
    );
  }

  Future<void> _submitDecision() async {
    final decisionProvider = context.read<DecisionProvider>();
    final userProvider = context.read<UserProvider>();
    final userId = userProvider.userProfile?.id ?? '';

    final options = _options
        .map((o) => DecisionOption(
              id: o.id,
              title: o.title,
              description: o.description,
              pros: o.pros,
              cons: o.cons,
              perceivedRisk: o.perceivedRisk,
              expectedOutcomeScore: o.expectedOutcomeScore,
            ))
        .toList();

    final decisionId = await decisionProvider.createDecision(
      title: _titleController.text.trim(),
      category: _category,
      options: options,
      timeHorizon: _timeHorizon,
      emotionalState: _emotionalState,
      riskLevel: _riskLevel,
      notes: _notesController.text.trim().isEmpty
          ? null
          : _notesController.text.trim(),
      userId: userId,
    );

    if (decisionId.isNotEmpty && mounted) {
      // Auto-analyze
      if (userProvider.userProfile != null) {
        decisionProvider
            .analyzeDecision(decisionId, userProvider.userProfile!);
      }
      Navigator.pushReplacementNamed(
        context,
        '/decision/analysis',
        arguments: decisionId,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bgPrimary,
      appBar: AppBar(
        title: const Text('New Decision'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded),
          onPressed: () {
            if (_step > 0) {
              _prevStep();
            } else {
              Navigator.pop(context);
            }
          },
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Center(
              child: Text(
                'Step ${_step + 1}/$_totalSteps',
                style: Theme.of(context)
                    .textTheme
                    .bodySmall
                    ?.copyWith(color: AppTheme.textMuted),
              ),
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          // Progress
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                value: (_step + 1) / _totalSteps,
                backgroundColor: AppTheme.bgCard,
                valueColor: const AlwaysStoppedAnimation<Color>(
                    AppTheme.primaryPurple),
                minHeight: 3,
              ),
            ),
          ),
          const SizedBox(height: 4),

          Expanded(
            child: PageView(
              controller: _pageController,
              physics: const NeverScrollableScrollPhysics(),
              children: [
                _Step1BasicInfo(
                  titleController: _titleController,
                  category: _category,
                  timeHorizon: _timeHorizon,
                  emotionalState: _emotionalState,
                  riskLevel: _riskLevel,
                  onCategoryChanged: (v) => setState(() => _category = v),
                  onTimeHorizonChanged: (v) =>
                      setState(() => _timeHorizon = v),
                  onEmotionalStateChanged: (v) =>
                      setState(() => _emotionalState = v),
                  onRiskLevelChanged: (v) =>
                      setState(() => _riskLevel = v),
                ),
                _Step2Options(
                  options: _options,
                  onAddOption: () {
                    setState(() {
                      if (_options.length < 5) {
                        _options.add(_OptionDraft(id: const Uuid().v4()));
                      }
                    });
                  },
                  onRemoveOption: (index) {
                    setState(() {
                      if (_options.length > 2) {
                        _options.removeAt(index);
                      }
                    });
                  },
                  onOptionChanged: (index, draft) {
                    setState(() => _options[index] = draft);
                  },
                ),
                _Step3Review(
                  title: _titleController.text,
                  category: _category,
                  options: _options,
                  timeHorizon: _timeHorizon,
                  emotionalState: _emotionalState,
                  riskLevel: _riskLevel,
                  notesController: _notesController,
                ),
              ],
            ),
          ),

          // Bottom navigation
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
            child: Row(
              children: [
                if (_step > 0)
                  Expanded(
                    flex: 1,
                    child: OutlinedButton(
                      onPressed: _prevStep,
                      style: OutlinedButton.styleFrom(
                        side: BorderSide(
                            color: Colors.white.withOpacity(0.15)),
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                      ),
                      child: const Text('Back',
                          style: TextStyle(color: AppTheme.textSecondary)),
                    ),
                  ),
                if (_step > 0) const SizedBox(width: 12),
                Expanded(
                  flex: 3,
                  child: Consumer<DecisionProvider>(
                    builder: (ctx, dp, _) {
                      return SizedBox(
                        height: 54,
                        child: DecoratedBox(
                          decoration: BoxDecoration(
                            gradient: AppTheme.primaryGradient,
                            borderRadius: BorderRadius.circular(16),
                            boxShadow: [
                              BoxShadow(
                                color: AppTheme.primaryPurple.withOpacity(0.4),
                                blurRadius: 16,
                                offset: const Offset(0, 6),
                              ),
                            ],
                          ),
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.transparent,
                              shadowColor: Colors.transparent,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(16),
                              ),
                            ),
                            onPressed: dp.isLoading
                                ? null
                                : _step < _totalSteps - 1
                                    ? _nextStep
                                    : _submitDecision,
                            child: dp.isLoading
                                ? const SizedBox(
                                    width: 24,
                                    height: 24,
                                    child: CircularProgressIndicator(
                                        color: Colors.white, strokeWidth: 2),
                                  )
                                : Text(
                                    _step < _totalSteps - 1
                                        ? 'Continue →'
                                        : '🔮 Run Analysis',
                                    style: Theme.of(context)
                                        .textTheme
                                        .labelLarge
                                        ?.copyWith(
                                          color: Colors.white,
                                          fontSize: 15,
                                        ),
                                  ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ===================== STEP 1: Basic Info =====================
class _Step1BasicInfo extends StatelessWidget {
  final TextEditingController titleController;
  final String category;
  final TimeHorizon timeHorizon;
  final EmotionalState emotionalState;
  final RiskLevel riskLevel;
  final Function(String) onCategoryChanged;
  final Function(TimeHorizon) onTimeHorizonChanged;
  final Function(EmotionalState) onEmotionalStateChanged;
  final Function(RiskLevel) onRiskLevelChanged;

  const _Step1BasicInfo({
    required this.titleController,
    required this.category,
    required this.timeHorizon,
    required this.emotionalState,
    required this.riskLevel,
    required this.onCategoryChanged,
    required this.onTimeHorizonChanged,
    required this.onEmotionalStateChanged,
    required this.onRiskLevelChanged,
  });

  @override
  Widget build(BuildContext context) {
    const categories = [
      {'value': 'career', 'label': '💼 Career'},
      {'value': 'relationships', 'label': '❤️ Relationships'},
      {'value': 'finance', 'label': '💰 Finance'},
      {'value': 'education', 'label': '📚 Education'},
      {'value': 'health', 'label': '🏥 Health'},
      {'value': 'lifestyle', 'label': '🌿 Lifestyle'},
      {'value': 'other', 'label': '🎯 Other'},
    ];

    const emotions = [
      {'value': EmotionalState.calm, 'label': '😌 Calm'},
      {'value': EmotionalState.anxious, 'label': '😰 Anxious'},
      {'value': EmotionalState.excited, 'label': '😃 Excited'},
      {'value': EmotionalState.stressed, 'label': '😤 Stressed'},
      {'value': EmotionalState.confident, 'label': '💪 Confident'},
      {'value': EmotionalState.uncertain, 'label': '🤔 Uncertain'},
      {'value': EmotionalState.hopeful, 'label': '🌟 Hopeful'},
      {'value': EmotionalState.fearful, 'label': '😨 Fearful'},
    ];

    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('📝 Decision Details',
              style: Theme.of(context).textTheme.headlineMedium),
          const SizedBox(height: 20),

          // Title
          TextField(
            controller: titleController,
            style: Theme.of(context).textTheme.bodyLarge,
            maxLines: 2,
            decoration: const InputDecoration(
              labelText: 'What decision are you facing?',
              hintText: 'e.g., Should I accept the job offer in NYC?',
            ),
          ),

          const SizedBox(height: 20),

          // Category
          Text('Category', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontSize: 15)),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: categories.map((c) {
              final isSelected = category == c['value'];
              return GestureDetector(
                onTap: () => onCategoryChanged(c['value'] as String),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  padding: const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 8),
                  decoration: BoxDecoration(
                    color: isSelected
                        ? AppTheme.primaryPurple.withOpacity(0.2)
                        : AppTheme.bgCard,
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(
                      color: isSelected
                          ? AppTheme.primaryPurple
                          : Colors.white.withOpacity(0.08),
                    ),
                  ),
                  child: Text(
                    c['label'] as String,
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: isSelected
                              ? AppTheme.textPrimary
                              : AppTheme.textSecondary,
                          fontWeight: isSelected
                              ? FontWeight.w600
                              : FontWeight.w400,
                        ),
                  ),
                ),
              );
            }).toList(),
          ),

          const SizedBox(height: 20),

          // Time Horizon
          Text('Time Horizon',
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontSize: 15)),
          const SizedBox(height: 10),
          _SegmentedPicker<TimeHorizon>(
            options: [
              _SegOption(
                  value: TimeHorizon.shortTerm, label: '< 6 Months'),
              _SegOption(
                  value: TimeHorizon.midTerm, label: '6M - 2Y'),
              _SegOption(
                  value: TimeHorizon.longTerm, label: '> 2 Years'),
            ],
            selected: timeHorizon,
            onChanged: onTimeHorizonChanged,
          ),

          const SizedBox(height: 20),

          // Risk Level
          Text('Perceived Risk Level',
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontSize: 15)),
          const SizedBox(height: 10),
          _SegmentedPicker<RiskLevel>(
            options: [
              _SegOption(value: RiskLevel.low, label: '🟢 Low'),
              _SegOption(value: RiskLevel.moderate, label: '🟡 Moderate'),
              _SegOption(value: RiskLevel.high, label: '🔴 High'),
              _SegOption(value: RiskLevel.extreme, label: '💀 Extreme'),
            ],
            selected: riskLevel,
            onChanged: onRiskLevelChanged,
          ),

          const SizedBox(height: 20),

          // Emotional State
          Text('Your Emotional State Right Now',
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontSize: 15)),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: emotions.map((e) {
              final isSelected = emotionalState == e['value'];
              return GestureDetector(
                onTap: () =>
                    onEmotionalStateChanged(e['value'] as EmotionalState),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  padding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    color: isSelected
                        ? AppTheme.accentCyan.withOpacity(0.2)
                        : AppTheme.bgCard,
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(
                      color: isSelected
                          ? AppTheme.accentCyan
                          : Colors.white.withOpacity(0.08),
                    ),
                  ),
                  child: Text(
                    e['label'] as String,
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: isSelected
                              ? AppTheme.textPrimary
                              : AppTheme.textSecondary,
                        ),
                  ),
                ),
              );
            }).toList(),
          ),

          const SizedBox(height: 20),
        ],
      ),
    );
  }
}

class _SegOption<T> {
  final T value;
  final String label;
  const _SegOption({required this.value, required this.label});
}

class _SegmentedPicker<T> extends StatelessWidget {
  final List<_SegOption<T>> options;
  final T selected;
  final Function(T) onChanged;

  const _SegmentedPicker({
    required this.options,
    required this.selected,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white.withOpacity(0.06)),
      ),
      child: Row(
        children: options.map((o) {
          final isSelected = selected == o.value;
          return Expanded(
            child: GestureDetector(
              onTap: () => onChanged(o.value),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: const EdgeInsets.symmetric(vertical: 10),
                decoration: BoxDecoration(
                  color: isSelected
                      ? AppTheme.primaryPurple
                      : Colors.transparent,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Center(
                  child: Text(
                    o.label,
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: isSelected
                              ? Colors.white
                              : AppTheme.textMuted,
                          fontWeight: isSelected
                              ? FontWeight.w600
                              : FontWeight.w400,
                          fontSize: 11,
                        ),
                  ),
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}

// ===================== STEP 2: Options =====================
class _Step2Options extends StatelessWidget {
  final List<_OptionDraft> options;
  final VoidCallback onAddOption;
  final Function(int) onRemoveOption;
  final Function(int, _OptionDraft) onOptionChanged;

  const _Step2Options({
    required this.options,
    required this.onAddOption,
    required this.onRemoveOption,
    required this.onOptionChanged,
  });

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('⚖️ Your Options',
              style: Theme.of(context).textTheme.headlineMedium),
          const SizedBox(height: 8),
          Text(
            'Add at least 2 options to compare (max 5)',
            style: Theme.of(context).textTheme.bodyMedium,
          ),
          const SizedBox(height: 20),
          ...options.asMap().entries.map((entry) {
            return _OptionCard(
              index: entry.key,
              draft: entry.value,
              canRemove: options.length > 2,
              onChanged: (draft) => onOptionChanged(entry.key, draft),
              onRemove: () => onRemoveOption(entry.key),
            );
          }),
          if (options.length < 5) ...[
            const SizedBox(height: 12),
            GestureDetector(
              onTap: onAddOption,
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppTheme.bgCard,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                    color: AppTheme.primaryPurple.withOpacity(0.3),
                    style: BorderStyle.solid,
                    width: 1.5,
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.add, color: AppTheme.primaryPurple),
                    const SizedBox(width: 8),
                    Text(
                      'Add Another Option',
                      style: Theme.of(context)
                          .textTheme
                          .bodyMedium
                          ?.copyWith(color: AppTheme.primaryPurple),
                    ),
                  ],
                ),
              ),
            ),
          ],
          const SizedBox(height: 20),
        ],
      ),
    );
  }
}

class _OptionCard extends StatefulWidget {
  final int index;
  final _OptionDraft draft;
  final bool canRemove;
  final Function(_OptionDraft) onChanged;
  final VoidCallback onRemove;

  const _OptionCard({
    required this.index,
    required this.draft,
    required this.canRemove,
    required this.onChanged,
    required this.onRemove,
  });

  @override
  State<_OptionCard> createState() => _OptionCardState();
}

class _OptionCardState extends State<_OptionCard> {
  bool _expanded = false;
  late final TextEditingController _titleCtrl;
  late final TextEditingController _descCtrl;
  final _proCtrl = TextEditingController();
  final _conCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _titleCtrl = TextEditingController(text: widget.draft.title);
    _descCtrl = TextEditingController(text: widget.draft.description);
  }

  @override
  void dispose() {
    _titleCtrl.dispose();
    _descCtrl.dispose();
    _proCtrl.dispose();
    _conCtrl.dispose();
    super.dispose();
  }

  void _update() {
    widget.onChanged(widget.draft.copyWith(
      title: _titleCtrl.text,
      description: _descCtrl.text,
    ));
  }

  void _addPro() {
    if (_proCtrl.text.trim().isEmpty) return;
    final updated = List<String>.from(widget.draft.pros)
      ..add(_proCtrl.text.trim());
    widget.onChanged(widget.draft.copyWith(pros: updated));
    _proCtrl.clear();
  }

  void _addCon() {
    if (_conCtrl.text.trim().isEmpty) return;
    final updated = List<String>.from(widget.draft.cons)
      ..add(_conCtrl.text.trim());
    widget.onChanged(widget.draft.copyWith(cons: updated));
    _conCtrl.clear();
  }

  final _optionColors = [
    AppTheme.accentCyan,
    AppTheme.accentAmber,
    AppTheme.accentEmerald,
    AppTheme.dangerRed,
    AppTheme.primaryPurple,
  ];

  @override
  Widget build(BuildContext context) {
    final color = _optionColors[widget.index % _optionColors.length];

    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Column(
        children: [
          // Header
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Container(
                  width: 32,
                  height: 32,
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Center(
                    child: Text(
                      'Option ${widget.index + 1}',
                      style: TextStyle(
                          color: color,
                          fontSize: 9,
                          fontWeight: FontWeight.w700),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: TextField(
                    controller: _titleCtrl,
                    onChanged: (_) => _update(),
                    style: Theme.of(context)
                        .textTheme
                        .bodyLarge
                        ?.copyWith(fontWeight: FontWeight.w600),
                    decoration: InputDecoration(
                      hintText: 'Option title...',
                      border: InputBorder.none,
                      enabledBorder: InputBorder.none,
                      focusedBorder: InputBorder.none,
                      contentPadding: EdgeInsets.zero,
                      filled: false,
                      fillColor: Colors.transparent,
                    ),
                  ),
                ),
                GestureDetector(
                  onTap: () => setState(() => _expanded = !_expanded),
                  child: Icon(
                    _expanded
                        ? Icons.expand_less
                        : Icons.expand_more,
                    color: AppTheme.textMuted,
                  ),
                ),
                if (widget.canRemove) ...[
                  const SizedBox(width: 8),
                  GestureDetector(
                    onTap: widget.onRemove,
                    child: const Icon(Icons.close,
                        color: AppTheme.textMuted, size: 18),
                  ),
                ],
              ],
            ),
          ),

          // Expanded details
          if (_expanded)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Divider(),
                  const SizedBox(height: 12),

                  // Description
                  TextField(
                    controller: _descCtrl,
                    onChanged: (_) => _update(),
                    maxLines: 2,
                    style: Theme.of(context).textTheme.bodyMedium,
                    decoration: const InputDecoration(
                      labelText: 'Description (optional)',
                      hintText: 'What does this option involve?',
                    ),
                  ),

                  const SizedBox(height: 16),

                  // Risk slider
                  Text('Perceived Risk: ${widget.draft.perceivedRisk.round()}%',
                      style: Theme.of(context).textTheme.bodySmall),
                  Slider(
                    value: widget.draft.perceivedRisk,
                    min: 0,
                    max: 100,
                    onChanged: (v) => widget.onChanged(
                        widget.draft.copyWith(perceivedRisk: v)),
                  ),

                  // Pros
                  Row(
                    children: [
                      const Icon(Icons.add_circle_outline,
                          color: AppTheme.accentEmerald, size: 18),
                      const SizedBox(width: 6),
                      Text('Pros',
                          style: Theme.of(context)
                              .textTheme
                              .bodySmall
                              ?.copyWith(color: AppTheme.accentEmerald)),
                    ],
                  ),
                  const SizedBox(height: 6),
                  ...widget.draft.pros.map((p) => Padding(
                        padding: const EdgeInsets.only(bottom: 4),
                        child: Row(
                          children: [
                            const Icon(Icons.check,
                                color: AppTheme.accentEmerald, size: 14),
                            const SizedBox(width: 6),
                            Expanded(
                              child: Text(p,
                                  style: Theme.of(context).textTheme.bodySmall),
                            ),
                          ],
                        ),
                      )),
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _proCtrl,
                          style: Theme.of(context).textTheme.bodySmall,
                          decoration: const InputDecoration(
                            hintText: 'Add a pro...',
                            contentPadding: EdgeInsets.symmetric(
                                horizontal: 10, vertical: 8),
                          ),
                          onSubmitted: (_) => _addPro(),
                        ),
                      ),
                      const SizedBox(width: 8),
                      GestureDetector(
                        onTap: _addPro,
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: AppTheme.accentEmerald.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: const Icon(Icons.add,
                              color: AppTheme.accentEmerald, size: 16),
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 12),

                  // Cons
                  Row(
                    children: [
                      const Icon(Icons.remove_circle_outline,
                          color: AppTheme.dangerRed, size: 18),
                      const SizedBox(width: 6),
                      Text('Cons',
                          style: Theme.of(context)
                              .textTheme
                              .bodySmall
                              ?.copyWith(color: AppTheme.dangerRed)),
                    ],
                  ),
                  const SizedBox(height: 6),
                  ...widget.draft.cons.map((c) => Padding(
                        padding: const EdgeInsets.only(bottom: 4),
                        child: Row(
                          children: [
                            const Icon(Icons.close,
                                color: AppTheme.dangerRed, size: 14),
                            const SizedBox(width: 6),
                            Expanded(
                              child: Text(c,
                                  style: Theme.of(context).textTheme.bodySmall),
                            ),
                          ],
                        ),
                      )),
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _conCtrl,
                          style: Theme.of(context).textTheme.bodySmall,
                          decoration: const InputDecoration(
                            hintText: 'Add a con...',
                            contentPadding: EdgeInsets.symmetric(
                                horizontal: 10, vertical: 8),
                          ),
                          onSubmitted: (_) => _addCon(),
                        ),
                      ),
                      const SizedBox(width: 8),
                      GestureDetector(
                        onTap: _addCon,
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: AppTheme.dangerRed.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: const Icon(Icons.add,
                              color: AppTheme.dangerRed, size: 16),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

// ===================== STEP 3: Review =====================
class _Step3Review extends StatelessWidget {
  final String title;
  final String category;
  final List<_OptionDraft> options;
  final TimeHorizon timeHorizon;
  final EmotionalState emotionalState;
  final RiskLevel riskLevel;
  final TextEditingController notesController;

  const _Step3Review({
    required this.title,
    required this.category,
    required this.options,
    required this.timeHorizon,
    required this.emotionalState,
    required this.riskLevel,
    required this.notesController,
  });

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('✅ Review & Analyze',
              style: Theme.of(context).textTheme.headlineMedium),
          const SizedBox(height: 20),

          // Decision summary
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppTheme.bgCard,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: Colors.white.withOpacity(0.06)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title.isEmpty ? 'Untitled Decision' : title,
                  style: Theme.of(context)
                      .textTheme
                      .headlineSmall
                      ?.copyWith(height: 1.3),
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 6,
                  children: [
                    _ReviewChip(label: '📂 $category'),
                    _ReviewChip(label: '⏱ ${_horizonLabel(timeHorizon)}'),
                    _ReviewChip(label: '😌 ${emotionalState.name}'),
                    _ReviewChip(label: '⚠️ ${riskLevel.name} risk'),
                  ],
                ),
              ],
            ),
          ),

          const SizedBox(height: 16),

          Text('${options.length} Options to Analyze',
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontSize: 15)),
          const SizedBox(height: 10),

          ...options.asMap().entries.map((e) {
            final o = e.value;
            return Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppTheme.bgCard,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.white.withOpacity(0.06)),
              ),
              child: Row(
                children: [
                  Text('${e.key + 1}.',
                      style: Theme.of(context)
                          .textTheme
                          .bodyLarge
                          ?.copyWith(color: AppTheme.primaryPurple, fontWeight: FontWeight.w700)),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          o.title.isEmpty ? 'Unnamed option' : o.title,
                          style: Theme.of(context).textTheme.bodyLarge,
                        ),
                        if (o.pros.isNotEmpty || o.cons.isNotEmpty)
                          Text(
                            '${o.pros.length} pros · ${o.cons.length} cons',
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          }),

          const SizedBox(height: 16),

          // Notes
          TextField(
            controller: notesController,
            maxLines: 3,
            style: Theme.of(context).textTheme.bodyMedium,
            decoration: const InputDecoration(
              labelText: 'Additional context (optional)',
              hintText: 'Any background info that might help the AI...',
            ),
          ),

          const SizedBox(height: 20),

          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  AppTheme.primaryPurple.withOpacity(0.15),
                  AppTheme.primaryIndigo.withOpacity(0.1),
                ],
              ),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                  color: AppTheme.primaryPurple.withOpacity(0.3)),
            ),
            child: Row(
              children: [
                const Text('🔮', style: TextStyle(fontSize: 28)),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'AI Analysis Ready',
                        style: Theme.of(context)
                            .textTheme
                            .bodyLarge
                            ?.copyWith(fontWeight: FontWeight.w700),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'The engine will run Monte Carlo simulations across all options using your personality profile.',
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(height: 1.5),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 20),
        ],
      ),
    );
  }

  String _horizonLabel(TimeHorizon h) {
    switch (h) {
      case TimeHorizon.shortTerm:
        return 'Short Term';
      case TimeHorizon.midTerm:
        return 'Mid Term';
      case TimeHorizon.longTerm:
        return 'Long Term';
    }
  }
}

class _ReviewChip extends StatelessWidget {
  final String label;
  const _ReviewChip({required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: AppTheme.bgSurface,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(label,
          style: Theme.of(context)
              .textTheme
              .bodySmall
              ?.copyWith(color: AppTheme.textSecondary)),
    );
  }
}

// Draft model (in-memory while composing)
class _OptionDraft {
  final String id;
  final String title;
  final String description;
  final List<String> pros;
  final List<String> cons;
  final double perceivedRisk;
  final double expectedOutcomeScore;

  const _OptionDraft({
    required this.id,
    this.title = '',
    this.description = '',
    this.pros = const [],
    this.cons = const [],
    this.perceivedRisk = 50,
    this.expectedOutcomeScore = 50,
  });

  _OptionDraft copyWith({
    String? id,
    String? title,
    String? description,
    List<String>? pros,
    List<String>? cons,
    double? perceivedRisk,
    double? expectedOutcomeScore,
  }) {
    return _OptionDraft(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      pros: pros ?? this.pros,
      cons: cons ?? this.cons,
      perceivedRisk: perceivedRisk ?? this.perceivedRisk,
      expectedOutcomeScore: expectedOutcomeScore ?? this.expectedOutcomeScore,
    );
  }
}
