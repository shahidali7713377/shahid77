import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:percent_indicator/percent_indicator.dart';
import '../../core/theme/app_theme.dart';
import '../../models/decision_model.dart';
import '../../providers/decision_provider.dart';
import '../../providers/user_provider.dart';

class DecisionAnalysisScreen extends StatefulWidget {
  final String decisionId;
  const DecisionAnalysisScreen({super.key, required this.decisionId});

  @override
  State<DecisionAnalysisScreen> createState() => _DecisionAnalysisScreenState();
}

class _DecisionAnalysisScreenState extends State<DecisionAnalysisScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  int _selectedOptionIndex = 0;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    WidgetsBinding.instance.addPostFrameCallback((_) => _checkAndAnalyze());
  }

  void _checkAndAnalyze() {
    final dp = context.read<DecisionProvider>();
    final up = context.read<UserProvider>();
    DecisionModel? decision;
    try {
      decision = dp.decisions.firstWhere((d) => d.id == widget.decisionId);
    } catch (_) {
      decision = dp.currentDecision;
    }
    if (decision != null && !decision.isAnalyzed && up.userProfile != null) {
      dp.analyzeDecision(widget.decisionId, up.userProfile!);
    }
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<DecisionProvider>(
      builder: (context, dp, _) {
        DecisionModel? decision;
        try {
          decision = dp.decisions.firstWhere((d) => d.id == widget.decisionId);
        } catch (_) {
          decision = dp.currentDecision;
        }
        if (decision == null) {
          return Scaffold(
            appBar: AppBar(title: const Text('Analysis')),
            body: const Center(child: Text('Decision not found')),
          );
        }
        return Scaffold(
          backgroundColor: AppTheme.bgPrimary,
          body: dp.isAnalyzing
              ? _AnalyzingView(decision: decision)
              : _AnalysisView(
                  decision: decision,
                  tabController: _tabController,
                  selectedOptionIndex: _selectedOptionIndex,
                  onOptionSelected: (i) => setState(() => _selectedOptionIndex = i),
                  onChooseOption: (optionId) async {
                    await dp.chooseOption(decision!.id, optionId);
                    if (mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                        content: Text('Decision recorded ✓'),
                        backgroundColor: AppTheme.accentEmerald,
                      ));
                    }
                  },
                ),
        );
      },
    );
  }
}

// ===================== ANALYZING VIEW =====================
class _AnalyzingView extends StatelessWidget {
  final DecisionModel decision;
  const _AnalyzingView({required this.decision});

  @override
  Widget build(BuildContext context) {
    final steps = [
      '🧠 Analyzing personality profile...',
      '🎲 Running Monte Carlo simulations...',
      '📊 Computing regret probabilities...',
      '🔮 Generating Future You insights...',
    ];
    return Scaffold(
      backgroundColor: AppTheme.bgPrimary,
      appBar: AppBar(
        title: Text(decision.title, overflow: TextOverflow.ellipsis),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(40),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 100, height: 100,
                decoration: BoxDecoration(
                  gradient: AppTheme.primaryGradient,
                  borderRadius: BorderRadius.circular(28),
                  boxShadow: [BoxShadow(color: AppTheme.primaryPurple.withOpacity(0.5), blurRadius: 40, spreadRadius: 8)],
                ),
                child: const Icon(Icons.psychology_rounded, color: Colors.white, size: 52),
              )
                  .animate(onPlay: (c) => c.repeat(reverse: true))
                  .scale(begin: const Offset(0.95, 0.95), end: const Offset(1.05, 1.05), duration: 1200.ms),
              const SizedBox(height: 32),
              Text('Running AI Analysis...', style: Theme.of(context).textTheme.headlineLarge),
              const SizedBox(height: 10),
              Text(
                'Monte Carlo simulations · Personality mapping · Risk modeling',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: AppTheme.textMuted),
              ),
              const SizedBox(height: 40),
              ...steps.asMap().entries.map((e) => Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: Row(children: [
                      const SizedBox(
                        width: 16, height: 16,
                        child: CircularProgressIndicator(strokeWidth: 2, color: AppTheme.primaryPurple),
                      ),
                      const SizedBox(width: 12),
                      Text(e.value, style: Theme.of(context).textTheme.bodySmall),
                    ]).animate(delay: (e.key * 500).ms).fadeIn().slideX(begin: -0.1),
                  )),
            ],
          ),
        ),
      ),
    );
  }
}

// ===================== ANALYSIS VIEW =====================
class _AnalysisView extends StatelessWidget {
  final DecisionModel decision;
  final TabController tabController;
  final int selectedOptionIndex;
  final Function(int) onOptionSelected;
  final Function(String) onChooseOption;

  const _AnalysisView({
    required this.decision,
    required this.tabController,
    required this.selectedOptionIndex,
    required this.onOptionSelected,
    required this.onChooseOption,
  });

  @override
  Widget build(BuildContext context) {
    return NestedScrollView(
      headerSliverBuilder: (context, _) => [
        SliverAppBar(
          floating: true,
          pinned: true,
          backgroundColor: AppTheme.bgSecondary,
          title: Text(decision.title, style: Theme.of(context).textTheme.headlineSmall, overflow: TextOverflow.ellipsis),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios_rounded),
            onPressed: () => Navigator.pop(context),
          ),
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(48),
            child: TabBar(
              controller: tabController,
              indicatorColor: AppTheme.primaryPurple,
              labelColor: AppTheme.textPrimary,
              unselectedLabelColor: AppTheme.textMuted,
              tabs: const [Tab(text: 'Overview'), Tab(text: 'Compare'), Tab(text: 'Insights')],
            ),
          ),
        ),
      ],
      body: TabBarView(
        controller: tabController,
        children: [
          _OverviewTab(decision: decision, selectedOptionIndex: selectedOptionIndex, onOptionSelected: onOptionSelected, onChooseOption: onChooseOption),
          _CompareTab(decision: decision),
          _InsightsTab(decision: decision),
        ],
      ),
    );
  }
}

// ===================== OVERVIEW TAB =====================
class _OverviewTab extends StatelessWidget {
  final DecisionModel decision;
  final int selectedOptionIndex;
  final Function(int) onOptionSelected;
  final Function(String) onChooseOption;
  const _OverviewTab({required this.decision, required this.selectedOptionIndex, required this.onOptionSelected, required this.onChooseOption});

  @override
  Widget build(BuildContext context) {
    final lowestRegret = decision.lowestRegretOption;
    final safeIndex = selectedOptionIndex.clamp(0, decision.options.length - 1);
    final selectedOption = decision.options.isNotEmpty ? decision.options[safeIndex] : null;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // AI Recommendation banner
          if (lowestRegret != null)
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: AppTheme.emeraldGradient,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [BoxShadow(color: AppTheme.accentEmerald.withOpacity(0.35), blurRadius: 20, offset: const Offset(0, 6))],
              ),
              child: Row(children: [
                const Text('🏆', style: TextStyle(fontSize: 28)),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('AI Recommends', style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Colors.white.withOpacity(0.8))),
                    Text(lowestRegret.title, style: Theme.of(context).textTheme.headlineSmall?.copyWith(color: Colors.white, fontWeight: FontWeight.w700)),
                    Text('Lowest regret probability: ${lowestRegret.prediction?.overallRegretScore.round()}%',
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Colors.white.withOpacity(0.8))),
                  ]),
                ),
              ]),
            ).animate().fadeIn(delay: 200.ms).slideY(begin: -0.1),

          const SizedBox(height: 20),

          // Option selector tabs
          Text('Select Option to Explore', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontSize: 15)),
          const SizedBox(height: 12),
          SizedBox(
            height: 44,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: decision.options.length,
              itemBuilder: (context, i) {
                final isSelected = i == selectedOptionIndex;
                final opt = decision.options[i];
                final score = opt.prediction?.overallRegretScore ?? 0;
                final color = regretScoreColor(score);
                return GestureDetector(
                  onTap: () => onOptionSelected(i),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    margin: const EdgeInsets.only(right: 10),
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(
                      color: isSelected ? color.withOpacity(0.18) : AppTheme.bgCard,
                      borderRadius: BorderRadius.circular(24),
                      border: Border.all(color: isSelected ? color : Colors.white.withOpacity(0.08)),
                    ),
                    child: Row(children: [
                      Text(opt.title,
                          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              color: isSelected ? color : AppTheme.textSecondary,
                              fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400)),
                      if (opt.prediction != null) ...[
                        const SizedBox(width: 6),
                        Text('${score.round()}%',
                            style: Theme.of(context).textTheme.bodySmall?.copyWith(color: color, fontWeight: FontWeight.w700, fontSize: 11)),
                      ],
                    ]),
                  ),
                );
              },
            ),
          ),

          const SizedBox(height: 20),
          if (selectedOption != null)
            _OptionDetailCard(
              option: selectedOption,
              isChosen: decision.chosenOptionId == selectedOption.id,
              onChoose: () => onChooseOption(selectedOption.id),
            ).animate().fadeIn(delay: 100.ms),
          const SizedBox(height: 100),
        ],
      ),
    );
  }
}

class _OptionDetailCard extends StatelessWidget {
  final DecisionOption option;
  final bool isChosen;
  final VoidCallback onChoose;
  const _OptionDetailCard({required this.option, required this.isChosen, required this.onChoose});

  @override
  Widget build(BuildContext context) {
    final pred = option.prediction;
    if (pred == null) return const Center(child: CircularProgressIndicator());
    final score = pred.overallRegretScore;
    final color = regretScoreColor(score);

    return Column(
      children: [
        // Score Ring
        Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: AppTheme.bgCard,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: color.withOpacity(0.2)),
          ),
          child: Column(children: [
            Text(option.title, style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w700)),
            const SizedBox(height: 24),
            CircularPercentIndicator(
              radius: 88,
              lineWidth: 12,
              percent: (score / 100).clamp(0.0, 1.0),
              center: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Text('${score.round()}%', style: Theme.of(context).textTheme.displayMedium?.copyWith(color: color, fontWeight: FontWeight.w800)),
                Text('Regret Risk', style: Theme.of(context).textTheme.bodySmall),
              ]),
              progressColor: color,
              backgroundColor: color.withOpacity(0.1),
              circularStrokeCap: CircularStrokeCap.round,
              animation: true,
              animationDuration: 1500,
            ),
            const SizedBox(height: 20),
            _TimeBar(label: '6 months', value: pred.regretProbability6Months, color: color),
            const SizedBox(height: 8),
            _TimeBar(label: '1 year', value: pred.regretProbability1Year, color: color),
            const SizedBox(height: 8),
            _TimeBar(label: '5 years', value: pred.regretProbability5Years, color: color),
          ]),
        ),

        const SizedBox(height: 14),

        Row(children: [
          Expanded(child: _MetricCard(label: 'Confidence', value: '${pred.confidenceLevel.round()}%', icon: Icons.verified_outlined, color: AppTheme.accentCyan)),
          const SizedBox(width: 12),
          Expanded(child: _MetricCard(label: 'Satisfaction', value: '${pred.longTermSatisfactionScore.round()}%', icon: Icons.sentiment_satisfied_alt, color: AppTheme.accentEmerald)),
        ]),

        const SizedBox(height: 14),

        _ScenarioCard(icon: '✅', title: 'Best Case', text: pred.bestCaseScenario, color: AppTheme.accentEmerald),
        const SizedBox(height: 10),
        _ScenarioCard(icon: '📊', title: 'Most Likely', text: pred.mostLikelyScenario, color: AppTheme.accentCyan),
        const SizedBox(height: 10),
        _ScenarioCard(icon: '⚠️', title: 'Worst Case', text: pred.worstCaseScenario, color: AppTheme.dangerRed),

        const SizedBox(height: 14),

        // Future You Advice
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [AppTheme.primaryPurple.withOpacity(0.18), AppTheme.primaryIndigo.withOpacity(0.1)]),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppTheme.primaryPurple.withOpacity(0.3)),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              const Text('🔮', style: TextStyle(fontSize: 20)),
              const SizedBox(width: 8),
              Text('Future You Says', style: Theme.of(context).textTheme.headlineSmall?.copyWith(color: AppTheme.textAccent)),
            ]),
            const SizedBox(height: 10),
            Text(pred.aiAdvice, style: Theme.of(context).textTheme.bodyMedium?.copyWith(height: 1.6)),
          ]),
        ),

        const SizedBox(height: 14),

        // Risk Factors
        if (pred.keyRiskFactors.isNotEmpty)
          _BulletSection(
            title: '⚠️ Key Risk Factors',
            items: pred.keyRiskFactors,
            color: AppTheme.dangerRed,
            prefix: '•',
          ),

        const SizedBox(height: 12),

        // Mitigations
        if (pred.mitigationStrategies.isNotEmpty)
          _BulletSection(
            title: '💡 Mitigation Strategies',
            items: pred.mitigationStrategies,
            color: AppTheme.accentEmerald,
            prefix: '✓',
          ),

        const SizedBox(height: 16),

        // Choose CTA
        if (!isChosen)
          SizedBox(
            width: double.infinity,
            height: 52,
            child: OutlinedButton(
              onPressed: onChoose,
              style: OutlinedButton.styleFrom(
                side: BorderSide(color: color.withOpacity(0.5)),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              ),
              child: Text("I'll Go With This Option", style: TextStyle(color: color, fontWeight: FontWeight.w600)),
            ),
          )
        else
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppTheme.accentEmerald.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppTheme.accentEmerald.withOpacity(0.3)),
            ),
            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              const Icon(Icons.check_circle, color: AppTheme.accentEmerald, size: 18),
              const SizedBox(width: 8),
              Text('You chose this option',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: AppTheme.accentEmerald, fontWeight: FontWeight.w600)),
            ]),
          ),
      ],
    );
  }
}

class _TimeBar extends StatelessWidget {
  final String label;
  final double value;
  final Color color;
  const _TimeBar({required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      SizedBox(width: 72, child: Text(label, style: Theme.of(context).textTheme.bodySmall)),
      Expanded(
        child: ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: LinearProgressIndicator(
            value: (value / 100).clamp(0.0, 1.0),
            backgroundColor: color.withOpacity(0.1),
            valueColor: AlwaysStoppedAnimation<Color>(color),
            minHeight: 8,
          ),
        ),
      ),
      const SizedBox(width: 10),
      Text('${value.round()}%',
          style: Theme.of(context).textTheme.bodySmall?.copyWith(color: color, fontWeight: FontWeight.w700)),
    ]);
  }
}

class _MetricCard extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color color;
  const _MetricCard({required this.label, required this.value, required this.icon, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Row(children: [
        Icon(icon, color: color, size: 20),
        const SizedBox(width: 10),
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: Theme.of(context).textTheme.bodySmall),
          Text(value, style: Theme.of(context).textTheme.headlineSmall?.copyWith(color: color, fontWeight: FontWeight.w700)),
        ]),
      ]),
    );
  }
}

class _ScenarioCard extends StatelessWidget {
  final String icon;
  final String title;
  final String text;
  final Color color;
  const _ScenarioCard({required this.icon, required this.title, required this.text, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: color.withOpacity(0.06),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withOpacity(0.15)),
      ),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(icon, style: const TextStyle(fontSize: 18)),
        const SizedBox(width: 10),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: Theme.of(context).textTheme.bodySmall?.copyWith(color: color, fontWeight: FontWeight.w700)),
            const SizedBox(height: 4),
            Text(text, style: Theme.of(context).textTheme.bodySmall?.copyWith(height: 1.5)),
          ]),
        ),
      ]),
    );
  }
}

class _BulletSection extends StatelessWidget {
  final String title;
  final List<String> items;
  final Color color;
  final String prefix;
  const _BulletSection({required this.title, required this.items, required this.color, required this.prefix});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: color.withOpacity(0.06),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withOpacity(0.15)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: Theme.of(context).textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.w600, color: color)),
        const SizedBox(height: 10),
        ...items.map((r) => Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(prefix, style: TextStyle(color: color, fontWeight: FontWeight.w700)),
                const SizedBox(width: 8),
                Expanded(child: Text(r, style: Theme.of(context).textTheme.bodySmall?.copyWith(height: 1.5))),
              ]),
            )),
      ]),
    );
  }
}

// ===================== COMPARE TAB =====================
class _CompareTab extends StatelessWidget {
  final DecisionModel decision;
  const _CompareTab({required this.decision});

  @override
  Widget build(BuildContext context) {
    if (!decision.isAnalyzed || decision.options.isEmpty) {
      return const Center(child: Text('No analysis available'));
    }
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Side-by-Side Comparison', style: Theme.of(context).textTheme.headlineMedium),
        const SizedBox(height: 20),

        // Bar chart
        SizedBox(
          height: 220,
          child: BarChart(BarChartData(
            barGroups: decision.options.asMap().entries.map((e) {
              final score = e.value.prediction?.overallRegretScore ?? 0;
              return BarChartGroupData(x: e.key, barRods: [
                BarChartRodData(
                  toY: score,
                  gradient: regretScoreGradient(score),
                  width: 36,
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(8)),
                ),
              ]);
            }).toList(),
            titlesData: FlTitlesData(
              leftTitles: AxisTitles(sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 38,
                getTitlesWidget: (v, _) => Text('${v.round()}%', style: Theme.of(context).textTheme.bodySmall?.copyWith(fontSize: 10)),
              )),
              bottomTitles: AxisTitles(sideTitles: SideTitles(
                showTitles: true,
                getTitlesWidget: (v, _) {
                  final i = v.toInt();
                  if (i < 0 || i >= decision.options.length) return const SizedBox();
                  final t = decision.options[i].title;
                  return Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Text(t.length > 9 ? '${t.substring(0, 8)}…' : t,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(fontSize: 10)),
                  );
                },
              )),
              topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
              rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            ),
            gridData: FlGridData(getDrawingHorizontalLine: (v) => FlLine(color: Colors.white.withOpacity(0.06), strokeWidth: 1), drawVerticalLine: false),
            borderData: FlBorderData(show: false),
            maxY: 100,
          )),
        ),

        const SizedBox(height: 24),
        Text('Metric Breakdown', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontSize: 16)),
        const SizedBox(height: 12),

        // Comparison cards
        ...decision.options.map((opt) {
          final pred = opt.prediction;
          if (pred == null) return const SizedBox();
          final score = pred.overallRegretScore;
          final color = regretScoreColor(score);
          return Container(
            margin: const EdgeInsets.only(bottom: 14),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppTheme.bgCard,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: color.withOpacity(0.2)),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Expanded(child: Text(opt.title, style: Theme.of(context).textTheme.headlineSmall)),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(color: color.withOpacity(0.15), borderRadius: BorderRadius.circular(20)),
                  child: Text('${score.round()}% regret', style: Theme.of(context).textTheme.bodySmall?.copyWith(color: color, fontWeight: FontWeight.w700)),
                ),
              ]),
              const SizedBox(height: 14),
              _CompareMetricRow(label: 'Satisfaction', value: pred.longTermSatisfactionScore, color: AppTheme.accentEmerald, maxIs100: true),
              const SizedBox(height: 8),
              _CompareMetricRow(label: '6-Month Regret', value: pred.regretProbability6Months, color: color, maxIs100: true),
              const SizedBox(height: 8),
              _CompareMetricRow(label: '5-Year Regret', value: pred.regretProbability5Years, color: color, maxIs100: true),
              const SizedBox(height: 8),
              _CompareMetricRow(label: 'Confidence', value: pred.confidenceLevel, color: AppTheme.accentCyan, maxIs100: true),
            ]),
          );
        }),
        const SizedBox(height: 80),
      ]),
    );
  }
}

class _CompareMetricRow extends StatelessWidget {
  final String label;
  final double value;
  final Color color;
  final bool maxIs100;
  const _CompareMetricRow({required this.label, required this.value, required this.color, this.maxIs100 = true});

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      SizedBox(width: 110, child: Text(label, style: Theme.of(context).textTheme.bodySmall)),
      Expanded(
        child: ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: LinearProgressIndicator(
            value: (value / 100).clamp(0.0, 1.0),
            backgroundColor: color.withOpacity(0.1),
            valueColor: AlwaysStoppedAnimation<Color>(color),
            minHeight: 7,
          ),
        ),
      ),
      const SizedBox(width: 10),
      Text('${value.round()}%', style: Theme.of(context).textTheme.bodySmall?.copyWith(color: color, fontWeight: FontWeight.w700)),
    ]);
  }
}

// ===================== INSIGHTS TAB =====================
class _InsightsTab extends StatelessWidget {
  final DecisionModel decision;
  const _InsightsTab({required this.decision});

  @override
  Widget build(BuildContext context) {
    final biases = _getBiases(decision);
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Psychological Insights', style: Theme.of(context).textTheme.headlineMedium),
        const SizedBox(height: 20),

        // Context card
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppTheme.accentAmber.withOpacity(0.08),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppTheme.accentAmber.withOpacity(0.2)),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              const Text('🧠', style: TextStyle(fontSize: 20)),
              const SizedBox(width: 8),
              Text('Decision Context', style: Theme.of(context).textTheme.headlineSmall?.copyWith(color: AppTheme.accentAmber)),
            ]),
            const SizedBox(height: 12),
            _ContextRow(label: 'Emotional State', value: decision.emotionalStateAtInput.name.toUpperCase()),
            _ContextRow(label: 'Risk Level', value: decision.perceivedRiskLevel.name.toUpperCase()),
            _ContextRow(label: 'Time Horizon', value: decision.timeHorizonLabel),
            _ContextRow(label: 'Category', value: decision.category.toUpperCase()),
          ]),
        ),

        const SizedBox(height: 20),
        Text('Potential Decision Biases', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontSize: 16)),
        const SizedBox(height: 12),

        ...biases.map((bias) => Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppTheme.bgCard,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Colors.white.withOpacity(0.06)),
              ),
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(bias['icon']!, style: const TextStyle(fontSize: 22)),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(bias['name']!, style: Theme.of(context).textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.w600)),
                    const SizedBox(height: 4),
                    Text(bias['description']!, style: Theme.of(context).textTheme.bodySmall?.copyWith(height: 1.5)),
                  ]),
                ),
              ]),
            )),

        const SizedBox(height: 20),

        // Reflection prompts
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [AppTheme.primaryPurple.withOpacity(0.15), AppTheme.primaryIndigo.withOpacity(0.1)]),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppTheme.primaryPurple.withOpacity(0.3)),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('🤔 Before You Decide', style: Theme.of(context).textTheme.headlineSmall?.copyWith(color: AppTheme.textAccent)),
            const SizedBox(height: 12),
            ...[
              'What would you tell a close friend in this same situation?',
              'How will this decision look 5 years from now?',
              'Are you deciding from clarity or from fear?',
              'What information are you missing that could change your mind?',
            ].map((q) => Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('→', style: TextStyle(color: AppTheme.primaryPurple)),
                    const SizedBox(width: 8),
                    Expanded(child: Text(q, style: Theme.of(context).textTheme.bodySmall?.copyWith(height: 1.5))),
                  ]),
                )),
          ]),
        ),
        const SizedBox(height: 100),
      ]),
    );
  }

  List<Map<String, String>> _getBiases(DecisionModel d) {
    final biases = <Map<String, String>>[];
    if (d.emotionalStateAtInput == EmotionalState.excited || d.emotionalStateAtInput == EmotionalState.stressed) {
      biases.add({'icon': '🌊', 'name': 'Emotional Decision Bias', 'description': 'You were ${d.emotionalStateAtInput.name} when entering this. Emotions can cloud rational judgment—consider waiting until calmer.'});
    }
    if (d.perceivedRiskLevel == RiskLevel.extreme) {
      biases.add({'icon': '⚡', 'name': 'Risk Amplification Bias', 'description': 'Extreme risk situations trigger fight-or-flight responses, often leading to avoidance or impulsive action.'});
    }
    if (d.timeHorizon == TimeHorizon.shortTerm) {
      biases.add({'icon': '⏱', 'name': 'Present Bias', 'description': 'Short-term decisions overweight immediate rewards over long-term consequences. Ask: will this matter in 5 years?'});
    }
    biases.add({'icon': '🔒', 'name': 'Confirmation Bias Risk', 'description': 'We naturally seek information that confirms what we already believe. Actively seek perspectives that challenge your preferred option.'});
    biases.add({'icon': '🎭', 'name': 'Social Proof Influence', 'description': 'Are you choosing partly based on what others will think? Ensure this aligns with your own values, not external expectations.'});
    return biases;
  }
}

class _ContextRow extends StatelessWidget {
  final String label;
  final String value;
  const _ContextRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text(label, style: Theme.of(context).textTheme.bodySmall),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          decoration: BoxDecoration(color: AppTheme.bgSurface, borderRadius: BorderRadius.circular(8)),
          child: Text(value, style: Theme.of(context).textTheme.bodySmall?.copyWith(color: AppTheme.accentAmber, fontWeight: FontWeight.w700)),
        ),
      ]),
    );
  }
}
