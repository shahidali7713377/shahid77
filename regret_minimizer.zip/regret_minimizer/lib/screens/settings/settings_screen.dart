import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:fl_chart/fl_chart.dart';
import '../../core/theme/app_theme.dart';
import '../../core/storage/hive_storage.dart';
import '../../providers/user_provider.dart';
import '../../providers/decision_provider.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<UserProvider>(
      builder: (context, up, _) {
        final user = up.userProfile;
        return Scaffold(
          backgroundColor: AppTheme.bgPrimary,
          appBar: AppBar(
            title: const Text('Settings'),
            leading: IconButton(
              icon: const Icon(Icons.arrow_back_ios_rounded),
              onPressed: () => Navigator.pop(context),
            ),
          ),
          body: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

              // Profile card
              if (user != null)
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    gradient: AppTheme.primaryGradient,
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [BoxShadow(color: AppTheme.primaryPurple.withOpacity(0.4), blurRadius: 20, offset: const Offset(0, 6))],
                  ),
                  child: Row(children: [
                    Container(
                      width: 56, height: 56,
                      decoration: BoxDecoration(color: Colors.white.withOpacity(0.2), borderRadius: BorderRadius.circular(16)),
                      child: Center(
                        child: Text(user.name.isNotEmpty ? user.name[0].toUpperCase() : 'U',
                            style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w700, color: Colors.white)),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(user.name, style: Theme.of(context).textTheme.headlineSmall?.copyWith(color: Colors.white)),
                        Text('${user.totalDecisions} decisions analyzed', style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Colors.white.withOpacity(0.75))),
                        Text('Dominant trait: ${user.dominantTrait}', style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Colors.white.withOpacity(0.75))),
                      ]),
                    ),
                  ]),
                ),

              const SizedBox(height: 24),

              // Personality summary
              if (user != null) ...[
                Text('Personality Profile', style: Theme.of(context).textTheme.headlineMedium),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppTheme.bgCard,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.white.withOpacity(0.06)),
                  ),
                  child: Column(children: [
                    _TraitBar(label: 'Openness', value: user.personality.openness, color: AppTheme.accentCyan),
                    const SizedBox(height: 10),
                    _TraitBar(label: 'Conscientiousness', value: user.personality.conscientiousness, color: AppTheme.accentEmerald),
                    const SizedBox(height: 10),
                    _TraitBar(label: 'Extraversion', value: user.personality.extraversion, color: AppTheme.accentAmber),
                    const SizedBox(height: 10),
                    _TraitBar(label: 'Agreeableness', value: user.personality.agreeableness, color: AppTheme.primaryPurple),
                    const SizedBox(height: 10),
                    _TraitBar(label: 'Neuroticism', value: user.personality.neuroticism, color: AppTheme.dangerRed),
                  ]),
                ),

                const SizedBox(height: 24),
              ],

              // Settings sections
              Text('Preferences', style: Theme.of(context).textTheme.headlineMedium),
              const SizedBox(height: 12),

              _SettingsGroup(children: [
                _SettingsTile(
                  icon: Icons.notifications_outlined,
                  title: 'Reflection Reminders',
                  subtitle: 'Get notified when it\'s time to reflect',
                  trailing: Switch(
                    value: HiveStorage.areNotificationsEnabled(),
                    onChanged: (v) => HiveStorage.setNotifications(v),
                    activeColor: AppTheme.primaryPurple,
                  ),
                ),
              ]),

              const SizedBox(height: 16),
              Text('Data & Privacy', style: Theme.of(context).textTheme.headlineMedium),
              const SizedBox(height: 12),

              _SettingsGroup(children: [
                _SettingsTile(
                  icon: Icons.lock_outline,
                  title: 'Data Storage',
                  subtitle: 'All data stored locally on your device',
                  trailing: const Icon(Icons.check_circle, color: AppTheme.accentEmerald, size: 20),
                ),
                const Divider(height: 1),
                _SettingsTile(
                  icon: Icons.analytics_outlined,
                  title: 'Decision History',
                  subtitle: '${context.watch<DecisionProvider>().decisions.length} decisions stored',
                  onTap: () => Navigator.pushNamed(context, '/history'),
                ),
                const Divider(height: 1),
                _SettingsTile(
                  icon: Icons.delete_outline,
                  title: 'Clear All Data',
                  subtitle: 'Delete all decisions and reset app',
                  iconColor: AppTheme.dangerRed,
                  textColor: AppTheme.dangerRed,
                  onTap: () => _showClearDataDialog(context),
                ),
              ]),

              const SizedBox(height: 16),
              Text('About', style: Theme.of(context).textTheme.headlineMedium),
              const SizedBox(height: 12),

              _SettingsGroup(children: [
                _SettingsTile(
                  icon: Icons.psychology_outlined,
                  title: 'AI Regret Minimizer',
                  subtitle: 'Version 1.0.0 · Psychology-based Decision Intelligence',
                ),
                const Divider(height: 1),
                _SettingsTile(
                  icon: Icons.science_outlined,
                  title: 'Methodology',
                  subtitle: 'Big Five personality + Monte Carlo simulation',
                ),
                const Divider(height: 1),
                _SettingsTile(
                  icon: Icons.security_outlined,
                  title: 'Privacy First',
                  subtitle: '100% offline · No data leaves your device · GDPR compliant',
                ),
              ]),

              const SizedBox(height: 24),

              // Reset onboarding
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: () => _showResetProfileDialog(context),
                  icon: const Icon(Icons.refresh, color: AppTheme.warningOrange),
                  label: const Text('Re-take Personality Assessment', style: TextStyle(color: AppTheme.warningOrange)),
                  style: OutlinedButton.styleFrom(
                    side: BorderSide(color: AppTheme.warningOrange.withOpacity(0.4)),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  ),
                ),
              ),

              const SizedBox(height: 80),
            ]),
          ),
        );
      },
    );
  }

  void _showClearDataDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppTheme.bgCard,
        title: const Text('⚠️ Clear All Data'),
        content: const Text('This will permanently delete all decisions, your personality profile, and reset the app. This cannot be undone.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          TextButton(
            onPressed: () async {
              Navigator.pop(context);
              await context.read<UserProvider>().clearProfile();
              await HiveStorage.setOnboardingComplete(false);
              if (context.mounted) {
                Navigator.pushNamedAndRemoveUntil(context, '/onboarding', (r) => false);
              }
            },
            child: const Text('Clear Everything', style: TextStyle(color: AppTheme.dangerRed)),
          ),
        ],
      ),
    );
  }

  void _showResetProfileDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppTheme.bgCard,
        title: const Text('Re-take Assessment'),
        content: const Text('This will reset your personality profile but keep your decision history. Continue?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          TextButton(
            onPressed: () async {
              Navigator.pop(context);
              await HiveStorage.setOnboardingComplete(false);
              if (context.mounted) {
                Navigator.pushNamedAndRemoveUntil(context, '/onboarding', (r) => false);
              }
            },
            child: const Text('Continue', style: TextStyle(color: AppTheme.primaryPurple)),
          ),
        ],
      ),
    );
  }
}

class _TraitBar extends StatelessWidget {
  final String label;
  final double value;
  final Color color;
  const _TraitBar({required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      SizedBox(width: 130, child: Text(label, style: Theme.of(context).textTheme.bodySmall)),
      Expanded(
        child: ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: LinearProgressIndicator(
            value: value / 100,
            backgroundColor: color.withOpacity(0.1),
            valueColor: AlwaysStoppedAnimation<Color>(color),
            minHeight: 7,
          ),
        ),
      ),
      const SizedBox(width: 10),
      Text('${value.round()}', style: Theme.of(context).textTheme.bodySmall?.copyWith(color: color, fontWeight: FontWeight.w700)),
    ]);
  }
}

class _SettingsGroup extends StatelessWidget {
  final List<Widget> children;
  const _SettingsGroup({required this.children});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.06)),
      ),
      child: Column(children: children),
    );
  }
}

class _SettingsTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Widget? trailing;
  final VoidCallback? onTap;
  final Color? iconColor;
  final Color? textColor;

  const _SettingsTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    this.trailing,
    this.onTap,
    this.iconColor,
    this.textColor,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: onTap,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      leading: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: (iconColor ?? AppTheme.primaryPurple).withOpacity(0.12),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Icon(icon, color: iconColor ?? AppTheme.primaryPurple, size: 20),
      ),
      title: Text(title, style: Theme.of(context).textTheme.bodyLarge?.copyWith(color: textColor ?? AppTheme.textPrimary, fontWeight: FontWeight.w500)),
      subtitle: Text(subtitle, style: Theme.of(context).textTheme.bodySmall),
      trailing: trailing ?? (onTap != null ? const Icon(Icons.chevron_right, color: AppTheme.textMuted, size: 20) : null),
    );
  }
}
