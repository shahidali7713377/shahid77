import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../core/theme/app_theme.dart';
import '../../models/decision_model.dart';
import '../../providers/decision_provider.dart';
import '../../widgets/decision_card.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  String _filter = 'all';
  String _searchQuery = '';
  final _searchCtrl = TextEditingController();

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<DecisionProvider>(
      builder: (context, dp, _) {
        final filtered = _applyFilter(dp.decisions);

        return Scaffold(
          backgroundColor: AppTheme.bgPrimary,
          appBar: AppBar(
            title: const Text('Decision History'),
            leading: IconButton(
              icon: const Icon(Icons.arrow_back_ios_rounded),
              onPressed: () => Navigator.pop(context),
            ),
          ),
          body: Column(
            children: [
              // Search bar
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 0),
                child: TextField(
                  controller: _searchCtrl,
                  onChanged: (v) => setState(() => _searchQuery = v),
                  style: Theme.of(context).textTheme.bodyMedium,
                  decoration: InputDecoration(
                    hintText: 'Search decisions...',
                    prefixIcon: const Icon(Icons.search, color: AppTheme.textMuted),
                    suffixIcon: _searchQuery.isNotEmpty
                        ? GestureDetector(
                            onTap: () {
                              _searchCtrl.clear();
                              setState(() => _searchQuery = '');
                            },
                            child: const Icon(Icons.close, color: AppTheme.textMuted),
                          )
                        : null,
                  ),
                ),
              ),

              const SizedBox(height: 12),

              // Filter chips
              SizedBox(
                height: 36,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  children: [
                    _FilterChip(label: 'All', value: 'all', selected: _filter == 'all', onTap: () => setState(() => _filter = 'all')),
                    const SizedBox(width: 8),
                    _FilterChip(label: '🔮 Analyzed', value: 'analyzed', selected: _filter == 'analyzed', onTap: () => setState(() => _filter = 'analyzed')),
                    const SizedBox(width: 8),
                    _FilterChip(label: '⏳ Pending', value: 'pending', selected: _filter == 'pending', onTap: () => setState(() => _filter = 'pending')),
                    const SizedBox(width: 8),
                    _FilterChip(label: '✅ Reflected', value: 'reflected', selected: _filter == 'reflected', onTap: () => setState(() => _filter = 'reflected')),
                  ],
                ),
              ),

              const SizedBox(height: 12),

              // Count
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(children: [
                  Text('${filtered.length} decisions', style: Theme.of(context).textTheme.bodySmall?.copyWith(color: AppTheme.textMuted)),
                ]),
              ),

              const SizedBox(height: 8),

              // Decision list
              Expanded(
                child: filtered.isEmpty
                    ? _EmptyHistory(filter: _filter)
                    : ListView.builder(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        itemCount: filtered.length,
                        itemBuilder: (context, i) {
                          final decision = filtered[i];
                          return DecisionCard(
                            decision: decision,
                            showReflectButton: _shouldShowReflect(decision),
                            onTap: () {
                              context.read<DecisionProvider>().setCurrentDecision(decision.id);
                              Navigator.pushNamed(context, '/decision/analysis', arguments: decision.id);
                            },
                            onReflect: () => _showReflectionDialog(context, decision),
                            onDelete: () => _showDeleteDialog(context, dp, decision),
                          );
                        },
                      ),
              ),
            ],
          ),
        );
      },
    );
  }

  List<DecisionModel> _applyFilter(List<DecisionModel> all) {
    var list = all;
    if (_searchQuery.isNotEmpty) {
      list = list.where((d) => d.title.toLowerCase().contains(_searchQuery.toLowerCase())).toList();
    }
    switch (_filter) {
      case 'analyzed':
        return list.where((d) => d.isAnalyzed).toList();
      case 'pending':
        return list.where((d) => !d.isAnalyzed).toList();
      case 'reflected':
        return list.where((d) => d.reflectionCompleted).toList();
      default:
        return list;
    }
  }

  bool _shouldShowReflect(DecisionModel d) {
    if (d.reflectionCompleted || !d.isAnalyzed || d.chosenOptionId == null) return false;
    final due = d.reflectionDueAt;
    if (due == null) return false;
    return DateTime.now().isAfter(due.subtract(const Duration(days: 7)));
  }

  void _showReflectionDialog(BuildContext context, DecisionModel decision) {
    final chosenOption = decision.chosenOption;
    if (chosenOption == null) return;

    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.bgSecondary,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('⏰ Reflection Time', style: Theme.of(context).textTheme.headlineMedium),
          const SizedBox(height: 8),
          Text('You chose: "${chosenOption.title}"', style: Theme.of(context).textTheme.bodyMedium),
          const SizedBox(height: 24),
          Text('Did you regret this decision?', style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 16),
          Row(children: [
            Expanded(
              child: ElevatedButton.icon(
                onPressed: () {
                  Navigator.pop(context);
                  context.read<DecisionProvider>().submitReflection(decision.id, chosenOption.id, false);
                },
                icon: const Icon(Icons.thumb_up_outlined),
                label: const Text('No Regret'),
                style: ElevatedButton.styleFrom(backgroundColor: AppTheme.accentEmerald),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: ElevatedButton.icon(
                onPressed: () {
                  Navigator.pop(context);
                  context.read<DecisionProvider>().submitReflection(decision.id, chosenOption.id, true);
                },
                icon: const Icon(Icons.thumb_down_outlined),
                label: const Text('I Regret It'),
                style: ElevatedButton.styleFrom(backgroundColor: AppTheme.dangerRed),
              ),
            ),
          ]),
          const SizedBox(height: 16),
        ]),
      ),
    );
  }

  void _showDeleteDialog(BuildContext context, DecisionProvider dp, DecisionModel decision) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppTheme.bgCard,
        title: const Text('Delete Decision'),
        content: Text('Are you sure you want to delete "${decision.title}"? This cannot be undone.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              dp.deleteDecision(decision.id);
            },
            child: const Text('Delete', style: TextStyle(color: AppTheme.dangerRed)),
          ),
        ],
      ),
    );
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final String value;
  final bool selected;
  final VoidCallback onTap;
  const _FilterChip({required this.label, required this.value, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        decoration: BoxDecoration(
          color: selected ? AppTheme.primaryPurple : AppTheme.bgCard,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: selected ? AppTheme.primaryPurple : Colors.white.withOpacity(0.08)),
        ),
        child: Text(label,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: selected ? Colors.white : AppTheme.textSecondary,
                  fontWeight: selected ? FontWeight.w600 : FontWeight.w400,
                )),
      ),
    );
  }
}

class _EmptyHistory extends StatelessWidget {
  final String filter;
  const _EmptyHistory({required this.filter});

  @override
  Widget build(BuildContext context) {
    final msgs = {
      'all': ('📋', 'No decisions yet', 'Tap the + button to analyze your first decision'),
      'analyzed': ('🔮', 'No analyzed decisions', 'Run AI analysis on your decisions'),
      'pending': ('✅', 'All caught up!', 'All your decisions have been analyzed'),
      'reflected': ('🪞', 'No reflections yet', 'Reflections appear after your decision horizon passes'),
    };
    final msg = msgs[filter] ?? msgs['all']!;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(40),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text(msg.$1, style: const TextStyle(fontSize: 56)),
          const SizedBox(height: 16),
          Text(msg.$2, style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 8),
          Text(msg.$3, textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodyMedium),
        ]),
      ),
    );
  }
}
