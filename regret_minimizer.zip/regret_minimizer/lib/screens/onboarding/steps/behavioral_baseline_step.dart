import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/theme/app_theme.dart';
import '../../../providers/onboarding_provider.dart';

class BehavioralBaselineStep extends StatelessWidget {
  const BehavioralBaselineStep({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<OnboardingProvider>(
      builder: (context, provider, _) {
        return SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(24, 20, 24, 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '🎯 Behavioral Baseline',
                style: Theme.of(context).textTheme.headlineMedium,
              ),
              const SizedBox(height: 8),
              Text(
                'Help us understand your decision-making patterns',
                style: Theme.of(context).textTheme.bodyMedium,
              ),

              const SizedBox(height: 28),

              // Risk Tolerance
              _SectionLabel(label: 'Risk Tolerance'),
              const SizedBox(height: 4),
              Text(
                'How comfortable are you with uncertainty?',
                style: Theme.of(context).textTheme.bodySmall,
              ),
              const SizedBox(height: 8),
              _SliderCard(
                value: provider.riskTolerance,
                min: 0,
                max: 100,
                divisions: 20,
                leftLabel: 'Risk Averse',
                rightLabel: 'Risk Seeker',
                activeColor: AppTheme.accentCyan,
                onChanged: provider.setRiskTolerance,
                displayValue:
                    '${provider.riskTolerance.round()}% tolerance',
              ),

              const SizedBox(height: 24),

              // Decision Style
              _SectionLabel(label: 'Decision-Making Style'),
              const SizedBox(height: 12),
              ...decisionStyles.asMap().entries.map((entry) {
                final style = entry.value;
                final isSelected =
                    provider.decisionStyle == style['value'];
                return GestureDetector(
                  onTap: () => provider.setDecisionStyle(style['value']!),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    margin: const EdgeInsets.only(bottom: 10),
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color:
                          isSelected ? AppTheme.bgCardLight : AppTheme.bgCard,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                        color: isSelected
                            ? AppTheme.primaryPurple
                            : Colors.white.withOpacity(0.06),
                        width: isSelected ? 1.5 : 1,
                      ),
                    ),
                    child: Row(
                      children: [
                        AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          width: 20,
                          height: 20,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: isSelected
                                ? AppTheme.primaryPurple
                                : Colors.transparent,
                            border: Border.all(
                              color: isSelected
                                  ? AppTheme.primaryPurple
                                  : AppTheme.textMuted,
                              width: 2,
                            ),
                          ),
                          child: isSelected
                              ? const Icon(Icons.check,
                                  color: Colors.white, size: 12)
                              : null,
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                style['label']!,
                                style: Theme.of(context)
                                    .textTheme
                                    .bodyLarge
                                    ?.copyWith(
                                      fontWeight: FontWeight.w600,
                                      color: isSelected
                                          ? AppTheme.textPrimary
                                          : AppTheme.textSecondary,
                                    ),
                              ),
                              Text(
                                style['desc']!,
                                style:
                                    Theme.of(context).textTheme.bodySmall,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }),

              const SizedBox(height: 24),

              // Emotional Volatility
              _SectionLabel(label: 'Emotional Volatility'),
              const SizedBox(height: 4),
              Text(
                'How strongly do emotions influence your decisions?',
                style: Theme.of(context).textTheme.bodySmall,
              ),
              const SizedBox(height: 8),
              _SliderCard(
                value: provider.emotionalVolatility,
                min: 0,
                max: 100,
                divisions: 20,
                leftLabel: 'Very Stable',
                rightLabel: 'Very Emotional',
                activeColor: AppTheme.accentAmber,
                onChanged: provider.setEmotionalVolatility,
                displayValue:
                    '${provider.emotionalVolatility.round()}% emotional',
              ),

              const SizedBox(height: 24),

              // Regret Triggers
              _SectionLabel(label: 'Primary Regret Triggers'),
              const SizedBox(height: 8),
              Text(
                'Select areas where you most commonly experience regret',
                style: Theme.of(context).textTheme.bodySmall,
              ),
              const SizedBox(height: 12),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: regretTriggerOptions.map((trigger) {
                  final isSelected = provider.isTriggerSelected(trigger);
                  return GestureDetector(
                    onTap: () => provider.toggleRegretTrigger(trigger),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 8),
                      decoration: BoxDecoration(
                        color: isSelected
                            ? AppTheme.primaryPurple.withOpacity(0.2)
                            : AppTheme.bgCard,
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(
                          color: isSelected
                              ? AppTheme.primaryPurple
                              : Colors.white.withOpacity(0.08),
                        ),
                      ),
                      child: Text(
                        trigger,
                        style:
                            Theme.of(context).textTheme.bodySmall?.copyWith(
                                  color: isSelected
                                      ? AppTheme.textPrimary
                                      : AppTheme.textSecondary,
                                  fontWeight: isSelected
                                      ? FontWeight.w600
                                      : FontWeight.w400,
                                ),
                      ),
                    ),
                  );
                }).toList(),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String label;
  const _SectionLabel({required this.label});

  @override
  Widget build(BuildContext context) {
    return Text(
      label,
      style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontSize: 15),
    );
  }
}

class _SliderCard extends StatelessWidget {
  final double value;
  final double min;
  final double max;
  final int? divisions;
  final String leftLabel;
  final String rightLabel;
  final Color activeColor;
  final Function(double) onChanged;
  final String displayValue;

  const _SliderCard({
    required this.value,
    required this.min,
    required this.max,
    this.divisions,
    required this.leftLabel,
    required this.rightLabel,
    required this.activeColor,
    required this.onChanged,
    required this.displayValue,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withOpacity(0.06)),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Text(leftLabel, style: Theme.of(context).textTheme.bodySmall),
              const Spacer(),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: activeColor.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  displayValue,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: activeColor,
                        fontWeight: FontWeight.w600,
                      ),
                ),
              ),
              const Spacer(),
              Text(rightLabel, style: Theme.of(context).textTheme.bodySmall),
            ],
          ),
          SliderTheme(
            data: SliderThemeData(
              trackHeight: 4,
              activeTrackColor: activeColor,
              inactiveTrackColor: AppTheme.bgSurface,
              thumbColor: Colors.white,
              overlayColor: activeColor.withOpacity(0.2),
            ),
            child: Slider(
              value: value,
              min: min,
              max: max,
              divisions: divisions,
              onChanged: onChanged,
            ),
          ),
        ],
      ),
    );
  }
}
