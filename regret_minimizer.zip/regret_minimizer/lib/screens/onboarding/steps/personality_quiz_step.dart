import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/theme/app_theme.dart';
import '../../../providers/onboarding_provider.dart';

class PersonalityQuizStep extends StatefulWidget {
  const PersonalityQuizStep({super.key});

  @override
  State<PersonalityQuizStep> createState() => _PersonalityQuizStepState();
}

class _PersonalityQuizStepState extends State<PersonalityQuizStep> {
  final ScrollController _scrollController = ScrollController();

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<OnboardingProvider>(
      builder: (context, provider, _) {
        final answeredCount = provider.quizAnswers.length;
        final totalQ = personalityQuestions.length;

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 20, 24, 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '🧠 Personality Assessment',
                    style: Theme.of(context).textTheme.headlineMedium,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Rate each statement from 1 (Disagree) to 5 (Agree)',
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(4),
                          child: LinearProgressIndicator(
                            value: answeredCount / totalQ,
                            backgroundColor: AppTheme.bgCard,
                            valueColor: const AlwaysStoppedAnimation<Color>(
                                AppTheme.accentCyan),
                            minHeight: 4,
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Text(
                        '$answeredCount/$totalQ',
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              color: AppTheme.accentCyan,
                              fontWeight: FontWeight.w600,
                            ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 16),

            Expanded(
              child: ListView.builder(
                controller: _scrollController,
                padding: const EdgeInsets.symmetric(horizontal: 24),
                itemCount: personalityQuestions.length,
                itemBuilder: (context, index) {
                  final q = personalityQuestions[index];
                  final currentVal = provider.quizAnswers[q['index']] ?? 0;

                  return _QuizCard(
                    question: q,
                    currentValue: currentVal,
                    onChanged: (val) {
                      provider.setQuizAnswer(q['index'] as int, val);
                    },
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }
}

class _QuizCard extends StatelessWidget {
  final Map<String, dynamic> question;
  final double currentValue;
  final Function(double) onChanged;

  const _QuizCard({
    required this.question,
    required this.currentValue,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final isAnswered = currentValue > 0;

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: isAnswered
            ? AppTheme.bgCardLight
            : AppTheme.bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isAnswered
              ? AppTheme.primaryPurple.withOpacity(0.3)
              : Colors.white.withOpacity(0.06),
          width: 1,
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: AppTheme.bgSurface,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    question['emoji'] as String,
                    style: const TextStyle(fontSize: 16),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    question['text'] as String,
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: isAnswered
                              ? AppTheme.textPrimary
                              : AppTheme.textSecondary,
                          height: 1.4,
                        ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Text('1', style: Theme.of(context).textTheme.bodySmall),
                Expanded(
                  child: SliderTheme(
                    data: SliderThemeData(
                      trackHeight: 4,
                      activeTrackColor: AppTheme.primaryPurple,
                      inactiveTrackColor: AppTheme.bgSurface,
                      thumbColor: Colors.white,
                      overlayColor: AppTheme.primaryPurple.withOpacity(0.2),
                      thumbShape: const RoundSliderThumbShape(
                          enabledThumbRadius: 10),
                    ),
                    child: Slider(
                      value: currentValue == 0 ? 3.0 : currentValue,
                      min: 1,
                      max: 5,
                      divisions: 4,
                      onChanged: onChanged,
                      onChangeStart: (_) {
                        if (currentValue == 0) onChanged(3.0);
                      },
                    ),
                  ),
                ),
                Text('5', style: Theme.of(context).textTheme.bodySmall),
              ],
            ),
            if (currentValue > 0)
              Center(
                child: Text(
                  _getLabelForValue(currentValue),
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: AppTheme.primaryPurple,
                        fontWeight: FontWeight.w600,
                      ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  String _getLabelForValue(double value) {
    switch (value.round()) {
      case 1:
        return 'Strongly Disagree';
      case 2:
        return 'Disagree';
      case 3:
        return 'Neutral';
      case 4:
        return 'Agree';
      case 5:
        return 'Strongly Agree';
      default:
        return '';
    }
  }
}
