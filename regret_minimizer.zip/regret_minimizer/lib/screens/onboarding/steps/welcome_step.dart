import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import '../../../core/theme/app_theme.dart';
import '../../../providers/onboarding_provider.dart';

class WelcomeStep extends StatelessWidget {
  const WelcomeStep({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<OnboardingProvider>(
      builder: (context, provider, _) {
        return SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Illustration
              Center(
                child: Container(
                  width: 120,
                  height: 120,
                  decoration: BoxDecoration(
                    gradient: AppTheme.primaryGradient,
                    borderRadius: BorderRadius.circular(32),
                    boxShadow: [
                      BoxShadow(
                        color: AppTheme.primaryPurple.withOpacity(0.4),
                        blurRadius: 40,
                        spreadRadius: 4,
                      ),
                    ],
                  ),
                  child: const Icon(
                    Icons.psychology_rounded,
                    color: Colors.white,
                    size: 64,
                  ),
                ).animate().scale(duration: 600.ms, curve: Curves.elasticOut),
              ),

              const SizedBox(height: 32),

              Text(
                'Meet Your\nFuture Self',
                style: Theme.of(context).textTheme.displayMedium?.copyWith(
                      height: 1.15,
                    ),
              ).animate().fadeIn(delay: 200.ms).slideX(begin: -0.1),

              const SizedBox(height: 16),

              Text(
                'The AI Regret Minimizer predicts how likely you are to regret a decision before you make it — using behavioral science and your unique personality profile.',
                style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                      color: AppTheme.textSecondary,
                      height: 1.6,
                    ),
              ).animate().fadeIn(delay: 400.ms),

              const SizedBox(height: 32),

              // Feature highlights
              ...['🧠 Big Five Personality Mapping',
                '🎲 Monte Carlo Risk Simulation',
                '🔮 Future Regret Probability Score',
                '📊 Long-term Satisfaction Forecast',
              ].asMap().entries.map((e) => Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: _FeatureChip(label: e.value)
                        .animate()
                        .fadeIn(delay: (500 + e.key * 100).ms)
                        .slideX(begin: -0.1),
                  )),

              const SizedBox(height: 32),

              Text(
                "What's your name?",
                style: Theme.of(context).textTheme.headlineSmall,
              ).animate().fadeIn(delay: 900.ms),

              const SizedBox(height: 12),

              TextFormField(
                initialValue: provider.name,
                onChanged: provider.setName,
                style: Theme.of(context).textTheme.bodyLarge,
                decoration: const InputDecoration(
                  hintText: 'Enter your first name',
                  prefixIcon:
                      Icon(Icons.person_outline, color: AppTheme.textMuted),
                ),
              ).animate().fadeIn(delay: 1000.ms),

              const SizedBox(height: 16),

              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppTheme.primaryPurple.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: AppTheme.primaryPurple.withOpacity(0.2),
                  ),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.lock_outline,
                        color: AppTheme.primaryPurple, size: 18),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        '100% offline. Your data stays on your device.',
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              color: AppTheme.textSecondary,
                            ),
                      ),
                    ),
                  ],
                ),
              ).animate().fadeIn(delay: 1100.ms),
            ],
          ),
        );
      },
    );
  }
}

class _FeatureChip extends StatelessWidget {
  final String label;
  const _FeatureChip({required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white.withOpacity(0.06)),
      ),
      child: Row(
        children: [
          Text(label, style: Theme.of(context).textTheme.bodyMedium),
          const Spacer(),
          const Icon(Icons.check_circle,
              color: AppTheme.accentEmerald, size: 18),
        ],
      ),
    );
  }
}
