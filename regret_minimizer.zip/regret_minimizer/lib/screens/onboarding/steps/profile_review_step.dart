import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:fl_chart/fl_chart.dart';
import '../../../core/theme/app_theme.dart';
import '../../../providers/onboarding_provider.dart';

class ProfileReviewStep extends StatelessWidget {
  const ProfileReviewStep({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<OnboardingProvider>(
      builder: (context, provider, _) {
        final personality = provider.computedPersonality;

        return SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(24, 20, 24, 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '✨ Your Profile',
                style: Theme.of(context).textTheme.headlineMedium,
              ),
              const SizedBox(height: 8),
              Text(
                'Here\'s what the AI knows about you, ${provider.name}',
                style: Theme.of(context).textTheme.bodyMedium,
              ),

              const SizedBox(height: 24),

              // Personality radar
              if (personality != null) ...[
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: AppTheme.bgCard,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: Colors.white.withOpacity(0.06)),
                  ),
                  child: Column(
                    children: [
                      Text(
                        'Big Five Personality Profile',
                        style: Theme.of(context).textTheme.headlineSmall,
                      ),
                      const SizedBox(height: 20),
                      SizedBox(
                        height: 220,
                        child: RadarChart(
                          RadarChartData(
                            dataSets: [
                              RadarDataSet(
                                fillColor:
                                    AppTheme.primaryPurple.withOpacity(0.2),
                                borderColor: AppTheme.primaryPurple,
                                borderWidth: 2,
                                dataEntries: [
                                  RadarEntry(value: personality.openness),
                                  RadarEntry(
                                      value: personality.conscientiousness),
                                  RadarEntry(value: personality.extraversion),
                                  RadarEntry(value: personality.agreeableness),
                                  RadarEntry(value: personality.neuroticism),
                                ],
                              ),
                            ],
                            radarShape: RadarShape.polygon,
                            getTitle: (index, angle) {
                              const titles = [
                                'Openness',
                                'Conscien.',
                                'Extraver.',
                                'Agreeable',
                                'Neurot.',
                              ];
                              return RadarChartTitle(
                                text: titles[index],
                                angle: angle,
                              );
                            },
                            titleTextStyle: Theme.of(context)
                                .textTheme
                                .bodySmall!
                                .copyWith(color: AppTheme.textSecondary),
                            radarBackgroundColor: Colors.transparent,
                            borderData: FlBorderData(show: false),
                            radarBorderData: const BorderSide(
                                color: Colors.transparent),
                            gridBorderData: BorderSide(
                                color: Colors.white.withOpacity(0.08),
                                width: 1),
                            tickCount: 4,
                            tickBorderData: BorderSide(
                                color: Colors.white.withOpacity(0.04)),
                            ticksTextStyle: const TextStyle(
                                fontSize: 0, color: Colors.transparent),
                          ),
                        ),
                      ),

                      const SizedBox(height: 16),
                      _TraitRow(
                          label: 'Dominant Trait',
                          value: personality.dominantTrait,
                          color: AppTheme.primaryPurple),
                      const SizedBox(height: 8),
                      _TraitRow(
                          label: 'Regret Susceptibility',
                          value:
                              '${personality.regretSusceptibility.round()}%',
                          color: regretScoreColor(
                              personality.regretSusceptibility)),
                    ],
                  ),
                ),

                const SizedBox(height: 16),
              ],

              // Profile stats
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: AppTheme.bgCard,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.white.withOpacity(0.06)),
                ),
                child: Column(
                  children: [
                    _ProfileRow(
                      icon: Icons.trending_up,
                      label: 'Risk Tolerance',
                      value: '${provider.riskTolerance.round()}%',
                      color: AppTheme.accentCyan,
                    ),
                    const Divider(height: 24),
                    _ProfileRow(
                      icon: Icons.psychology,
                      label: 'Decision Style',
                      value: provider.decisionStyle.replaceFirst(
                          provider.decisionStyle[0],
                          provider.decisionStyle[0].toUpperCase()),
                      color: AppTheme.accentAmber,
                    ),
                    const Divider(height: 24),
                    _ProfileRow(
                      icon: Icons.waves,
                      label: 'Emotional Volatility',
                      value: '${provider.emotionalVolatility.round()}%',
                      color: AppTheme.warningOrange,
                    ),
                    if (provider.primaryRegretTriggers.isNotEmpty) ...[
                      const Divider(height: 24),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Icon(Icons.warning_amber_rounded,
                              color: AppTheme.dangerRed, size: 20),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Regret Triggers',
                                  style:
                                      Theme.of(context).textTheme.bodySmall,
                                ),
                                const SizedBox(height: 8),
                                Wrap(
                                  spacing: 6,
                                  runSpacing: 6,
                                  children:
                                      provider.primaryRegretTriggers.map(
                                    (t) {
                                      final label = t.split(' ').skip(1).join(' ');
                                      return Container(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 8, vertical: 4),
                                        decoration: BoxDecoration(
                                          color: AppTheme.dangerRed
                                              .withOpacity(0.1),
                                          borderRadius:
                                              BorderRadius.circular(6),
                                          border: Border.all(
                                              color: AppTheme.dangerRed
                                                  .withOpacity(0.3)),
                                        ),
                                        child: Text(
                                          label,
                                          style: Theme.of(context)
                                              .textTheme
                                              .bodySmall
                                              ?.copyWith(
                                                color: AppTheme.dangerRed,
                                              ),
                                        ),
                                      );
                                    },
                                  ).toList(),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ],
                  ],
                ),
              ),

              const SizedBox(height: 20),

              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      AppTheme.primaryPurple.withOpacity(0.2),
                      AppTheme.primaryIndigo.withOpacity(0.1),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                      color: AppTheme.primaryPurple.withOpacity(0.3)),
                ),
                child: Row(
                  children: [
                    const Text('🚀', style: TextStyle(fontSize: 24)),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        'You\'re all set! Your AI model is now calibrated to your unique psychological profile.',
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                              color: AppTheme.textPrimary,
                              height: 1.5,
                            ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _TraitRow extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  const _TraitRow({required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: Theme.of(context).textTheme.bodySmall),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          decoration: BoxDecoration(
            color: color.withOpacity(0.15),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Text(value,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: color,
                    fontWeight: FontWeight.w700,
                  )),
        ),
      ],
    );
  }
}

class _ProfileRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color color;
  const _ProfileRow(
      {required this.icon, required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: color.withOpacity(0.15),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon, color: color, size: 18),
        ),
        const SizedBox(width: 12),
        Text(label, style: Theme.of(context).textTheme.bodyMedium),
        const Spacer(),
        Text(
          value,
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                fontWeight: FontWeight.w600,
                color: AppTheme.textPrimary,
              ),
        ),
      ],
    );
  }
}
