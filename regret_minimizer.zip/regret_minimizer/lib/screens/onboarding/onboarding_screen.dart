import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';
import '../../core/theme/app_theme.dart';
import '../../providers/onboarding_provider.dart';
import '../../providers/user_provider.dart';
import '../../core/storage/hive_storage.dart';
import 'steps/welcome_step.dart';
import 'steps/personality_quiz_step.dart';
import 'steps/behavioral_baseline_step.dart';
import 'steps/profile_review_step.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController _pageController = PageController();

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  void _nextPage(OnboardingProvider provider) {
    if (provider.currentStep == 0 && provider.name.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter your name to continue')),
      );
      return;
    }

    if (provider.currentStep == 1) {
      provider.computePersonality();
    }

    provider.nextStep();
    _pageController.nextPage(
      duration: const Duration(milliseconds: 400),
      curve: Curves.easeInOutCubic,
    );
  }

  void _prevPage(OnboardingProvider provider) {
    provider.previousStep();
    _pageController.previousPage(
      duration: const Duration(milliseconds: 400),
      curve: Curves.easeInOutCubic,
    );
  }

  Future<void> _completeOnboarding() async {
    final provider = context.read<OnboardingProvider>();
    final userProvider = context.read<UserProvider>();

    if (provider.computedPersonality == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please complete the personality quiz')),
      );
      return;
    }

    await userProvider.createProfile(
      name: provider.name,
      personality: provider.computedPersonality!,
      riskTolerance: provider.riskTolerance,
      decisionStyle: provider.decisionStyle,
      emotionalVolatility: provider.emotionalVolatility,
      primaryRegretTriggers: provider.primaryRegretTriggers,
    );

    await HiveStorage.setOnboardingComplete(true);

    if (mounted) {
      Navigator.pushReplacementNamed(context, '/home');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<OnboardingProvider>(
      builder: (context, provider, _) {
        return Scaffold(
          body: Container(
            decoration: const BoxDecoration(gradient: AppTheme.bgGradient),
            child: SafeArea(
              child: Column(
                children: [
                  // Header
                  _buildHeader(provider),

                  // Page content
                  Expanded(
                    child: PageView(
                      controller: _pageController,
                      physics: const NeverScrollableScrollPhysics(),
                      children: const [
                        WelcomeStep(),
                        PersonalityQuizStep(),
                        BehavioralBaselineStep(),
                        ProfileReviewStep(),
                      ],
                    ),
                  ),

                  // Navigation buttons
                  _buildNavigation(provider),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildHeader(OnboardingProvider provider) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(24, 16, 24, 0),
      child: Column(
        children: [
          Row(
            children: [
              if (provider.currentStep > 0)
                GestureDetector(
                  onTap: () => _prevPage(provider),
                  child: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: AppTheme.bgCard,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                          color: Colors.white.withOpacity(0.08), width: 1),
                    ),
                    child: const Icon(Icons.arrow_back_ios_rounded,
                        color: AppTheme.textSecondary, size: 18),
                  ),
                ),
              const Spacer(),
              Text(
                'Step ${provider.currentStep + 1} of ${provider.totalSteps}',
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: AppTheme.textMuted,
                    ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          // Progress bar
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: provider.completionPercent,
              backgroundColor: AppTheme.bgCard,
              valueColor: const AlwaysStoppedAnimation<Color>(
                AppTheme.primaryPurple,
              ),
              minHeight: 4,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNavigation(OnboardingProvider provider) {
    final isLastStep = provider.currentStep == provider.totalSteps - 1;

    return Padding(
      padding: const EdgeInsets.fromLTRB(24, 16, 24, 32),
      child: SizedBox(
        width: double.infinity,
        height: 54,
        child: DecoratedBox(
          decoration: BoxDecoration(
            gradient: AppTheme.primaryGradient,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: AppTheme.primaryPurple.withOpacity(0.4),
                blurRadius: 20,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.transparent,
              shadowColor: Colors.transparent,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
            ),
            onPressed: provider.isProcessing
                ? null
                : isLastStep
                    ? _completeOnboarding
                    : () => _nextPage(provider),
            child: provider.isProcessing
                ? const SizedBox(
                    width: 24,
                    height: 24,
                    child: CircularProgressIndicator(
                      color: Colors.white,
                      strokeWidth: 2,
                    ),
                  )
                : Text(
                    isLastStep ? 'Complete Profile →' : 'Continue →',
                    style: Theme.of(context).textTheme.labelLarge?.copyWith(
                          color: Colors.white,
                          fontSize: 16,
                        ),
                  ),
          ),
        ),
      ),
    );
  }
}
