import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:intl/intl.dart';
import '../../core/theme/app_theme.dart';
import '../../providers/analytics_provider.dart';
import '../../providers/decision_provider.dart';
import '../../providers/user_provider.dart';

class AnalyticsScreen extends StatelessWidget {
  const AnalyticsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer3<AnalyticsProvider, DecisionProvider, UserProvider>(
      builder: (context, analytics, dp, up, _) {
        // Sync analytics
        WidgetsBinding.instance.addPostFrameCallback((_) {
          analytics.updateDecisions(dp.decisions);
        });

        return Scaffold(
          backgroundColor: AppTheme.bgPrimary,
          appBar: AppBar(
            title: const Text('Regret Analytics'),
            leading: IconButton(
              icon: const Icon(Icons.arrow_back_ios_rounded),
              onPressed: () => Navigator.pop(context),
            ),
          ),
          body: analytics.totalDecisions == 0
              ? _EmptyAnalytics()
              : SingleChildScrollView(
                  padding: const EdgeInsets.all(20),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    // Personality insight
                    if (up.userProfile != null)
                      _PersonalityInsightCard(analytics: analytics, userName: up.userProfile!.name),

                    const SizedBox(height: 20),

                    // Key stats grid
                    Text('Key Metrics', style: Theme.of(context).textTheme.headlineMedium),
                    const SizedBox(height: 12),
                    GridView.count(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      crossAxisCount: 2,
                      mainAxisSpacing: 12,
                      crossAxisSpacing: 12,
                      childAspectRatio: 1.6,
                      children: [
                        _StatCard(label: 'Total Decisions', value: analytics.totalDecisions.toString(), icon: '🎯', color: AppTheme.primaryPurple),
                        _StatCard(label: 'Avg Regret Risk', value: '${analytics.avgPredictedRegret.round()}%', icon: '📊', color: regretScoreColor(analytics.avgPredictedRegret)),
                        _StatCard(label: 'Regret Rate', value: '${analytics.overallRegretRate.round()}%', icon: '😔', color: AppTheme.warningOrange),
                        _StatCard(label: 'AI Accuracy', value: analytics.predictionAccuracy > 0 ? '${analytics.predictionAccuracy.round()}%' : 'N/A', icon: '🤖', color: AppTheme.accentCyan),
                      ],
                    ),

                    const SizedBox(height: 24),

                    // Monthly trend
                    if (analytics.monthlyTrend.length >= 2) ...[
                      Text('Regret Risk Trend', style: Theme.of(context).textTheme.headlineMedium),
                      const SizedBox(height: 4),
                      Text('Average predicted regret score over time', style: Theme.of(context).textTheme.bodySmall),
                      const SizedBox(height: 14),
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: AppTheme.bgCard,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: Colors.white.withOpacity(0.06)),
                        ),
                        child: SizedBox(
                          height: 200,
                          child: LineChart(LineChartData(
                            lineBarsData: [
                              LineChartBarData(
                                spots: analytics.monthlyTrend.asMap().entries.map((e) {
                                  return FlSpot(e.key.toDouble(), e.value.avgRegretScore);
                                }).toList(),
                                isCurved: true,
                                gradient: AppTheme.primaryGradient,
                                barWidth: 3,
                                belowBarData: BarAreaData(
                                  show: true,
                                  gradient: LinearGradient(
                                    colors: [AppTheme.primaryPurple.withOpacity(0.3), AppTheme.primaryPurple.withOpacity(0)],
                                    begin: Alignment.topCenter,
                                    end: Alignment.bottomCenter,
                                  ),
                                ),
                                dotData: FlDotData(
                                  getDotPainter: (_, __, ___, ____) => FlDotCirclePainter(radius: 4, color: AppTheme.primaryPurple, strokeWidth: 2, strokeColor: Colors.white),
                                ),
                              ),
                            ],
                            titlesData: FlTitlesData(
                              leftTitles: AxisTitles(sideTitles: SideTitles(
                                showTitles: true,
                                reservedSize: 36,
                                getTitlesWidget: (v, _) => Text('${v.round()}%', style: Theme.of(context).textTheme.bodySmall?.copyWith(fontSize: 10)),
                              )),
                              bottomTitles: AxisTitles(sideTitles: SideTitles(
                                showTitles: true,
                                getTitlesWidget: (v, _) {
                                  final i = v.toInt();
                                  if (i < 0 || i >= analytics.monthlyTrend.length) return const SizedBox();
                                  final m = analytics.monthlyTrend[i].month;
                                  return Padding(
                                    padding: const EdgeInsets.only(top: 8),
                                    child: Text(DateFormat('MMM').format(m), style: Theme.of(context).textTheme.bodySmall?.copyWith(fontSize: 10)),
                                  );
                                },
                              )),
                              topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                              rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                            ),
                            gridData: FlGridData(getDrawingHorizontalLine: (v) => FlLine(color: Colors.white.withOpacity(0.05), strokeWidth: 1), drawVerticalLine: false),
                            borderData: FlBorderData(show: false),
                            minY: 0,
                            maxY: 100,
                          )),
                        ),
                      ),
                    ],

                    const SizedBox(height: 24),

                    // Category breakdown
                    if (analytics.categoryInsights.isNotEmpty) ...[
                      Text('Category Risk Breakdown', style: Theme.of(context).textTheme.headlineMedium),
                      const SizedBox(height: 12),
                      ...analytics.categoryInsights.map((insight) {
                        final color = regretScoreColor(insight.avgRegretScore);
                        return Container(
                          margin: const EdgeInsets.only(bottom: 10),
                          padding: const EdgeInsets.all(14),
                          decoration: BoxDecoration(
                            color: AppTheme.bgCard,
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(color: color.withOpacity(0.2)),
                          ),
                          child: Row(children: [
                            Text(insight.emoji, style: const TextStyle(fontSize: 24)),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Text(insight.category.toUpperCase(),
                                    style: Theme.of(context).textTheme.bodySmall?.copyWith(fontWeight: FontWeight.w700, color: AppTheme.textMuted, letterSpacing: 0.8)),
                                const SizedBox(height: 6),
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(4),
                                  child: LinearProgressIndicator(
                                    value: insight.avgRegretScore / 100,
                                    backgroundColor: color.withOpacity(0.1),
                                    valueColor: AlwaysStoppedAnimation<Color>(color),
                                    minHeight: 7,
                                  ),
                                ),
                              ]),
                            ),
                            const SizedBox(width: 12),
                            Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                              Text('${insight.avgRegretScore.round()}%',
                                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(color: color, fontWeight: FontWeight.w800)),
                              Text('${insight.count} decisions', style: Theme.of(context).textTheme.bodySmall),
                            ]),
                          ]),
                        );
                      }),
                    ],

                    const SizedBox(height: 24),

                    // Emotional state breakdown
                    if (analytics.emotionalStateFrequency.isNotEmpty) ...[
                      Text('Emotional State at Decision Time', style: Theme.of(context).textTheme.headlineMedium),
                      const SizedBox(height: 12),
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: AppTheme.bgCard,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: Colors.white.withOpacity(0.06)),
                        ),
                        child: Column(
                          children: analytics.emotionalStateFrequency.entries.map((e) {
                            final maxCount = analytics.emotionalStateFrequency.values.reduce((a, b) => a > b ? a : b);
                            final ratio = e.value / maxCount;
                            const emotionEmojis = {
                              'calm': '😌', 'anxious': '😰', 'excited': '😃', 'stressed': '😤',
                              'confident': '💪', 'uncertain': '🤔', 'hopeful': '🌟', 'fearful': '😨',
                            };
                            return Padding(
                              padding: const EdgeInsets.only(bottom: 10),
                              child: Row(children: [
                                Text(emotionEmojis[e.key] ?? '😐', style: const TextStyle(fontSize: 18)),
                                const SizedBox(width: 10),
                                SizedBox(width: 70, child: Text(e.key, style: Theme.of(context).textTheme.bodySmall?.copyWith(textBaseline: TextBaseline.alphabetic))),
                                Expanded(
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(4),
                                    child: LinearProgressIndicator(
                                      value: ratio,
                                      backgroundColor: AppTheme.bgSurface,
                                      valueColor: const AlwaysStoppedAnimation<Color>(AppTheme.primaryPurple),
                                      minHeight: 7,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 10),
                                Text('${e.value}', style: Theme.of(context).textTheme.bodySmall?.copyWith(fontWeight: FontWeight.w700)),
                              ]),
                            );
                          }).toList(),
                        ),
                      ),
                    ],

                    const SizedBox(height: 24),

                    // Timing insight
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(colors: [AppTheme.accentCyan.withOpacity(0.1), AppTheme.accentCyan.withOpacity(0.05)]),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: AppTheme.accentCyan.withOpacity(0.25)),
                      ),
                      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        const Text('💡', style: TextStyle(fontSize: 24)),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Text('Optimal Decision State', style: Theme.of(context).textTheme.headlineSmall?.copyWith(color: AppTheme.accentCyan)),
                            const SizedBox(height: 6),
                            Text(
                              'Your data suggests lowest regret when deciding while ${analytics.bestTimeToDecide}. Plan your big decisions accordingly.',
                              style: Theme.of(context).textTheme.bodySmall?.copyWith(height: 1.5),
                            ),
                          ]),
                        ),
                      ]),
                    ),

                    const SizedBox(height: 80),
                  ]),
                ),
        );
      },
    );
  }
}

class _PersonalityInsightCard extends StatelessWidget {
  final AnalyticsProvider analytics;
  final String userName;
  const _PersonalityInsightCard({required this.analytics, required this.userName});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: AppTheme.primaryGradient,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [BoxShadow(color: AppTheme.primaryPurple.withOpacity(0.35), blurRadius: 20, offset: const Offset(0, 6))],
      ),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('🔬', style: TextStyle(fontSize: 28)),
        const SizedBox(width: 14),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Your Decision Profile', style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Colors.white.withOpacity(0.75))),
            const SizedBox(height: 4),
            Text(analytics.personalityInsight, style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Colors.white, height: 1.5)),
          ]),
        ),
      ]),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String label;
  final String value;
  final String icon;
  final Color color;
  const _StatCard({required this.label, required this.value, required this.icon, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Text(icon, style: const TextStyle(fontSize: 18)),
          const Spacer(),
        ]),
        const Spacer(),
        Text(value, style: Theme.of(context).textTheme.headlineLarge?.copyWith(color: color, fontWeight: FontWeight.w800, fontSize: 26)),
        Text(label, style: Theme.of(context).textTheme.bodySmall?.copyWith(color: AppTheme.textMuted, fontSize: 11)),
      ]),
    );
  }
}

class _EmptyAnalytics extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(40),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          const Text('📊', style: TextStyle(fontSize: 64)),
          const SizedBox(height: 20),
          Text('No Data Yet', style: Theme.of(context).textTheme.headlineLarge),
          const SizedBox(height: 10),
          Text(
            'Analyze at least one decision to see your personal regret analytics and behavioral patterns.',
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodyMedium,
          ),
          const SizedBox(height: 24),
          ElevatedButton(
            onPressed: () => Navigator.pushNamed(context, '/decision/new'),
            child: const Text('Analyze First Decision'),
          ),
        ]),
      ),
    );
  }
}
