import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../core/theme/app_theme.dart';
import '../../providers/user_provider.dart';
import '../../providers/decision_provider.dart';
import '../../providers/analytics_provider.dart';
import '../../models/decision_model.dart';
import '../../widgets/bottom_nav.dart';
import '../../widgets/decision_card.dart';
import '../../widgets/stat_chip.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentNavIndex = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final decisionProvider = context.read<DecisionProvider>();
      final analyticsProvider = context.read<AnalyticsProvider>();
      analyticsProvider.updateDecisions(decisionProvider.decisions);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Consumer3<UserProvider, DecisionProvider, AnalyticsProvider>(
      builder: (context, userProvider, decisionProvider, analytics, _) {
        final user = userProvider.userProfile;
        final hour = DateTime.now().hour;
        final greeting = hour < 12
            ? 'Good morning'
            : hour < 17
                ? 'Good afternoon'
                : 'Good evening';

        return Scaffold(
          backgroundColor: AppTheme.bgPrimary,
          body: CustomScrollView(
            slivers: [
              // App Bar
              SliverAppBar(
                floating: true,
                backgroundColor: AppTheme.bgPrimary,
                expandedHeight: 0,
                toolbarHeight: 72,
                flexibleSpace: FlexibleSpaceBar(
                  background: Container(color: AppTheme.bgPrimary),
                ),
                title: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              '$greeting,',
                              style: Theme.of(context)
                                  .textTheme
                                  .bodyMedium
                                  ?.copyWith(color: AppTheme.textMuted),
                            ),
                            Text(
                              user?.name ?? 'User',
                              style: Theme.of(context)
                                  .textTheme
                                  .headlineMedium
                                  ?.copyWith(fontWeight: FontWeight.w700),
                            ),
                          ],
                        ),
                      ),
                      // Notification bell
                      GestureDetector(
                        onTap: () {},
                        child: Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: AppTheme.bgCard,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                                color: Colors.white.withOpacity(0.08)),
                          ),
                          child: Stack(
                            children: [
                              const Icon(Icons.notifications_outlined,
                                  color: AppTheme.textSecondary, size: 22),
                              if (decisionProvider.pendingReflections().isNotEmpty)
                                Positioned(
                                  right: 0,
                                  top: 0,
                                  child: Container(
                                    width: 8,
                                    height: 8,
                                    decoration: const BoxDecoration(
                                      color: AppTheme.dangerRed,
                                      shape: BoxShape.circle,
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      GestureDetector(
                        onTap: () =>
                            Navigator.pushNamed(context, '/settings'),
                        child: Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: AppTheme.bgCard,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                                color: Colors.white.withOpacity(0.08)),
                          ),
                          child: const Icon(Icons.person_outline,
                              color: AppTheme.textSecondary, size: 22),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              SliverPadding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                sliver: SliverList(
                  delegate: SliverChildListDelegate([
                    // Stats row
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: StatChip(
                            icon: '🎯',
                            label: 'Decisions',
                            value: analytics.totalDecisions.toString(),
                            color: AppTheme.primaryPurple,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: StatChip(
                            icon: '📊',
                            label: 'Avg Regret',
                            value: analytics.totalDecisions == 0
                                ? 'N/A'
                                : '${analytics.avgPredictedRegret.round()}%',
                            color: regretScoreColor(analytics.avgPredictedRegret),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: StatChip(
                            icon: '✅',
                            label: 'Reflected',
                            value: analytics.reflectedDecisions.toString(),
                            color: AppTheme.accentEmerald,
                          ),
                        ),
                      ],
                    ).animate().fadeIn(delay: 100.ms).slideY(begin: 0.1),

                    const SizedBox(height: 24),

                    // New Decision CTA
                    GestureDetector(
                      onTap: () =>
                          Navigator.pushNamed(context, '/decision/new'),
                      child: Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          gradient: AppTheme.primaryGradient,
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: [
                            BoxShadow(
                              color: AppTheme.primaryPurple.withOpacity(0.4),
                              blurRadius: 24,
                              offset: const Offset(0, 8),
                            ),
                          ],
                        ),
                        child: Row(
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Analyze a Decision',
                                    style: Theme.of(context)
                                        .textTheme
                                        .headlineSmall
                                        ?.copyWith(
                                          color: Colors.white,
                                          fontWeight: FontWeight.w700,
                                        ),
                                  ),
                                  const SizedBox(height: 6),
                                  Text(
                                    'Get your Future Regret Probability Score',
                                    style: Theme.of(context)
                                        .textTheme
                                        .bodySmall
                                        ?.copyWith(
                                          color: Colors.white.withOpacity(0.75),
                                        ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.15),
                                borderRadius: BorderRadius.circular(14),
                              ),
                              child: const Icon(Icons.add,
                                  color: Colors.white, size: 24),
                            ),
                          ],
                        ),
                      ),
                    ).animate().fadeIn(delay: 200.ms).slideY(begin: 0.1),

                    const SizedBox(height: 24),

                    // Pending Reflections Alert
                    if (decisionProvider.pendingReflections().isNotEmpty) ...[
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: AppTheme.accentAmber.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: AppTheme.accentAmber.withOpacity(0.3),
                          ),
                        ),
                        child: Row(
                          children: [
                            const Text('⏰', style: TextStyle(fontSize: 22)),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    '${decisionProvider.pendingReflections().length} Reflection(s) Due',
                                    style: Theme.of(context)
                                        .textTheme
                                        .bodyLarge
                                        ?.copyWith(
                                          fontWeight: FontWeight.w600,
                                          color: AppTheme.accentAmber,
                                        ),
                                  ),
                                  Text(
                                    'Tell Future You how it went',
                                    style: Theme.of(context).textTheme.bodySmall,
                                  ),
                                ],
                              ),
                            ),
                            const Icon(Icons.chevron_right,
                                color: AppTheme.accentAmber),
                          ],
                        ),
                      ).animate().fadeIn(delay: 300.ms).slideY(begin: 0.1),
                      const SizedBox(height: 24),
                    ],

                    // Recent decisions
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Recent Decisions',
                          style: Theme.of(context).textTheme.headlineSmall,
                        ),
                        TextButton(
                          onPressed: () =>
                              Navigator.pushNamed(context, '/history'),
                          child: const Text('View All'),
                        ),
                      ],
                    ).animate().fadeIn(delay: 400.ms),

                    const SizedBox(height: 12),

                    if (decisionProvider.decisions.isEmpty)
                      _EmptyState()
                    else
                      ...decisionProvider.recentDecisions.asMap().entries.map(
                            (e) => DecisionCard(
                              decision: e.value,
                              onTap: () {
                                decisionProvider.setCurrentDecision(e.value.id);
                                Navigator.pushNamed(
                                  context,
                                  '/decision/analysis',
                                  arguments: e.value.id,
                                );
                              },
                            )
                                .animate()
                                .fadeIn(delay: (500 + e.key * 80).ms)
                                .slideY(begin: 0.1),
                          ),

                    const SizedBox(height: 100),
                  ]),
                ),
              ),
            ],
          ),
          bottomNavigationBar: AppBottomNav(
            currentIndex: _currentNavIndex,
            onTap: (index) {
              setState(() => _currentNavIndex = index);
              switch (index) {
                case 1:
                  Navigator.pushNamed(context, '/history');
                  break;
                case 2:
                  Navigator.pushNamed(context, '/decision/new');
                  break;
                case 3:
                  Navigator.pushNamed(context, '/analytics');
                  break;
                case 4:
                  Navigator.pushNamed(context, '/settings');
                  break;
              }
            },
          ),
        );
      },
    );
  }
}

class _EmptyState extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(40),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.06)),
      ),
      child: Column(
        children: [
          const Text('🔮', style: TextStyle(fontSize: 48)),
          const SizedBox(height: 16),
          Text(
            'No decisions yet',
            style: Theme.of(context).textTheme.headlineSmall,
          ),
          const SizedBox(height: 8),
          Text(
            'Start analyzing your first decision to see your regret probability score',
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodyMedium,
          ),
        ],
      ),
    ).animate().fadeIn(delay: 500.ms);
  }
}
