import 'dart:math';
import '../models/decision_model.dart';
import '../models/user_profile_model.dart';

/// AI-powered regret prediction engine using behavioral modeling
/// and Monte Carlo-style simulation
class RegretPredictionEngine {
  static final Random _random = Random();

  /// Run the full prediction pipeline for all options in a decision
  static List<RegretPrediction> analyzeDecision({
    required DecisionModel decision,
    required UserProfile userProfile,
  }) {
    final predictions = <RegretPrediction>[];

    for (final option in decision.options) {
      final prediction = _predictOptionRegret(
        option: option,
        decision: decision,
        userProfile: userProfile,
      );
      predictions.add(prediction);
    }

    return predictions;
  }

  static RegretPrediction _predictOptionRegret({
    required DecisionOption option,
    required DecisionModel decision,
    required UserProfile userProfile,
  }) {
    // === STEP 1: Base regret probability from personality ===
    final personalityRegretBase =
        userProfile.personality.regretSusceptibility;

    // === STEP 2: Risk-adjusted modifiers ===
    final riskModifier = _getRiskModifier(decision.perceivedRiskLevel);
    final optionRiskModifier = (option.perceivedRisk / 100) * 20;

    // === STEP 3: Emotional state modifier ===
    final emotionalModifier =
        _getEmotionalModifier(decision.emotionalStateAtInput);

    // === STEP 4: Time horizon modifier ===
    final timeModifier = _getTimeHorizonModifier(decision.timeHorizon);

    // === STEP 5: Pros/cons analysis ===
    final prosConsBalance = _analyzeProsConsBalance(option);

    // === STEP 6: Category-specific base rates ===
    final categoryBase = _getCategoryBaseRegret(decision.category);

    // === STEP 7: Risk tolerance alignment ===
    final riskToleranceAlignment = _getRiskToleranceAlignment(
      userRiskTolerance: userProfile.riskTolerance,
      optionRisk: option.perceivedRisk,
    );

    // === STEP 8: Monte Carlo Simulation (100 iterations) ===
    final monteCarlo = _runMonteCarlo(
      baseRegret: personalityRegretBase,
      riskModifier: riskModifier + optionRiskModifier,
      emotionalModifier: emotionalModifier,
      prosConsBalance: prosConsBalance,
      categoryBase: categoryBase,
      riskToleranceAlignment: riskToleranceAlignment,
      iterations: 100,
    );

    // === STEP 9: Time-based projection ===
    final regret6M = monteCarlo * _getTimeDecayFactor(6);
    final regret1Y = monteCarlo * _getTimeDecayFactor(12);
    final regret5Y = monteCarlo * _getTimeDecayFactor(60);

    // === STEP 10: Satisfaction and emotional impact ===
    final satisfactionScore =
        _computeSatisfactionScore(monteCarlo, prosConsBalance, timeModifier);
    final emotionalImpact =
        _computeEmotionalImpact(monteCarlo, prosConsBalance);

    // === STEP 11: Confidence level (based on data completeness) ===
    final confidence = _computeConfidence(option, decision);

    // === STEP 12: Generate narrative insights ===
    final narratives = _generateNarratives(
      option: option,
      decision: decision,
      userProfile: userProfile,
      regretScore: monteCarlo,
      satisfactionScore: satisfactionScore,
    );

    return RegretPrediction(
      optionId: option.id,
      regretProbability6Months: regret6M.clamp(0, 100),
      regretProbability1Year: regret1Y.clamp(0, 100),
      regretProbability5Years: regret5Y.clamp(0, 100),
      confidenceLevel: confidence.clamp(0, 100),
      emotionalImpactScore: emotionalImpact.clamp(-100, 100),
      longTermSatisfactionScore: satisfactionScore.clamp(0, 100),
      bestCaseScenario: narratives['best']!,
      worstCaseScenario: narratives['worst']!,
      mostLikelyScenario: narratives['likely']!,
      aiAdvice: narratives['advice']!,
      keyRiskFactors: narratives['risks'] as List<String>? ?? [],
      mitigationStrategies: narratives['mitigations'] as List<String>? ?? [],
      calculatedAt: DateTime.now(),
    );
  }

  // --- Sub-calculations ---

  static double _getRiskModifier(RiskLevel level) {
    switch (level) {
      case RiskLevel.low:
        return -10;
      case RiskLevel.moderate:
        return 0;
      case RiskLevel.high:
        return 15;
      case RiskLevel.extreme:
        return 30;
    }
  }

  static double _getEmotionalModifier(EmotionalState state) {
    switch (state) {
      case EmotionalState.calm:
        return -8;
      case EmotionalState.confident:
        return -12;
      case EmotionalState.hopeful:
        return -5;
      case EmotionalState.excited:
        return 5; // excitement leads to impulsive decisions
      case EmotionalState.anxious:
        return 10;
      case EmotionalState.stressed:
        return 15;
      case EmotionalState.uncertain:
        return 8;
      case EmotionalState.fearful:
        return 12;
    }
  }

  static double _getTimeHorizonModifier(TimeHorizon horizon) {
    switch (horizon) {
      case TimeHorizon.shortTerm:
        return 0.8;
      case TimeHorizon.midTerm:
        return 1.0;
      case TimeHorizon.longTerm:
        return 1.2;
    }
  }

  static double _analyzeProsConsBalance(DecisionOption option) {
    final pros = option.pros.length;
    final cons = option.cons.length;
    if (pros + cons == 0) return 0;
    return ((pros - cons) / (pros + cons)) * 20; // -20 to +20
  }

  static double _getCategoryBaseRegret(String category) {
    const categoryBases = {
      'career': 35.0,
      'relationships': 40.0,
      'finance': 30.0,
      'education': 28.0,
      'health': 25.0,
      'lifestyle': 32.0,
      'other': 35.0,
    };
    return categoryBases[category.toLowerCase()] ?? 35.0;
  }

  static double _getRiskToleranceAlignment({
    required double userRiskTolerance,
    required double optionRisk,
  }) {
    // If option risk is much higher than user's tolerance, regret goes up
    final mismatch = (optionRisk - userRiskTolerance).abs();
    return mismatch * 0.15; // 0-15 additional points
  }

  static double _runMonteCarlo({
    required double baseRegret,
    required double riskModifier,
    required double emotionalModifier,
    required double prosConsBalance,
    required double categoryBase,
    required double riskToleranceAlignment,
    required int iterations,
  }) {
    double totalRegret = 0;

    for (int i = 0; i < iterations; i++) {
      // Add Gaussian noise to simulate uncertainty
      final noise = _gaussianRandom() * 8;

      final iterationRegret = categoryBase +
          (baseRegret * 0.3) +
          riskModifier +
          emotionalModifier -
          prosConsBalance +
          riskToleranceAlignment +
          noise;

      totalRegret += iterationRegret;
    }

    return totalRegret / iterations;
  }

  static double _getTimeDecayFactor(int months) {
    // Regret patterns differ by time:
    // - Short term: higher initial regret
    // - Long term: often lower for bold decisions (regret of inaction)
    if (months <= 6) return 0.9;
    if (months <= 12) return 1.0;
    return 1.15; // Long term regret often higher for safe choices
  }

  static double _computeSatisfactionScore(
      double regretScore, double prosConsBalance, double timeModifier) {
    final base = 100 - regretScore;
    final prosBonus = prosConsBalance;
    return (base + prosBonus) * (1 / timeModifier);
  }

  static double _computeEmotionalImpact(
      double regretScore, double prosConsBalance) {
    return prosConsBalance * 3 - (regretScore - 50) * 0.5;
  }

  static double _computeConfidence(
      DecisionOption option, DecisionModel decision) {
    double confidence = 60; // Base confidence
    if (option.description.isNotEmpty && option.description.length > 20)
      confidence += 10;
    if (option.pros.length >= 2) confidence += 5;
    if (option.cons.length >= 2) confidence += 5;
    if (option.perceivedRisk != 50) confidence += 5;
    if (decision.notes != null && decision.notes!.isNotEmpty) confidence += 5;
    if (decision.tags.isNotEmpty) confidence += 5;
    return confidence;
  }

  static Map<String, dynamic> _generateNarratives({
    required DecisionOption option,
    required DecisionModel decision,
    required UserProfile userProfile,
    required double regretScore,
    required double satisfactionScore,
  }) {
    final optionName = option.title;
    final category = decision.category;
    final riskWord = _getRiskWord(decision.perceivedRiskLevel);
    final traitWord = userProfile.personality.dominantTrait.toLowerCase();

    // Scenarios
    String best, worst, likely, advice;
    List<String> risks, mitigations;

    if (regretScore < 25) {
      best =
          "Choosing '$optionName' leads to strong alignment with your values. Your $traitWord personality thrives here, creating lasting positive impact in your $category life.";
      worst =
          "In the unlikely worst case, '$optionName' underperforms expectations, but your risk profile suggests quick recovery and adaptation.";
      likely =
          "Most likely, '$optionName' delivers steady, satisfying progress. Low regret probability suggests this aligns well with your long-term goals.";
      advice =
          "Your analytical profile strongly supports this option. The data suggests minimal regret risk—move forward with measured confidence.";
      risks = [
        "External market conditions",
        "Changing personal priorities",
        "Opportunity costs"
      ];
      mitigations = [
        "Set quarterly check-in milestones",
        "Maintain backup contingencies",
        "Stay adaptive to feedback"
      ];
    } else if (regretScore < 50) {
      best =
          "If '$optionName' succeeds, your $category situation transforms meaningfully. Your $traitWord traits position you to capitalize on the upside.";
      worst =
          "A $riskWord downside scenario may create temporary dissatisfaction, particularly given your emotional volatility patterns.";
      likely =
          "Moderate regret probability suggests mixed outcomes. Success depends heavily on execution quality and external conditions aligning.";
      advice =
          "This is a balanced choice with moderate upside. Consider stress-testing your assumptions before committing—particularly around timeline and resources.";
      risks = [
        "Timeline misalignment",
        "Resource constraints",
        "External dependencies",
        "Emotional decision bias"
      ];
      mitigations = [
        "Create detailed action plan",
        "Build in decision review checkpoints",
        "Seek trusted second opinions",
        "Delay if emotionally elevated"
      ];
    } else if (regretScore < 75) {
      best =
          "The optimistic scenario for '$optionName' requires significant favorable conditions. Your $traitWord personality may struggle with this $riskWord decision.";
      worst =
          "High probability of regret if external factors don't align. Your personality profile shows sensitivity to this type of $category decision.";
      likely =
          "Elevated regret probability signals misalignment. You may look back and wish you'd chosen a more considered path.";
      advice =
          "Future You sends a caution signal. Consider taking 48–72 hours before deciding, and explore whether Option B reduces risk without sacrificing your core goals.";
      risks = [
        "Overconfidence bias",
        "Emotional urgency driving choice",
        "Insufficient information",
        "Peer influence",
        "Sunk cost thinking"
      ];
      mitigations = [
        "Apply the 10/10/10 rule (how will you feel in 10 min/months/years?)",
        "Consult a mentor in this domain",
        "List your core values and test alignment",
        "Identify what information you're missing"
      ];
    } else {
      best =
          "Even in the best case, '$optionName' creates significant emotional overhead for your $traitWord personality. This will require exceptional execution.";
      worst =
          "High regret risk detected. This decision significantly conflicts with your personality profile, risk tolerance, and historical patterns.";
      likely =
          "Future You predicts strong regret probability. The combination of high risk, emotional state, and personality-decision mismatch is a red flag.";
      advice =
          "PAUSE. The algorithm detects high regret potential. Your emotional state at input time ($riskWord risk + ${decision.emotionalStateAtInput.name} state) is a known regret amplifier. Sleep on this.";
      risks = [
        "Severe emotional decision bias",
        "High personality-option mismatch",
        "Extreme downside exposure",
        "Recovery timeline too long",
        "Cognitive distortions present"
      ];
      mitigations = [
        "Mandatory 72-hour waiting period",
        "Talk to 3 trusted advisors",
        "Write a pre-mortem analysis",
        "Explore what's driving urgency",
        "Consider professional guidance"
      ];
    }

    return {
      'best': best,
      'worst': worst,
      'likely': likely,
      'advice': advice,
      'risks': risks,
      'mitigations': mitigations,
    };
  }

  static String _getRiskWord(RiskLevel level) {
    switch (level) {
      case RiskLevel.low:
        return 'minimal';
      case RiskLevel.moderate:
        return 'moderate';
      case RiskLevel.high:
        return 'high';
      case RiskLevel.extreme:
        return 'extreme';
    }
  }

  // Box-Muller transform for Gaussian random numbers
  static double _gaussianRandom() {
    final u1 = 1 - _random.nextDouble();
    final u2 = _random.nextDouble();
    return sqrt(-2 * log(u1)) * cos(2 * pi * u2);
  }

  // Personality quiz scoring
  static PersonalityProfile scorePersonalityQuiz(
      Map<int, double> answers) {
    // Questions map to Big Five traits
    // Q0-Q4: Openness, Q5-Q9: Conscientiousness, Q10-Q14: Extraversion
    // Q15-Q19: Agreeableness, Q20-Q24: Neuroticism

    double openness = 0,
        conscientiousness = 0,
        extraversion = 0,
        agreeableness = 0,
        neuroticism = 0;

    final questionsPerTrait = 5;

    for (int i = 0; i < questionsPerTrait; i++) {
      openness += answers[i] ?? 50;
      conscientiousness += answers[i + 5] ?? 50;
      extraversion += answers[i + 10] ?? 50;
      agreeableness += answers[i + 15] ?? 50;
      neuroticism += answers[i + 20] ?? 50;
    }

    return PersonalityProfile(
      openness: (openness / questionsPerTrait).clamp(0, 100),
      conscientiousness: (conscientiousness / questionsPerTrait).clamp(0, 100),
      extraversion: (extraversion / questionsPerTrait).clamp(0, 100),
      agreeableness: (agreeableness / questionsPerTrait).clamp(0, 100),
      neuroticism: (neuroticism / questionsPerTrait).clamp(0, 100),
    );
  }
}
