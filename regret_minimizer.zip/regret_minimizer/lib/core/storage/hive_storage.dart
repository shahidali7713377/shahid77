import 'package:hive_flutter/hive_flutter.dart';
import '../../models/decision_model.dart';
import '../../models/user_profile_model.dart';
import '../../models/personality_model.dart';

class HiveStorage {
  static const String userBox = 'user_box';
  static const String decisionsBox = 'decisions_box';
  static const String settingsBox = 'settings_box';

  static Future<void> init() async {
    await Hive.openBox<UserProfile>(userBox);
    await Hive.openBox<DecisionModel>(decisionsBox);
    await Hive.openBox(settingsBox);
  }

  // User Profile
  static Box<UserProfile> get userStore => Hive.box<UserProfile>(userBox);

  static Future<void> saveUserProfile(UserProfile profile) async {
    await userStore.put('profile', profile);
  }

  static UserProfile? getUserProfile() {
    return userStore.get('profile');
  }

  static Future<void> clearUserProfile() async {
    await userStore.clear();
  }

  // Decisions
  static Box<DecisionModel> get decisionsStore => Hive.box<DecisionModel>(decisionsBox);

  static Future<void> saveDecision(DecisionModel decision) async {
    await decisionsStore.put(decision.id, decision);
  }

  static Future<void> deleteDecision(String id) async {
    await decisionsStore.delete(id);
  }

  static List<DecisionModel> getAllDecisions() {
    return decisionsStore.values.toList()
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
  }

  static DecisionModel? getDecision(String id) {
    return decisionsStore.get(id);
  }

  // Settings
  static Box get settingsStore => Hive.box(settingsBox);

  static bool isOnboardingComplete() {
    return settingsStore.get('onboarding_complete', defaultValue: false);
  }

  static Future<void> setOnboardingComplete(bool value) async {
    await settingsStore.put('onboarding_complete', value);
  }

  static bool isDarkMode() {
    return settingsStore.get('dark_mode', defaultValue: true);
  }

  static Future<void> setDarkMode(bool value) async {
    await settingsStore.put('dark_mode', value);
  }

  static bool areNotificationsEnabled() {
    return settingsStore.get('notifications', defaultValue: true);
  }

  static Future<void> setNotifications(bool value) async {
    await settingsStore.put('notifications', value);
  }
}
