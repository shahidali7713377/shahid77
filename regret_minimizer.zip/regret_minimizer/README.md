# 🔮 AI Future Regret Minimizer
### Psychology-Based Decision Intelligence Mobile Application

A production-ready Flutter app that predicts your probability of future regret **before** you make a decision, using behavioral science and on-device AI modeling.

---

## 🏗️ Architecture Overview

```
lib/
├── main.dart                    # Entry point + Hive init + Provider setup
├── app.dart                     # MaterialApp + routing
│
├── core/
│   ├── theme/
│   │   └── app_theme.dart       # Dark theme, gradients, color system
│   ├── storage/
│   │   └── hive_storage.dart    # Offline storage service (Hive)
│   └── engine/
│       └── regret_prediction_engine.dart  # 🧠 AI prediction algorithm
│
├── models/
│   ├── user_profile_model.dart  # UserProfile + PersonalityProfile + Adapters
│   ├── personality_model.dart   # Re-export
│   └── decision_model.dart      # DecisionModel, DecisionOption, RegretPrediction + Adapters
│
├── providers/
│   ├── user_provider.dart       # User state management
│   ├── onboarding_provider.dart # Multi-step onboarding state
│   ├── decision_provider.dart   # Decision CRUD + analysis trigger
│   └── analytics_provider.dart # Computed analytics from decision history
│
├── screens/
│   ├── splash/splash_screen.dart
│   ├── onboarding/
│   │   ├── onboarding_screen.dart
│   │   └── steps/
│   │       ├── welcome_step.dart
│   │       ├── personality_quiz_step.dart
│   │       ├── behavioral_baseline_step.dart
│   │       └── profile_review_step.dart
│   ├── home/home_screen.dart
│   ├── decision/
│   │   ├── decision_input_screen.dart
│   │   └── decision_analysis_screen.dart
│   ├── history/history_screen.dart
│   ├── analytics/analytics_screen.dart
│   └── settings/settings_screen.dart
│
└── widgets/
    ├── bottom_nav.dart
    ├── decision_card.dart
    └── stat_chip.dart
```

---

## 🧠 AI Prediction Engine

The `RegretPredictionEngine` implements a multi-factor behavioral model:

### Algorithm Pipeline

```
1. Personality Regret Base       (Big Five → regret susceptibility score)
2. Risk-Adjusted Modifiers       (perceived risk level + option-specific risk)
3. Emotional State Modifier      (calm = -8pts, stressed = +15pts, etc.)
4. Time Horizon Modifier         (long-term decisions carry more weight)
5. Pros/Cons Balance Analysis    (quantified advantage/disadvantage ratio)
6. Category-Specific Base Rates  (career=35%, relationships=40%, health=25%...)
7. Risk Tolerance Alignment      (mismatch penalty between user & option)
8. Monte Carlo Simulation        (100 iterations with Gaussian noise)
9. Time-Based Projection         (6-month, 1-year, 5-year probability curves)
10. Satisfaction + Impact Scores
11. Confidence Level             (data completeness scoring)
12. Narrative Generation         (AI-written scenarios + advice)
```

### Key Formula

```dart
regret = categoryBase + (personalityBase × 0.3) + riskModifier 
       + emotionalModifier - prosConsBalance + toleranceMismatch + noise
```

---

## 🗃️ Data Models

### UserProfile
- `personality: PersonalityProfile` — Big Five vector
- `riskTolerance: double` — 0-100
- `decisionStyle: String` — analytical/intuitive/consultative/spontaneous
- `emotionalVolatility: double` — 0-100

### PersonalityProfile
- `openness, conscientiousness, extraversion, agreeableness, neuroticism` — 0-100
- `get regretSusceptibility` — computed from neuroticism (40%) + conscientiousness (30%) + agreeableness (15%) + openness (15%)

### DecisionModel
- `options: List<DecisionOption>` — 2-5 options to compare
- `timeHorizon: TimeHorizon` — short/mid/long term
- `emotionalStateAtInput: EmotionalState` — 8 states
- `perceivedRiskLevel: RiskLevel` — low/moderate/high/extreme
- `chosenOptionId: String?` — user's final choice
- `reflectionDueAt: DateTime` — when to prompt for reflection
- `reflectionCompleted: bool` — whether user gave feedback

### RegretPrediction
- `regretProbability6Months/1Year/5Years: double`
- `confidenceLevel: double`
- `emotionalImpactScore: double` (-100 to +100)
- `longTermSatisfactionScore: double`
- `bestCaseScenario / worstCaseScenario / mostLikelyScenario: String`
- `aiAdvice: String`
- `keyRiskFactors / mitigationStrategies: List<String>`

---

## 📱 Screens

| Screen | Description |
|--------|-------------|
| **Splash** | Animated loading, routes to onboarding or home |
| **Onboarding** | 4-step: Name → Personality Quiz (25 Qs) → Behavioral Baseline → Review |
| **Home** | Dashboard with stats, recent decisions, pending reflections |
| **Decision Input** | 3-step: Basics → Options (pros/cons/risk) → Review |
| **Decision Analysis** | Overview (score ring) / Compare (bar chart) / Insights (bias detection) |
| **History** | Full decision list with search + filters |
| **Analytics** | Trend charts, category breakdown, emotional state patterns |
| **Settings** | Profile, personality bars, data management |

---

## 🚀 Setup

### Prerequisites
- Flutter 3.10+
- Dart 3.0+

### Installation

```bash
# 1. Get dependencies
flutter pub get

# 2. Run the app
flutter run

# Optional: Generate Hive adapters (already included manually)
# dart run build_runner build
```

### Key Dependencies

| Package | Purpose |
|---------|---------|
| `provider` | State management |
| `hive_flutter` | Offline local storage |
| `fl_chart` | Bar, line, radar charts |
| `flutter_animate` | Micro-animations |
| `percent_indicator` | Circular progress rings |
| `google_fonts` | Inter font family |
| `uuid` | Unique IDs |
| `intl` | Date formatting |

---

## 🎨 Design System

**Color Palette:**
- Background: `#0A0A14` (primary), `#12121E` (secondary), `#1A1A2E` (card)
- Brand: Purple `#7C3AED`, Indigo `#4F46E5`
- Accent: Cyan `#06B6D4`, Emerald `#10B981`, Amber `#F59E0B`
- Danger: Red `#EF4444`, Orange `#F97316`

**Score Coloring:**
- 0–25% regret → 🟢 Emerald (safe)
- 25–50% → 🟡 Amber (moderate)
- 50–75% → 🟠 Orange (high risk)
- 75–100% → 🔴 Red (extreme risk)

---

## 🔒 Privacy & Offline

- **100% offline** — all computation happens on-device
- **Hive** encrypted local storage
- No network calls required
- GDPR-compliant by design (no external data transmission)

---

## 📊 Analytics Features

- Monthly regret score trend (line chart)
- Category risk breakdown (per-category avg)
- Emotional state frequency analysis
- AI prediction accuracy tracking (post-reflection)
- Optimal decision-time recommendation
- Bias detection (confirmation bias, present bias, emotional bias)

---

## 🔮 Future Roadmap

- [ ] TensorFlow Lite on-device model (replace heuristic engine)
- [ ] Voice input via speech-to-text
- [ ] Widget for quick decision logging
- [ ] Export decisions as PDF report
- [ ] Collaborative decisions (share with trusted advisor)
- [ ] Premium tier: Deep psychological report PDF
