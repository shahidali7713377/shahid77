// lib/core/services/notification_service.dart
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest.dart' as tz_data;

class NotificationService {
  NotificationService._();
  static final NotificationService instance = NotificationService._();

  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();

  bool _initialized = false;

  Future<void> init() async {
    if (_initialized) return;
    tz_data.initializeTimeZones();

    const androidSettings =
        AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosSettings = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );

    await _plugin.initialize(
      const InitializationSettings(
          android: androidSettings, iOS: iosSettings),
      onDidReceiveNotificationResponse: _onNotificationTapped,
    );

    // Create notification channel for Android
    const channel = AndroidNotificationChannel(
      'lifeadmin_reminders',
      'LifeAdmin Reminders',
      description: 'Document and subscription expiry reminders',
      importance: Importance.high,
      enableLights: true,
      enableVibration: true,
    );
    await _plugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);

    _initialized = true;
  }

  Future<bool> requestPermission() async {
    final android = _plugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>();
    final granted = await android?.requestNotificationsPermission();
    return granted ?? false;
  }

  void _onNotificationTapped(NotificationResponse response) {
    debugPrint('Notification tapped: ${response.payload}');
  }

  Future<void> scheduleReminders({
    required int baseId,
    required String title,
    required String body,
    required DateTime expiryDate,
    required List<int> reminderDays,
  }) async {
    // Cancel existing notifications for this item
    for (final days in [1, 7, 30]) {
      await _plugin.cancel(baseId + days);
    }

    final now = DateTime.now();

    for (final days in reminderDays) {
      final notifDate = expiryDate.subtract(Duration(days: days));
      if (notifDate.isAfter(now)) {
        await _scheduleOne(
          id: baseId + days,
          title: title,
          body: '⏰ $body — expires in $days day${days == 1 ? '' : 's'}!',
          scheduledDate: notifDate,
        );
      }
    }

    // Also notify on day of expiry
    if (expiryDate.isAfter(now)) {
      await _scheduleOne(
        id: baseId,
        title: '🔴 Expires TODAY: $title',
        body: body,
        scheduledDate: DateTime(
            expiryDate.year, expiryDate.month, expiryDate.day, 9, 0),
      );
    }
  }

  Future<void> _scheduleOne({
    required int id,
    required String title,
    required String body,
    required DateTime scheduledDate,
  }) async {
    try {
      final tzDate = tz.TZDateTime.from(scheduledDate, tz.local);
      await _plugin.zonedSchedule(
        id,
        title,
        body,
        tzDate,
        const NotificationDetails(
          android: AndroidNotificationDetails(
            'lifeadmin_reminders',
            'LifeAdmin Reminders',
            channelDescription: 'Document and subscription expiry reminders',
            importance: Importance.high,
            priority: Priority.high,
            icon: '@mipmap/ic_launcher',
            enableLights: true,
            ledColor: Color(0xFF00D4AA),
            ledOnMs: 1000,
            ledOffMs: 500,
          ),
          iOS: DarwinNotificationDetails(
            presentAlert: true,
            presentBadge: true,
            presentSound: true,
          ),
        ),
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
      );
    } catch (e) {
      debugPrint('Notification scheduling error: $e');
    }
  }

  Future<void> cancelAll(int baseId) async {
    for (final days in [0, 1, 7, 30]) {
      await _plugin.cancel(baseId + days);
    }
  }

  Future<void> showImmediate({
    required int id,
    required String title,
    required String body,
  }) async {
    await _plugin.show(
      id,
      title,
      body,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'lifeadmin_reminders',
          'LifeAdmin Reminders',
          importance: Importance.defaultImportance,
          priority: Priority.defaultPriority,
        ),
      ),
    );
  }
}
