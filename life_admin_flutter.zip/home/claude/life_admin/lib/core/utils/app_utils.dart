// lib/core/utils/date_utils.dart
import 'package:intl/intl.dart';
import '../constants/app_constants.dart';
import '../theme/app_theme.dart';
import 'package:flutter/material.dart';

class AppDateUtils {
  AppDateUtils._();

  static final _displayFormat = DateFormat('MMM d, yyyy');
  static final _shortFormat = DateFormat('MMM d');
  static final _monthYear = DateFormat('MMM yyyy');

  static String format(DateTime date) => _displayFormat.format(date);
  static String formatShort(DateTime date) => _shortFormat.format(date);
  static String formatMonthYear(DateTime date) => _monthYear.format(date);

  static String formatRelative(DateTime date) {
    final now = DateTime.now();
    final diff = now.difference(date);
    if (diff.inDays == 0) return 'Today';
    if (diff.inDays == 1) return 'Yesterday';
    if (diff.inDays < 0) {
      final ahead = date.difference(now);
      if (ahead.inDays == 0) return 'Today';
      if (ahead.inDays == 1) return 'Tomorrow';
      if (ahead.inDays < 7) return 'In ${ahead.inDays} days';
      if (ahead.inDays < 30) return 'In ${(ahead.inDays / 7).round()} weeks';
      if (ahead.inDays < 365) return 'In ${(ahead.inDays / 30).round()} months';
      return 'In ${(ahead.inDays / 365).round()} years';
    }
    return '${diff.inDays} days ago';
  }

  static int daysUntil(DateTime expiry) {
    final now = DateTime.now();
    final diff = expiry.difference(DateTime(now.year, now.month, now.day));
    return diff.inDays;
  }

  static UrgencyLevel urgencyFromDays(int days) {
    if (days < 0) return UrgencyLevel.expired;
    if (days <= AppConstants.urgencyRed) return UrgencyLevel.critical;
    if (days <= AppConstants.urgencyOrange) return UrgencyLevel.warning;
    return UrgencyLevel.safe;
  }

  static String urgencyLabel(int days) {
    if (days < 0) return 'Expired ${(-days)} days ago';
    if (days == 0) return 'Expires today!';
    if (days == 1) return 'Expires tomorrow!';
    if (days <= 7) return 'Expires in $days days';
    if (days <= 30) return 'Expires in $days days';
    return 'Expires ${format(DateTime.now().add(Duration(days: days)))}';
  }

  static String formatCurrency(double amount, {String symbol = '\$'}) {
    if (amount == 0) return '${symbol}0';
    return '$symbol${amount.toStringAsFixed(amount == amount.toInt() ? 0 : 2)}';
  }

  static DateTime? tryParse(String? s) {
    if (s == null || s.isEmpty) return null;
    return DateTime.tryParse(s);
  }

  static DateTime nextBillingDate(DateTime lastDate, String cycle, {int customDays = 30}) {
    final now = DateTime.now();
    DateTime next = lastDate;
    while (next.isBefore(now)) {
      switch (cycle) {
        case AppConstants.cycleMonthly:
          next = DateTime(next.year, next.month + 1, next.day);
          break;
        case AppConstants.cycleYearly:
          next = DateTime(next.year + 1, next.month, next.day);
          break;
        case AppConstants.cycleWeekly:
          next = next.add(const Duration(days: 7));
          break;
        default:
          next = next.add(Duration(days: customDays));
      }
    }
    return next;
  }
}

enum UrgencyLevel { expired, critical, warning, safe }

extension UrgencyExtension on UrgencyLevel {
  Color get color {
    switch (this) {
      case UrgencyLevel.expired:
        return AppColors.expired;
      case UrgencyLevel.critical:
        return AppColors.expiringSoon;
      case UrgencyLevel.warning:
        return AppColors.expiringSoon;
      case UrgencyLevel.safe:
        return AppColors.safe;
    }
  }

  Color get bgColor {
    switch (this) {
      case UrgencyLevel.expired:
        return AppColors.expiredBg;
      case UrgencyLevel.critical:
        return AppColors.expiringSoonBg;
      case UrgencyLevel.warning:
        return AppColors.expiringSoonBg;
      case UrgencyLevel.safe:
        return AppColors.safeBg;
    }
  }

  String get emoji {
    switch (this) {
      case UrgencyLevel.expired:
        return '🔴';
      case UrgencyLevel.critical:
        return '🟠';
      case UrgencyLevel.warning:
        return '🟡';
      case UrgencyLevel.safe:
        return '🟢';
    }
  }

  String get label {
    switch (this) {
      case UrgencyLevel.expired:
        return 'EXPIRED';
      case UrgencyLevel.critical:
        return 'URGENT';
      case UrgencyLevel.warning:
        return 'SOON';
      case UrgencyLevel.safe:
        return 'SAFE';
    }
  }
}
