// lib/core/constants/app_constants.dart

class AppConstants {
  AppConstants._();

  static const String appName = 'LifeAdmin';
  static const String appTagline = 'Your private life, organized.';
  static const String dbName = 'lifeadmin.db';
  static const int dbVersion = 1;

  // Tables
  static const String tableDocuments = 'documents';
  static const String tableSubscriptions = 'subscriptions';
  static const String tableVehicles = 'vehicles';
  static const String tablePassports = 'passports';
  static const String tableSims = 'sims';
  static const String tableCategories = 'custom_categories';

  // Document types
  static const String docTypeCnic = 'CNIC / National ID';
  static const String docTypeDriving = 'Driving License';
  static const String docTypeCompany = 'Company ID';
  static const String docTypeCustom = 'Custom';

  // Billing cycles
  static const String cycleMonthly = 'Monthly';
  static const String cycleYearly = 'Yearly';
  static const String cycleWeekly = 'Weekly';
  static const String cycleCustom = 'Custom';

  // Urgency thresholds (days)
  static const int urgencyExpired = 0;
  static const int urgencyRed = 7;
  static const int urgencyOrange = 30;

  // Notification IDs base
  static const int notifBaseDocuments = 1000;
  static const int notifBaseSubscriptions = 2000;
  static const int notifBaseVehicles = 3000;
  static const int notifBasePassports = 4000;
  static const int notifBaseSims = 5000;

  // Reminder days
  static const List<int> defaultReminderDays = [1, 7, 30];

  // Subscription icons
  static const Map<String, String> subscriptionIcons = {
    'Netflix': '🎬',
    'Internet Bill': '🌐',
    'Mobile Package': '📱',
    'Insurance': '🛡️',
    'Gym Membership': '💪',
    'YouTube Premium': '▶️',
    'Spotify': '🎵',
    'Amazon Prime': '📦',
    'Electricity': '⚡',
    'Gas Bill': '🔥',
    'Water Bill': '💧',
    'Custom': '📋',
  };

  static const List<String> defaultDocumentTypes = [
    'CNIC / National ID',
    'Driving License',
    'Company ID',
    'Student ID',
    'Health Card',
    'Library Card',
    'Voter Card',
    'Custom',
  ];

  static const List<String> defaultSubscriptions = [
    'Netflix',
    'Internet Bill',
    'Mobile Package',
    'Insurance',
    'Gym Membership',
    'YouTube Premium',
    'Spotify',
    'Amazon Prime',
    'Electricity',
    'Gas Bill',
    'Water Bill',
    'Custom',
  ];
}
