// lib/data/database/database_helper.dart
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/models.dart';
import '../../core/constants/app_constants.dart';

class DatabaseHelper {
  DatabaseHelper._();
  static final DatabaseHelper instance = DatabaseHelper._();
  static Database? _db;

  Future<Database> get db async {
    _db ??= await _init();
    return _db!;
  }

  Future<Database> _init() async {
    final path = join(await getDatabasesPath(), AppConstants.dbName);
    return openDatabase(path, version: AppConstants.dbVersion, onCreate: _create);
  }

  Future<void> _create(Database db, int version) async {
    await db.execute('''
      CREATE TABLE ${AppConstants.tableDocuments} (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        type TEXT NOT NULL,
        document_number TEXT NOT NULL,
        issue_date TEXT,
        expiry_date TEXT,
        notes TEXT DEFAULT '',
        reminder_days TEXT DEFAULT '1,7,30',
        created_at TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE ${AppConstants.tableSubscriptions} (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        icon TEXT DEFAULT '📋',
        amount REAL DEFAULT 0,
        currency TEXT DEFAULT 'USD',
        billing_cycle TEXT NOT NULL,
        custom_days INTEGER DEFAULT 30,
        renewal_date TEXT NOT NULL,
        auto_renew INTEGER DEFAULT 0,
        notes TEXT DEFAULT '',
        reminder_days TEXT DEFAULT '1,3,7',
        is_active INTEGER DEFAULT 1,
        created_at TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE ${AppConstants.tableVehicles} (
        id TEXT PRIMARY KEY,
        vehicle_type TEXT NOT NULL,
        registration_number TEXT NOT NULL,
        make TEXT DEFAULT '',
        model TEXT DEFAULT '',
        token_expiry TEXT,
        insurance_expiry TEXT,
        fitness_expiry TEXT,
        notes TEXT DEFAULT '',
        reminder_days TEXT DEFAULT '1,7,30',
        created_at TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE ${AppConstants.tablePassports} (
        id TEXT PRIMARY KEY,
        holder_name TEXT NOT NULL,
        passport_number TEXT NOT NULL,
        country TEXT NOT NULL,
        issue_date TEXT,
        expiry_date TEXT,
        visa_country TEXT DEFAULT '',
        visa_expiry TEXT,
        notes TEXT DEFAULT '',
        reminder_days TEXT DEFAULT '30,90,180',
        created_at TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE ${AppConstants.tableSims} (
        id TEXT PRIMARY KEY,
        sim_number TEXT NOT NULL,
        network_provider TEXT NOT NULL,
        last_recharge_date TEXT,
        expiry_date TEXT,
        notes TEXT DEFAULT '',
        reminder_days TEXT DEFAULT '1,3,7',
        created_at TEXT NOT NULL
      )
    ''');
  }

  // ─── Documents ─────────────────────────────────────────────────────────────

  Future<List<DocumentModel>> getDocuments() async {
    final r = await (await db).query(AppConstants.tableDocuments, orderBy: 'created_at DESC');
    return r.map(DocumentModel.fromMap).toList();
  }

  Future<void> insertDocument(DocumentModel d) async =>
      (await db).insert(AppConstants.tableDocuments, d.toMap());

  Future<void> updateDocument(DocumentModel d) async =>
      (await db).update(AppConstants.tableDocuments, d.toMap(),
          where: 'id = ?', whereArgs: [d.id]);

  Future<void> deleteDocument(String id) async =>
      (await db).delete(AppConstants.tableDocuments, where: 'id = ?', whereArgs: [id]);

  // ─── Subscriptions ──────────────────────────────────────────────────────────

  Future<List<SubscriptionModel>> getSubscriptions() async {
    final r = await (await db).query(AppConstants.tableSubscriptions,
        orderBy: 'renewal_date ASC');
    return r.map(SubscriptionModel.fromMap).toList();
  }

  Future<void> insertSubscription(SubscriptionModel s) async =>
      (await db).insert(AppConstants.tableSubscriptions, s.toMap());

  Future<void> updateSubscription(SubscriptionModel s) async =>
      (await db).update(AppConstants.tableSubscriptions, s.toMap(),
          where: 'id = ?', whereArgs: [s.id]);

  Future<void> deleteSubscription(String id) async =>
      (await db).delete(AppConstants.tableSubscriptions, where: 'id = ?', whereArgs: [id]);

  // ─── Vehicles ───────────────────────────────────────────────────────────────

  Future<List<VehicleModel>> getVehicles() async {
    final r = await (await db).query(AppConstants.tableVehicles, orderBy: 'created_at DESC');
    return r.map(VehicleModel.fromMap).toList();
  }

  Future<void> insertVehicle(VehicleModel v) async =>
      (await db).insert(AppConstants.tableVehicles, v.toMap());

  Future<void> updateVehicle(VehicleModel v) async =>
      (await db).update(AppConstants.tableVehicles, v.toMap(),
          where: 'id = ?', whereArgs: [v.id]);

  Future<void> deleteVehicle(String id) async =>
      (await db).delete(AppConstants.tableVehicles, where: 'id = ?', whereArgs: [id]);

  // ─── Passports ──────────────────────────────────────────────────────────────

  Future<List<PassportModel>> getPassports() async {
    final r = await (await db).query(AppConstants.tablePassports, orderBy: 'created_at DESC');
    return r.map(PassportModel.fromMap).toList();
  }

  Future<void> insertPassport(PassportModel p) async =>
      (await db).insert(AppConstants.tablePassports, p.toMap());

  Future<void> updatePassport(PassportModel p) async =>
      (await db).update(AppConstants.tablePassports, p.toMap(),
          where: 'id = ?', whereArgs: [p.id]);

  Future<void> deletePassport(String id) async =>
      (await db).delete(AppConstants.tablePassports, where: 'id = ?', whereArgs: [id]);

  // ─── SIMs ────────────────────────────────────────────────────────────────────

  Future<List<SimModel>> getSims() async {
    final r = await (await db).query(AppConstants.tableSims, orderBy: 'expiry_date ASC');
    return r.map(SimModel.fromMap).toList();
  }

  Future<void> insertSim(SimModel s) async =>
      (await db).insert(AppConstants.tableSims, s.toMap());

  Future<void> updateSim(SimModel s) async =>
      (await db).update(AppConstants.tableSims, s.toMap(),
          where: 'id = ?', whereArgs: [s.id]);

  Future<void> deleteSim(String id) async =>
      (await db).delete(AppConstants.tableSims, where: 'id = ?', whereArgs: [id]);

  // ─── Backup/Restore ──────────────────────────────────────────────────────────

  Future<Map<String, dynamic>> exportAll() async {
    final database = await db;
    return {
      'version': 1,
      'exported_at': DateTime.now().toIso8601String(),
      'documents': await database.query(AppConstants.tableDocuments),
      'subscriptions': await database.query(AppConstants.tableSubscriptions),
      'vehicles': await database.query(AppConstants.tableVehicles),
      'passports': await database.query(AppConstants.tablePassports),
      'sims': await database.query(AppConstants.tableSims),
    };
  }

  Future<void> importAll(Map<String, dynamic> data) async {
    final database = await db;
    await database.transaction((txn) async {
      for (final table in [
        AppConstants.tableDocuments,
        AppConstants.tableSubscriptions,
        AppConstants.tableVehicles,
        AppConstants.tablePassports,
        AppConstants.tableSims,
      ]) {
        await txn.delete(table);
      }
      for (final row in (data['documents'] as List? ?? [])) {
        await txn.insert(AppConstants.tableDocuments, Map<String, dynamic>.from(row));
      }
      for (final row in (data['subscriptions'] as List? ?? [])) {
        await txn.insert(AppConstants.tableSubscriptions, Map<String, dynamic>.from(row));
      }
      for (final row in (data['vehicles'] as List? ?? [])) {
        await txn.insert(AppConstants.tableVehicles, Map<String, dynamic>.from(row));
      }
      for (final row in (data['passports'] as List? ?? [])) {
        await txn.insert(AppConstants.tablePassports, Map<String, dynamic>.from(row));
      }
      for (final row in (data['sims'] as List? ?? [])) {
        await txn.insert(AppConstants.tableSims, Map<String, dynamic>.from(row));
      }
    });
  }

  Future<void> clearAll() async {
    final database = await db;
    await database.transaction((txn) async {
      for (final table in [
        AppConstants.tableDocuments,
        AppConstants.tableSubscriptions,
        AppConstants.tableVehicles,
        AppConstants.tablePassports,
        AppConstants.tableSims,
      ]) {
        await txn.delete(table);
      }
    });
  }
}
