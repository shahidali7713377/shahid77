// lib/data/models/document_model.dart

class DocumentModel {
  final String id;
  final String name;
  final String type;
  final String documentNumber;
  final DateTime? issueDate;
  final DateTime? expiryDate;
  final String notes;
  final List<int> reminderDays;
  final DateTime createdAt;

  const DocumentModel({
    required this.id,
    required this.name,
    required this.type,
    required this.documentNumber,
    this.issueDate,
    this.expiryDate,
    this.notes = '',
    this.reminderDays = const [1, 7, 30],
    required this.createdAt,
  });

  bool get hasExpiry => expiryDate != null;

  int get daysUntilExpiry {
    if (expiryDate == null) return 999;
    final now = DateTime.now();
    return expiryDate!.difference(DateTime(now.year, now.month, now.day)).inDays;
  }

  DocumentModel copyWith({
    String? id,
    String? name,
    String? type,
    String? documentNumber,
    DateTime? issueDate,
    DateTime? expiryDate,
    String? notes,
    List<int>? reminderDays,
    DateTime? createdAt,
  }) =>
      DocumentModel(
        id: id ?? this.id,
        name: name ?? this.name,
        type: type ?? this.type,
        documentNumber: documentNumber ?? this.documentNumber,
        issueDate: issueDate ?? this.issueDate,
        expiryDate: expiryDate ?? this.expiryDate,
        notes: notes ?? this.notes,
        reminderDays: reminderDays ?? this.reminderDays,
        createdAt: createdAt ?? this.createdAt,
      );

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'type': type,
        'document_number': documentNumber,
        'issue_date': issueDate?.toIso8601String(),
        'expiry_date': expiryDate?.toIso8601String(),
        'notes': notes,
        'reminder_days': reminderDays.join(','),
        'created_at': createdAt.toIso8601String(),
      };

  factory DocumentModel.fromMap(Map<String, dynamic> m) => DocumentModel(
        id: m['id'] as String,
        name: m['name'] as String,
        type: m['type'] as String,
        documentNumber: m['document_number'] as String,
        issueDate: m['issue_date'] != null
            ? DateTime.tryParse(m['issue_date'] as String)
            : null,
        expiryDate: m['expiry_date'] != null
            ? DateTime.tryParse(m['expiry_date'] as String)
            : null,
        notes: m['notes'] as String? ?? '',
        reminderDays: (m['reminder_days'] as String? ?? '1,7,30')
            .split(',')
            .map((e) => int.tryParse(e) ?? 7)
            .toList(),
        createdAt: DateTime.parse(m['created_at'] as String),
      );

  Map<String, dynamic> toJson() => toMap();
  factory DocumentModel.fromJson(Map<String, dynamic> j) =>
      DocumentModel.fromMap(j);
}

// ─────────────────────────────────────────────────────────────────────────────

class SubscriptionModel {
  final String id;
  final String name;
  final String icon;
  final double amount;
  final String currency;
  final String billingCycle;
  final int customDays;
  final DateTime renewalDate;
  final bool autoRenew;
  final String notes;
  final List<int> reminderDays;
  final bool isActive;
  final DateTime createdAt;

  const SubscriptionModel({
    required this.id,
    required this.name,
    required this.icon,
    required this.amount,
    this.currency = 'USD',
    required this.billingCycle,
    this.customDays = 30,
    required this.renewalDate,
    this.autoRenew = false,
    this.notes = '',
    this.reminderDays = const [1, 3, 7],
    this.isActive = true,
    required this.createdAt,
  });

  int get daysUntilRenewal {
    final now = DateTime.now();
    return renewalDate.difference(DateTime(now.year, now.month, now.day)).inDays;
  }

  SubscriptionModel copyWith({
    String? id,
    String? name,
    String? icon,
    double? amount,
    String? currency,
    String? billingCycle,
    int? customDays,
    DateTime? renewalDate,
    bool? autoRenew,
    String? notes,
    List<int>? reminderDays,
    bool? isActive,
    DateTime? createdAt,
  }) =>
      SubscriptionModel(
        id: id ?? this.id,
        name: name ?? this.name,
        icon: icon ?? this.icon,
        amount: amount ?? this.amount,
        currency: currency ?? this.currency,
        billingCycle: billingCycle ?? this.billingCycle,
        customDays: customDays ?? this.customDays,
        renewalDate: renewalDate ?? this.renewalDate,
        autoRenew: autoRenew ?? this.autoRenew,
        notes: notes ?? this.notes,
        reminderDays: reminderDays ?? this.reminderDays,
        isActive: isActive ?? this.isActive,
        createdAt: createdAt ?? this.createdAt,
      );

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'icon': icon,
        'amount': amount,
        'currency': currency,
        'billing_cycle': billingCycle,
        'custom_days': customDays,
        'renewal_date': renewalDate.toIso8601String(),
        'auto_renew': autoRenew ? 1 : 0,
        'notes': notes,
        'reminder_days': reminderDays.join(','),
        'is_active': isActive ? 1 : 0,
        'created_at': createdAt.toIso8601String(),
      };

  factory SubscriptionModel.fromMap(Map<String, dynamic> m) =>
      SubscriptionModel(
        id: m['id'] as String,
        name: m['name'] as String,
        icon: m['icon'] as String? ?? '📋',
        amount: (m['amount'] as num).toDouble(),
        currency: m['currency'] as String? ?? 'USD',
        billingCycle: m['billing_cycle'] as String,
        customDays: m['custom_days'] as int? ?? 30,
        renewalDate: DateTime.parse(m['renewal_date'] as String),
        autoRenew: (m['auto_renew'] as int?) == 1,
        notes: m['notes'] as String? ?? '',
        reminderDays: (m['reminder_days'] as String? ?? '1,3,7')
            .split(',')
            .map((e) => int.tryParse(e) ?? 3)
            .toList(),
        isActive: (m['is_active'] as int?) != 0,
        createdAt: DateTime.parse(m['created_at'] as String),
      );

  Map<String, dynamic> toJson() => toMap();
  factory SubscriptionModel.fromJson(Map<String, dynamic> j) =>
      SubscriptionModel.fromMap(j);
}

// ─────────────────────────────────────────────────────────────────────────────

class VehicleModel {
  final String id;
  final String vehicleType;
  final String registrationNumber;
  final String make;
  final String model;
  final DateTime? tokenExpiry;
  final DateTime? insuranceExpiry;
  final DateTime? fitnessExpiry;
  final String notes;
  final List<int> reminderDays;
  final DateTime createdAt;

  const VehicleModel({
    required this.id,
    required this.vehicleType,
    required this.registrationNumber,
    this.make = '',
    this.model = '',
    this.tokenExpiry,
    this.insuranceExpiry,
    this.fitnessExpiry,
    this.notes = '',
    this.reminderDays = const [1, 7, 30],
    required this.createdAt,
  });

  /// Earliest expiry date across all tracked fields
  DateTime? get nearestExpiry {
    final dates = [tokenExpiry, insuranceExpiry, fitnessExpiry]
        .whereType<DateTime>()
        .toList();
    if (dates.isEmpty) return null;
    dates.sort();
    return dates.first;
  }

  int get daysUntilNearestExpiry {
    final expiry = nearestExpiry;
    if (expiry == null) return 999;
    final now = DateTime.now();
    return expiry.difference(DateTime(now.year, now.month, now.day)).inDays;
  }

  VehicleModel copyWith({
    String? id,
    String? vehicleType,
    String? registrationNumber,
    String? make,
    String? model,
    DateTime? tokenExpiry,
    DateTime? insuranceExpiry,
    DateTime? fitnessExpiry,
    String? notes,
    List<int>? reminderDays,
    DateTime? createdAt,
  }) =>
      VehicleModel(
        id: id ?? this.id,
        vehicleType: vehicleType ?? this.vehicleType,
        registrationNumber: registrationNumber ?? this.registrationNumber,
        make: make ?? this.make,
        model: model ?? this.model,
        tokenExpiry: tokenExpiry ?? this.tokenExpiry,
        insuranceExpiry: insuranceExpiry ?? this.insuranceExpiry,
        fitnessExpiry: fitnessExpiry ?? this.fitnessExpiry,
        notes: notes ?? this.notes,
        reminderDays: reminderDays ?? this.reminderDays,
        createdAt: createdAt ?? this.createdAt,
      );

  Map<String, dynamic> toMap() => {
        'id': id,
        'vehicle_type': vehicleType,
        'registration_number': registrationNumber,
        'make': make,
        'model': model,
        'token_expiry': tokenExpiry?.toIso8601String(),
        'insurance_expiry': insuranceExpiry?.toIso8601String(),
        'fitness_expiry': fitnessExpiry?.toIso8601String(),
        'notes': notes,
        'reminder_days': reminderDays.join(','),
        'created_at': createdAt.toIso8601String(),
      };

  factory VehicleModel.fromMap(Map<String, dynamic> m) => VehicleModel(
        id: m['id'] as String,
        vehicleType: m['vehicle_type'] as String,
        registrationNumber: m['registration_number'] as String,
        make: m['make'] as String? ?? '',
        model: m['model'] as String? ?? '',
        tokenExpiry: m['token_expiry'] != null
            ? DateTime.tryParse(m['token_expiry'] as String)
            : null,
        insuranceExpiry: m['insurance_expiry'] != null
            ? DateTime.tryParse(m['insurance_expiry'] as String)
            : null,
        fitnessExpiry: m['fitness_expiry'] != null
            ? DateTime.tryParse(m['fitness_expiry'] as String)
            : null,
        notes: m['notes'] as String? ?? '',
        reminderDays: (m['reminder_days'] as String? ?? '1,7,30')
            .split(',')
            .map((e) => int.tryParse(e) ?? 7)
            .toList(),
        createdAt: DateTime.parse(m['created_at'] as String),
      );

  Map<String, dynamic> toJson() => toMap();
  factory VehicleModel.fromJson(Map<String, dynamic> j) =>
      VehicleModel.fromMap(j);
}

// ─────────────────────────────────────────────────────────────────────────────

class PassportModel {
  final String id;
  final String holderName;
  final String passportNumber;
  final String country;
  final DateTime? issueDate;
  final DateTime? expiryDate;
  final String visaCountry;
  final DateTime? visaExpiry;
  final String notes;
  final List<int> reminderDays;
  final DateTime createdAt;

  const PassportModel({
    required this.id,
    required this.holderName,
    required this.passportNumber,
    required this.country,
    this.issueDate,
    this.expiryDate,
    this.visaCountry = '',
    this.visaExpiry,
    this.notes = '',
    this.reminderDays = const [30, 90, 180],
    required this.createdAt,
  });

  int get daysUntilExpiry {
    if (expiryDate == null) return 999;
    final now = DateTime.now();
    return expiryDate!.difference(DateTime(now.year, now.month, now.day)).inDays;
  }

  int get daysUntilVisaExpiry {
    if (visaExpiry == null) return 999;
    final now = DateTime.now();
    return visaExpiry!.difference(DateTime(now.year, now.month, now.day)).inDays;
  }

  PassportModel copyWith({
    String? id,
    String? holderName,
    String? passportNumber,
    String? country,
    DateTime? issueDate,
    DateTime? expiryDate,
    String? visaCountry,
    DateTime? visaExpiry,
    String? notes,
    List<int>? reminderDays,
    DateTime? createdAt,
  }) =>
      PassportModel(
        id: id ?? this.id,
        holderName: holderName ?? this.holderName,
        passportNumber: passportNumber ?? this.passportNumber,
        country: country ?? this.country,
        issueDate: issueDate ?? this.issueDate,
        expiryDate: expiryDate ?? this.expiryDate,
        visaCountry: visaCountry ?? this.visaCountry,
        visaExpiry: visaExpiry ?? this.visaExpiry,
        notes: notes ?? this.notes,
        reminderDays: reminderDays ?? this.reminderDays,
        createdAt: createdAt ?? this.createdAt,
      );

  Map<String, dynamic> toMap() => {
        'id': id,
        'holder_name': holderName,
        'passport_number': passportNumber,
        'country': country,
        'issue_date': issueDate?.toIso8601String(),
        'expiry_date': expiryDate?.toIso8601String(),
        'visa_country': visaCountry,
        'visa_expiry': visaExpiry?.toIso8601String(),
        'notes': notes,
        'reminder_days': reminderDays.join(','),
        'created_at': createdAt.toIso8601String(),
      };

  factory PassportModel.fromMap(Map<String, dynamic> m) => PassportModel(
        id: m['id'] as String,
        holderName: m['holder_name'] as String,
        passportNumber: m['passport_number'] as String,
        country: m['country'] as String,
        issueDate: m['issue_date'] != null
            ? DateTime.tryParse(m['issue_date'] as String)
            : null,
        expiryDate: m['expiry_date'] != null
            ? DateTime.tryParse(m['expiry_date'] as String)
            : null,
        visaCountry: m['visa_country'] as String? ?? '',
        visaExpiry: m['visa_expiry'] != null
            ? DateTime.tryParse(m['visa_expiry'] as String)
            : null,
        notes: m['notes'] as String? ?? '',
        reminderDays: (m['reminder_days'] as String? ?? '30,90,180')
            .split(',')
            .map((e) => int.tryParse(e) ?? 30)
            .toList(),
        createdAt: DateTime.parse(m['created_at'] as String),
      );

  Map<String, dynamic> toJson() => toMap();
  factory PassportModel.fromJson(Map<String, dynamic> j) =>
      PassportModel.fromMap(j);
}

// ─────────────────────────────────────────────────────────────────────────────

class SimModel {
  final String id;
  final String simNumber;
  final String networkProvider;
  final DateTime? lastRechargeDate;
  final DateTime? expiryDate;
  final String notes;
  final List<int> reminderDays;
  final DateTime createdAt;

  const SimModel({
    required this.id,
    required this.simNumber,
    required this.networkProvider,
    this.lastRechargeDate,
    this.expiryDate,
    this.notes = '',
    this.reminderDays = const [1, 3, 7],
    required this.createdAt,
  });

  int get daysUntilExpiry {
    if (expiryDate == null) return 999;
    final now = DateTime.now();
    return expiryDate!.difference(DateTime(now.year, now.month, now.day)).inDays;
  }

  SimModel copyWith({
    String? id,
    String? simNumber,
    String? networkProvider,
    DateTime? lastRechargeDate,
    DateTime? expiryDate,
    String? notes,
    List<int>? reminderDays,
    DateTime? createdAt,
  }) =>
      SimModel(
        id: id ?? this.id,
        simNumber: simNumber ?? this.simNumber,
        networkProvider: networkProvider ?? this.networkProvider,
        lastRechargeDate: lastRechargeDate ?? this.lastRechargeDate,
        expiryDate: expiryDate ?? this.expiryDate,
        notes: notes ?? this.notes,
        reminderDays: reminderDays ?? this.reminderDays,
        createdAt: createdAt ?? this.createdAt,
      );

  Map<String, dynamic> toMap() => {
        'id': id,
        'sim_number': simNumber,
        'network_provider': networkProvider,
        'last_recharge_date': lastRechargeDate?.toIso8601String(),
        'expiry_date': expiryDate?.toIso8601String(),
        'notes': notes,
        'reminder_days': reminderDays.join(','),
        'created_at': createdAt.toIso8601String(),
      };

  factory SimModel.fromMap(Map<String, dynamic> m) => SimModel(
        id: m['id'] as String,
        simNumber: m['sim_number'] as String,
        networkProvider: m['network_provider'] as String,
        lastRechargeDate: m['last_recharge_date'] != null
            ? DateTime.tryParse(m['last_recharge_date'] as String)
            : null,
        expiryDate: m['expiry_date'] != null
            ? DateTime.tryParse(m['expiry_date'] as String)
            : null,
        notes: m['notes'] as String? ?? '',
        reminderDays: (m['reminder_days'] as String? ?? '1,3,7')
            .split(',')
            .map((e) => int.tryParse(e) ?? 3)
            .toList(),
        createdAt: DateTime.parse(m['created_at'] as String),
      );

  Map<String, dynamic> toJson() => toMap();
  factory SimModel.fromJson(Map<String, dynamic> j) => SimModel.fromMap(j);
}
