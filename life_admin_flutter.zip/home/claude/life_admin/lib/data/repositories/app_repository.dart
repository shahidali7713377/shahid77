// lib/data/repositories/app_repository.dart
import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import '../database/database_helper.dart';
import '../models/models.dart';

class AppRepository {
  final _db = DatabaseHelper.instance;

  // ─── Documents ────────────────────────────────────────────────────────────
  Future<List<DocumentModel>> getDocuments() => _db.getDocuments();
  Future<void> addDocument(DocumentModel d) => _db.insertDocument(d);
  Future<void> updateDocument(DocumentModel d) => _db.updateDocument(d);
  Future<void> deleteDocument(String id) => _db.deleteDocument(id);

  // ─── Subscriptions ────────────────────────────────────────────────────────
  Future<List<SubscriptionModel>> getSubscriptions() => _db.getSubscriptions();
  Future<void> addSubscription(SubscriptionModel s) => _db.insertSubscription(s);
  Future<void> updateSubscription(SubscriptionModel s) => _db.updateSubscription(s);
  Future<void> deleteSubscription(String id) => _db.deleteSubscription(id);

  // ─── Vehicles ─────────────────────────────────────────────────────────────
  Future<List<VehicleModel>> getVehicles() => _db.getVehicles();
  Future<void> addVehicle(VehicleModel v) => _db.insertVehicle(v);
  Future<void> updateVehicle(VehicleModel v) => _db.updateVehicle(v);
  Future<void> deleteVehicle(String id) => _db.deleteVehicle(id);

  // ─── Passports ────────────────────────────────────────────────────────────
  Future<List<PassportModel>> getPassports() => _db.getPassports();
  Future<void> addPassport(PassportModel p) => _db.insertPassport(p);
  Future<void> updatePassport(PassportModel p) => _db.updatePassport(p);
  Future<void> deletePassport(String id) => _db.deletePassport(id);

  // ─── SIMs ─────────────────────────────────────────────────────────────────
  Future<List<SimModel>> getSims() => _db.getSims();
  Future<void> addSim(SimModel s) => _db.insertSim(s);
  Future<void> updateSim(SimModel s) => _db.updateSim(s);
  Future<void> deleteSim(String id) => _db.deleteSim(id);

  // ─── Backup ───────────────────────────────────────────────────────────────
  Future<String> exportToFile() async {
    final data = await _db.exportAll();
    final json = jsonEncode(data);
    final dir = await getExternalStorageDirectory() ??
        await getApplicationDocumentsDirectory();
    final ts = DateTime.now().millisecondsSinceEpoch;
    final file = File('${dir.path}/lifeadmin_backup_$ts.json');
    await file.writeAsString(json);
    return file.path;
  }

  Future<void> importFromFile(String path) async {
    final file = File(path);
    final data = jsonDecode(await file.readAsString()) as Map<String, dynamic>;
    await _db.importAll(data);
  }

  Future<void> clearAll() => _db.clearAll();
}
