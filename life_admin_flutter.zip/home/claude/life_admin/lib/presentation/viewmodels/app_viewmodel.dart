// lib/presentation/viewmodels/app_viewmodel.dart
import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';
import '../../data/models/models.dart';
import '../../data/repositories/app_repository.dart';
import '../../core/services/notification_service.dart';
import '../../core/constants/app_constants.dart';
import '../../core/utils/app_utils.dart';

enum ViewState { idle, loading, success, error }

class AppViewModel extends ChangeNotifier {
  final AppRepository _repo = AppRepository();
  final _ns = NotificationService.instance;
  final _uuid = const Uuid();

  // ─── State ────────────────────────────────────────────────────────────────
  ViewState _state = ViewState.idle;
  ViewState get state => _state;
  String? _error;
  String? get error => _error;

  List<DocumentModel> _documents = [];
  List<SubscriptionModel> _subscriptions = [];
  List<VehicleModel> _vehicles = [];
  List<PassportModel> _passports = [];
  List<SimModel> _sims = [];

  List<DocumentModel> get documents => _documents;
  List<SubscriptionModel> get subscriptions => _subscriptions;
  List<VehicleModel> get vehicles => _vehicles;
  List<PassportModel> get passports => _passports;
  List<SimModel> get sims => _sims;

  String _searchQuery = '';
  String get searchQuery => _searchQuery;

  // ─── Initialization ───────────────────────────────────────────────────────

  Future<void> init() async {
    _state = ViewState.loading;
    notifyListeners();
    try {
      await Future.wait([
        _loadDocuments(),
        _loadSubscriptions(),
        _loadVehicles(),
        _loadPassports(),
        _loadSims(),
      ]);
      _state = ViewState.success;
    } catch (e) {
      _error = e.toString();
      _state = ViewState.error;
    }
    notifyListeners();
  }

  Future<void> _loadDocuments() async {
    _documents = await _repo.getDocuments();
  }

  Future<void> _loadSubscriptions() async {
    _subscriptions = await _repo.getSubscriptions();
  }

  Future<void> _loadVehicles() async {
    _vehicles = await _repo.getVehicles();
  }

  Future<void> _loadPassports() async {
    _passports = await _repo.getPassports();
  }

  Future<void> _loadSims() async {
    _sims = await _repo.getSims();
  }

  // ─── Dashboard Analytics ──────────────────────────────────────────────────

  int get totalItems =>
      _documents.length + _subscriptions.length + _vehicles.length +
      _passports.length + _sims.length;

  List<_ExpiryItem> get allExpiryItems {
    final items = <_ExpiryItem>[];

    for (final d in _documents) {
      if (d.expiryDate != null) {
        items.add(_ExpiryItem(d.name, d.daysUntilExpiry, '🪪', 'Document'));
      }
    }
    for (final s in _subscriptions.where((s) => s.isActive)) {
      items.add(_ExpiryItem(s.name, s.daysUntilRenewal, s.icon, 'Subscription'));
    }
    for (final v in _vehicles) {
      final days = v.daysUntilNearestExpiry;
      if (days < 999) {
        items.add(_ExpiryItem(v.registrationNumber, days, '🚗', 'Vehicle'));
      }
    }
    for (final p in _passports) {
      if (p.expiryDate != null) {
        items.add(_ExpiryItem(p.holderName, p.daysUntilExpiry, '🛂', 'Passport'));
      }
    }
    for (final s in _sims) {
      if (s.expiryDate != null) {
        items.add(_ExpiryItem(s.simNumber, s.daysUntilExpiry, '📱', 'SIM'));
      }
    }

    items.sort((a, b) => a.daysUntil.compareTo(b.daysUntil));
    return items;
  }

  List<_ExpiryItem> get expiredItems =>
      allExpiryItems.where((e) => e.daysUntil < 0).toList();

  List<_ExpiryItem> get expiringThisWeek =>
      allExpiryItems.where((e) => e.daysUntil >= 0 && e.daysUntil <= 7).toList();

  List<_ExpiryItem> get expiringThisMonth =>
      allExpiryItems.where((e) => e.daysUntil > 7 && e.daysUntil <= 30).toList();

  double get monthlySubscriptionTotal {
    double total = 0;
    for (final s in _subscriptions.where((s) => s.isActive)) {
      switch (s.billingCycle) {
        case AppConstants.cycleMonthly:
          total += s.amount;
          break;
        case AppConstants.cycleYearly:
          total += s.amount / 12;
          break;
        case AppConstants.cycleWeekly:
          total += s.amount * 4.33;
          break;
        default:
          total += s.amount / (s.customDays / 30);
      }
    }
    return total;
  }

  // ─── Documents CRUD ───────────────────────────────────────────────────────

  Future<void> addDocument({
    required String name,
    required String type,
    required String documentNumber,
    DateTime? issueDate,
    DateTime? expiryDate,
    String notes = '',
    List<int> reminderDays = const [1, 7, 30],
  }) async {
    final doc = DocumentModel(
      id: _uuid.v4(),
      name: name,
      type: type,
      documentNumber: documentNumber,
      issueDate: issueDate,
      expiryDate: expiryDate,
      notes: notes,
      reminderDays: reminderDays,
      createdAt: DateTime.now(),
    );
    await _repo.addDocument(doc);
    if (expiryDate != null) {
      await _ns.scheduleReminders(
        baseId: AppConstants.notifBaseDocuments + doc.hashCode.abs() % 100,
        title: name,
        body: '$type expires',
        expiryDate: expiryDate,
        reminderDays: reminderDays,
      );
    }
    await _loadDocuments();
    notifyListeners();
  }

  Future<void> updateDocument(DocumentModel doc) async {
    await _repo.updateDocument(doc);
    if (doc.expiryDate != null) {
      await _ns.scheduleReminders(
        baseId: AppConstants.notifBaseDocuments + doc.hashCode.abs() % 100,
        title: doc.name,
        body: '${doc.type} expires',
        expiryDate: doc.expiryDate!,
        reminderDays: doc.reminderDays,
      );
    }
    await _loadDocuments();
    notifyListeners();
  }

  Future<void> deleteDocument(String id) async {
    await _repo.deleteDocument(id);
    await _loadDocuments();
    notifyListeners();
  }

  // ─── Subscriptions CRUD ───────────────────────────────────────────────────

  Future<void> addSubscription({
    required String name,
    required String icon,
    required double amount,
    String currency = 'USD',
    required String billingCycle,
    int customDays = 30,
    required DateTime renewalDate,
    bool autoRenew = false,
    String notes = '',
    List<int> reminderDays = const [1, 3, 7],
  }) async {
    final sub = SubscriptionModel(
      id: _uuid.v4(),
      name: name,
      icon: icon,
      amount: amount,
      currency: currency,
      billingCycle: billingCycle,
      customDays: customDays,
      renewalDate: renewalDate,
      autoRenew: autoRenew,
      notes: notes,
      reminderDays: reminderDays,
      createdAt: DateTime.now(),
    );
    await _repo.addSubscription(sub);
    await _ns.scheduleReminders(
      baseId: AppConstants.notifBaseSubscriptions + sub.hashCode.abs() % 100,
      title: name,
      body: '$name subscription renews',
      expiryDate: renewalDate,
      reminderDays: reminderDays,
    );
    await _loadSubscriptions();
    notifyListeners();
  }

  Future<void> updateSubscription(SubscriptionModel sub) async {
    await _repo.updateSubscription(sub);
    await _ns.scheduleReminders(
      baseId: AppConstants.notifBaseSubscriptions + sub.hashCode.abs() % 100,
      title: sub.name,
      body: '${sub.name} subscription renews',
      expiryDate: sub.renewalDate,
      reminderDays: sub.reminderDays,
    );
    await _loadSubscriptions();
    notifyListeners();
  }

  Future<void> deleteSubscription(String id) async {
    await _repo.deleteSubscription(id);
    await _loadSubscriptions();
    notifyListeners();
  }

  // ─── Vehicles CRUD ────────────────────────────────────────────────────────

  Future<void> addVehicle({
    required String vehicleType,
    required String registrationNumber,
    String make = '',
    String model = '',
    DateTime? tokenExpiry,
    DateTime? insuranceExpiry,
    DateTime? fitnessExpiry,
    String notes = '',
    List<int> reminderDays = const [1, 7, 30],
  }) async {
    final v = VehicleModel(
      id: _uuid.v4(),
      vehicleType: vehicleType,
      registrationNumber: registrationNumber,
      make: make,
      model: model,
      tokenExpiry: tokenExpiry,
      insuranceExpiry: insuranceExpiry,
      fitnessExpiry: fitnessExpiry,
      notes: notes,
      reminderDays: reminderDays,
      createdAt: DateTime.now(),
    );
    await _repo.addVehicle(v);
    await _scheduleVehicleReminders(v);
    await _loadVehicles();
    notifyListeners();
  }

  Future<void> updateVehicle(VehicleModel v) async {
    await _repo.updateVehicle(v);
    await _scheduleVehicleReminders(v);
    await _loadVehicles();
    notifyListeners();
  }

  Future<void> _scheduleVehicleReminders(VehicleModel v) async {
    final base = AppConstants.notifBaseVehicles + v.hashCode.abs() % 100;
    if (v.tokenExpiry != null) {
      await _ns.scheduleReminders(
          baseId: base,
          title: '🚗 Token Tax: ${v.registrationNumber}',
          body: 'Vehicle token expires',
          expiryDate: v.tokenExpiry!,
          reminderDays: v.reminderDays);
    }
    if (v.insuranceExpiry != null) {
      await _ns.scheduleReminders(
          baseId: base + 200,
          title: '🛡️ Insurance: ${v.registrationNumber}',
          body: 'Vehicle insurance expires',
          expiryDate: v.insuranceExpiry!,
          reminderDays: v.reminderDays);
    }
  }

  Future<void> deleteVehicle(String id) async {
    await _repo.deleteVehicle(id);
    await _loadVehicles();
    notifyListeners();
  }

  // ─── Passports CRUD ───────────────────────────────────────────────────────

  Future<void> addPassport({
    required String holderName,
    required String passportNumber,
    required String country,
    DateTime? issueDate,
    DateTime? expiryDate,
    String visaCountry = '',
    DateTime? visaExpiry,
    String notes = '',
    List<int> reminderDays = const [30, 90, 180],
  }) async {
    final p = PassportModel(
      id: _uuid.v4(),
      holderName: holderName,
      passportNumber: passportNumber,
      country: country,
      issueDate: issueDate,
      expiryDate: expiryDate,
      visaCountry: visaCountry,
      visaExpiry: visaExpiry,
      notes: notes,
      reminderDays: reminderDays,
      createdAt: DateTime.now(),
    );
    await _repo.addPassport(p);
    if (expiryDate != null) {
      await _ns.scheduleReminders(
        baseId: AppConstants.notifBasePassports + p.hashCode.abs() % 100,
        title: '🛂 Passport: $holderName',
        body: 'Passport expires',
        expiryDate: expiryDate,
        reminderDays: reminderDays,
      );
    }
    await _loadPassports();
    notifyListeners();
  }

  Future<void> updatePassport(PassportModel p) async {
    await _repo.updatePassport(p);
    if (p.expiryDate != null) {
      await _ns.scheduleReminders(
        baseId: AppConstants.notifBasePassports + p.hashCode.abs() % 100,
        title: '🛂 Passport: ${p.holderName}',
        body: 'Passport expires',
        expiryDate: p.expiryDate!,
        reminderDays: p.reminderDays,
      );
    }
    await _loadPassports();
    notifyListeners();
  }

  Future<void> deletePassport(String id) async {
    await _repo.deletePassport(id);
    await _loadPassports();
    notifyListeners();
  }

  // ─── SIMs CRUD ────────────────────────────────────────────────────────────

  Future<void> addSim({
    required String simNumber,
    required String networkProvider,
    DateTime? lastRechargeDate,
    DateTime? expiryDate,
    String notes = '',
    List<int> reminderDays = const [1, 3, 7],
  }) async {
    final s = SimModel(
      id: _uuid.v4(),
      simNumber: simNumber,
      networkProvider: networkProvider,
      lastRechargeDate: lastRechargeDate,
      expiryDate: expiryDate,
      notes: notes,
      reminderDays: reminderDays,
      createdAt: DateTime.now(),
    );
    await _repo.addSim(s);
    if (expiryDate != null) {
      await _ns.scheduleReminders(
        baseId: AppConstants.notifBaseSims + s.hashCode.abs() % 100,
        title: '📱 SIM: $simNumber',
        body: 'SIM expires',
        expiryDate: expiryDate,
        reminderDays: reminderDays,
      );
    }
    await _loadSims();
    notifyListeners();
  }

  Future<void> updateSim(SimModel s) async {
    await _repo.updateSim(s);
    if (s.expiryDate != null) {
      await _ns.scheduleReminders(
        baseId: AppConstants.notifBaseSims + s.hashCode.abs() % 100,
        title: '📱 SIM: ${s.simNumber}',
        body: 'SIM expires',
        expiryDate: s.expiryDate!,
        reminderDays: s.reminderDays,
      );
    }
    await _loadSims();
    notifyListeners();
  }

  Future<void> deleteSim(String id) async {
    await _repo.deleteSim(id);
    await _loadSims();
    notifyListeners();
  }

  // ─── Search ───────────────────────────────────────────────────────────────

  void setSearch(String q) {
    _searchQuery = q.toLowerCase();
    notifyListeners();
  }

  List<DocumentModel> get filteredDocuments {
    if (_searchQuery.isEmpty) return _documents;
    return _documents.where((d) =>
        d.name.toLowerCase().contains(_searchQuery) ||
        d.documentNumber.toLowerCase().contains(_searchQuery) ||
        d.type.toLowerCase().contains(_searchQuery)).toList();
  }

  List<SubscriptionModel> get filteredSubscriptions {
    if (_searchQuery.isEmpty) return _subscriptions;
    return _subscriptions.where((s) =>
        s.name.toLowerCase().contains(_searchQuery)).toList();
  }

  // ─── Backup ───────────────────────────────────────────────────────────────

  Future<String?> exportData() async {
    try {
      return await _repo.exportToFile();
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      return null;
    }
  }

  Future<bool> importData(String path) async {
    try {
      await _repo.importFromFile(path);
      await init();
      return true;
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      return false;
    }
  }

  Future<void> clearAll() async {
    await _repo.clearAll();
    await init();
  }
}

class _ExpiryItem {
  final String name;
  final int daysUntil;
  final String icon;
  final String type;
  const _ExpiryItem(this.name, this.daysUntil, this.icon, this.type);

  UrgencyLevel get urgency => AppDateUtils.urgencyFromDays(daysUntil);
}
