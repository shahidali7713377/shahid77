// lib/presentation/screens/vehicles/vehicles_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import '../../viewmodels/app_viewmodel.dart';
import '../../widgets/common/common_widgets.dart';
import '../../../data/models/models.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/utils/app_utils.dart';

class VehiclesScreen extends StatelessWidget {
  const VehiclesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<AppViewModel>();
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(title: const Text('Vehicles')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _push(context, const AddEditVehicleScreen()),
        backgroundColor: AppColors.accent,
        foregroundColor: Colors.black,
        icon: const Icon(Icons.add),
        label: const Text('Add Vehicle', style: TextStyle(fontWeight: FontWeight.w700)),
      ).animate().scale(delay: 300.ms, duration: 400.ms, curve: Curves.elasticOut),
      body: vm.vehicles.isEmpty
          ? EmptyState(
              emoji: '🚗',
              title: 'No vehicles added',
              message: 'Track vehicle token, insurance, and fitness certificate expiry.',
              actionLabel: 'Add Vehicle',
              onAction: () => _push(context, const AddEditVehicleScreen()),
            )
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
              itemCount: vm.vehicles.length,
              itemBuilder: (ctx, i) {
                final v = vm.vehicles[i];
                return Animate(
                  effects: [FadeEffect(duration: 250.ms, delay: (i * 50).ms)],
                  child: SwipableCard(
                    id: v.id,
                    onDelete: () => vm.deleteVehicle(v.id),
                    child: _VehicleCard(
                      v: v,
                      isDark: isDark,
                      onTap: () => _push(context, AddEditVehicleScreen(existing: v)),
                    ),
                  ),
                );
              },
            ),
    );
  }

  void _push(BuildContext ctx, Widget w) =>
      Navigator.push(ctx, MaterialPageRoute(builder: (_) => w));
}

class _VehicleCard extends StatelessWidget {
  final VehicleModel v;
  final bool isDark;
  final VoidCallback onTap;
  const _VehicleCard({required this.v, required this.isDark, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final days = v.daysUntilNearestExpiry;
    final urgency = days < 999 ? AppDateUtils.urgencyFromDays(days) : UrgencyLevel.safe;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: isDark ? AppColors.darkCard : Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: urgency.color.withOpacity(0.15)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Text('🚗', style: TextStyle(fontSize: 24)),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        v.registrationNumber,
                        style: TextStyle(
                          color: isDark ? AppColors.textPrimary : AppColors.lightText,
                          fontWeight: FontWeight.w700,
                          fontSize: 16,
                        ),
                      ),
                      Text(
                        '${v.vehicleType}${v.make.isNotEmpty ? ' · ${v.make} ${v.model}' : ''}',
                        style: const TextStyle(color: AppColors.textMuted, fontSize: 11),
                      ),
                    ],
                  ),
                ),
                if (days < 999) UrgencyBadge(daysUntil: days, compact: true),
              ],
            ),
            const SizedBox(height: 12),
            _ExpiryRow(label: 'Token Tax', date: v.tokenExpiry, isDark: isDark),
            _ExpiryRow(label: 'Insurance', date: v.insuranceExpiry, isDark: isDark),
            _ExpiryRow(label: 'Fitness', date: v.fitnessExpiry, isDark: isDark),
          ],
        ),
      ),
    );
  }
}

class _ExpiryRow extends StatelessWidget {
  final String label;
  final DateTime? date;
  final bool isDark;
  const _ExpiryRow({required this.label, this.date, required this.isDark});

  @override
  Widget build(BuildContext context) {
    if (date == null) return const SizedBox.shrink();
    final days = AppDateUtils.daysUntil(date!);
    final urgency = AppDateUtils.urgencyFromDays(days);
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(
        children: [
          Text(label,
              style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
          const Spacer(),
          Text(
            AppDateUtils.format(date!),
            style: const TextStyle(color: AppColors.textSecondary, fontSize: 12),
          ),
          const SizedBox(width: 8),
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(color: urgency.color, shape: BoxShape.circle),
          ),
        ],
      ),
    );
  }
}

// ─── Add / Edit Vehicle ───────────────────────────────────────────────────────

class AddEditVehicleScreen extends StatefulWidget {
  final VehicleModel? existing;
  const AddEditVehicleScreen({super.key, this.existing});

  @override
  State<AddEditVehicleScreen> createState() => _AddEditVehicleScreenState();
}

class _AddEditVehicleScreenState extends State<AddEditVehicleScreen> {
  final _formKey = GlobalKey<FormState>();
  final _regCtrl = TextEditingController();
  final _makeCtrl = TextEditingController();
  final _modelCtrl = TextEditingController();
  final _notesCtrl = TextEditingController();

  String _vehicleType = 'Car';
  DateTime? _tokenExpiry;
  DateTime? _insuranceExpiry;
  DateTime? _fitnessExpiry;
  List<int> _reminderDays = [1, 7, 30];
  bool _loading = false;

  static const _types = ['Car', 'Motorcycle', 'Truck', 'Van', 'Bus', 'Other'];

  bool get _editing => widget.existing != null;

  @override
  void initState() {
    super.initState();
    if (_editing) {
      final v = widget.existing!;
      _regCtrl.text = v.registrationNumber;
      _makeCtrl.text = v.make;
      _modelCtrl.text = v.model;
      _notesCtrl.text = v.notes;
      _vehicleType = v.vehicleType;
      _tokenExpiry = v.tokenExpiry;
      _insuranceExpiry = v.insuranceExpiry;
      _fitnessExpiry = v.fitnessExpiry;
      _reminderDays = List.from(v.reminderDays);
    }
  }

  @override
  void dispose() {
    _regCtrl.dispose();
    _makeCtrl.dispose();
    _modelCtrl.dispose();
    _notesCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_editing ? 'Edit Vehicle' : 'Add Vehicle')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            _Label('Vehicle Type'),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: _types.map((t) {
                final sel = t == _vehicleType;
                return GestureDetector(
                  onTap: () => setState(() => _vehicleType = t),
                  child: AnimatedContainer(
                    duration: 150.ms,
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                    decoration: BoxDecoration(
                      color: sel ? AppColors.accentSoft : AppColors.darkCardElevated,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                          color: sel ? AppColors.accent : AppColors.darkBorder,
                          width: sel ? 1.5 : 1),
                    ),
                    child: Text(t,
                        style: TextStyle(
                            color: sel ? AppColors.accent : AppColors.textSecondary,
                            fontSize: 13,
                            fontWeight: sel ? FontWeight.w600 : FontWeight.w400)),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _regCtrl,
              decoration: const InputDecoration(
                  labelText: 'Registration Number *',
                  hintText: 'e.g. ABC-1234'),
              validator: (v) => v == null || v.trim().isEmpty ? 'Required' : null,
              textCapitalization: TextCapitalization.characters,
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: TextFormField(
                    controller: _makeCtrl,
                    decoration: const InputDecoration(labelText: 'Make'),
                    textCapitalization: TextCapitalization.words,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: TextFormField(
                    controller: _modelCtrl,
                    decoration: const InputDecoration(labelText: 'Model'),
                    textCapitalization: TextCapitalization.words,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            _Label('Expiry Dates'),
            const SizedBox(height: 8),
            FormDatePicker(
              label: 'Token / Tax Expiry',
              value: _tokenExpiry,
              onChanged: (d) => setState(() => _tokenExpiry = d),
            ),
            const SizedBox(height: 10),
            FormDatePicker(
              label: 'Insurance Expiry',
              value: _insuranceExpiry,
              onChanged: (d) => setState(() => _insuranceExpiry = d),
            ),
            const SizedBox(height: 10),
            FormDatePicker(
              label: 'Fitness Certificate Expiry',
              value: _fitnessExpiry,
              onChanged: (d) => setState(() => _fitnessExpiry = d),
            ),
            const SizedBox(height: 20),
            ReminderDaySelector(
              selected: _reminderDays,
              onChanged: (d) => setState(() => _reminderDays = d),
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _notesCtrl,
              decoration: const InputDecoration(labelText: 'Notes'),
              maxLines: 2,
            ),
            const SizedBox(height: 32),
            _loading
                ? const Center(child: CircularProgressIndicator())
                : ElevatedButton.icon(
                    onPressed: _save,
                    icon: Icon(_editing ? Icons.save : Icons.add),
                    label: Text(_editing ? 'Save Changes' : 'Add Vehicle'),
                    style: ElevatedButton.styleFrom(
                        minimumSize: const Size(double.infinity, 52)),
                  ),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  Widget _Label(String t) => Text(t.toUpperCase(),
      style: const TextStyle(
          color: AppColors.textMuted, fontSize: 11,
          fontWeight: FontWeight.w700, letterSpacing: 1.2));

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _loading = true);
    final vm = context.read<AppViewModel>();
    try {
      if (_editing) {
        await vm.updateVehicle(widget.existing!.copyWith(
          vehicleType: _vehicleType,
          registrationNumber: _regCtrl.text.trim().toUpperCase(),
          make: _makeCtrl.text.trim(),
          model: _modelCtrl.text.trim(),
          tokenExpiry: _tokenExpiry,
          insuranceExpiry: _insuranceExpiry,
          fitnessExpiry: _fitnessExpiry,
          notes: _notesCtrl.text.trim(),
          reminderDays: _reminderDays,
        ));
      } else {
        await vm.addVehicle(
          vehicleType: _vehicleType,
          registrationNumber: _regCtrl.text.trim().toUpperCase(),
          make: _makeCtrl.text.trim(),
          model: _modelCtrl.text.trim(),
          tokenExpiry: _tokenExpiry,
          insuranceExpiry: _insuranceExpiry,
          fitnessExpiry: _fitnessExpiry,
          notes: _notesCtrl.text.trim(),
          reminderDays: _reminderDays,
        );
      }
      if (mounted) Navigator.pop(context);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }
}

// ═════════════════════════════════════════════════════════════════════════════
// PASSPORTS SCREEN
// ═════════════════════════════════════════════════════════════════════════════

class PassportsScreen extends StatelessWidget {
  const PassportsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<AppViewModel>();
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(title: const Text('Passports')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _push(context, const AddEditPassportScreen()),
        backgroundColor: AppColors.accent,
        foregroundColor: Colors.black,
        icon: const Icon(Icons.add),
        label: const Text('Add', style: TextStyle(fontWeight: FontWeight.w700)),
      ).animate().scale(delay: 300.ms, duration: 400.ms, curve: Curves.elasticOut),
      body: vm.passports.isEmpty
          ? EmptyState(
              emoji: '🛂',
              title: 'No passports added',
              message: 'Track passport and visa expiry dates.',
              actionLabel: 'Add Passport',
              onAction: () => _push(context, const AddEditPassportScreen()),
            )
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
              itemCount: vm.passports.length,
              itemBuilder: (ctx, i) {
                final p = vm.passports[i];
                final days = p.daysUntilExpiry;
                final urgency = p.expiryDate != null
                    ? AppDateUtils.urgencyFromDays(days)
                    : UrgencyLevel.safe;
                return Animate(
                  effects: [FadeEffect(duration: 250.ms, delay: (i * 50).ms)],
                  child: SwipableCard(
                    id: p.id,
                    onDelete: () => vm.deletePassport(p.id),
                    child: GestureDetector(
                      onTap: () => _push(context, AddEditPassportScreen(existing: p)),
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 10),
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: isDark ? AppColors.darkCard : Colors.white,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: urgency.color.withOpacity(0.15)),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                const Text('🛂', style: TextStyle(fontSize: 24)),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(p.holderName,
                                          style: TextStyle(
                                              color: isDark ? AppColors.textPrimary : AppColors.lightText,
                                              fontWeight: FontWeight.w600, fontSize: 15)),
                                      Text('${p.country} · ${p.passportNumber}',
                                          style: const TextStyle(
                                              color: AppColors.textMuted, fontSize: 11)),
                                    ],
                                  ),
                                ),
                                if (p.expiryDate != null) UrgencyBadge(daysUntil: days),
                              ],
                            ),
                            if (p.expiryDate != null) ...[
                              const SizedBox(height: 10),
                              _ExpiryRow(label: 'Passport', date: p.expiryDate, isDark: isDark),
                            ],
                            if (p.visaExpiry != null) ...[
                              _ExpiryRow(label: 'Visa (${p.visaCountry})', date: p.visaExpiry, isDark: isDark),
                            ],
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
    );
  }

  void _push(BuildContext ctx, Widget w) =>
      Navigator.push(ctx, MaterialPageRoute(builder: (_) => w));
}

class AddEditPassportScreen extends StatefulWidget {
  final PassportModel? existing;
  const AddEditPassportScreen({super.key, this.existing});

  @override
  State<AddEditPassportScreen> createState() => _AddEditPassportScreenState();
}

class _AddEditPassportScreenState extends State<AddEditPassportScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameCtrl = TextEditingController();
  final _numberCtrl = TextEditingController();
  final _countryCtrl = TextEditingController();
  final _visaCountryCtrl = TextEditingController();
  final _notesCtrl = TextEditingController();

  DateTime? _issueDate;
  DateTime? _expiryDate;
  DateTime? _visaExpiry;
  List<int> _reminderDays = [30, 90, 180];
  bool _loading = false;

  bool get _editing => widget.existing != null;

  @override
  void initState() {
    super.initState();
    if (_editing) {
      final p = widget.existing!;
      _nameCtrl.text = p.holderName;
      _numberCtrl.text = p.passportNumber;
      _countryCtrl.text = p.country;
      _visaCountryCtrl.text = p.visaCountry;
      _notesCtrl.text = p.notes;
      _issueDate = p.issueDate;
      _expiryDate = p.expiryDate;
      _visaExpiry = p.visaExpiry;
      _reminderDays = List.from(p.reminderDays);
    }
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _numberCtrl.dispose();
    _countryCtrl.dispose();
    _visaCountryCtrl.dispose();
    _notesCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_editing ? 'Edit Passport' : 'Add Passport')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            TextFormField(
              controller: _nameCtrl,
              decoration: const InputDecoration(labelText: 'Holder Name *'),
              validator: (v) => v == null || v.trim().isEmpty ? 'Required' : null,
              textCapitalization: TextCapitalization.words,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _numberCtrl,
              decoration: const InputDecoration(labelText: 'Passport Number *'),
              validator: (v) => v == null || v.trim().isEmpty ? 'Required' : null,
              textCapitalization: TextCapitalization.characters,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _countryCtrl,
              decoration: const InputDecoration(labelText: 'Country *'),
              validator: (v) => v == null || v.trim().isEmpty ? 'Required' : null,
              textCapitalization: TextCapitalization.words,
            ),
            const SizedBox(height: 16),
            FormDatePicker(label: 'Issue Date', value: _issueDate,
                lastDate: DateTime.now(), onChanged: (d) => setState(() => _issueDate = d)),
            const SizedBox(height: 10),
            FormDatePicker(label: 'Expiry Date', value: _expiryDate,
                onChanged: (d) => setState(() => _expiryDate = d)),
            const SizedBox(height: 16),
            const Text('VISA (OPTIONAL)', style: TextStyle(color: AppColors.textMuted, fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 1.2)),
            const SizedBox(height: 8),
            TextFormField(
              controller: _visaCountryCtrl,
              decoration: const InputDecoration(labelText: 'Visa Country'),
              textCapitalization: TextCapitalization.words,
            ),
            const SizedBox(height: 10),
            FormDatePicker(label: 'Visa Expiry', value: _visaExpiry,
                onChanged: (d) => setState(() => _visaExpiry = d)),
            const SizedBox(height: 16),
            ReminderDaySelector(selected: _reminderDays, onChanged: (d) => setState(() => _reminderDays = d)),
            const SizedBox(height: 12),
            TextFormField(controller: _notesCtrl, decoration: const InputDecoration(labelText: 'Notes'), maxLines: 2),
            const SizedBox(height: 32),
            _loading ? const Center(child: CircularProgressIndicator())
                : ElevatedButton.icon(
                    onPressed: _save,
                    icon: Icon(_editing ? Icons.save : Icons.add),
                    label: Text(_editing ? 'Save Changes' : 'Add Passport'),
                    style: ElevatedButton.styleFrom(minimumSize: const Size(double.infinity, 52)),
                  ),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _loading = true);
    final vm = context.read<AppViewModel>();
    try {
      if (_editing) {
        await vm.updatePassport(widget.existing!.copyWith(
          holderName: _nameCtrl.text.trim(),
          passportNumber: _numberCtrl.text.trim().toUpperCase(),
          country: _countryCtrl.text.trim(),
          issueDate: _issueDate,
          expiryDate: _expiryDate,
          visaCountry: _visaCountryCtrl.text.trim(),
          visaExpiry: _visaExpiry,
          notes: _notesCtrl.text.trim(),
          reminderDays: _reminderDays,
        ));
      } else {
        await vm.addPassport(
          holderName: _nameCtrl.text.trim(),
          passportNumber: _numberCtrl.text.trim().toUpperCase(),
          country: _countryCtrl.text.trim(),
          issueDate: _issueDate,
          expiryDate: _expiryDate,
          visaCountry: _visaCountryCtrl.text.trim(),
          visaExpiry: _visaExpiry,
          notes: _notesCtrl.text.trim(),
          reminderDays: _reminderDays,
        );
      }
      if (mounted) Navigator.pop(context);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }
}

// ═════════════════════════════════════════════════════════════════════════════
// SIMS SCREEN
// ═════════════════════════════════════════════════════════════════════════════

class SimsScreen extends StatelessWidget {
  const SimsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<AppViewModel>();
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(title: const Text('SIM Cards')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _push(context, const AddEditSimScreen()),
        backgroundColor: AppColors.accent,
        foregroundColor: Colors.black,
        icon: const Icon(Icons.add),
        label: const Text('Add SIM', style: TextStyle(fontWeight: FontWeight.w700)),
      ).animate().scale(delay: 300.ms, duration: 400.ms, curve: Curves.elasticOut),
      body: vm.sims.isEmpty
          ? EmptyState(
              emoji: '📱',
              title: 'No SIM cards added',
              message: 'Track prepaid SIM expiry and recharge reminders.',
              actionLabel: 'Add SIM',
              onAction: () => _push(context, const AddEditSimScreen()),
            )
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
              itemCount: vm.sims.length,
              itemBuilder: (ctx, i) {
                final s = vm.sims[i];
                final days = s.daysUntilExpiry;
                final urgency = s.expiryDate != null
                    ? AppDateUtils.urgencyFromDays(days)
                    : UrgencyLevel.safe;
                return Animate(
                  effects: [FadeEffect(duration: 250.ms, delay: (i * 50).ms)],
                  child: SwipableCard(
                    id: s.id,
                    onDelete: () => vm.deleteSim(s.id),
                    child: GestureDetector(
                      onTap: () => _push(context, AddEditSimScreen(existing: s)),
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 10),
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: isDark ? AppColors.darkCard : Colors.white,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: urgency.color.withOpacity(0.15)),
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 44,
                              height: 44,
                              decoration: BoxDecoration(
                                color: urgency.bgColor,
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: const Center(child: Text('📱', style: TextStyle(fontSize: 22))),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(s.simNumber,
                                      style: TextStyle(
                                          color: isDark ? AppColors.textPrimary : AppColors.lightText,
                                          fontWeight: FontWeight.w600, fontSize: 15)),
                                  Text(s.networkProvider,
                                      style: const TextStyle(color: AppColors.textMuted, fontSize: 11)),
                                  if (s.expiryDate != null)
                                    Text(
                                      'Expires: ${AppDateUtils.format(s.expiryDate!)}',
                                      style: const TextStyle(color: AppColors.textSecondary, fontSize: 12),
                                    ),
                                ],
                              ),
                            ),
                            if (s.expiryDate != null) UrgencyBadge(daysUntil: days),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
    );
  }

  void _push(BuildContext ctx, Widget w) =>
      Navigator.push(ctx, MaterialPageRoute(builder: (_) => w));
}

class AddEditSimScreen extends StatefulWidget {
  final SimModel? existing;
  const AddEditSimScreen({super.key, this.existing});

  @override
  State<AddEditSimScreen> createState() => _AddEditSimScreenState();
}

class _AddEditSimScreenState extends State<AddEditSimScreen> {
  final _formKey = GlobalKey<FormState>();
  final _numberCtrl = TextEditingController();
  final _providerCtrl = TextEditingController();
  final _notesCtrl = TextEditingController();

  DateTime? _lastRecharge;
  DateTime? _expiryDate;
  List<int> _reminderDays = [1, 3, 7];
  bool _loading = false;

  bool get _editing => widget.existing != null;

  @override
  void initState() {
    super.initState();
    if (_editing) {
      final s = widget.existing!;
      _numberCtrl.text = s.simNumber;
      _providerCtrl.text = s.networkProvider;
      _notesCtrl.text = s.notes;
      _lastRecharge = s.lastRechargeDate;
      _expiryDate = s.expiryDate;
      _reminderDays = List.from(s.reminderDays);
    }
  }

  @override
  void dispose() {
    _numberCtrl.dispose();
    _providerCtrl.dispose();
    _notesCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_editing ? 'Edit SIM' : 'Add SIM')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            TextFormField(
              controller: _numberCtrl,
              decoration: const InputDecoration(labelText: 'SIM Number *', hintText: 'e.g. 0300-1234567'),
              validator: (v) => v == null || v.trim().isEmpty ? 'Required' : null,
              keyboardType: TextInputType.phone,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _providerCtrl,
              decoration: const InputDecoration(labelText: 'Network Provider *', hintText: 'e.g. Zong, Jazz, Telenor'),
              validator: (v) => v == null || v.trim().isEmpty ? 'Required' : null,
              textCapitalization: TextCapitalization.words,
            ),
            const SizedBox(height: 16),
            FormDatePicker(label: 'Last Recharge Date', value: _lastRecharge,
                lastDate: DateTime.now(), onChanged: (d) => setState(() => _lastRecharge = d)),
            const SizedBox(height: 10),
            FormDatePicker(label: 'SIM Expiry Date', value: _expiryDate,
                onChanged: (d) => setState(() => _expiryDate = d)),
            const SizedBox(height: 16),
            ReminderDaySelector(selected: _reminderDays, onChanged: (d) => setState(() => _reminderDays = d)),
            const SizedBox(height: 12),
            TextFormField(controller: _notesCtrl, decoration: const InputDecoration(labelText: 'Notes'), maxLines: 2),
            const SizedBox(height: 32),
            _loading ? const Center(child: CircularProgressIndicator())
                : ElevatedButton.icon(
                    onPressed: _save,
                    icon: Icon(_editing ? Icons.save : Icons.add),
                    label: Text(_editing ? 'Save Changes' : 'Add SIM'),
                    style: ElevatedButton.styleFrom(minimumSize: const Size(double.infinity, 52)),
                  ),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _loading = true);
    final vm = context.read<AppViewModel>();
    try {
      if (_editing) {
        await vm.updateSim(widget.existing!.copyWith(
          simNumber: _numberCtrl.text.trim(),
          networkProvider: _providerCtrl.text.trim(),
          lastRechargeDate: _lastRecharge,
          expiryDate: _expiryDate,
          notes: _notesCtrl.text.trim(),
          reminderDays: _reminderDays,
        ));
      } else {
        await vm.addSim(
          simNumber: _numberCtrl.text.trim(),
          networkProvider: _providerCtrl.text.trim(),
          lastRechargeDate: _lastRecharge,
          expiryDate: _expiryDate,
          notes: _notesCtrl.text.trim(),
          reminderDays: _reminderDays,
        );
      }
      if (mounted) Navigator.pop(context);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }
}
