// lib/presentation/screens/documents/documents_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../viewmodels/app_viewmodel.dart';
import '../../widgets/common/common_widgets.dart';
import '../../../data/models/models.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/utils/app_utils.dart';
import '../../../core/constants/app_constants.dart';

class DocumentsScreen extends StatefulWidget {
  const DocumentsScreen({super.key});

  @override
  State<DocumentsScreen> createState() => _DocumentsScreenState();
}

class _DocumentsScreenState extends State<DocumentsScreen> {
  final _searchCtrl = TextEditingController();

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<AppViewModel>();
    final isDark = Theme.of(context).brightness == Brightness.dark;

    final docs = _searchCtrl.text.isEmpty
        ? vm.documents
        : vm.documents
            .where((d) =>
                d.name.toLowerCase().contains(_searchCtrl.text.toLowerCase()) ||
                d.documentNumber.toLowerCase().contains(_searchCtrl.text.toLowerCase()))
            .toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Documents'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(60),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
            child: TextField(
              controller: _searchCtrl,
              onChanged: (_) => setState(() {}),
              decoration: InputDecoration(
                hintText: 'Search documents...',
                prefixIcon: const Icon(Icons.search, size: 20),
                suffixIcon: _searchCtrl.text.isNotEmpty
                    ? GestureDetector(
                        onTap: () {
                          _searchCtrl.clear();
                          setState(() {});
                        },
                        child: const Icon(Icons.close, size: 18),
                      )
                    : null,
                isDense: true,
              ),
            ),
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showAddEdit(context),
        backgroundColor: AppColors.accent,
        foregroundColor: Colors.black,
        icon: const Icon(Icons.add),
        label: const Text('Add Document', style: TextStyle(fontWeight: FontWeight.w700)),
      ).animate().scale(delay: 300.ms, duration: 400.ms, curve: Curves.elasticOut),
      body: docs.isEmpty
          ? EmptyState(
              emoji: '🪪',
              title: 'No documents yet',
              message: 'Add your CNIC, driving license, or any ID to track expiry.',
              actionLabel: 'Add Document',
              onAction: () => _showAddEdit(context),
            )
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
              itemCount: docs.length,
              itemBuilder: (ctx, i) {
                final doc = docs[i];
                return Animate(
                  effects: [
                    FadeEffect(duration: 250.ms, delay: (i * 50).ms),
                    SlideEffect(
                        begin: const Offset(0, 0.05),
                        end: Offset.zero,
                        duration: 250.ms,
                        delay: (i * 50).ms),
                  ],
                  child: SwipableCard(
                    id: doc.id,
                    onDelete: () => vm.deleteDocument(doc.id),
                    child: _DocumentCard(
                      doc: doc,
                      isDark: isDark,
                      onTap: () => _showAddEdit(context, existing: doc),
                    ),
                  ),
                );
              },
            ),
    );
  }

  void _showAddEdit(BuildContext context, {DocumentModel? existing}) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => AddEditDocumentScreen(existing: existing)),
    );
  }
}

class _DocumentCard extends StatelessWidget {
  final DocumentModel doc;
  final bool isDark;
  final VoidCallback onTap;

  const _DocumentCard({required this.doc, required this.isDark, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final days = doc.daysUntilExpiry;
    final urgency = doc.hasExpiry ? AppDateUtils.urgencyFromDays(days) : null;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        decoration: BoxDecoration(
          color: isDark ? AppColors.darkCard : Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: urgency != null
                ? urgency.color.withOpacity(0.2)
                : isDark ? AppColors.darkBorder : AppColors.lightBorder,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: AppColors.accent.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Text('🪪', style: TextStyle(fontSize: 20)),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          doc.name,
                          style: TextStyle(
                            color: isDark ? AppColors.textPrimary : AppColors.lightText,
                            fontWeight: FontWeight.w600,
                            fontSize: 15,
                          ),
                        ),
                        Text(
                          doc.type,
                          style: const TextStyle(
                              color: AppColors.textMuted, fontSize: 11),
                        ),
                      ],
                    ),
                  ),
                  if (doc.hasExpiry) UrgencyBadge(daysUntil: days),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  _InfoChip(
                      icon: Icons.numbers, label: doc.documentNumber),
                  const Spacer(),
                  if (doc.expiryDate != null)
                    _InfoChip(
                      icon: Icons.event,
                      label: AppDateUtils.format(doc.expiryDate!),
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _InfoChip extends StatelessWidget {
  final IconData icon;
  final String label;
  const _InfoChip({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 12, color: AppColors.textMuted),
        const SizedBox(width: 5),
        Text(label,
            style: const TextStyle(color: AppColors.textMuted, fontSize: 12)),
      ],
    );
  }
}

// ─── Add / Edit Document ──────────────────────────────────────────────────────

class AddEditDocumentScreen extends StatefulWidget {
  final DocumentModel? existing;
  const AddEditDocumentScreen({super.key, this.existing});

  @override
  State<AddEditDocumentScreen> createState() => _AddEditDocumentScreenState();
}

class _AddEditDocumentScreenState extends State<AddEditDocumentScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameCtrl = TextEditingController();
  final _numberCtrl = TextEditingController();
  final _notesCtrl = TextEditingController();

  String _type = AppConstants.defaultDocumentTypes.first;
  DateTime? _issueDate;
  DateTime? _expiryDate;
  List<int> _reminderDays = [1, 7, 30];
  bool _loading = false;

  bool get _editing => widget.existing != null;

  @override
  void initState() {
    super.initState();
    if (_editing) {
      final d = widget.existing!;
      _nameCtrl.text = d.name;
      _numberCtrl.text = d.documentNumber;
      _notesCtrl.text = d.notes;
      _type = d.type;
      _issueDate = d.issueDate;
      _expiryDate = d.expiryDate;
      _reminderDays = List.from(d.reminderDays);
    }
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _numberCtrl.dispose();
    _notesCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_editing ? 'Edit Document' : 'Add Document'),
        actions: [
          if (_editing)
            TextButton(
              onPressed: _save,
              child: const Text('Save',
                  style: TextStyle(color: AppColors.accent, fontWeight: FontWeight.w700)),
            ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            _label('Document Type'),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: AppConstants.defaultDocumentTypes.map((t) {
                final sel = t == _type;
                return GestureDetector(
                  onTap: () => setState(() => _type = t),
                  child: AnimatedContainer(
                    duration: 150.ms,
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
                    decoration: BoxDecoration(
                      color: sel ? AppColors.accentSoft : AppColors.darkCardElevated,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                          color: sel ? AppColors.accent : AppColors.darkBorder,
                          width: sel ? 1.5 : 1),
                    ),
                    child: Text(t,
                        style: TextStyle(
                            color: sel ? AppColors.accent : AppColors.textSecondary,
                            fontSize: 13,
                            fontWeight: sel ? FontWeight.w600 : FontWeight.w400)),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 20),
            TextFormField(
              controller: _nameCtrl,
              decoration: const InputDecoration(labelText: 'Document Name *'),
              validator: (v) =>
                  v == null || v.trim().isEmpty ? 'Required' : null,
              textCapitalization: TextCapitalization.words,
            ),
            const SizedBox(height: 14),
            TextFormField(
              controller: _numberCtrl,
              decoration: const InputDecoration(
                  labelText: 'Document Number *',
                  hintText: 'e.g. 12345-6789012-3'),
              validator: (v) =>
                  v == null || v.trim().isEmpty ? 'Required' : null,
            ),
            const SizedBox(height: 14),
            FormDatePicker(
              label: 'Issue Date',
              value: _issueDate,
              lastDate: DateTime.now(),
              onChanged: (d) => setState(() => _issueDate = d),
            ),
            const SizedBox(height: 14),
            FormDatePicker(
              label: 'Expiry Date',
              value: _expiryDate,
              firstDate: DateTime(2000),
              onChanged: (d) => setState(() => _expiryDate = d),
            ),
            const SizedBox(height: 20),
            ReminderDaySelector(
              selected: _reminderDays,
              onChanged: (days) => setState(() => _reminderDays = days),
            ),
            const SizedBox(height: 20),
            TextFormField(
              controller: _notesCtrl,
              decoration: const InputDecoration(
                  labelText: 'Notes', hintText: 'Any additional info...'),
              maxLines: 3,
              textCapitalization: TextCapitalization.sentences,
            ),
            const SizedBox(height: 32),
            _loading
                ? const Center(child: CircularProgressIndicator())
                : ElevatedButton.icon(
                    onPressed: _save,
                    icon: Icon(_editing ? Icons.save : Icons.add),
                    label: Text(_editing ? 'Save Changes' : 'Add Document'),
                    style: ElevatedButton.styleFrom(
                        minimumSize: const Size(double.infinity, 52)),
                  ),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  Widget _label(String text) => Text(
        text.toUpperCase(),
        style: const TextStyle(
          color: AppColors.textMuted,
          fontSize: 11,
          fontWeight: FontWeight.w700,
          letterSpacing: 1.2,
        ),
      );

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _loading = true);
    final vm = context.read<AppViewModel>();

    try {
      if (_editing) {
        await vm.updateDocument(widget.existing!.copyWith(
          name: _nameCtrl.text.trim(),
          type: _type,
          documentNumber: _numberCtrl.text.trim(),
          issueDate: _issueDate,
          expiryDate: _expiryDate,
          notes: _notesCtrl.text.trim(),
          reminderDays: _reminderDays,
        ));
      } else {
        await vm.addDocument(
          name: _nameCtrl.text.trim(),
          type: _type,
          documentNumber: _numberCtrl.text.trim(),
          issueDate: _issueDate,
          expiryDate: _expiryDate,
          notes: _notesCtrl.text.trim(),
          reminderDays: _reminderDays,
        );
      }
      if (mounted) Navigator.pop(context);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }
}
