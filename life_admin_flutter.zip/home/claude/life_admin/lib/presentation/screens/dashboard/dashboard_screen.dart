// lib/presentation/screens/dashboard/dashboard_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../viewmodels/app_viewmodel.dart';
import '../../viewmodels/theme_viewmodel.dart';
import '../documents/documents_screen.dart';
import '../subscriptions/subscriptions_screen.dart';
import '../vehicles/vehicles_screen.dart';
import '../passports/passports_screen.dart';
import '../sims/sims_screen.dart';
import '../../widgets/common/common_widgets.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/utils/app_utils.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _navIndex = 0;

  final List<Widget> _screens = [
    const _HomeTab(),
    const DocumentsScreen(),
    const SubscriptionsScreen(),
    const _MoreTab(),
  ];

  @override
  Widget build(BuildContext context) {
    final isDark = context.watch<ThemeViewModel>().isDark;
    return Scaffold(
      body: IndexedStack(index: _navIndex, children: _screens),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _navIndex,
        onDestinationSelected: (i) => setState(() => _navIndex = i),
        backgroundColor:
            isDark ? AppColors.darkSurface : Colors.white,
        elevation: 0,
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.dashboard_outlined),
            selectedIcon: Icon(Icons.dashboard_rounded),
            label: 'Home',
          ),
          NavigationDestination(
            icon: Icon(Icons.badge_outlined),
            selectedIcon: Icon(Icons.badge_rounded),
            label: 'Documents',
          ),
          NavigationDestination(
            icon: Icon(Icons.subscriptions_outlined),
            selectedIcon: Icon(Icons.subscriptions_rounded),
            label: 'Subscriptions',
          ),
          NavigationDestination(
            icon: Icon(Icons.grid_view_outlined),
            selectedIcon: Icon(Icons.grid_view_rounded),
            label: 'More',
          ),
        ],
      ),
    );
  }
}

// ─── Home Tab ─────────────────────────────────────────────────────────────────

class _HomeTab extends StatelessWidget {
  const _HomeTab();

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<AppViewModel>();
    final themeVm = context.watch<ThemeViewModel>();
    final isDark = themeVm.isDark;

    return CustomScrollView(
      slivers: [
        SliverAppBar(
          floating: true,
          snap: true,
          expandedHeight: 140,
          flexibleSpace: FlexibleSpaceBar(
            collapseMode: CollapseMode.pin,
            background: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: isDark
                      ? [AppColors.darkSurface, AppColors.darkBg]
                      : [Colors.white, AppColors.lightBg],
                ),
              ),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 56, 20, 0),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'LifeAdmin',
                            style: TextStyle(
                              color: AppColors.accent,
                              fontSize: 28,
                              fontWeight: FontWeight.w800,
                              letterSpacing: -1,
                            ),
                          ).animate().fadeIn(duration: 400.ms),
                          Text(
                            'Your private life, organized.',
                            style: TextStyle(
                              color: isDark
                                  ? AppColors.textSecondary
                                  : AppColors.lightTextSecondary,
                              fontSize: 13,
                            ),
                          ).animate().fadeIn(delay: 100.ms, duration: 400.ms),
                        ],
                      ),
                    ),
                    IconButton(
                      icon: Icon(
                        isDark ? Icons.light_mode_outlined : Icons.dark_mode_outlined,
                        color: isDark ? AppColors.textSecondary : AppColors.lightTextSecondary,
                      ),
                      onPressed: () => context.read<ThemeViewModel>().toggle(),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
        SliverPadding(
          padding: const EdgeInsets.all(20),
          sliver: SliverList(
            delegate: SliverChildListDelegate([
              // Alert counters
              _AlertBanner(vm: vm),
              const SizedBox(height: 20),

              // Monthly summary
              _MonthlySummary(vm: vm),
              const SizedBox(height: 24),

              // Category grid
              SectionHeader(title: 'Categories'),
              _CategoryGrid(context: context, vm: vm),
              const SizedBox(height: 24),

              // Expiring soon
              if (vm.expiringThisWeek.isNotEmpty || vm.expiredItems.isNotEmpty) ...[
                SectionHeader(title: 'Needs Attention'),
                ...[...vm.expiredItems, ...vm.expiringThisWeek]
                    .take(5)
                    .toList()
                    .asMap()
                    .entries
                    .map((e) => ExpiryAlertCard(
                          name: e.value.name,
                          type: e.value.type,
                          icon: e.value.icon,
                          daysUntil: e.value.daysUntil,
                          animIndex: e.key,
                        )),
                const SizedBox(height: 8),
              ],

              // Expiring this month
              if (vm.expiringThisMonth.isNotEmpty) ...[
                SectionHeader(title: 'Expiring This Month'),
                ...vm.expiringThisMonth
                    .take(5)
                    .toList()
                    .asMap()
                    .entries
                    .map((e) => ExpiryAlertCard(
                          name: e.value.name,
                          type: e.value.type,
                          icon: e.value.icon,
                          daysUntil: e.value.daysUntil,
                          animIndex: e.key,
                        )),
              ],

              const SizedBox(height: 80),
            ]),
          ),
        ),
      ],
    );
  }
}

class _AlertBanner extends StatelessWidget {
  final AppViewModel vm;
  const _AlertBanner({required this.vm});

  @override
  Widget build(BuildContext context) {
    final expired = vm.expiredItems.length;
    final soon = vm.expiringThisWeek.length;
    if (expired == 0 && soon == 0) return const SizedBox();

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: expired > 0
              ? [AppColors.expiredBg, AppColors.expiringSoonBg]
              : [AppColors.expiringSoonBg, AppColors.accentSoft],
        ),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: expired > 0
              ? AppColors.expired.withOpacity(0.3)
              : AppColors.expiringSoon.withOpacity(0.3),
        ),
      ),
      child: Row(
        children: [
          Text(
            expired > 0 ? '🔴' : '🟡',
            style: const TextStyle(fontSize: 24),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  expired > 0
                      ? '$expired item${expired > 1 ? 's' : ''} expired'
                      : '$soon item${soon > 1 ? 's' : ''} expiring this week',
                  style: TextStyle(
                    color: expired > 0
                        ? AppColors.expired
                        : AppColors.expiringSoon,
                    fontWeight: FontWeight.w700,
                    fontSize: 14,
                  ),
                ),
                Text(
                  'Tap categories below to review',
                  style: const TextStyle(
                      color: AppColors.textSecondary, fontSize: 12),
                ),
              ],
            ),
          ),
        ],
      ),
    ).animate().fadeIn(duration: 400.ms).slideY(begin: -0.1);
  }
}

class _MonthlySummary extends StatelessWidget {
  final AppViewModel vm;
  const _MonthlySummary({required this.vm});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF0F2A24), Color(0xFF0A1F1C)],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.accent.withOpacity(0.2)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'MONTHLY SPEND',
                  style: TextStyle(
                    color: AppColors.textMuted,
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.5,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  AppDateUtils.formatCurrency(vm.monthlySubscriptionTotal),
                  style: const TextStyle(
                    color: AppColors.accent,
                    fontSize: 28,
                    fontWeight: FontWeight.w800,
                    letterSpacing: -1,
                  ),
                ),
                Text(
                  '${vm.subscriptions.where((s) => s.isActive).length} active subscriptions',
                  style: const TextStyle(
                      color: AppColors.textSecondary, fontSize: 12),
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              _MiniStat(label: 'Documents', value: '${vm.documents.length}'),
              const SizedBox(height: 8),
              _MiniStat(label: 'Vehicles', value: '${vm.vehicles.length}'),
              const SizedBox(height: 8),
              _MiniStat(label: 'Passports', value: '${vm.passports.length}'),
            ],
          ),
        ],
      ),
    ).animate().fadeIn(delay: 150.ms, duration: 400.ms);
  }
}

class _MiniStat extends StatelessWidget {
  final String label;
  final String value;
  const _MiniStat({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          value,
          style: const TextStyle(
            color: AppColors.textPrimary,
            fontWeight: FontWeight.w700,
            fontSize: 14,
          ),
        ),
        const SizedBox(width: 6),
        Text(
          label,
          style: const TextStyle(
              color: AppColors.textMuted, fontSize: 11),
        ),
      ],
    );
  }
}

class _CategoryGrid extends StatelessWidget {
  final BuildContext context;
  final AppViewModel vm;
  const _CategoryGrid({required this.context, required this.vm});

  int _alertsFor(List items, int Function(dynamic) daysGetter) {
    return items.where((i) => daysGetter(i) < 30).length;
  }

  @override
  Widget build(BuildContext _) {
    final items = [
      _CatItem(
        '🪪', 'Documents', vm.documents.length,
        _alertsFor(vm.documents, (d) => d.daysUntilExpiry),
        () => _nav(context, const DocumentsScreen()),
      ),
      _CatItem(
        '📺', 'Subscriptions', vm.subscriptions.length,
        _alertsFor(vm.subscriptions, (s) => s.daysUntilRenewal),
        () => _nav(context, const SubscriptionsScreen()),
      ),
      _CatItem(
        '🚗', 'Vehicles', vm.vehicles.length,
        _alertsFor(vm.vehicles, (v) => v.daysUntilNearestExpiry),
        () => _nav(context, const VehiclesScreen()),
      ),
      _CatItem(
        '🛂', 'Passports', vm.passports.length,
        _alertsFor(vm.passports, (p) => p.daysUntilExpiry),
        () => _nav(context, const PassportsScreen()),
      ),
      _CatItem(
        '📱', 'SIM Cards', vm.sims.length,
        _alertsFor(vm.sims, (s) => s.daysUntilExpiry),
        () => _nav(context, const SimsScreen()),
      ),
    ];

    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisSpacing: 12,
      mainAxisSpacing: 12,
      childAspectRatio: 1.3,
      children: items
          .asMap()
          .entries
          .map((e) => CategorySummaryCard(
                emoji: e.value.emoji,
                label: e.value.label,
                count: e.value.count,
                alertCount: e.value.alerts,
                onTap: e.value.onTap,
                animIndex: e.key,
              ))
          .toList(),
    );
  }

  void _nav(BuildContext ctx, Widget screen) {
    Navigator.push(ctx, MaterialPageRoute(builder: (_) => screen));
  }
}

class _CatItem {
  final String emoji;
  final String label;
  final int count;
  final int alerts;
  final VoidCallback onTap;
  const _CatItem(this.emoji, this.label, this.count, this.alerts, this.onTap);
}

// ─── More Tab ─────────────────────────────────────────────────────────────────

class _MoreTab extends StatelessWidget {
  const _MoreTab();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('More')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          _MoreItem(
            icon: '🚗',
            label: 'Vehicles',
            onTap: () => _push(context, const VehiclesScreen()),
          ),
          _MoreItem(
            icon: '🛂',
            label: 'Passports',
            onTap: () => _push(context, const PassportsScreen()),
          ),
          _MoreItem(
            icon: '📱',
            label: 'SIM Cards',
            onTap: () => _push(context, const SimsScreen()),
          ),
          const Divider(height: 32),
          _MoreItem(
            icon: '⚙️',
            label: 'Settings & Backup',
            onTap: () => _push(context, const _SettingsScreen()),
          ),
        ],
      ),
    );
  }

  void _push(BuildContext ctx, Widget w) =>
      Navigator.push(ctx, MaterialPageRoute(builder: (_) => w));
}

class _MoreItem extends StatelessWidget {
  final String icon;
  final String label;
  final VoidCallback onTap;
  const _MoreItem({required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        decoration: BoxDecoration(
          color: isDark ? AppColors.darkCard : Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
              color: isDark ? AppColors.darkBorder : AppColors.lightBorder),
        ),
        child: Row(
          children: [
            Text(icon, style: const TextStyle(fontSize: 22)),
            const SizedBox(width: 14),
            Text(
              label,
              style: TextStyle(
                color: isDark ? AppColors.textPrimary : AppColors.lightText,
                fontSize: 15,
                fontWeight: FontWeight.w500,
              ),
            ),
            const Spacer(),
            const Icon(Icons.chevron_right, color: AppColors.textMuted, size: 18),
          ],
        ),
      ),
    );
  }
}

// Inline settings screen
class _SettingsScreen extends StatelessWidget {
  const _SettingsScreen();

  @override
  Widget build(BuildContext context) {
    final vm = context.read<AppViewModel>();
    final themeVm = context.watch<ThemeViewModel>();
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          ListTile(
            leading: Icon(themeVm.isDark ? Icons.light_mode : Icons.dark_mode),
            title: const Text('Toggle Theme'),
            trailing: Switch(
              value: themeVm.isDark,
              onChanged: (_) => themeVm.toggle(),
              activeColor: AppColors.accent,
            ),
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.upload_outlined),
            title: const Text('Export Backup'),
            onTap: () async {
              final path = await vm.exportData();
              if (path != null && context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Saved to: $path')));
              }
            },
          ),
          ListTile(
            leading: const Icon(Icons.download_outlined),
            title: const Text('Import Backup'),
            onTap: () async {
              // FilePicker import flow
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Select a .json backup file')),
              );
            },
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.delete_forever_outlined,
                color: AppColors.expired),
            title: const Text('Clear All Data',
                style: TextStyle(color: AppColors.expired)),
            onTap: () async {
              final confirm = await showDialog<bool>(
                context: context,
                builder: (_) => AlertDialog(
                  title: const Text('Clear All?'),
                  content: const Text('This will delete everything.'),
                  actions: [
                    TextButton(
                        onPressed: () => Navigator.pop(context, false),
                        child: const Text('Cancel')),
                    TextButton(
                        onPressed: () => Navigator.pop(context, true),
                        child: const Text('Delete',
                            style: TextStyle(color: AppColors.expired))),
                  ],
                ),
              );
              if (confirm == true) {
                await vm.clearAll();
              }
            },
          ),
          const SizedBox(height: 40),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.accentSoft,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.accent.withOpacity(0.2)),
            ),
            child: const Column(
              children: [
                Icon(Icons.lock_outline, color: AppColors.accent, size: 28),
                SizedBox(height: 8),
                Text(
                  'Your data stays on this device.',
                  style: TextStyle(
                      color: AppColors.textPrimary, fontWeight: FontWeight.w600),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 4),
                Text(
                  'No internet • No cloud • No tracking',
                  style: TextStyle(color: AppColors.textMuted, fontSize: 12),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
