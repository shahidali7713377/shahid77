// lib/presentation/screens/subscriptions/subscriptions_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../viewmodels/app_viewmodel.dart';
import '../../widgets/common/common_widgets.dart';
import '../../../data/models/models.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/utils/app_utils.dart';
import '../../../core/constants/app_constants.dart';

class SubscriptionsScreen extends StatelessWidget {
  const SubscriptionsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<AppViewModel>();
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final active = vm.subscriptions.where((s) => s.isActive).toList();
    final inactive = vm.subscriptions.where((s) => !s.isActive).toList();

    return Scaffold(
      appBar: AppBar(title: const Text('Subscriptions')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _push(context, const AddEditSubscriptionScreen()),
        backgroundColor: AppColors.accent,
        foregroundColor: Colors.black,
        icon: const Icon(Icons.add),
        label: const Text('Add', style: TextStyle(fontWeight: FontWeight.w700)),
      ).animate().scale(delay: 300.ms, duration: 400.ms, curve: Curves.elasticOut),
      body: vm.subscriptions.isEmpty
          ? EmptyState(
              emoji: '📺',
              title: 'No subscriptions yet',
              message: 'Track Netflix, internet bills, gym memberships and more.',
              actionLabel: 'Add Subscription',
              onAction: () => _push(context, const AddEditSubscriptionScreen()),
            )
          : ListView(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
              children: [
                // Monthly total header
                if (active.isNotEmpty) ...[
                  Container(
                    padding: const EdgeInsets.all(16),
                    margin: const EdgeInsets.only(bottom: 16),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFF0F2A24), Color(0xFF0A1F1C)],
                      ),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                          color: AppColors.accent.withOpacity(0.2)),
                    ),
                    child: Row(
                      children: [
                        const Text('💳', style: TextStyle(fontSize: 24)),
                        const SizedBox(width: 12),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('Monthly Total',
                                style: TextStyle(
                                    color: AppColors.textSecondary,
                                    fontSize: 12)),
                            Text(
                              AppDateUtils.formatCurrency(vm.monthlySubscriptionTotal),
                              style: const TextStyle(
                                color: AppColors.accent,
                                fontSize: 22,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ],
                        ),
                        const Spacer(),
                        Text(
                          '${active.length} active',
                          style: const TextStyle(
                              color: AppColors.textMuted, fontSize: 12),
                        ),
                      ],
                    ),
                  ).animate().fadeIn(duration: 350.ms),
                ],

                ...active.asMap().entries.map((e) => Animate(
                      effects: [
                        FadeEffect(duration: 250.ms, delay: (e.key * 50).ms),
                        SlideEffect(
                            begin: const Offset(0, 0.05),
                            end: Offset.zero,
                            duration: 250.ms,
                            delay: (e.key * 50).ms),
                      ],
                      child: SwipableCard(
                        id: e.value.id,
                        onDelete: () => vm.deleteSubscription(e.value.id),
                        child: _SubCard(
                          sub: e.value,
                          isDark: isDark,
                          onTap: () => _push(
                              context, AddEditSubscriptionScreen(existing: e.value)),
                        ),
                      ),
                    )),

                if (inactive.isNotEmpty) ...[
                  const SizedBox(height: 16),
                  SectionHeader(title: 'Inactive'),
                  ...inactive.map((s) => SwipableCard(
                        id: s.id,
                        onDelete: () => vm.deleteSubscription(s.id),
                        child: Opacity(
                          opacity: 0.5,
                          child: _SubCard(
                            sub: s,
                            isDark: isDark,
                            onTap: () => _push(
                                context, AddEditSubscriptionScreen(existing: s)),
                          ),
                        ),
                      )),
                ],
              ],
            ),
    );
  }

  void _push(BuildContext ctx, Widget w) =>
      Navigator.push(ctx, MaterialPageRoute(builder: (_) => w));
}

class _SubCard extends StatelessWidget {
  final SubscriptionModel sub;
  final bool isDark;
  final VoidCallback onTap;

  const _SubCard({required this.sub, required this.isDark, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final days = sub.daysUntilRenewal;
    final urgency = AppDateUtils.urgencyFromDays(days);

    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: isDark ? AppColors.darkCard : Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
              color: urgency.color.withOpacity(0.15)),
        ),
        child: Column(
          children: [
            Row(
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: urgency.bgColor,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Center(
                    child: Text(sub.icon,
                        style: const TextStyle(fontSize: 22)),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        sub.name,
                        style: TextStyle(
                          color: isDark
                              ? AppColors.textPrimary
                              : AppColors.lightText,
                          fontWeight: FontWeight.w600,
                          fontSize: 15,
                        ),
                      ),
                      Text(
                        '${sub.billingCycle} · ${sub.autoRenew ? "Auto-renew" : "Manual"}',
                        style: const TextStyle(
                            color: AppColors.textMuted, fontSize: 11),
                      ),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      AppDateUtils.formatCurrency(sub.amount,
                          symbol: sub.currency == 'USD' ? '\$' : sub.currency),
                      style: TextStyle(
                        color: isDark
                            ? AppColors.textPrimary
                            : AppColors.lightText,
                        fontWeight: FontWeight.w700,
                        fontSize: 16,
                      ),
                    ),
                    UrgencyBadge(daysUntil: days, compact: true),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: isDark ? AppColors.darkCardElevated : AppColors.lightBg,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                children: [
                  const Icon(Icons.calendar_today_outlined,
                      size: 12, color: AppColors.textMuted),
                  const SizedBox(width: 6),
                  Text(
                    'Renews ${AppDateUtils.format(sub.renewalDate)}',
                    style: const TextStyle(
                        color: AppColors.textSecondary, fontSize: 12),
                  ),
                  const Spacer(),
                  Text(
                    AppDateUtils.urgencyLabel(days),
                    style: TextStyle(
                      color: urgency.color,
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Add / Edit Subscription ──────────────────────────────────────────────────

class AddEditSubscriptionScreen extends StatefulWidget {
  final SubscriptionModel? existing;
  const AddEditSubscriptionScreen({super.key, this.existing});

  @override
  State<AddEditSubscriptionScreen> createState() =>
      _AddEditSubscriptionScreenState();
}

class _AddEditSubscriptionScreenState
    extends State<AddEditSubscriptionScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameCtrl = TextEditingController();
  final _amountCtrl = TextEditingController();
  final _notesCtrl = TextEditingController();

  String _selectedName = AppConstants.defaultSubscriptions.first;
  String _icon = '📋';
  String _cycle = AppConstants.cycleMonthly;
  int _customDays = 30;
  bool _autoRenew = false;
  bool _isActive = true;
  DateTime _renewalDate = DateTime.now().add(const Duration(days: 30));
  List<int> _reminderDays = [1, 3, 7];
  bool _loading = false;

  bool get _editing => widget.existing != null;

  @override
  void initState() {
    super.initState();
    if (_editing) {
      final s = widget.existing!;
      _selectedName = s.name;
      _nameCtrl.text = s.name;
      _amountCtrl.text = s.amount.toStringAsFixed(2);
      _notesCtrl.text = s.notes;
      _icon = s.icon;
      _cycle = s.billingCycle;
      _customDays = s.customDays;
      _autoRenew = s.autoRenew;
      _isActive = s.isActive;
      _renewalDate = s.renewalDate;
      _reminderDays = List.from(s.reminderDays);
    }
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _amountCtrl.dispose();
    _notesCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_editing ? 'Edit Subscription' : 'Add Subscription'),
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            // Quick select
            _Label('Quick Select'),
            const SizedBox(height: 8),
            SizedBox(
              height: 40,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: AppConstants.defaultSubscriptions.map((name) {
                  final sel = name == _selectedName;
                  return GestureDetector(
                    onTap: () {
                      setState(() {
                        _selectedName = name;
                        _nameCtrl.text = name == 'Custom' ? '' : name;
                        _icon = AppConstants.subscriptionIcons[name] ?? '📋';
                      });
                    },
                    child: AnimatedContainer(
                      duration: 150.ms,
                      margin: const EdgeInsets.only(right: 8),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 8),
                      decoration: BoxDecoration(
                        color: sel
                            ? AppColors.accentSoft
                            : AppColors.darkCardElevated,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(
                            color: sel
                                ? AppColors.accent
                                : AppColors.darkBorder,
                            width: sel ? 1.5 : 1),
                      ),
                      child: Text(
                        '${AppConstants.subscriptionIcons[name] ?? '📋'} $name',
                        style: TextStyle(
                          color: sel
                              ? AppColors.accent
                              : AppColors.textSecondary,
                          fontSize: 12,
                          fontWeight: sel ? FontWeight.w600 : FontWeight.w400,
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _nameCtrl,
              decoration: const InputDecoration(labelText: 'Name *'),
              validator: (v) =>
                  v == null || v.trim().isEmpty ? 'Required' : null,
            ),
            const SizedBox(height: 14),
            TextFormField(
              controller: _amountCtrl,
              decoration: const InputDecoration(
                  labelText: 'Amount *', prefixText: '\$ '),
              keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
              validator: (v) {
                if (v == null || v.isEmpty) return 'Required';
                if (double.tryParse(v) == null) return 'Invalid amount';
                return null;
              },
            ),
            const SizedBox(height: 14),
            _Label('Billing Cycle'),
            const SizedBox(height: 8),
            Row(
              children: [AppConstants.cycleWeekly, AppConstants.cycleMonthly, AppConstants.cycleYearly, AppConstants.cycleCustom]
                  .map((c) {
                final sel = c == _cycle;
                return Expanded(
                  child: GestureDetector(
                    onTap: () => setState(() => _cycle = c),
                    child: AnimatedContainer(
                      duration: 150.ms,
                      margin: const EdgeInsets.only(right: 6),
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      decoration: BoxDecoration(
                        color: sel ? AppColors.accentSoft : AppColors.darkCardElevated,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(
                            color: sel ? AppColors.accent : AppColors.darkBorder,
                            width: sel ? 1.5 : 1),
                      ),
                      child: Text(
                        c,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: sel ? AppColors.accent : AppColors.textSecondary,
                          fontSize: 12,
                          fontWeight: sel ? FontWeight.w600 : FontWeight.w400,
                        ),
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 14),
            FormDatePicker(
              label: 'Next Renewal Date',
              value: _renewalDate,
              firstDate: DateTime(2000),
              onChanged: (d) => setState(() => _renewalDate = d),
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                const Expanded(
                  child: Text('Auto-Renew',
                      style: TextStyle(color: AppColors.textSecondary)),
                ),
                Switch(
                  value: _autoRenew,
                  onChanged: (v) => setState(() => _autoRenew = v),
                  activeColor: AppColors.accent,
                ),
              ],
            ),
            Row(
              children: [
                const Expanded(
                  child: Text('Active',
                      style: TextStyle(color: AppColors.textSecondary)),
                ),
                Switch(
                  value: _isActive,
                  onChanged: (v) => setState(() => _isActive = v),
                  activeColor: AppColors.accent,
                ),
              ],
            ),
            const SizedBox(height: 16),
            ReminderDaySelector(
              selected: _reminderDays,
              onChanged: (d) => setState(() => _reminderDays = d),
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _notesCtrl,
              decoration: const InputDecoration(labelText: 'Notes'),
              maxLines: 2,
            ),
            const SizedBox(height: 32),
            _loading
                ? const Center(child: CircularProgressIndicator())
                : ElevatedButton.icon(
                    onPressed: _save,
                    icon: Icon(_editing ? Icons.save : Icons.add),
                    label: Text(_editing ? 'Save Changes' : 'Add Subscription'),
                    style: ElevatedButton.styleFrom(
                        minimumSize: const Size(double.infinity, 52)),
                  ),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  Widget _Label(String t) => Padding(
        padding: const EdgeInsets.only(bottom: 0),
        child: Text(
          t.toUpperCase(),
          style: const TextStyle(
              color: AppColors.textMuted,
              fontSize: 11,
              fontWeight: FontWeight.w700,
              letterSpacing: 1.2),
        ),
      );

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _loading = true);
    final vm = context.read<AppViewModel>();
    try {
      if (_editing) {
        await vm.updateSubscription(widget.existing!.copyWith(
          name: _nameCtrl.text.trim(),
          icon: _icon,
          amount: double.parse(_amountCtrl.text),
          billingCycle: _cycle,
          customDays: _customDays,
          renewalDate: _renewalDate,
          autoRenew: _autoRenew,
          isActive: _isActive,
          notes: _notesCtrl.text.trim(),
          reminderDays: _reminderDays,
        ));
      } else {
        await vm.addSubscription(
          name: _nameCtrl.text.trim(),
          icon: _icon,
          amount: double.parse(_amountCtrl.text),
          billingCycle: _cycle,
          customDays: _customDays,
          renewalDate: _renewalDate,
          autoRenew: _autoRenew,
          notes: _notesCtrl.text.trim(),
          reminderDays: _reminderDays,
        );
      }
      if (mounted) Navigator.pop(context);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }
}
