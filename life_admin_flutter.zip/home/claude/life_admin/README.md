# LifeAdmin 🔐
**Offline Life Admin Manager – Private Document & Expiry Organizer**

> Your private life, organized. 100% offline. Zero cloud. Zero tracking.

---

## 📱 Features

| Module | What you track |
|--------|---------------|
| 🪪 Documents | CNIC, Driving License, Company ID, custom IDs |
| 📺 Subscriptions | Netflix, bills, insurance, gym, custom |
| 🚗 Vehicles | Token tax, insurance, fitness certificate |
| 🛂 Passports | Expiry + visa tracking per passport |
| 📱 SIM Cards | Prepaid SIM recharge & expiry reminders |

---

## 🏗 Architecture

```
lib/
├── core/
│   ├── constants/         # AppConstants — table names, defaults, thresholds
│   ├── services/          # NotificationService (flutter_local_notifications)
│   ├── theme/             # AppTheme dark/light + AppColors
│   └── utils/             # AppDateUtils, UrgencyLevel enum
├── data/
│   ├── database/          # DatabaseHelper — SQLite via sqflite
│   ├── models/            # DocumentModel, SubscriptionModel, VehicleModel,
│   │                      #   PassportModel, SimModel
│   └── repositories/      # AppRepository — data access layer
└── presentation/
    ├── screens/
    │   ├── dashboard/     # Home tab + More tab + DashboardScreen shell
    │   ├── documents/     # DocumentsScreen + AddEditDocumentScreen
    │   ├── subscriptions/ # SubscriptionsScreen + AddEditSubscriptionScreen
    │   ├── vehicles/      # VehiclesScreen + PassportsScreen + SimsScreen
    │   │                  # (all in one file + re-exported)
    ├── viewmodels/        # AppViewModel (all CRUD) + ThemeViewModel
    └── widgets/common/    # Shared UI components
```

**Pattern**: MVVM — Screens observe `AppViewModel` via `Provider`, `AppViewModel` calls `AppRepository`, which calls `DatabaseHelper`.

---

## 🚀 Setup

### Prerequisites
- Flutter 3.x (stable)
- Android Studio / VS Code
- Android SDK 26+ (Android 8.0)

### Run

```bash
cd life_admin
flutter pub get
flutter run
```

### Release APK

```bash
flutter build apk --release --split-per-abi
# Output: build/app/outputs/flutter-apk/
```

---

## 📦 Dependencies

| Package | Version | Purpose |
|---------|---------|---------|
| `provider` | ^6.1.2 | State management |
| `sqflite` | ^2.3.3 | Local SQLite database |
| `flutter_local_notifications` | ^17.2.2 | Scheduled local notifications |
| `timezone` | ^0.9.4 | Timezone-aware notification scheduling |
| `flutter_animate` | ^4.5.0 | Smooth animations |
| `fl_chart` | ^0.68.0 | Analytics charts (future) |
| `uuid` | ^4.4.0 | Unique IDs |
| `intl` | ^0.19.0 | Date formatting |
| `shared_preferences` | ^2.3.2 | Theme preference |
| `path_provider` | ^2.1.3 | File paths for backup |
| `share_plus` | ^9.0.0 | Export backup file |
| `file_picker` | ^8.0.6 | Import backup |
| `permission_handler` | ^11.3.1 | Notification permission |

---

## 🔔 Notification System

- **Scheduled local notifications** only (no server, no FCM)
- Runs at exact scheduled time using `zonedSchedule`
- Survives device reboot via `RECEIVE_BOOT_COMPLETED`
- Configurable reminder intervals per item: 1, 3, 7, 14, 30, 60, 90, 180 days
- Separate notification IDs per item (no conflicts)

### Default Reminder Windows

| Category | Default reminders |
|----------|------------------|
| Documents | 1, 7, 30 days before |
| Subscriptions | 1, 3, 7 days before |
| Vehicles | 1, 7, 30 days before |
| Passports | 30, 90, 180 days before |
| SIM Cards | 1, 3, 7 days before |

---

## 🎨 Design System

| Token | Value |
|-------|-------|
| Accent | `#00D4AA` Teal |
| Expired | `#FF4757` Red |
| Expiring soon | `#FF8C42` Orange |
| Safe | `#2ECC71` Green |
| Dark background | `#07090F` |
| Dark surface | `#0F1523` |

---

## 🔐 Privacy

- ✅ No internet permission in `AndroidManifest.xml`
- ✅ No Firebase, no analytics, no crash reporting
- ✅ No login, no account, no email
- ✅ Local SQLite only — data never leaves the device
- ✅ Backup is exported as local JSON file only

---

## 🛠 Extending

### Adding a new tracker category
1. Add model class in `lib/data/models/models.dart`
2. Add table in `DatabaseHelper._create()`
3. Add CRUD methods in `DatabaseHelper` and `AppRepository`
4. Add CRUD + computed getters in `AppViewModel`
5. Create screen in `lib/presentation/screens/your_category/`
6. Add `NavigationDestination` or `_MoreItem` in `DashboardScreen`

### Changing reminder intervals globally
Edit `AppConstants.defaultReminderDays` and re-seed user data.

### Adding currency support
`SubscriptionModel.currency` field is already stored. Extend UI to show formatted amounts per currency in settings.

---

## 📋 Play Store Checklist

- [ ] Replace `@mipmap/ic_launcher` with your actual icon
- [ ] Set `applicationId` in `android/app/build.gradle`
- [ ] Set `minSdkVersion 26` in `build.gradle`
- [ ] Create keystore and sign release APK
- [ ] Fill Play Store listing (privacy policy required — state "no data collected")
- [ ] Test on Android 8, 10, 12, 14
